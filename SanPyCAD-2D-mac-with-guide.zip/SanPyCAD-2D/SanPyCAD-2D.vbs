' SanPyCAD-2D.vbs -- double-click launcher for Windows, no command line
' needed.
'
' This is the Windows equivalent of SanPyCAD-2D.app on macOS: it finds
' a Python 3 interpreter that actually has the packages this app needs
' (numpy, scipy, sympy, scikit-image), then runs app.py with no
' console window popping up (the app's own window, opened by
' pywebview, still appears normally -- only the Python interpreter's
' own console is hidden). If something goes wrong, it shows a message
' box instead of failing silently, and always logs details to
' SanPyCAD-2D.log next to this file.
'
' Just double-click this file. Don't move it out of the project folder
' (it finds app.py relative to its own location, so the app still
' works if the whole folder is renamed or moved, as long as this file
' stays alongside app.py).

Option Explicit

Dim fso, shell, scriptDir, logPath, appPath
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
logPath = fso.BuildPath(scriptDir, "SanPyCAD-2D.log")
appPath = fso.BuildPath(scriptDir, "app.py")

Sub LogLine(msg)
    Dim f
    Set f = fso.OpenTextFile(logPath, 8, True) ' 8 = ForAppending, True = create if missing
    f.WriteLine Now & "  " & msg
    f.Close
End Sub

Sub Alert(msg)
    MsgBox msg, vbExclamation, "SanPyCAD 2D Sketch"
End Sub

Function QuoteIfPath(cand)
    If InStr(cand, "\") > 0 Then
        QuoteIfPath = """" & cand & """"
    Else
        QuoteIfPath = cand
    End If
End Function

Function QuietLauncher(cand)
    Dim lc, pw
    lc = LCase(Trim(cand))
    If lc = "py -3" Then
        QuietLauncher = "pyw -3"
    ElseIf lc = "py" Then
        QuietLauncher = "pyw"
    ElseIf InStr(cand, "\python.exe") > 0 Then
        pw = Replace(cand, "\python.exe", "\pythonw.exe")
        If fso.FileExists(pw) Then
            QuietLauncher = pw
        Else
            QuietLauncher = cand
        End If
    Else
        QuietLauncher = cand
    End If
End Function

If Not fso.FileExists(appPath) Then
    Alert "Could not find app.py next to SanPyCAD-2D.vbs." & vbCrLf & _
          "Don't move this file out of the project folder."
    WScript.Quit 1
End If

LogLine "===== launch ====="

Dim candidates, i, cand, cmd, tmpOut, rc, foundExe, found, errText, tf
candidates = Array( _
    "py -3", "py", "python", "python3", _
    shell.ExpandEnvironmentStrings("%LocalAppData%\Programs\Python\Python313\python.exe"), _
    shell.ExpandEnvironmentStrings("%LocalAppData%\Programs\Python\Python312\python.exe"), _
    shell.ExpandEnvironmentStrings("%LocalAppData%\Programs\Python\Python311\python.exe"), _
    shell.ExpandEnvironmentStrings("%LocalAppData%\Programs\Python\Python310\python.exe"), _
    shell.ExpandEnvironmentStrings("%LocalAppData%\Programs\Python\Python39\python.exe"), _
    "C:\Python313\python.exe", "C:\Python312\python.exe", _
    "C:\Python311\python.exe", "C:\Python310\python.exe", "C:\Python39\python.exe", _
    shell.ExpandEnvironmentStrings("%ProgramFiles%\Python313\python.exe"), _
    shell.ExpandEnvironmentStrings("%ProgramFiles%\Python312\python.exe"), _
    shell.ExpandEnvironmentStrings("%ProgramFiles%\Python311\python.exe") _
)

found = False
tmpOut = fso.BuildPath(shell.ExpandEnvironmentStrings("%TEMP%"), "sanpycad2d_check.txt")

For i = 0 To UBound(candidates)
    cand = candidates(i)
    If Len(cand) > 0 Then
        cmd = "cmd /c " & QuoteIfPath(cand) & _
              " -c ""import numpy, scipy, sympy, skimage"" > """ & tmpOut & """ 2>&1"
        rc = shell.Run(cmd, 0, True)
        If rc = 0 Then
            LogLine "OK: " & cand & " has numpy/scipy/sympy/scikit-image"
            foundExe = cand
            found = True
            Exit For
        Else
            errText = ""
            If fso.FileExists(tmpOut) Then
                Set tf = fso.OpenTextFile(tmpOut, 1)
                If Not tf.AtEndOfStream Then errText = tf.ReadLine
                tf.Close
            End If
            LogLine "skip: " & cand & " -- " & errText
        End If
    End If
Next

If fso.FileExists(tmpOut) Then fso.DeleteFile(tmpOut, True)

If Not found Then
    Alert "SanPyCAD 2D Sketch couldn't find a Python 3 with numpy/scipy/sympy/scikit-image " & _
          "installed." & vbCrLf & "See SanPyCAD-2D.log in this folder for what was tried." & _
          vbCrLf & vbCrLf & "Fix: open Command Prompt and run:" & vbCrLf & _
          "    pip install numpy scipy sympy scikit-image pywebview"
    WScript.Quit 42
End If

LogLine "Using: " & foundExe

Dim quietCmd, runCmd
quietCmd = QuietLauncher(foundExe)
LogLine "Launching with: " & quietCmd

runCmd = "cmd /c cd /d " & QuoteIfPath(scriptDir) & " && " & _
          QuoteIfPath(quietCmd) & " app.py >> " & QuoteIfPath(logPath) & " 2>&1"

rc = shell.Run(runCmd, 0, True)
If rc <> 0 Then
    Alert "SanPyCAD 2D Sketch stopped unexpectedly (exit code " & rc & ")." & vbCrLf & _
          "See SanPyCAD-2D.log in this folder for details."
End If
