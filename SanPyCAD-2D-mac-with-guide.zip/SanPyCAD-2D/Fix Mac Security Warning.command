#!/bin/bash
# Run this ONCE, right after downloading/unzipping SanPyCAD-2D, before
# you ever double-click SanPyCAD-2D.app -- just double-click this file
# itself (Finder may still warn about an unidentified developer the
# first time; that's expected, and it's fine to allow).
#
# Why this is needed: macOS tags every file extracted from a downloaded
# zip with a "quarantine" flag. If an app still has that flag the very
# first time it's launched, Gatekeeper runs it from an isolated,
# read-only, randomly-named copy instead of its real location ("App
# Translocation"). SanPyCAD-2D.app finds app.py by looking right next
# to itself on disk, so a translocated copy can't see any of it and
# fails with a "could not find app.py" error, even though nothing was
# actually moved.
#
# This script just removes that quarantine flag from the whole
# SanPyCAD-2D folder, so macOS never translocates it in the first
# place. It doesn't touch anything else, doesn't need admin/sudo, and
# only needs to be run once per download.
DIR="$(cd "$(dirname "$0")" && pwd)"
xattr -cr "$DIR" 2>/dev/null
/usr/bin/osascript -e 'display alert "SanPyCAD 2D Sketch" message "Done -- the download quarantine flag has been cleared. You can now double-click SanPyCAD-2D.app normally, including the very first time."' >/dev/null 2>&1
