@echo off
rem run_sanpycad2d.bat -- alternate Windows launcher for SanPyCAD 2D Sketch.
rem
rem Double-click SanPyCAD-2D.vbs instead for the normal experience (no
rem console window, error alerts instead of a raw traceback). This .bat
rem file is a simpler backup for locked-down machines that block .vbs
rem files, or if you'd rather see console output live.

setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 app.py
  goto :done
)

where python >nul 2>nul
if %errorlevel%==0 (
  python app.py
  goto :done
)

where python3 >nul 2>nul
if %errorlevel%==0 (
  python3 app.py
  goto :done
)

echo Could not find Python 3 on PATH.
echo Install it from https://www.python.org/downloads/
echo (check "Add python.exe to PATH" during setup), then re-run this file.
pause
exit /b 1

:done
if errorlevel 1 (
  echo.
  echo SanPyCAD 2D Sketch exited with an error -- see the messages above.
  echo If a package is missing, try: pip install numpy scipy sympy scikit-image pywebview
  pause
)
