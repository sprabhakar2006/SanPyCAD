#!/bin/bash
# Helper invoked (via the user's login shell) by the SanPyCAD-2D
# launcher. Finds a python3 that actually HAS the packages this app
# needs (numpy, scipy, sympy, scikit-image) and uses it to run app.py.
# See SanPyCAD's own run_sanpycad.sh for the full reasoning -- this is
# the same script, just for this app.
set -u
DIR="$1"
cd "$DIR" || exit 1

REQUIRED='import numpy, scipy, sympy, skimage'

candidates=()
p="$(command -v python3 2>/dev/null || true)"
[ -n "$p" ] && candidates+=("$p")
while IFS= read -r p; do
  [ -n "$p" ] && candidates+=("$p")
done < <(type -ap python3 2>/dev/null)
for p in /opt/homebrew/bin/python3 /usr/local/bin/python3 \
         "$HOME/.pyenv/shims/python3" \
         /Library/Frameworks/Python.framework/Versions/3.13/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/3.12/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/3.11/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/3.10/bin/python3 \
         /usr/bin/python3; do
  candidates+=("$p")
done

HAVE_ARCH=""
command -v arch >/dev/null 2>&1 && HAVE_ARCH=1

found_prefix=()
seen=" "
for p in "${candidates[@]}"; do
  [ -x "$p" ] || continue
  case "$seen" in *" $p "*) continue ;; esac
  seen="$seen$p "

  attempts=("$p")
  if [ -n "$HAVE_ARCH" ]; then
    attempts+=("arch -arm64 $p" "arch -x86_64 $p")
  fi

  ok=""
  for attempt in "${attempts[@]}"; do
    err="$($attempt -c "$REQUIRED" 2>&1 >/dev/null)"
    if [ $? -eq 0 ]; then
      echo "OK: $attempt has numpy/scipy/sympy/scikit-image"
      found_prefix=($attempt)
      ok=1
      break
    else
      firstline="$(echo "$err" | head -n 1)"
      echo "skip: $attempt -- $firstline"
    fi
  done
  [ -n "$ok" ] && break
done

if [ "${#found_prefix[@]}" -eq 0 ]; then
  echo "No python3 with the required packages was found (tried plain and, where available, arch -arm64/-x86_64 forced)."
  echo "Tried: $seen"
  echo "Fix: install the packages this app needs for whichever python3 you want to use, e.g.:"
  echo "    python3 -m pip install --force-reinstall --no-cache-dir numpy scipy sympy scikit-image pywebview"
  exit 42
fi

echo "Using: ${found_prefix[*]}"
exec "${found_prefix[@]}" "$DIR/app.py"
