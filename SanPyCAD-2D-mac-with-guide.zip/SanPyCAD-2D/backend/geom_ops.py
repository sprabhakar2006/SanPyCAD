"""
geom_ops.py -- the "editing" operations for SanPyCAD 2D Sketch: things
you do to a shape that's already been drawn, rather than drawing a new
one (see ocad.py for that half). These are AutoCAD-style commands:
Difference, Offset, Chamfer, Trim, Hatch.

Where ocad.py already has a robust, real function for the job
(Offset, and the existing Fillet), this just calls it -- see server.py.
This module is for the operations ocad.py has no equivalent for:

- difference_raster(): 2D polygon boolean subtract. ocad.py has no
  2D polygon boolean at all (only 3D mesh CSG, which needs either a
  real OpenSCAD install or the mesh-CSG pipeline this app doesn't
  carry), and hand-rolling an exact polygon clipper (Weiler-Atherton or
  similar) is a genuinely hard problem in its own right -- the same
  class of thing this project's own docs elsewhere say is better left
  to a real, tested library. Rather than pull in a new hard dependency
  (shapely) that may not even be installable in every environment this
  app runs in, this rasterizes both shapes to a fine grid, does the
  boolean as plain pixel math (numpy), and re-traces the result's
  contour(s) with scikit-image -- the exact same "approximate raster
  method" tradeoff SanPyCAD's own 3D CSG pipeline already documents
  and ships as a real fallback when OpenSCAD itself isn't installed.
  Good enough for sketching; simplified afterward so it isn't
  thousands of points.

- trim(): removes the piece of one shape's own boundary that lies
  between its two nearest crossings with other shapes, keeping the
  rest -- ordinary segment-segment intersection plus some arc-length
  bookkeeping, not something ocad.py has a ready-made tool for
  either.

- extend_line(): Trim's opposite -- lengthens an open chain's last point
  forward until it reaches the nearest other shape. ocad.py has its
  OWN extend_line() this is loosely modeled on, but that version always
  treats its whole "sec" argument as a single closed loop (via seg()'s
  unconditional wraparound), so it can't be handed this app's flat,
  possibly-open, possibly-multi-entity other_segs the way Trim's own
  other_segs already works -- this is a from-scratch reimplementation of
  the same ray-vs-segment idea over that shared convention instead.

- hatch_lines(): even-odd scanline fill (parallel lines at an angle,
  clipped to one or more shapes' combined boundary -- so a circle
  entity nested inside a profile becomes a hole in the hatch).

- chamfer_corner(): a straight-line corner cut (as opposed to
  fillet3points()'s rounded one) -- simple enough to not need any
  geometry library at all, just two points a fixed distance back along
  each edge from the corner.

- eval_function_curve(): samples a user-TYPED y=f(x) expression (the
  Function curve tool) into a point list. ocad.py has nothing like
  this either (every one of its curve functions takes numeric
  parameters, never a formula), and it's the one place in this whole
  app that has to run text the user wrote themselves rather than a
  fixed set of numeric fields -- see the AST-walking evaluator below for
  why that isn't just Python's own eval().

- extrude_wave_to_path(): ocad.py DOES already have the real
  function this wraps (extrude_wave2path) -- but that function works in
  3D (it orients a wave's excursion to a path's local tangent via a 3D
  rotation) and matches wave points to path points by INDEX, not arc
  length, so calling it directly with this app's raw 2D entities would
  crash or under-cover the path depending on which curve has more
  points. This pads both to 3D, resamples both to the same point count
  first (ocad.equidistant_path/equidistant_pathc), and drops back
  to 2D afterward -- see the function's own docstring for why that
  result is always exactly flat (z=0) for the planar inputs this app
  only ever has.
"""

import ast
import math

import numpy as np
from skimage.draw import polygon as _sk_polygon
from skimage.measure import find_contours, approximate_polygon

import ocad as o4


# ---------------------------------------------------------------------
# Difference (raster-approximated 2D polygon boolean subtract)
# ---------------------------------------------------------------------

def difference_raster(outer_pts, cutter_pts, resolution=600, simplify_px=1.5):
    """
    `outer_pts` minus `cutter_pts` (both closed point-list loops).
    Returns a list of resulting closed loops (usually 1; 2 if the cut
    leaves a separate hole boundary, as for a shape with a hole punched
    all the way through, etc) -- each a plain [[x,y],...] point list,
    already simplified (Douglas-Peucker) to remove raster staircase
    noise. Returns [] if the result is empty (cutter fully covers outer).
    """
    outer = np.asarray(outer_pts, dtype=float)
    cutter = np.asarray(cutter_pts, dtype=float)
    allpts = np.vstack([outer, cutter])
    minx, miny = allpts.min(0)
    maxx, maxy = allpts.max(0)
    span = max(maxx - minx, maxy - miny, 1e-9)
    pad = span * 0.05
    minx -= pad; miny -= pad; maxx += pad; maxy += pad
    w, h = maxx - minx, maxy - miny
    scale = resolution / max(w, h, 1e-9)
    W = max(2, int(w * scale))
    H = max(2, int(h * scale))

    def mask_of(pts):
        r = (pts[:, 1] - miny) * scale
        c = (pts[:, 0] - minx) * scale
        rr, cc = _sk_polygon(r, c, shape=(H + 1, W + 1))
        m = np.zeros((H + 1, W + 1), dtype=bool)
        m[rr, cc] = True
        return m

    m = mask_of(outer) & ~mask_of(cutter)
    if not m.any():
        return []

    contours = find_contours(m.astype(float), level=0.5)
    if not contours:
        return []
    contours.sort(key=len, reverse=True)

    # `cont` (from find_contours) is in (row, col) PIXEL space, so the
    # Douglas-Peucker tolerance passed to approximate_polygon needs to be
    # in pixel space too -- i.e. just simplify_px itself. This used to read
    # `tolerance=tol / scale * scale` where `tol = simplify_px / scale`
    # (a world-space tolerance) -- the `/ scale * scale` was meant to
    # convert it back to pixel space but algebraically cancels out to
    # exactly `tol` again, leaving the tolerance actually used ~`scale`
    # times too small (scale is ~10-20 px/unit for a typical sketch). At
    # that tolerance almost nothing gets simplified: a modest triangle-
    # minus-circle difference came out as an 864-point near-raw raster
    # contour instead of a clean, mostly-circular boundary, which also
    # meant Round Corner's arc detection (localArcRun) couldn't fit a
    # circle to it at all -- confirmed directly against the backend.
    out = []
    for cont in contours:
        simplified = approximate_polygon(cont, tolerance=simplify_px)
        # simplified is in (row, col) pixel space -- convert to world [x,y]
        world = [[col / scale + minx, row / scale + miny] for row, col in simplified]
        # approximate_polygon repeats the first point at the end for closed input; drop that dup
        if len(world) > 1 and world[0] == world[-1]:
            world = world[:-1]
        if len(world) >= 3:
            out.append(world)
    return out


# ---------------------------------------------------------------------
# Chamfer (straight-cut corner, the sibling of fillet3points())
# ---------------------------------------------------------------------

def chamfer_corner(p_prev, p_corner, p_next, dist):
    """
    Replaces the sharp corner at `p_corner` (between `p_prev` and
    `p_next`) with a straight cut: one point `dist` back toward
    p_prev, one point `dist` back toward p_next. Returns the 2
    replacement points (the corner itself is dropped).
    """
    def toward(a, b, d):
        vx, vy = b[0] - a[0], b[1] - a[1]
        L = math.hypot(vx, vy)
        if L < 1e-12:
            raise ValueError("chamfer_corner(): coincident points")
        if d > L - 1e-9:
            raise ValueError(f"chamfer_corner(): distance {d} is too large for this edge (length {L:.4g})")
        return [a[0] + vx / L * d, a[1] + vy / L * d]

    p1 = toward(p_corner, p_prev, dist)
    p2 = toward(p_corner, p_next, dist)
    return [p1, p2]


# ---------------------------------------------------------------------
# Trim
# ---------------------------------------------------------------------

def _seg_intersect(p1, p2, p3, p4):
    x1, y1 = p1; x2, y2 = p2; x3, y3 = p3; x4, y4 = p4
    d = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if abs(d) < 1e-12:
        return None
    t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / d
    u = ((x1 - x3) * (y1 - y2) - (y1 - y3) * (x1 - x2)) / d
    if -1e-9 <= t <= 1 + 1e-9 and -1e-9 <= u <= 1 + 1e-9:
        return [x1 + t * (x2 - x1), y1 + t * (y2 - y1)]
    return None


def _path_segments(points, closed):
    n = len(points)
    rng = n if closed else n - 1
    return [(points[i], points[(i + 1) % n]) for i in range(rng)]


def _arc_length_params(points, closed):
    segs = _path_segments(points, closed)
    cum = [0.0]
    for a, b in segs:
        cum.append(cum[-1] + math.hypot(b[0] - a[0], b[1] - a[1]))
    return cum


def _nearest_param_on_path(points, closed, click):
    segs = _path_segments(points, closed)
    cum = _arc_length_params(points, closed)
    best = None
    for i, (a, b) in enumerate(segs):
        vx, vy = b[0] - a[0], b[1] - a[1]
        L2 = vx * vx + vy * vy
        if L2 < 1e-12:
            continue
        t = ((click[0] - a[0]) * vx + (click[1] - a[1]) * vy) / L2
        t = max(0.0, min(1.0, t))
        fx, fy = a[0] + vx * t, a[1] + vy * t
        d = math.hypot(click[0] - fx, click[1] - fy)
        param = cum[i] + t * math.hypot(vx, vy)
        if best is None or d < best[0]:
            best = (d, param)
    if best is None:
        raise ValueError("trim(): degenerate path (all-coincident points)")
    return best[1]


def _point_near_segment(p, a, b, tol):
    """Foot of perpendicular from p onto segment a-b, if within tol --
    used below to catch tangent touches, which `_seg_intersect` correctly
    does NOT report as crossings (see its caller for why that's a problem
    here). Delegates the actual clamped-projection-within-distance test to
    ocad.npol(), the same "is this point on that line, roughly"
    primitive SanPyCAD's own trim_sec_ip() uses, rather than duplicating
    that math by hand."""
    ax, ay = a; bx, by = b
    try:
        foot = o4.npol([[ax, ay], [bx, by]], p, dist=tol, closed_loop=0)
    except Exception:
        return None
    if foot is None or (hasattr(foot, '__len__') and len(foot) == 0):
        return None
    fx, fy = foot[0], foot[1]
    vx, vy = bx - ax, by - ay
    L2 = vx * vx + vy * vy
    t = 0.0 if L2 < 1e-12 else ((fx - ax) * vx + (fy - ay) * vy) / L2
    return (max(0.0, min(1.0, t)), [fx, fy])


def _intersections_along(points, closed, other_segs, other_endpoints=None):
    segs = _path_segments(points, closed)
    cum = _arc_length_params(points, closed)
    # Each entry is (param, point, kind) -- kind is 'cross' for a genuine
    # transversal crossing, 'touch' for a tangency (see below). trim() gives
    # 'touch' entries priority over 'cross' ones on the same side of the
    # click: a tangent arc built specifically to round off a corner (via
    # the Two-circle tangent arc tool's Internal option, say) is meant to
    # entirely supersede whatever the two ORIGINAL circles used to do right
    # there -- including the sliver of one circle that's technically still
    # crossing the other circle just past the tangent point. Cutting at
    # that further-out crossing instead of the tangent point would leave
    # that sliver in the kept piece, overlapping the new tangent arc instead
    # of meeting it end to end.
    params = []
    for i, (a, b) in enumerate(segs):
        seglen = math.hypot(b[0] - a[0], b[1] - a[1])
        if seglen < 1e-12:
            continue
        for (c, d) in other_segs:
            ip = _seg_intersect(a, b, c, d)
            if ip:
                t = math.hypot(ip[0] - a[0], ip[1] - a[1]) / seglen
                params.append((cum[i] + t * seglen, ip, 'cross'))

    # Endpoint touches (ANY other entity, not just tangent-arc output):
    # when some other shape was itself trimmed against `points` earlier,
    # its resulting edge doesn't cross back out through `points` again --
    # it just STARTS (or ends) exactly on `points`' own boundary and runs
    # away from it. That's a genuine, deliberate cut location (it's
    # LITERALLY the old crossing point, carried over), but ordinary
    # segment intersection above finds nothing there: a segment that only
    # touches the other curve at its own endpoint and immediately moves
    # away is a touch, not a transversal crossing, by definition.
    #
    # Missing this is worse than the "coincidental nearby endpoint"
    # problem the tangentRefs-gated other_endpoints check below guards
    # against (see its own comment): if `points` genuinely crosses some
    # other shape at 2 points and one of those 2 shows up here while the
    # other is missed, trim()'s closed-loop branch collapses the kept arc
    # down to the tiny sliver between the ONE detected point and its
    # nearest neighbor on `points`' own discretization -- which reads as
    # "the whole shape just vanished" (confirmed directly: trimming a
    # circle against an already-trimmed neighbor's edge, whose endpoint
    # sits exactly on the circle, deleted the entire circle with nothing
    # left in its place instead of leaving the correct majority arc).
    #
    # The tolerance can't be a truly tiny/absolute one: `points` (and the
    # other entity) are only ever polygon APPROXIMATIONS of the real curve
    # (a circle is a 60-gon here, say), so a point that's mathematically
    # exactly on the true circle can still sit a small but non-negligible
    # distance -- the discretization's own sagitta -- away from the
    # nearest straight chord standing in for it. That gap scales with how
    # coarsely the shape happened to be discretized, so the tolerance has
    # to scale with it too: a fraction of the smaller of the two local
    # segment lengths involved (this segment's, and the other entity's
    # segment the touching point came from), which is exactly the
    # resolution scale on each side.
    #
    # But that relative scale alone isn't safe for a shape made of a few
    # long STRAIGHT edges (a plain rectangle's sides are as long as the
    # rectangle itself, easily hundreds of units) -- a straight edge has
    # no discretization sagitta at all, so 20% of its length is a wildly
    # oversized tolerance there, and would treat some other entity's
    # endpoint that merely happens to pass within a large radius as a
    # deliberate touch (confirmed directly: a line ending 20 units past a
    # 100-unit rectangle edge -- nowhere near actually touching it -- got
    # counted as touching under a purely length-scaled tolerance). Capping
    # the result keeps it meaningful for genuinely coarse curves while
    # never ballooning past roughly the "practically the same point"
    # scale this sketching app otherwise works at (its own vertex-snap
    # radius is on a similar order). This still stays well short of the
    # tangent case's much more generous tolerance below (a real tangency
    # can legitimately sit further off, and that check is additionally
    # gated on tangentRefs so it can't misfire on an unrelated shape).
    _TOUCH_TOL_CAP = 1.0
    for i, (a, b) in enumerate(segs):
        seglen = math.hypot(b[0] - a[0], b[1] - a[1])
        if seglen < 1e-9:
            continue
        for (c, d) in other_segs:
            other_seglen = math.hypot(d[0] - c[0], d[1] - c[1])
            scale = min(seglen, other_seglen) if other_seglen > 1e-9 else seglen
            tol = min(max(1e-6, scale * 0.2), _TOUCH_TOL_CAP)
            for v in (c, d):
                hit = _point_near_segment(v, a, b, tol)
                if hit is not None:
                    t, _foot = hit
                    params.append((cum[i] + t * seglen, v, 'touch'))

    # Tangent touches: a tangent arc (e.g. from the Two-circle tangent arc
    # tool's Internal option) meets a circle at exactly one point where the
    # two curves run parallel, not crossing through each other -- so the
    # crossing test above correctly finds nothing there. But that touch
    # point is still exactly where SanPyCAD's own scripts cut (via
    # trim_sec_ip) to build a shape like a lens from circle arcs, so treat
    # it as a valid cut point too, even with no transversal crossing.
    #
    # Only `other_endpoints` (the actual START/END tips of other OPEN
    # chains, passed in separately by the frontend) are checked here, NOT
    # every vertex along those chains -- near a genuine tangency the two
    # curves stay close for a whole stretch on either side of the true
    # touch point (that's what tangency means: they diverge quadratically,
    # not linearly, in arc length), so testing every vertex against a
    # tolerance comparable to one segment's length flags a wide smear of
    # near-miss points along that stretch instead of the one real tangent
    # point. A chain's own endpoint, by contrast, is only ever placed
    # exactly at a deliberate construction point like a tangent point, so
    # it's safe to test against a generous tolerance.
    for i, (a, b) in enumerate(segs):
        seglen = math.hypot(b[0] - a[0], b[1] - a[1])
        if seglen < 1e-9:
            continue
        for ep in (other_endpoints or []):
            # `ep` is either a bare [x,y] (older callers) or {"p": [x,y],
            # "n": [x,y]} where "n" is that endpoint's own neighboring
            # point in ITS source chain -- i.e. how finely that specific
            # tangent arc happens to be discretized right there. Basing
            # the tolerance on that (a scale intrinsic to the endpoint
            # being tested) instead of on `seglen` (MY current segment's
            # length, which has nothing to do with how close a genuine
            # tangent point should land) matters because `seglen` can be
            # huge for an ordinary shape -- a rectangle's whole bottom
            # edge is one segment spanning its full width. At 35% of
            # THAT length as the tolerance, a point dozens of units away
            # from the real crossing -- nowhere near this segment at all
            # -- still counted as "touching" it, which is exactly what
            # produced a bogus diagonal cut to the wrong point (confirmed
            # directly: a far, unrelated arc endpoint matched a rectangle
            # edge under the old seglen-scaled tolerance). A local scale
            # of a few discretization steps is still generous enough to
            # bridge the genuine floating-point/chord-approximation gaps
            # this was meant to catch, without accepting matches that are
            # merely "somewhere along a long straight line".
            if isinstance(ep, dict):
                v = ep.get("p")
                nb = ep.get("n")
            else:
                v = ep
                nb = None
            if v is None:
                continue
            local_scale = math.hypot(nb[0] - v[0], nb[1] - v[1]) if nb else seglen
            tol = max(1e-4, min(seglen, local_scale) * 0.5)
            hit = _point_near_segment(v, a, b, tol)
            if hit is not None:
                # Use the OTHER entity's own endpoint `v` as the cut point,
                # not the foot of the perpendicular onto MY (discretized,
                # chord-approximated) segment -- the foot sits slightly off
                # the true tangent point since it's on a straight chord of
                # what's really a curve, so cutting there instead of at `v`
                # would leave a small gap between this trimmed piece's new
                # end and the tangent arc's endpoint instead of the two
                # meeting exactly, breaking a later Join into one contiguous
                # loop.
                t, _foot = hit
                params.append((cum[i] + t * seglen, v, 'touch'))

    # Merging near-duplicate params needs its own discretization-aware
    # tolerance too, for the same reason the new endpoint-touch check
    # above does: an ordinary 'cross' hit and the new endpoint-'touch'
    # hit for that SAME real-world touch point are computed by two
    # different methods (one's the foot of a perpendicular projection,
    # the other's the other entity's own vertex) and land on/near two
    # different chords of this shape's own polygon approximation, so they
    # can differ by up to about the discretization's sagitta -- a razor's
    # edge 1e-6 was fine back when this only ever merged truly-identical
    # floating point results, but now regularly misses genuine duplicates
    # by a hair, leaving two near-adjacent params that pinch the kept arc
    # down to almost nothing between them (the same "whole shape vanishes"
    # failure the touch check above exists to prevent in the first place,
    # just relocated instead of fixed). Scaled off the shape's own
    # smallest segment, same as every other discretization-aware
    # tolerance in this function.
    # Capped the same way, and for the same reason, as the touch-detection
    # tolerance above: `min_seg_len` can be huge for a shape made of a few
    # long straight edges, and this merge step has no business treating
    # two params that are merely within some large fraction of THAT length
    # of each other as "the same spot".
    min_seg_len = min((math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in segs), default=1.0)
    merge_tol_param = min(max(1e-6, min_seg_len * 0.25), 1.0)
    params.sort(key=lambda x: x[0])
    out = []
    for p, ip, kind in params:
        if out and abs(out[-1][0] - p) < merge_tol_param:
            # Same spot found both ways (e.g. a touch that also barely
            # registers as a crossing) -- keep 'touch' if either call said
            # so, since it's the more specific/intentional classification.
            if kind == 'touch':
                out[-1] = (out[-1][0], out[-1][1], 'touch')
            continue
        out.append((p, ip, kind))
    return out


def trim(points, closed, other_segs, click, other_endpoints=None):
    """
    Removes the piece of `points` (open or closed point list) that
    lies between the two crossings with `other_segs` (a flat list of
    (a,b) segment pairs from every OTHER entity) nearest to `click` --
    ordinary AutoCAD TRIM semantics: click the piece you want gone.

    `other_endpoints`: the start/end tips of any OTHER *open* chains
    (e.g. a tangent arc) -- also treated as valid cut points even where
    they only touch `points` tangentially rather than crossing through
    it, so a shape built by trimming circles against tangent arcs comes
    out as one contiguous, gap-free loop. See _intersections_along().

    Returns a list of resulting entities [{"closed": False, "points":
    [...]}, ...] (trimming a closed loop always yields exactly one
    open result; trimming an open polyline can yield 0, 1, or 2
    pieces depending on how many crossings are on each side of the
    click), or None if `points` doesn't cross anything.
    """
    cum = _arc_length_params(points, closed)
    total = cum[-1]
    if total < 1e-9:
        return None
    ips = _intersections_along(points, closed, other_segs, other_endpoints)
    if not ips:
        return None
    click_param = _nearest_param_on_path(points, closed, click)
    params = [p for p, _, _ in ips]
    kinds = {p: k for p, _, k in ips}  # dedup already guarantees unique params
    vparams = cum[:-1] if closed else cum

    def pts_between(lo_param, hi_param):
        span = (hi_param - lo_param) % total
        out = []
        for i, vp in enumerate(vparams):
            rel = (vp - lo_param) % total
            if 1e-9 < rel < span - 1e-9:
                out.append((rel, points[i]))
        out.sort(key=lambda x: x[0])
        return [p for _, p in out]

    # Same discretization-aware scale _intersections_along uses for its own
    # merge step -- reused below so pick_nearest's touch-tie-break only
    # fires for candidates that are genuinely close to each other, not
    # across the whole (possibly shape-spanning) candidate pool. See that
    # tie-break's own comment for why a blanket "any touch beats any
    # crossing" rule (the original form of this) is wrong.
    _tol_segs = _path_segments(points, closed)
    _min_seg_len = min((math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in _tol_segs), default=1.0)
    tie_tol = min(max(1e-6, _min_seg_len * 0.25), 1.0)

    def pick_nearest(candidates, want_max):
        # `candidates` is a subset of the params above, all on the same
        # side of click (or, via the wraparound fallback below, the WHOLE
        # candidate list when that side is empty -- in which case this is
        # picking "the extreme/wrapped boundary", not "the nearest to
        # click", so touch-priority doesn't apply there at all: see the
        # `plain` early-return).
        plain = max(candidates) if want_max else min(candidates)
        # A tangent touch wins over a plain crossing ONLY when it's
        # essentially tied with the plain answer -- e.g. a tangent arc's
        # own touch point and a sliver of stale crossing from the shape it
        # replaced, sitting right on top of each other (see
        # _intersections_along's comment for why the touch should win
        # there). A touch that's genuinely far from `plain` is a
        # DIFFERENT, unrelated boundary elsewhere on the shape, not a more
        # "intentional" version of this one -- letting it win regardless
        # of distance used to collapse the kept arc down to almost
        # nothing between two genuinely distinct cut points (confirmed
        # directly: trimming a circle against an already-trimmed
        # neighbor's single touch point, with a real crossing from a
        # second, unrelated shape on the opposite side, picked the touch
        # for BOTH boundaries of the kept arc instead of one each).
        touches = [p for p in candidates if kinds[p] == 'touch']
        if touches:
            touch_best = max(touches) if want_max else min(touches)
            if abs(touch_best - plain) < tie_tol:
                return touch_best
        return plain

    if closed:
        below = [p for p in params if p <= click_param]
        above = [p for p in params if p >= click_param]
        # If click lands exactly on the path's own param-0 vertex (its
        # first point), `below`/`above` can come out empty on one side
        # even though cut points exist -- wrap around instead of falling
        # back to a plain, priority-blind max/min (that fallback used to
        # skip touch-priority entirely, so a click positioned just so could
        # still snap to a stale crossing instead of the tangent touch).
        lo = pick_nearest(below, True) if below else pick_nearest(params, True) - total
        hi = pick_nearest(above, False) if above else pick_nearest(params, False) + total
        lo_mod, hi_mod = lo % total, hi % total
        lo_pt = next(ip for p, ip, _ in ips if abs(p - lo_mod) < 1e-6)
        hi_pt = next(ip for p, ip, _ in ips if abs(p - hi_mod) < 1e-6)
        # lo_mod and hi_mod land on the SAME point when `points` only has
        # one genuine cut against everything else (a single crossing/touch
        # total, so there's nowhere else to split the loop) -- both the
        # "previous" and "next" cut boundary resolve to that one spot from
        # opposite directions. pts_between's span would then come out to
        # (near) zero, reporting "nothing between them" when the correct
        # answer is the OPPOSITE: everything else on the loop is between
        # them, going all the way around, since a closed loop cut at just
        # one point becomes one open chain containing every other vertex,
        # not an empty sliver. (Confirmed directly: an open line ending
        # inside a rectangle -- one real crossing, full stop -- collapsed
        # the "kept" rectangle down to the same point listed twice instead
        # of the rectangle-minus-nothing-else it should be.)
        if abs((hi_mod - lo_mod) % total) < tie_tol or abs((lo_mod - hi_mod) % total) < tie_tol:
            rest = []
            for i, vp in enumerate(vparams):
                rel = (vp - lo_mod) % total
                if rel > 1e-9:
                    rest.append((rel, points[i]))
            rest.sort(key=lambda x: x[0])
            kept = [lo_pt] + [p for _, p in rest] + [lo_pt]
        else:
            kept = [hi_pt] + pts_between(hi_mod, lo_mod) + [lo_pt]
        return [{"closed": False, "points": kept}] if len(kept) >= 2 else None
    else:
        below = [p for p in params if p <= click_param]
        above = [p for p in params if p >= click_param]
        results = []
        if below:
            lo = pick_nearest(below, True)
            lo_pt = next(ip for p, ip, _ in ips if abs(p - lo) < 1e-6)
            pre = [points[0]] + pts_between(0.0, lo) + [lo_pt]
            if len(pre) >= 2:
                results.append({"closed": False, "points": pre})
        if above:
            hi = pick_nearest(above, False)
            hi_pt = next(ip for p, ip, _ in ips if abs(p - hi) < 1e-6)
            post = [hi_pt] + pts_between(hi, total) + [points[-1]]
            if len(post) >= 2:
                results.append({"closed": False, "points": post})
        return results if results else None


# ---------------------------------------------------------------------
# Extend
# ---------------------------------------------------------------------

def _ray_seg_intersect(p1, p2, c, d):
    """
    Where the RAY starting at p2 and heading away from p1 (i.e. the
    forward extension of the segment p1->p2, not the segment itself) hits
    the bounded segment c-d, or None if it doesn't. Same determinant-based
    line-intersection algebra as _seg_intersect above, just with the
    first segment's parameter `t` unbounded above 1 (t=1 is p2 itself;
    t>1 is genuinely past it, in the extend direction) instead of clamped
    to [0,1] like an ordinary segment-segment test needs -- extending a
    line is exactly "keep going past your own endpoint until you hit
    something", not "cross this other thing somewhere along your current
    length" the way Trim's crossings are.
    """
    x1, y1 = p1; x2, y2 = p2; x3, y3 = c; x4, y4 = d
    den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if abs(den) < 1e-12:
        return None  # parallel (or degenerate) -- never meets, no matter how far extended
    t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / den
    u = ((x1 - x3) * (y1 - y2) - (y1 - y3) * (x1 - x2)) / den
    if t > 1 + 1e-9 and -1e-9 <= u <= 1 + 1e-9:
        return (t, [x1 + t * (x2 - x1), y1 + t * (y2 - y1)])
    return None


def extend_line(points, other_segs):
    """
    AutoCAD-style Extend: lengthens the OPEN chain `points` by moving its
    LAST point forward -- continuing in the same direction as its final
    segment -- until it meets the nearest thing in `other_segs` (a flat
    list of (a,b) segment pairs, exactly Trim's own other_segs convention
    -- gather them from every OTHER visible entity via entitySegments(),
    same as the frontend already does for Trim). To extend the START of a
    chain instead, the caller reverses `points` first and reverses the
    result back -- this function only ever grows the end, matching
    ocad.extend_line()'s own line[-2:] convention (this is a
    from-scratch reimplementation of that function's math, not a call to
    it, specifically so `other_segs` can span MULTIPLE different
    entities, open or closed, the same way Trim's other_segs already
    does -- ocad's own version always treats its whole `sec` arg as
    ONE closed loop via seg()'s unconditional wraparound, which would be
    wrong here both for an open target shape and for gathering segments
    from more than one shape at once).

    Picks whichever valid intersection is CLOSEST to the chain's current
    end (smallest forward distance) if more than one lies ahead of it,
    same "extend to the nearest thing in your path" behavior as the ref
    implementation's nearest-neighbor pick. Returns the new point list,
    or None if nothing lies ahead to extend to.
    """
    if len(points) < 2:
        return None
    p1, p2 = points[-2], points[-1]
    best = None
    for c, d in other_segs:
        hit = _ray_seg_intersect(p1, p2, c, d)
        if hit is not None and (best is None or hit[0] < best[0]):
            best = hit
    if best is None:
        return None
    return points[:-1] + [best[1]]


# ---------------------------------------------------------------------
# Hatch
# ---------------------------------------------------------------------

def _rotate_pt(p, ang_deg, origin=(0.0, 0.0)):
    a = math.radians(ang_deg)
    c, s = math.cos(a), math.sin(a)
    x, y = p[0] - origin[0], p[1] - origin[1]
    return [origin[0] + x * c - y * s, origin[1] + x * s + y * c]


def hatch_lines(entities, angle=45.0, spacing=2.0):
    """
    `entities`: [{"closed": bool, "points": [[x,y],...]}, ...] -- one
    or more shapes, hatched TOGETHER via the even-odd rule (so e.g. a
    circle entity sitting inside a profile entity becomes a hole,
    matching how AutoCAD hatch treats a boundary made of several
    nested loops). Returns a flat list of line segments [[p0,p1], ...]
    -- the hatch pattern, ready to draw/export as-is (each one a
    2-point line, so exporting them is the same "one Python list per
    entity" convention as everything else, just with `type: "hatch"`
    on the entity so a future edition of this tool -- or your own
    script -- knows to treat it as a bundle of lines, not a profile).
    """
    if spacing <= 0:
        raise ValueError("hatch_lines(): spacing must be positive")
    rot_entities = []
    for e in entities:
        rpts = [_rotate_pt(p, -angle) for p in e["points"]]
        rot_entities.append({"closed": e["closed"], "points": rpts})
    all_y = [p[1] for e in rot_entities for p in e["points"]]
    if not all_y:
        return []
    ymin, ymax = min(all_y), max(all_y)

    edges = []
    for e in rot_entities:
        pts = e["points"]
        n = len(pts)
        rng = n if e["closed"] else n - 1
        for i in range(rng):
            edges.append((pts[i], pts[(i + 1) % n]))

    lines = []
    y = ymin + spacing / 2.0
    guard = 0
    while y < ymax and guard < 100000:
        guard += 1
        xs = []
        for (ax, ay), (bx, by) in edges:
            if ay == by:
                continue
            if (ay <= y < by) or (by <= y < ay):
                t = (y - ay) / (by - ay)
                xs.append(ax + t * (bx - ax))
        xs.sort()
        for i in range(0, len(xs) - 1, 2):
            p1 = _rotate_pt([xs[i], y], angle)
            p2 = _rotate_pt([xs[i + 1], y], angle)
            lines.append([p1, p2])
        y += spacing
    return lines


# ---------------------------------------------------------------------
# Function curve (y = f(x), typed by the user)
# ---------------------------------------------------------------------

_CURVE_FUNCS = {
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "asin": math.asin, "acos": math.acos, "atan": math.atan, "atan2": math.atan2,
    "sinh": math.sinh, "cosh": math.cosh, "tanh": math.tanh,
    "sqrt": math.sqrt, "exp": math.exp,
    "log": math.log, "log2": math.log2, "log10": math.log10,
    "abs": abs, "floor": math.floor, "ceil": math.ceil, "pow": math.pow,
    "radians": math.radians, "degrees": math.degrees,
}
_CURVE_CONSTS = {"pi": math.pi, "e": math.e}
_CURVE_BINOPS = (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.Mod, ast.FloorDiv)


def _eval_curve_node(node, x):
    """
    Evaluates one node of the expression's AST for a single x value --
    walked recursively by eval_function_curve() below. Only the node
    types explicitly handled here are ever allowed through; anything
    else (attribute access like `().__class__`, subscripting, name
    lookups outside `x`/pi/e, comprehensions, lambdas, an actual
    statement, ...) falls through to the final `raise` and aborts the
    whole evaluation before any of it runs.
    """
    if isinstance(node, ast.Expression):
        return _eval_curve_node(node.body, x)
    if isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
            return node.value
        raise ValueError(f"Unsupported constant: {node.value!r}")
    if isinstance(node, ast.Name):
        if node.id == "x":
            return x
        if node.id in _CURVE_CONSTS:
            return _CURVE_CONSTS[node.id]
        raise ValueError(f"Unknown name '{node.id}' -- only x, pi, e, and the listed functions are allowed.")
    if isinstance(node, ast.BinOp) and isinstance(node.op, _CURVE_BINOPS):
        left = _eval_curve_node(node.left, x)
        right = _eval_curve_node(node.right, x)
        if isinstance(node.op, ast.Add):
            return left + right
        if isinstance(node.op, ast.Sub):
            return left - right
        if isinstance(node.op, ast.Mult):
            return left * right
        if isinstance(node.op, ast.Div):
            return left / right
        if isinstance(node.op, ast.Pow):
            return left ** right
        if isinstance(node.op, ast.Mod):
            return left % right
        if isinstance(node.op, ast.FloorDiv):
            return left // right
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
        val = _eval_curve_node(node.operand, x)
        return -val if isinstance(node.op, ast.USub) else val
    if isinstance(node, ast.Call):
        if not isinstance(node.func, ast.Name) or node.func.id not in _CURVE_FUNCS:
            allowed = ", ".join(sorted(_CURVE_FUNCS))
            raise ValueError(f"Only these functions are allowed: {allowed}.")
        if node.keywords:
            raise ValueError("Keyword arguments aren't supported in function expressions.")
        args = [_eval_curve_node(a, x) for a in node.args]
        return _CURVE_FUNCS[node.func.id](*args)
    raise ValueError("That expression uses syntax this tool doesn't support "
                      "(only numbers, x, pi, e, + - * / % // **, and the listed functions).")


def eval_function_curve(expr, xmin, xmax, steps):
    """
    Samples the user-typed expression `expr` (a function of `x`) at
    `steps`+1 evenly spaced x values from xmin to xmax, and returns the
    resulting [[x,y], ...] point list -- the Function curve tool's
    backing route.

    Deliberately NOT Python's own eval()/exec(): `expr` is parsed into
    an AST first (ast.parse(expr, mode="eval")) and walked node by node
    by _eval_curve_node above, which only knows how to evaluate a
    numeric literal, the name `x` (bound to the current sample) or
    `pi`/`e`, +-*/%//** and unary +/-, and a call to one of a fixed
    whitelist of math functions -- there is no path from this grammar to
    attribute access, imports, name lookups outside that whitelist, or
    any statement at all, so this can't be turned into arbitrary code
    execution even though it runs text the user typed themselves.
    """
    steps = max(1, int(steps))
    xmin, xmax = float(xmin), float(xmax)
    if xmax <= xmin:
        raise ValueError("x max must be greater than x min.")
    if not expr or not expr.strip():
        raise ValueError("Enter a function of x, e.g. sin(x).")
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as e:
        raise ValueError(f"Couldn't parse that expression: {e.msg}")
    pts = []
    for i in range(steps + 1):
        x = xmin + (xmax - xmin) * i / steps
        try:
            y = _eval_curve_node(tree, x)
        except ZeroDivisionError:
            raise ValueError(f"Division by zero at x={x:.6g} -- that function isn't defined everywhere in this range.")
        except ValueError:
            raise
        except Exception as e:
            raise ValueError(f"Couldn't evaluate that expression at x={x:.6g}: {e}")
        if not isinstance(y, (int, float)) or isinstance(y, bool) or not math.isfinite(y):
            raise ValueError(f"That function isn't defined (or isn't finite) at x={x:.6g}.")
        pts.append([x, float(y)])
    return pts


# ---------------------------------------------------------------------
# Extrude wave to path
# ---------------------------------------------------------------------

def extrude_wave_to_path(wave, wave_closed, path, path_closed, steps=100):
    """
    Wraps a 2D "wave" curve (typically a sine/cosine wave from the
    Function curve tool, but any open or closed curve works) around a 2D
    "path" (any other shape) as a perpendicular ripple, via ocad's
    own extrude_wave2path -- a genuinely 3D function (it re-orients the
    wave's local excursion to match the path's own tangent direction at
    each point using a 3D rotation), but one that comes back out exactly
    flat (z=0 everywhere) whenever both inputs are planar, which they
    always are here since this whole app is 2D. Confirmed directly: a
    real sinewave extruded around a circle, both padded to z=0, returns
    with max |z| == 0.0 across every point.

    extrude_wave2path matches wave points to path points ONE-TO-ONE BY
    INDEX, not by arc length, using the path only for position/tangent
    direction and the wave only for its own perpendicular (y) excursion
    at that same index. Calling it with the two curves' own, independently
    -sampled point arrays would either crash outright (IndexError, the
    moment the wave has more points than the path -- confirmed directly)
    or silently only wrap PART of the path (if the wave has fewer points,
    since the loop only ever runs len(wave) times) -- neither of which a
    user picking two arbitrary existing shapes should have to know or
    work around. Resampling both to the same `steps` equally arc-length-
    spaced points first (ocad.equidistant_path for an open curve,
    equidistant_pathc for a closed one) fixes both problems regardless of
    how the original two curves happened to be drawn.
    """
    steps = max(3, int(steps))
    wave_rs = o4.equidistant_pathc(wave, steps) if wave_closed else o4.equidistant_path(wave, steps - 1)
    path_rs = o4.equidistant_pathc(path, steps) if path_closed else o4.equidistant_path(path, steps - 1)
    wave3d = [[p[0], p[1], 0.0] for p in wave_rs]
    path3d = [[p[0], p[1], 0.0] for p in path_rs]
    result = o4.extrude_wave2path(wave3d, path3d)
    if not result:
        raise ValueError("That combination produced an empty result -- try a different wave or path.")
    for p in result:
        if abs(p[2]) > 1e-6:
            raise ValueError("Unexpected out-of-plane result -- this wave/path combination can't be flattened to 2D.")
    return [[p[0], p[1]] for p in result]
