"""
server.py -- backend for SanPyCAD 2D Sketch.

Small dependency-free HTTP backend (stdlib only -- same philosophy as
SanPyCAD's own server.py: the only hard dependencies are the ones
ocad.py itself already needs, no Flask/FastAPI required).

This app is a freeform 2D sketcher: every geometric primitive the
frontend draws (arcs, circles, rounded corners) is computed HERE, by
calling ocad.py's own real, already-tested 2D functions
(arc_2p/arc_3p/circle/fillet3points/corner_radius) -- the canvas just
sends click coordinates and gets back real point lists to draw and to
export. No geometry math is reimplemented in JavaScript.

Routes:
  GET  /                     -> frontend/index.html
  GET  /<static asset>       -> anything under frontend/ (fallback)
  POST /api/arc2p            -> {p1,p2,r,cw,s,long} -> {points} via
                                 ocad.arc_2p (or arc_long_2p if long=true)
  POST /api/arc3p            -> {p1,p2,p3,s}   -> {points} via ocad.arc_3p
  POST /api/circle           -> {cp,r,s}       -> {points} via ocad.circle
  POST /api/fillet_corner    -> {p_prev,p_corner,p_next,r,s}
                                 -> {points} via ocad.fillet3points
  POST /api/corner_radius    -> {sec: [[x,y,r], ...], s}
                                 -> {points} via ocad.corner_radius
  POST /api/offset_shape     -> {points,closed,r} -> {points} via
                                 ocad.offset()/path_offset()
  POST /api/chamfer_corner   -> {p_prev,p_corner,p_next,d} -> {points}
                                 via geom_ops.chamfer_corner
  POST /api/difference       -> {outer,cutter} -> {loops: [[...],...]}
                                 via geom_ops.difference_raster
  POST /api/trim             -> {points,closed,other_segs,other_endpoints,click}
                                 -> {results: [{closed,points},...]}
                                 via geom_ops.trim -- other_endpoints (the
                                 open-ended tips of any OTHER open chains,
                                 e.g. a tangent arc) also cuts at a tangent
                                 touch, not just a real crossing
  POST /api/extend_line      -> {points,other_segs} -> {points} via
                                 geom_ops.extend_line -- Trim's opposite:
                                 lengthens `points`' LAST point forward
                                 (continuing its final segment's direction)
                                 until it reaches the nearest thing in
                                 other_segs. To extend a chain's START
                                 instead, the frontend sends its points
                                 reversed and reverses the result back.
  POST /api/hatch            -> {entities,angle,spacing}
                                 -> {lines: [[p0,p1],...]} via
                                 geom_ops.hatch_lines
  POST /api/two_circle_tangent       -> {c1,c2,side} -> {points: [p0,p1]}
                                         via ocad.twoCircleTangentPoints
  POST /api/two_circle_cross_tangent -> {c1,c2,cw} -> {points: [p0,p1]}
                                         via ocad.twoCircleCrossTangent
  POST /api/two_circle_tangent_arc   -> {c1,c2,r,side,s} -> {points}
                                         via ocad.two_cir_tarc
  POST /api/two_circle_tangent_arc_internal -> {c1,c2,r,s} -> {points}
                                         via ocad.two_cir_tarc_internal --
                                         the CONCAVE fillet nestled into where
                                         2 intersecting circles/arcs cross,
                                         tangent to c1 at points[0] and to c2
                                         at points[-1]. Used by Round Corner
                                         when a corner's two edges are each
                                         circular arcs, not straight lines.
  POST /api/fillet_line_circle       -> {line,circle,r,option,internal,s}
                                         -> {points} via
                                         ocad.fillet_line_circle (or
                                         .fillet_line_circle_internal if
                                         internal=true) -- a fillet tangent
                                         to a straight LINE on one side and
                                         to a CIRCLE/arc on the other.
                                         'option' (1-4) picks which of the 4
                                         tangent solutions for whichever
                                         function is used; the frontend
                                         tries both functions and all 4
                                         options each (8 candidates total)
                                         and keeps whichever lands closest
                                         to the corner. Used by Round Corner
                                         when a corner's two edges are one
                                         straight and one curved (e.g. a
                                         fillet arc left over from an
                                         earlier Trim, or a circular notch
                                         cut in by Difference).
  POST /api/fillet_intersection_lines -> {l1,l2,r,side,s} -> {points} via
                                         ocad.fillet_intersection_lines
                                         -- a fillet at the corner where two
                                         STRAIGHT lines meet, tangent to l1 at
                                         points[0] and l2 at points[-1]. Unlike
                                         Round Corner, l1/l2 don't need to
                                         actually touch -- the corner used is
                                         where their infinite extensions cross
                                         (ocad.i_p2d), so this also
                                         covers two lines that overshoot or
                                         undershoot each other.
  POST /api/function_curve           -> {expr,xmin,xmax,steps} -> {points}
                                         Plots y=f(x) for a user-typed
                                         expression (sin, cos, sqrt, etc, and
                                         +-*/^) sampled at `steps`+1 evenly
                                         spaced x values from xmin to xmax.
                                         Evaluated with a restricted
                                         expression parser (ast.parse in
                                         'eval' mode, walked and rejected if
                                         it contains anything beyond numbers,
                                         the variable x, arithmetic, and a
                                         fixed whitelist of math functions) --
                                         not Python's own eval() -- since this
                                         is the one route that runs arbitrary
                                         user-typed text.
  POST /api/point_circle_tangent     -> {p,cir} -> {point: [x,y]}
                                         via ocad.p_cir_t
  POST /api/circle_line_tangent      -> {cir,line,side} -> {points: [p0,p1]}
                                         via ocad.cir_line_tangent
  POST /api/convex_hull              -> {points} -> {points}
                                         via ocad.convex_hull
  POST /api/concave_hull             -> {points,n,engaging_angle} -> {points}
                                         via ocad.concave_hull
  POST /api/bezier_curve             -> {points,s} -> {points}
                                         via ocad.bezier
  POST /api/extrude_wave2path -> {wave,wave_closed,path,path_closed,steps}
                                 -> {points, closed} via
                                 geom_ops.extrude_wave_to_path -- wraps the
                                 `wave` curve around the `path` shape as a
                                 perpendicular ripple (ocad's own
                                 extrude_wave2path, a 3D function that
                                 collapses back to flat 2D for the planar
                                 inputs this app always has). `closed`
                                 echoes path_closed -- the result is meant
                                 to loop if the path did.
  POST /api/export           -> {entities: [...], var_name?}
                                 -> {code: "<pasteable python>"}
  POST /api/export_dxf       -> {entities, layers} -> {content: "<dxf text>"}
                                 via cad_io.export_dxf. DWG isn't supported
                                 (proprietary binary format) -- DXF is the
                                 universal interchange every real CAD
                                 program (AutoCAD included) also reads.
  POST /api/import_dxf       -> {content: "<dxf text>"}
                                 -> {entities, layers, skipped} via
                                 cad_io.import_dxf -- same {entities,layers}
                                 shape parseSketchText() produces from a
                                 saved sketch, so the frontend feeds it
                                 straight into its existing mergeEntities().
  POST /api/export_svg       -> {entities, layers} -> {content: "<svg text>"}
                                 via cad_io.export_svg
  POST /api/import_svg       -> {content: "<svg text>"} -> {entities, layers}
                                 via cad_io.import_svg
"""

import json
import math
import os
import sys
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import ocad as o4  # noqa: E402
import geom_ops  # noqa: E402
import cad_io  # noqa: E402

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(os.path.dirname(BASE_DIR), "frontend")

MIME = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json",
}


def _round_pts(pts, ndp=5):
    return [[round(float(p[0]), ndp), round(float(p[1]), ndp)] for p in pts]


def _check_finite(pts, msg):
    """Several of ocad's geometric-constraint functions (a tangent arc
    between two circles, a tangent line from a point INSIDE a circle, ...)
    don't raise when the requested geometry doesn't actually exist for the
    given inputs -- numpy just silently produces nan/inf coordinates. Left
    unchecked those would reach the frontend as points that break the canvas
    render with no useful error. Call this on any such function's result
    before sending it back."""
    for p in pts:
        for x in p:
            if not math.isfinite(x):
                raise ValueError(msg)
    return pts


def _fmt_num(x):
    """Formats a float for pasted Python code -- an integer-valued float
    (e.g. 10.0) prints as `10` instead of `10.0`, matching how someone
    would actually type a profile by hand."""
    r = round(float(x), 5)
    if abs(r - round(r)) < 1e-9:
        return str(int(round(r)))
    return repr(r)


def build_export_code(entities, var_name="sec"):
    """
    entities: a list of {"type": "chain"|"circle"|"hatch"|"dimension",
    "closed": bool, "points"/"lines": [...]} -- one per sketch entity,
    in draw order. A single "chain" (the usual case -- one profile,
    possibly with arcs/fillets already expanded into their real point
    lists) becomes one `sec = [...]` list, ready to paste straight
    into polygon(sec)/prism(sec, path)/cr2dt-derived scripts etc.
    Multiple geometry entities (e.g. an outer profile plus one or more
    circles for holes) become `sec`, `sec2`, `sec3`, ... in order,
    with a comment noting which is which, since ocad.py itself
    doesn't have one single "profile with holes" container type --
    holes are normally cut afterward with a real boolean, or handled
    with two separate profiles.

    "hatch" entities (a bundle of line segments, not a profile) export
    as a list of 2-point segments instead of a point list. "dimension"
    and "text" entities are on-screen annotations only -- not real
    geometry -- so they're skipped entirely rather than exported as
    nonsense points. "point" entities (construction points -- see the
    Construction point tool) are single on-screen reference markers, not
    profile geometry either, so they're skipped the same way rather than
    exporting a meaningless 0-point/1-point block.
    """
    if not entities:
        return "# nothing drawn yet"

    blocks = []
    idx = 0
    for ent in entities:
        kind = ent.get("type", "chain")
        if kind in ("dimension", "text", "point"):
            continue
        idx += 1
        name = var_name if idx == 1 else f"{var_name}{idx}"
        if kind == "hatch":
            segs = ent.get("lines", [])
            lines = [f"# hatch ({len(segs)} lines)"]
            lines.append(f"{name} = [")
            for a, b in segs:
                lines.append(f"    [[{_fmt_num(a[0])}, {_fmt_num(a[1])}], [{_fmt_num(b[0])}, {_fmt_num(b[1])}]],")
            lines.append("]")
            blocks.append("\n".join(lines))
            continue
        pts = ent.get("points", [])
        closed_note = "closed" if ent.get("closed") else "open"
        lines = [f"# {kind} ({closed_note}, {len(pts)} points)"]
        lines.append(f"{name} = [")
        for p in pts:
            lines.append(f"    [{_fmt_num(p[0])}, {_fmt_num(p[1])}],")
        lines.append("]")
        blocks.append("\n".join(lines))

    if not blocks:
        return "# nothing exportable (only dimension annotations present)"
    return "\n\n".join(blocks) + "\n"


class Handler(BaseHTTPRequestHandler):
    server_version = "SanPyCAD2DSketch/1.0"

    def log_message(self, fmt, *args):
        pass

    # -- helpers ----------------------------------------------------------
    def _send_json(self, obj, status=200):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, path):
        if not os.path.isfile(path):
            self._send_json({"error": f"not found: {path}"}, 404)
            return
        ext = os.path.splitext(path)[1]
        ctype = MIME.get(ext, "application/octet-stream")
        with open(path, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _read_json_body(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw or b"{}")

    # -- routes -------------------------------------------------------
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path == "/":
            self._send_file(os.path.join(FRONTEND_DIR, "index.html"))
            return
        # static fallback: anything under frontend/
        rel = path.lstrip("/")
        candidate = os.path.normpath(os.path.join(FRONTEND_DIR, rel))
        if candidate.startswith(FRONTEND_DIR) and os.path.isfile(candidate):
            self._send_file(candidate)
            return
        self._send_json({"error": f"not found: {path}"}, 404)

    def do_POST(self):
        path = self.path.split("?", 1)[0]
        try:
            body = self._read_json_body()
        except Exception:
            self._send_json({"error": "invalid JSON body"}, 400)
            return

        try:
            if path == "/api/arc2p":
                p1, p2 = body["p1"], body["p2"]
                r = float(body["r"])
                cw = int(body.get("cw", 1))
                s = int(body.get("s", 20))
                long_arc = bool(body.get("long", False))
                fn = o4.arc_long_2p if long_arc else o4.arc_2p
                pts = fn(p1, p2, r, cw, s)
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/arc3p":
                p1, p2, p3 = body["p1"], body["p2"], body["p3"]
                s = int(body.get("s", 30))
                pts = o4.arc_3p(p1, p2, p3, s)
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/circle":
                cp = body.get("cp", [0, 0])
                r = float(body["r"])
                s = int(body.get("s", 50))
                pts = o4.circle(r, cp, s)
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/fillet_corner":
                p_prev, p_corner, p_next = body["p_prev"], body["p_corner"], body["p_next"]
                r = float(body["r"])
                s = int(body.get("s", 20))
                pts = o4.fillet3points([p_prev, p_corner, p_next], r, s)
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/corner_radius":
                sec = body["sec"]
                s = int(body.get("s", 20))
                pts = o4.corner_radius(sec, s)
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/offset_shape":
                pts = body["points"]
                closed = bool(body.get("closed", True))
                r = float(body["r"])
                if closed:
                    out = o4.offset(pts, r, type=1)
                else:
                    out = o4.path_offset(pts, r)
                self._send_json({"points": _round_pts(out)})

            elif path == "/api/chamfer_corner":
                p_prev, p_corner, p_next = body["p_prev"], body["p_corner"], body["p_next"]
                d = float(body["d"])
                pts = geom_ops.chamfer_corner(p_prev, p_corner, p_next, d)
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/difference":
                outer = body["outer"]
                cutter = body["cutter"]
                loops = geom_ops.difference_raster(outer, cutter)
                self._send_json({"loops": [_round_pts(loop) for loop in loops]})

            elif path == "/api/trim":
                pts = body["points"]
                closed = bool(body.get("closed", False))
                other_segs_raw = body.get("other_segs", [])
                other_segs = [(seg[0], seg[1]) for seg in other_segs_raw]
                other_endpoints = body.get("other_endpoints", [])
                click = body["click"]
                results = geom_ops.trim(pts, closed, other_segs, click, other_endpoints)
                if results is None:
                    self._send_json({"results": []})
                else:
                    out = [{"closed": r["closed"], "points": _round_pts(r["points"])} for r in results]
                    self._send_json({"results": out})

            elif path == "/api/extend_line":
                pts = body["points"]
                other_segs_raw = body.get("other_segs", [])
                other_segs = [(seg[0], seg[1]) for seg in other_segs_raw]
                extended = geom_ops.extend_line(pts, other_segs)
                if extended is None:
                    raise ValueError("Nothing lies ahead of that end to extend to -- "
                                      "try the other end, or check there's a shape in its path.")
                self._send_json({"points": _round_pts(extended)})

            elif path == "/api/two_circle_tangent":
                c1, c2 = body["c1"], body["c2"]
                side = int(body.get("side", 0))
                pts = o4.twoCircleTangentPoints(c1, c2, side)
                _check_finite(pts, "No tangent line exists between these two circles -- they may overlap.")
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/two_circle_cross_tangent":
                c1, c2 = body["c1"], body["c2"]
                cw = int(body.get("cw", -1))
                pts = o4.twoCircleCrossTangent(c1, c2, cw)
                _check_finite(pts, "No crossing tangent exists between these two circles -- they may overlap.")
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/two_circle_tangent_arc":
                c1, c2 = body["c1"], body["c2"]
                r = float(body["r"])
                side = int(body.get("side", 0))
                s = int(body.get("s", 30))
                pts = o4.two_cir_tarc(c1, c2, r, side, s)
                _check_finite(pts, "No arc of that radius bridges these two circles -- try a larger radius or the other side.")
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/two_circle_tangent_arc_internal":
                c1, c2 = body["c1"], body["c2"]
                r = float(body["r"])
                s = int(body.get("s", 16))
                pts = o4.two_cir_tarc_internal(c1, c2, r, s)
                _check_finite(pts, "That radius doesn't fit in the notch between these two arcs -- try a smaller radius.")
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/fillet_line_circle":
                line, circle = body["line"], body["circle"]
                r = float(body["r"])
                option = int(body.get("option", 1))
                s = int(body.get("s", 16))
                # 'internal' picks fillet_line_circle_internal instead of
                # fillet_line_circle -- the same external-vs-internal split
                # as two_circle_tangent_arc vs two_circle_tangent_arc_internal,
                # just for a line/circle pair instead of two circles. External
                # is the right shape for a fillet that wraps around the
                # OUTSIDE of the circle (e.g. rounding where a line runs into
                # a bump); internal is for one nestled INSIDE the gap where a
                # line meets a circular notch CUT into the material (e.g. a
                # Difference that bit a circular chunk out of a shape) -- the
                # frontend can't always tell which from the geometry alone, so
                # it tries both (4 options each) and keeps whichever lands
                # closest to the actual corner.
                internal = bool(body.get("internal", False))
                fn = o4.fillet_line_circle_internal if internal else o4.fillet_line_circle
                pts = fn(line, circle, r, option, s)
                _check_finite(pts, "That radius doesn't fit between this line and arc -- try a smaller radius or the other side.")
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/fillet_intersection_lines":
                # ocad.fillet_intersection_lines() rounds the corner where
                # two lines meet -- but "meet" means their INFINITE extensions
                # (via i_p2d), not necessarily the drawn segments themselves.
                # That's what makes this a distinct tool from the existing
                # Round Corner: two lines that overshoot/undershoot each other
                # (a common leftover from manual drafting, or two separate
                # entities that were never actually joined at a shared vertex)
                # still have a well defined corner to round here, same as
                # SanPyCAD's own fillet_intersection_lines usage.
                l1, l2 = body["l1"], body["l2"]
                r = float(body["r"])
                side = int(body.get("side", 0))
                s = int(body.get("s", 16))
                pts = o4.fillet_intersection_lines(l1, l2, r, s, side)
                _check_finite(pts, "That radius doesn't fit at this corner -- try a smaller radius or the other side.")
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/function_curve":
                expr = body["expr"]
                xmin = body["xmin"]
                xmax = body["xmax"]
                steps = body.get("steps", 100)
                pts = geom_ops.eval_function_curve(expr, xmin, xmax, steps)
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/extrude_wave2path":
                wave = body["wave"]
                wave_closed = bool(body.get("wave_closed", False))
                path_pts = body["path"]
                path_closed = bool(body.get("path_closed", False))
                steps = int(body.get("steps", 100))
                pts = geom_ops.extrude_wave_to_path(wave, wave_closed, path_pts, path_closed, steps)
                self._send_json({"points": _round_pts(pts), "closed": path_closed})

            elif path == "/api/trim_section":
                sec, p0, p1 = body["sec"], body["p0"], body["p1"]
                dist = float(body.get("dist", 1.0))
                pts = o4.trim_sec_ip(sec, p0, p1, dist)
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/point_circle_tangent":
                p, cir = body["p"], body["cir"]
                tp = o4.p_cir_t(p, cir)
                _check_finite([tp], "That point is inside the circle -- pick a point outside it.")
                self._send_json({"point": _round_pts([tp])[0]})

            elif path == "/api/circle_line_tangent":
                cir, line = body["cir"], body["line"]
                side = int(body.get("side", 0))
                pts = o4.cir_line_tangent(cir, line, side)
                _check_finite(pts, "Couldn't compute a tangent line for that circle/line pair.")
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/convex_hull":
                points = body["points"]
                if len(points) < 3:
                    raise ValueError("Need at least 3 points to compute a hull.")
                pts = o4.convex_hull(points)
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/concave_hull":
                points = body["points"]
                n = int(body.get("n", 3))
                engaging_angle = float(body.get("engaging_angle", 270))
                if len(points) < 6:
                    raise ValueError("Need at least 6 points for a concave hull -- try Convex hull instead for fewer points.")
                try:
                    pts = o4.concave_hull(points, n, engaging_angle)
                except (IndexError, ValueError):
                    raise ValueError("Couldn't trace a concave hull through these points (too few/too clustered) -- try Convex hull instead.")
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/bezier_curve":
                points = body["points"]
                s = int(body.get("s", 30))
                if len(points) < 2:
                    raise ValueError("Need at least 2 control points for a curve.")
                pts = o4.bezier(points, s)
                self._send_json({"points": _round_pts(pts)})

            elif path == "/api/hatch":
                entities = body.get("entities", [])
                angle = float(body.get("angle", 45.0))
                spacing = float(body.get("spacing", 2.0))
                lines = geom_ops.hatch_lines(entities, angle, spacing)
                out = [[_round_pts([p0])[0], _round_pts([p1])[0]] for p0, p1 in lines]
                self._send_json({"lines": out})

            elif path == "/api/export":
                entities = body.get("entities", [])
                var_name = body.get("var_name", "sec")
                code = build_export_code(entities, var_name)
                self._send_json({"code": code})

            elif path == "/api/export_dxf":
                content = cad_io.export_dxf(body.get("entities", []), body.get("layers", []))
                self._send_json({"content": content})

            elif path == "/api/import_dxf":
                result = cad_io.import_dxf(body["content"])
                self._send_json(result)

            elif path == "/api/export_svg":
                content = cad_io.export_svg(body.get("entities", []), body.get("layers", []))
                self._send_json({"content": content})

            elif path == "/api/import_svg":
                result = cad_io.import_svg(body["content"])
                self._send_json(result)

            else:
                self._send_json({"error": f"unknown route: {path}"}, 404)

        except KeyError as e:
            self._send_json({"error": f"missing field: {e}"}, 400)
        except Exception as e:
            traceback.print_exc()
            msg = str(e)
            if "Singular matrix" in msg:
                # Raised by ocad's line-intersection math (i_p2d) when the
                # two edges meeting at a clicked corner are parallel/collinear --
                # there's no unique corner there for a fillet/offset to use.
                # The frontend now filters this out before calling here, but
                # keep a clear message as a fallback in case a point list slips
                # through some other path.
                msg = ("That corner has no real angle -- its two edges are "
                       "parallel or run straight through it (often a leftover "
                       "from Trim), so there's nothing to round/offset there.")
            self._send_json({"error": msg}, 500)


def serve(host="127.0.0.1", port=0):
    httpd = ThreadingHTTPServer((host, port), Handler)
    actual_port = httpd.server_address[1]
    return httpd, actual_port


def print_backend_status():
    print("[SanPyCAD 2D Sketch] backend ready -- geometry computed via "
          "ocad.py (arc_2p/arc_3p/circle/fillet3points/corner_radius)")
