"""
_protected_loader.py -- shared helper used by the tiny stub files
(ocad.py, geom_ops.py, cad_io.py, server.py) that sit in this backend/
folder. This file itself has nothing to hide (it's just import
plumbing), which is exactly why it's the one thing here that's still
plain, readable source.

Why this exists: the 4 modules above contain the actual app logic
(the geometry engine, the AutoCAD-style editing ops, the DXF/SVG
reader/writer, and the HTTP route table), which this app ships as
precompiled bytecode only -- backend/_protected/<tag>/<name>.pyc --
rather than as plain .py source, so a curious end user opening the
folder doesn't find readable Python they can just copy out. Each stub
file below is a few lines that hand off to load_protected() here,
which finds the right .pyc for whatever Python version is actually
running (see the tag scheme below) and executes it in the stub's own
module slot, so callers see no difference at all: `import ocad as o4`
still gives you every function ocad.py always had.

This is bytecode-level protection, not real encryption -- Python still
has to be given something it can execute, and .pyc bytecode can be
decompiled back to close-to-original source with public tools (e.g.
decompyle3, pycdc). It raises the bar from "open it in any text editor"
to "run a decompiler," nothing stronger. If you ever need protection
that resists that too, look at PyArmor (adds real obfuscation, at the
cost of its own runtime dependency) or shipping a compiled standalone
executable via PyInstaller/Nuitka instead of Python source at all.

Version coverage: a .pyc file's bytecode format ("magic number") is
tied to the exact CPython minor version that compiled it, so a build
for 3.10 won't load under 3.11, 3.12, etc. This app supports whichever
versions have a matching folder under backend/_protected/ -- see
`available_tags()` below to check what's actually bundled in a given
copy of this app. Run build_protected_backend.py (in the main project
folder, NOT shipped in the end-user zip) under any additional Python
version you want to add coverage for.
"""
import importlib.util
import marshal
import os
import sys

_PYC_HEADER_SIZE = 16  # PEP 552 (Python 3.7+): 4-byte magic + 4-byte flags + 8 bytes of mtime/hash+size


def version_tag(version_info=None):
    """e.g. sys.version_info(3, 10, ...) -> 'cp310' -- also the folder
    name under backend/_protected/ that a matching .pyc build lives in."""
    vi = version_info or sys.version_info
    return f"cp{vi.major}{vi.minor}"


def available_tags(backend_dir):
    protected_dir = os.path.join(backend_dir, "_protected")
    if not os.path.isdir(protected_dir):
        return []
    return sorted(
        name for name in os.listdir(protected_dir)
        if os.path.isdir(os.path.join(protected_dir, name))
    )


def load_protected(modname, stub_path):
    """
    Loads modname's real implementation from its precompiled .pyc and
    runs it as if it were the code of the stub sitting at `stub_path`
    (i.e. backend/<modname>.py's own location) -- so any __file__-
    relative logic inside the real module (server.py locating
    frontend/index.html, for instance) keeps resolving exactly as it
    would if the real source were sitting right there in backend/.

    `modname` must already be registered in sys.modules (true for any
    module mid-import, which is the only time a stub ever calls this).
    """
    backend_dir = os.path.dirname(os.path.abspath(stub_path))
    tag = version_tag()
    pyc_path = os.path.join(backend_dir, "_protected", tag, modname + ".pyc")

    if not os.path.isfile(pyc_path):
        tags = available_tags(backend_dir)
        raise ImportError(
            f"No precompiled '{modname}' module for Python "
            f"{sys.version_info.major}.{sys.version_info.minor} ({tag}) -- "
            f"looked for {pyc_path}. "
            + (f"This copy of the app only bundles: {', '.join(tags)}. "
               if tags else "This copy of the app has no precompiled bundles at all. ")
            + "Install one of those Python versions (with numpy/scipy/sympy/"
              "scikit-image), or ask the developer to add a build for this one."
        )

    with open(pyc_path, "rb") as f:
        header = f.read(_PYC_HEADER_SIZE)
        if len(header) != _PYC_HEADER_SIZE:
            raise ImportError(f"{pyc_path} is truncated/corrupt (bad .pyc header)")
        code = marshal.loads(f.read())

    module = sys.modules[modname]
    module.__file__ = stub_path
    module.__cached__ = pyc_path
    # A real, if minimal, spec -- some libraries (importlib.reload,
    # certain introspection) get confused by a module with __spec__ left
    # as None after exec.
    module.__spec__ = importlib.util.spec_from_loader(modname, loader=None, origin=stub_path)
    exec(code, module.__dict__)
    return module
