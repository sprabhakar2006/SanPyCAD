"""
ocad.py -- loader stub. The real geometry engine is shipped as
precompiled bytecode only, under backend/_protected/<python-tag>/ocad.pyc
-- see backend/_protected_loader.py for why and how, and
build_protected_backend.py (in the main project folder, not shipped
here) for regenerating it under a Python version not already bundled.

Everything ocad.py has always exposed (arc_2p, offset, fillet3points,
etc.) still works exactly the same via `import ocad as o4` -- this stub
just hands the loading off transparently.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _protected_loader import load_protected  # noqa: E402

load_protected(__name__, os.path.abspath(__file__))
