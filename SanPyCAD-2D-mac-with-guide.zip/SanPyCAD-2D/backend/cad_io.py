"""
cad_io.py -- DXF and SVG import/export for SanPyCAD 2D Sketch.

Stdlib only (same dependency-free philosophy as the rest of this app --
see server.py's own docstring). Two file formats, four functions:

    export_dxf(entities, layers) -> str   (AutoCAD DXF, $ACADVER AC1015 --
                                            "AutoCAD 2000" format; the
                                            oldest version that supports
                                            LWPOLYLINE and 24-bit true
                                            color, and old enough that
                                            every CAD program made in the
                                            last 20+ years reads it fine)
    import_dxf(text) -> {entities, layers}
    export_svg(entities, layers) -> str
    import_svg(text) -> {entities, layers}

`entities`/`layers` on both sides use the exact same plain-JSON shape as
the frontend's own sketch save format (see serializeSketch()/
parseSketchText() in index.html): entities are
{id, type, points/point/lines, closed, layerId, ...} and layers are
{id, name, visible, color}. import_dxf()/import_svg() fabricate their
own sequential layer ids (1, 2, 3, ...) and stamp each entity's layerId
to match, so the result can be handed straight to the frontend's
mergeEntities(entities, layers) -- the same function that already
merges a Combined/Opened sketch file -- with zero extra plumbing.

True DWG (AutoCAD's native binary format) is intentionally NOT
supported: it's a proprietary, undocumented, revision-specific binary
format with no real open-source reader/writer, and the only practical
way to touch it at all is Autodesk's own (proprietary, separately
licensed) ODA File Converter. DXF is the universal, fully-documented
interchange format that every CAD program that reads/writes DWG --
AutoCAD, LibreCAD, FreeCAD, Fusion 360, Inkscape, etc. -- ALSO
reads/writes, so it's the practical substitute.

Known, deliberate scope limits (documented here rather than silently
producing wrong output):
  - DXF/SVG entity-level color overrides aren't preserved on import --
    only LAYER colors are. Real-world drawings overwhelmingly put color
    on the layer (BYLAYER), so entities are exported that way too (no
    per-entity color codes at all -- they inherit their layer's).
  - 'dimension' entities (on-screen annotations whose actual leader/
    extension-line geometry is computed by the frontend at draw time,
    not stored precomputed) are skipped on export, same as the existing
    "Export as Python" feature already does for the same reason.
  - SVG import applies transform="..." (translate/scale/rotate/matrix,
    composed down the group tree) but not every exotic SVG feature --
    gradients, clipping, use/symbol references, CSS stylesheets, nested
    <svg>, and skewX/skewY transforms are not interpreted.
  - Units are taken at face value (1 DXF/SVG unit = 1 world unit). DXF's
    $INSUNITS and SVG's mm/in/pt suffixes on width/height are not
    converted -- if a file was authored in millimeters, its numbers
    import as that many world units.
"""

import math
import re
import xml.etree.ElementTree as ET


# ---------------------------------------------------------------------------
# shared helpers
# ---------------------------------------------------------------------------

def _fmt(n):
    """DXF/SVG-safe number formatting -- plain decimal, no exponent
    notation (some DXF readers choke on '1e-05'), trailing zeros trimmed."""
    if abs(n) < 1e-12:
        n = 0.0
    s = f"{n:.6f}".rstrip("0").rstrip(".")
    return s if s not in ("", "-") else "0"


def _hex_to_rgb(hexcolor):
    h = (hexcolor or "#ffffff").lstrip("#")
    if len(h) != 6:
        return (255, 255, 255)
    try:
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    except ValueError:
        return (255, 255, 255)


def _rgb_to_hex(rgb):
    r, g, b = (max(0, min(255, int(round(c)))) for c in rgb)
    return f"#{r:02x}{g:02x}{b:02x}"


# A small, standard slice of the AutoCAD Color Index (ACI) palette -- just
# enough to give old ACI-only DXF readers a reasonable approximation of a
# layer's real color. Modern readers get the EXACT color instead, via the
# 24-bit true-color group (420) written alongside this on every LAYER
# table entry -- see export_dxf()'s _rgb_to_aci() docstring.
_ACI_RGB = {
    1: (255, 0, 0), 2: (255, 255, 0), 3: (0, 255, 0), 4: (0, 255, 255),
    5: (0, 0, 255), 6: (255, 0, 255), 7: (255, 255, 255), 8: (65, 65, 65),
    9: (128, 128, 128), 30: (255, 127, 0), 200: (128, 0, 255),
}


def _rgb_to_aci(rgb):
    best_code, best_d = 7, float("inf")
    for code, ref in _ACI_RGB.items():
        d = sum((a - b) ** 2 for a, b in zip(rgb, ref))
        if d < best_d:
            best_d, best_code = d, code
    return best_code


def _aci_to_rgb(aci):
    return _ACI_RGB.get(abs(int(aci)), (255, 255, 255))


def _fit_circle(points):
    """
    Algebraic (Kasa) least-squares circle fit through `points`. Returns
    (cx, cy, r, max_relative_residual) so callers can decide whether a
    discretized closed chain/circle entity is "circular enough" to write
    back out as a true DXF CIRCLE / SVG <circle> instead of a many-point
    polygon -- nicer for anyone opening the file in real CAD software,
    and exact only when the points really did come from a circle (this
    app's own /api/circle output, or an untouched imported CIRCLE), so a
    hand-drawn near-circular polygon won't get misrepresented: the
    residual check below rejects anything that isn't a tight fit.
    """
    n = len(points)
    if n < 8:
        return None
    sx = sy = sxx = syy = sxy = sxxx = syyy = sxyy = sxxy = 0.0
    for x, y in points:
        sx += x; sy += y
        sxx += x * x; syy += y * y; sxy += x * y
        sxxx += x * x * x; syyy += y * y * y
        sxyy += x * y * y; sxxy += x * x * y
    A = sxx - sx * sx / n
    B = sxy - sx * sy / n
    C = syy - sy * sy / n
    D = 0.5 * (sxxx + sxyy - (sxx + syy) * sx / n)
    E = 0.5 * (syyy + sxxy - (sxx + syy) * sy / n)
    det = A * C - B * B
    if abs(det) < 1e-9:
        return None
    cx = (D * C - B * E) / det
    cy = (A * E - B * D) / det
    r = math.sqrt(max(0.0, sum((x - cx) ** 2 + (y - cy) ** 2 for x, y in points) / n))
    if r < 1e-9:
        return None
    max_resid = max(abs(math.hypot(x - cx, y - cy) - r) for x, y in points)
    return (cx, cy, r, max_resid / r)


def _entity_points(ent):
    """Best-effort flat point list for an entity, for bbox/geometry export
    purposes -- 'chain'/'circle' -> points, 'hatch' -> its segment
    endpoints, 'point' -> its single point, everything else -> []."""
    t = ent.get("type", "chain")
    if t in ("chain", "circle"):
        return ent.get("points", [])
    if t == "hatch":
        return [p for seg in ent.get("lines", []) for p in seg]
    if t == "point":
        return [ent["point"]] if "point" in ent else []
    if t == "text":
        return [ent["point"]] if "point" in ent else []
    return []


def _bbox(entities):
    xs, ys = [], []
    for e in entities:
        for p in _entity_points(e):
            xs.append(p[0]); ys.append(p[1])
    if not xs:
        return (0.0, 0.0, 10.0, 10.0)
    return (min(xs), min(ys), max(xs), max(ys))


def _layer_lookup(layers):
    by_id = {l["id"]: l for l in (layers or [])}
    return by_id


def _dxf_layer_name(layer):
    if not layer:
        return "0"
    # DXF layer names can't contain these characters; sanitize rather than
    # produce a file some readers will reject outright.
    name = re.sub(r'[<>/\\":;?*|,=`]', "_", str(layer.get("name", "0"))).strip()
    return name or "0"


# ---------------------------------------------------------------------------
# DXF export
# ---------------------------------------------------------------------------

def export_dxf(entities, layers):
    by_id = _layer_lookup(layers)
    # Every layer that's actually referenced, plus a guaranteed fallback
    # "0" layer (DXF's own universal default) in case any entity has no
    # layerId at all.
    used_layer_ids = {e.get("layerId") for e in entities}
    dxf_layers = []  # (name, aci, rgbint)
    seen_names = set()
    for lid in used_layer_ids:
        layer = by_id.get(lid)
        name = _dxf_layer_name(layer)
        if name in seen_names:
            continue
        seen_names.add(name)
        rgb = _hex_to_rgb(layer["color"]) if layer and layer.get("color") else (255, 255, 255)
        dxf_layers.append((name, _rgb_to_aci(rgb), (rgb[0] << 16) | (rgb[1] << 8) | rgb[2]))
    if "0" not in seen_names:
        dxf_layers.append(("0", 7, 0xFFFFFF))

    out = []

    def w(code, val):
        out.append(str(code)); out.append(str(val))

    w(0, "SECTION"); w(2, "HEADER")
    w(9, "$ACADVER"); w(1, "AC1015")
    w(0, "ENDSEC")

    w(0, "SECTION"); w(2, "TABLES")
    w(0, "TABLE"); w(2, "LAYER"); w(70, len(dxf_layers))
    for name, aci, rgbint in dxf_layers:
        w(0, "LAYER"); w(2, name); w(70, 0); w(62, aci); w(6, "CONTINUOUS"); w(420, rgbint)
    w(0, "ENDTAB")
    w(0, "ENDSEC")

    w(0, "SECTION"); w(2, "ENTITIES")

    def layer_name_for(ent):
        return _dxf_layer_name(by_id.get(ent.get("layerId")))

    skipped = {"dimension": 0}
    for ent in entities:
        t = ent.get("type", "chain")
        lname = layer_name_for(ent)

        if t == "dimension":
            skipped["dimension"] += 1
            continue

        if t == "point":
            p = ent.get("point")
            if not p:
                continue
            w(0, "POINT"); w(8, lname); w(10, _fmt(p[0])); w(20, _fmt(p[1]))
            continue

        if t == "text":
            p = ent.get("point")
            if not p:
                continue
            h = ent.get("fontSize", 3) or 3
            angle = ent.get("angle", 0) or 0
            # A text entity's `text` can hold real newlines (the frontend's
            # Text tool supports Alt+Enter/Shift+Enter for a line break --
            # see drawTextEntity() in index.html) but DXF's plain TEXT
            # entity is single-line only, so each line becomes its own
            # TEXT entity, stacked along whatever direction is "down" FOR
            # THIS TEXT's own rotation (not always straight down in world
            # space) -- same rotate-then-step math drawTextEntity() and
            # the PDF export's pdfMultilineTextOps() both use, derived so
            # all three render identically.
            ang_rad = math.radians(angle)
            line_height = h * 1.25
            ddx = math.sin(ang_rad) * line_height
            ddy = -math.cos(ang_rad) * line_height
            for i, line in enumerate(str(ent.get("text", "")).split("\n")):
                w(0, "TEXT"); w(8, lname)
                w(10, _fmt(p[0] + ddx * i)); w(20, _fmt(p[1] + ddy * i)); w(40, _fmt(h))
                w(1, line)
                if angle:
                    w(50, _fmt(angle))  # DXF TEXT rotation: degrees, CCW -- same convention as this app's own ent.angle
            continue

        if t == "hatch":
            for a, b in ent.get("lines", []):
                w(0, "LINE"); w(8, lname)
                w(10, _fmt(a[0])); w(20, _fmt(a[1]))
                w(11, _fmt(b[0])); w(21, _fmt(b[1]))
            continue

        if t in ("chain", "circle"):
            pts = ent.get("points", [])
            if len(pts) < 2:
                continue
            closed = bool(ent.get("closed", t == "circle"))
            fit = _fit_circle(pts) if closed else None
            if fit and fit[3] < 0.01:  # within 1% of a perfect circle -> real CIRCLE
                cx, cy, r, _ = fit
                w(0, "CIRCLE"); w(8, lname)
                w(10, _fmt(cx)); w(20, _fmt(cy)); w(40, _fmt(r))
                continue
            if len(pts) == 2 and not closed:
                w(0, "LINE"); w(8, lname)
                w(10, _fmt(pts[0][0])); w(20, _fmt(pts[0][1]))
                w(11, _fmt(pts[1][0])); w(21, _fmt(pts[1][1]))
                continue
            w(0, "LWPOLYLINE"); w(8, lname)
            w(90, len(pts)); w(70, 1 if closed else 0); w(43, 0)
            for p in pts:
                w(10, _fmt(p[0])); w(20, _fmt(p[1]))
            continue

    w(0, "ENDSEC")
    w(0, "EOF")
    return "\n".join(out) + "\n"


# ---------------------------------------------------------------------------
# DXF import
# ---------------------------------------------------------------------------

def _parse_dxf_pairs(text):
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    pairs = []
    i, n = 0, len(lines)
    while i + 1 < n:
        code_line = lines[i].strip()
        if code_line == "":
            i += 1
            continue
        try:
            code = int(code_line)
        except ValueError:
            i += 1
            continue
        value = lines[i + 1].rstrip("\n").rstrip("\r")
        pairs.append((code, value.strip() if code != 1 else value))
        i += 2
    return pairs


def _bulge_arc_points(p1, p2, bulge, segs=16):
    """DXF's 'bulge' encodes an arc between two polyline vertices as
    bulge = tan(included_angle / 4); sign gives arc direction. Returns
    the intermediate points (NOT including p1/p2 themselves) so callers
    can splice them straight into a point list between the two verts."""
    if abs(bulge) < 1e-9:
        return []
    x1, y1 = p1; x2, y2 = p2
    theta = 4 * math.atan(bulge)
    d = math.hypot(x2 - x1, y2 - y1)
    if d < 1e-12 or abs(math.sin(theta / 2)) < 1e-12:
        return []
    # abs() here -- r is a magnitude regardless of arc direction; the
    # direction (which side of the chord the center falls on) is handled
    # separately below via `sign`, not by letting r itself go negative.
    r = d / (2 * abs(math.sin(theta / 2)))
    mx, my = (x1 + x2) / 2, (y1 + y2) / 2
    # sagitta offset perpendicular to the chord, direction set by bulge sign
    h = r * math.cos(theta / 2)
    ux, uy = (x2 - x1) / d, (y2 - y1) / d
    nx, ny = -uy, ux
    sign = 1 if bulge > 0 else -1
    cx, cy = mx + nx * h * sign, my + ny * h * sign
    a1 = math.atan2(y1 - cy, x1 - cx)
    a2 = a1 + theta
    n_seg = max(2, int(round(segs * abs(theta) / (2 * math.pi))) + 1)
    pts = []
    for k in range(1, n_seg):
        a = a1 + (a2 - a1) * k / n_seg
        pts.append([cx + r * math.cos(a), cy + r * math.sin(a)])
    return pts


def _expand_bulges(verts_bulges, closed):
    """verts_bulges: [(x, y, outgoing_bulge), ...]. Returns a flat point
    list with arcs discretized in."""
    pts = [v[:2] for v in verts_bulges]
    n = len(verts_bulges)
    out = [pts[0]]
    limit = n if closed else n - 1
    for i in range(limit):
        j = (i + 1) % n
        bulge = verts_bulges[i][2]
        if bulge:
            out.extend(_bulge_arc_points(pts[i], pts[j], bulge))
        # Don't re-append pts[0] when a closed loop wraps back around --
        # this app's own convention (see e.g. the Join tool) is that a
        # closed chain's point list does NOT repeat its own start point
        # at the end; the wraparound closing edge is implied by `closed`.
        if j != 0:
            out.append(pts[j])
    return out


def import_dxf(text):
    pairs = _parse_dxf_pairs(text)
    n = len(pairs)

    layers_by_name = {}
    layer_order = []

    def get_layer(name):
        name = name or "0"
        if name not in layers_by_name:
            new_id = len(layer_order) + 1
            layer_order.append(name)
            layers_by_name[name] = {"id": new_id, "name": name, "visible": True, "color": "#8fa0b3"}
        return layers_by_name[name]

    entities_out = []
    skipped_types = {}
    section = None
    i = 0

    def consume_body(i):
        start = i
        while i < n and pairs[i][0] != 0:
            i += 1
        return pairs[start:i], i

    while i < n:
        code, val = pairs[i]
        if code == 0 and val == "SECTION":
            section = pairs[i + 1][1] if i + 1 < n and pairs[i + 1][0] == 2 else None
            i += 2
            continue
        if code == 0 and val == "ENDSEC":
            section = None
            i += 1
            continue

        if section == "TABLES" and code == 0 and val == "LAYER":
            body, i = consume_body(i + 1)
            name, aci, rgbint, off = "0", 7, None, False
            for c, v in body:
                if c == 2:
                    name = v
                elif c == 62:
                    try:
                        aci = int(v); off = aci < 0
                    except ValueError:
                        pass
                elif c == 420:
                    try:
                        rgbint = int(v)
                    except ValueError:
                        pass
            layer = get_layer(name)
            layer["color"] = _rgb_to_hex((rgbint >> 16 & 255, rgbint >> 8 & 255, rgbint & 255)) if rgbint is not None else _rgb_to_hex(_aci_to_rgb(aci))
            layer["visible"] = not off
            continue

        if section == "ENTITIES" and code == 0 and val in (
            "LINE", "LWPOLYLINE", "CIRCLE", "ARC", "POINT", "TEXT", "MTEXT", "POLYLINE",
        ):
            etype = val
            body, i = consume_body(i + 1)
            layer_name = "0"
            for c, v in body:
                if c == 8:
                    layer_name = v
                    break
            layer = get_layer(layer_name)

            if etype == "LINE":
                p1 = p2 = None
                for c, v in body:
                    if c == 10: x1 = float(v)
                    elif c == 20: y1 = float(v)
                    elif c == 11: x2 = float(v)
                    elif c == 21: y2 = float(v)
                try:
                    entities_out.append({"type": "chain", "closed": False,
                                          "points": [[x1, y1], [x2, y2]], "layerId": layer["id"]})
                except NameError:
                    pass

            elif etype == "CIRCLE":
                cx = cy = r = None
                for c, v in body:
                    if c == 10: cx = float(v)
                    elif c == 20: cy = float(v)
                    elif c == 40: r = float(v)
                if cx is not None and r:
                    pts = [[cx + r * math.cos(2 * math.pi * k / 60), cy + r * math.sin(2 * math.pi * k / 60)] for k in range(60)]
                    entities_out.append({"type": "circle", "closed": True, "points": pts, "layerId": layer["id"]})

            elif etype == "ARC":
                cx = cy = r = None; a1 = 0.0; a2 = 360.0
                for c, v in body:
                    if c == 10: cx = float(v)
                    elif c == 20: cy = float(v)
                    elif c == 40: r = float(v)
                    elif c == 50: a1 = float(v)
                    elif c == 51: a2 = float(v)
                if cx is not None and r:
                    span = (a2 - a1) % 360 or 360
                    steps = max(4, int(round(60 * span / 360)))
                    pts = []
                    for k in range(steps + 1):
                        a = math.radians(a1 + span * k / steps)
                        pts.append([cx + r * math.cos(a), cy + r * math.sin(a)])
                    entities_out.append({"type": "chain", "closed": False, "points": pts, "layerId": layer["id"]})

            elif etype == "POINT":
                x = y = None
                for c, v in body:
                    if c == 10: x = float(v)
                    elif c == 20: y = float(v)
                if x is not None:
                    entities_out.append({"type": "point", "point": [x, y], "layerId": layer["id"]})

            elif etype in ("TEXT", "MTEXT"):
                x = y = None; h = 3.0; txt = ""; angle = 0.0
                for c, v in body:
                    if c == 10: x = float(v)
                    elif c == 20: y = float(v)
                    elif c == 40:
                        try: h = float(v)
                        except ValueError: pass
                    elif c == 50:
                        try: angle = float(v)
                        except ValueError: pass
                    elif c in (1, 3):
                        txt += v.replace("\\P", " ").replace("\\p", " ")
                if x is not None:
                    entities_out.append({"type": "text", "point": [x, y], "text": txt, "fontSize": h, "angle": angle, "layerId": layer["id"]})

            elif etype == "LWPOLYLINE":
                closed = False
                verts = []  # (x, y, bulge)
                pending_x = None
                pending_bulge = 0.0
                for c, v in body:
                    if c == 70:
                        try: closed = bool(int(v) & 1)
                        except ValueError: pass
                    elif c == 10:
                        if pending_x is not None:
                            verts.append((pending_x, 0.0, pending_bulge)); pending_bulge = 0.0
                        pending_x = float(v)
                    elif c == 20 and pending_x is not None:
                        verts.append((pending_x, float(v), 0.0))
                        pending_x = None
                    elif c == 42 and verts:
                        x0, y0, _ = verts[-1]
                        verts[-1] = (x0, y0, float(v))
                if verts:
                    pts = _expand_bulges(verts, closed)
                    entities_out.append({"type": "chain", "closed": closed, "points": pts, "layerId": layer["id"]})

            elif etype == "POLYLINE":
                closed = False
                for c, v in body:
                    if c == 70:
                        try: closed = bool(int(v) & 1)
                        except ValueError: pass
                verts = []
                while i < n and pairs[i] == pairs[i]:  # loop over VERTEX/SEQEND
                    if pairs[i][0] == 0 and pairs[i][1] == "VERTEX":
                        vbody, i = consume_body(i + 1)
                        x = y = None; bulge = 0.0
                        for c, v in vbody:
                            if c == 10: x = float(v)
                            elif c == 20: y = float(v)
                            elif c == 42:
                                try: bulge = float(v)
                                except ValueError: pass
                        if x is not None:
                            verts.append((x, y, bulge))
                        continue
                    if pairs[i][0] == 0 and pairs[i][1] == "SEQEND":
                        _, i = consume_body(i + 1)
                        break
                    break
                if verts:
                    pts = _expand_bulges(verts, closed)
                    entities_out.append({"type": "chain", "closed": closed, "points": pts, "layerId": layer["id"]})

            continue

        if code == 0 and section == "ENTITIES":
            skipped_types[val] = skipped_types.get(val, 0) + 1

        i += 1

    layers_out = list(layers_by_name.values()) or [{"id": 1, "name": "0", "visible": True, "color": "#8fa0b3"}]
    return {"entities": entities_out, "layers": layers_out, "skipped": skipped_types}


# ---------------------------------------------------------------------------
# SVG export
# ---------------------------------------------------------------------------

def export_svg(entities, layers):
    by_id = _layer_lookup(layers)
    minx, miny, maxx, maxy = _bbox(entities)
    pad = max(1.0, 0.02 * max(maxx - minx, maxy - miny, 1.0))
    minx -= pad; miny -= pad; maxx += pad; maxy += pad
    w_, h_ = max(1e-6, maxx - minx), max(1e-6, maxy - miny)
    stroke_w = max(0.05, min(w_, h_) / 500.0)

    def fy(y):
        # Bake the Y-flip into the coordinate itself (world is Y-up, SVG is
        # Y-down) so <text> stays right-side up with no extra CSS
        # transform needed -- see this module's docstring.
        return (miny + maxy) - y

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{_fmt(minx)} {_fmt(miny)} {_fmt(w_)} {_fmt(h_)}" '
        f'width="{_fmt(w_)}" height="{_fmt(h_)}">'
    ]

    def color_for(ent):
        layer = by_id.get(ent.get("layerId"))
        return (layer.get("color") if layer and layer.get("color") else "#8fa0b3")

    for ent in entities:
        t = ent.get("type", "chain")
        col = color_for(ent)

        if t == "dimension":
            continue

        if t == "point":
            p = ent.get("point")
            if not p:
                continue
            x, y = p[0], fy(p[1])
            s = max(0.15, stroke_w * 3)
            parts.append(f'<g stroke="{col}" stroke-width="{_fmt(stroke_w)}">'
                         f'<line x1="{_fmt(x - s)}" y1="{_fmt(y)}" x2="{_fmt(x + s)}" y2="{_fmt(y)}"/>'
                         f'<line x1="{_fmt(x)}" y1="{_fmt(y - s)}" x2="{_fmt(x)}" y2="{_fmt(y + s)}"/></g>')
            continue

        if t == "text":
            p = ent.get("point")
            if not p:
                continue
            size = ent.get("fontSize", 3) or 3
            angle = ent.get("angle", 0) or 0
            # SVG rotate() is clockwise-positive in its own Y-down frame,
            # same mismatch as the canvas fix in drawTextEntity() --
            # negate this app's CCW/Y-up angle to match.
            #
            # `text` can hold real newlines (Alt+Enter/Shift+Enter in the
            # frontend's Text tool) -- SVG has no auto-wrapping <text>, so
            # each line becomes its own element, stepped along whatever
            # "down" means FOR THIS TEXT's own rotation. fy() has already
            # flipped this point into Y-down space (same orientation as
            # the canvas), so -- unlike the DXF export's Y-up version of
            # this same math -- no extra sign flip is needed on ddy here.
            ang_rad = math.radians(angle)
            line_height = size * 1.25
            ddx = math.sin(ang_rad) * line_height
            ddy = math.cos(ang_rad) * line_height
            tx0, ty0 = p[0], fy(p[1])
            for i, line in enumerate(str(ent.get("text", "")).split("\n")):
                txt = line.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                tx, ty = tx0 + ddx * i, ty0 + ddy * i
                rot_attr = f' transform="rotate({_fmt(-angle)} {_fmt(tx)} {_fmt(ty)})"' if angle else ""
                parts.append(f'<text x="{_fmt(tx)}" y="{_fmt(ty)}" font-size="{_fmt(size)}" '
                             f'fill="{col}" font-family="sans-serif"{rot_attr}>{txt}</text>')
            continue

        if t == "hatch":
            for a, b in ent.get("lines", []):
                parts.append(f'<line x1="{_fmt(a[0])}" y1="{_fmt(fy(a[1]))}" x2="{_fmt(b[0])}" y2="{_fmt(fy(b[1]))}" '
                             f'stroke="{col}" stroke-width="{_fmt(stroke_w)}"/>')
            continue

        if t in ("chain", "circle"):
            pts = ent.get("points", [])
            if len(pts) < 2:
                continue
            closed = bool(ent.get("closed", t == "circle"))
            fit = _fit_circle(pts) if closed else None
            if fit and fit[3] < 0.01:
                cx, cy, r, _ = fit
                parts.append(f'<circle cx="{_fmt(cx)}" cy="{_fmt(fy(cy))}" r="{_fmt(r)}" '
                             f'fill="none" stroke="{col}" stroke-width="{_fmt(stroke_w)}"/>')
                continue
            pt_str = " ".join(f"{_fmt(p[0])},{_fmt(fy(p[1]))}" for p in pts)
            tag = "polygon" if closed else "polyline"
            parts.append(f'<{tag} points="{pt_str}" fill="none" stroke="{col}" stroke-width="{_fmt(stroke_w)}"/>')
            continue

    parts.append("</svg>")
    return "\n".join(parts) + "\n"


# ---------------------------------------------------------------------------
# SVG import
# ---------------------------------------------------------------------------

_SVG_NS = "{http://www.w3.org/2000/svg}"


def _strip_ns(tag):
    return tag.split("}", 1)[-1] if "}" in tag else tag


def _mat_mul(m1, m2):
    a1, b1, c1, d1, e1, f1 = m1
    a2, b2, c2, d2, e2, f2 = m2
    return (
        a1 * a2 + c1 * b2, b1 * a2 + d1 * b2,
        a1 * c2 + c1 * d2, b1 * c2 + d1 * d2,
        a1 * e2 + c1 * f2 + e1, b1 * e2 + d1 * f2 + f1,
    )


def _apply_mat(m, x, y):
    a, b, c, d, e, f = m
    return (a * x + c * y + e, b * x + d * y + f)


_TRANSFORM_RE = re.compile(r"(\w+)\s*\(([^)]*)\)")


def _parse_transform(s):
    m = (1, 0, 0, 1, 0, 0)
    if not s:
        return m
    for name, argstr in _TRANSFORM_RE.findall(s):
        args = [float(a) for a in re.split(r"[,\s]+", argstr.strip()) if a]
        if name == "translate":
            tx = args[0] if args else 0.0
            ty = args[1] if len(args) > 1 else 0.0
            m = _mat_mul(m, (1, 0, 0, 1, tx, ty))
        elif name == "scale":
            sx = args[0] if args else 1.0
            sy = args[1] if len(args) > 1 else sx
            m = _mat_mul(m, (sx, 0, 0, sy, 0, 0))
        elif name == "rotate":
            if not args:
                continue
            ang = math.radians(args[0])
            cx = args[1] if len(args) > 2 else 0.0
            cy = args[2] if len(args) > 2 else 0.0
            cosv, sinv = math.cos(ang), math.sin(ang)
            rot = (cosv, sinv, -sinv, cosv, 0, 0)
            if cx or cy:
                m = _mat_mul(m, _mat_mul((1, 0, 0, 1, cx, cy), _mat_mul(rot, (1, 0, 0, 1, -cx, -cy))))
            else:
                m = _mat_mul(m, rot)
        elif name == "matrix" and len(args) == 6:
            m = _mat_mul(m, tuple(args))
    return m


_PATH_TOKEN_RE = re.compile(r"([MmLlHhVvCcSsQqTtAaZz])|(-?\d*\.?\d+(?:[eE][-+]?\d+)?)")


def _parse_path(d):
    """Parses SVG path data into a list of subpaths, each a list of
    (x, y) points in the path's OWN local coordinate space (transform is
    applied by the caller). Curves (C/S/Q/T) are flattened by fixed
    subdivision; elliptical arcs (A) via the standard endpoint-to-center
    parameterization, also flattened."""
    tokens = []
    for m in _PATH_TOKEN_RE.finditer(d):
        tokens.append(m.group(1) or m.group(2))

    subpaths = []
    cur = []
    x = y = 0.0
    start_x = start_y = 0.0
    prev_ctrl = None  # for S/T reflection
    cmd = None
    i = 0
    n = len(tokens)

    def nums(k):
        nonlocal i
        vals = [float(tokens[i + j]) for j in range(k)]
        i += k
        return vals

    def flatten_cubic(p0, p1, p2, p3, segs=16):
        pts = []
        for s in range(1, segs + 1):
            t = s / segs
            mt = 1 - t
            bx = mt**3*p0[0] + 3*mt*mt*t*p1[0] + 3*mt*t*t*p2[0] + t**3*p3[0]
            by = mt**3*p0[1] + 3*mt*mt*t*p1[1] + 3*mt*t*t*p2[1] + t**3*p3[1]
            pts.append((bx, by))
        return pts

    def flatten_quad(p0, p1, p2, segs=12):
        pts = []
        for s in range(1, segs + 1):
            t = s / segs
            mt = 1 - t
            bx = mt*mt*p0[0] + 2*mt*t*p1[0] + t*t*p2[0]
            by = mt*mt*p0[1] + 2*mt*t*p1[1] + t*t*p2[1]
            pts.append((bx, by))
        return pts

    def flatten_arc(p0, rx, ry, phi_deg, large_arc, sweep, p1, segs=24):
        if rx == 0 or ry == 0:
            return [p1]
        phi = math.radians(phi_deg)
        cosphi, sinphi = math.cos(phi), math.sin(phi)
        dx2, dy2 = (p0[0] - p1[0]) / 2.0, (p0[1] - p1[1]) / 2.0
        x1p = cosphi * dx2 + sinphi * dy2
        y1p = -sinphi * dx2 + cosphi * dy2
        rx, ry = abs(rx), abs(ry)
        lam = (x1p**2) / (rx**2) + (y1p**2) / (ry**2)
        if lam > 1:
            rx *= math.sqrt(lam); ry *= math.sqrt(lam)
        num = rx**2*ry**2 - rx**2*y1p**2 - ry**2*x1p**2
        den = rx**2*y1p**2 + ry**2*x1p**2
        co = math.sqrt(max(0.0, num / den)) if den > 1e-12 else 0.0
        if large_arc == sweep:
            co = -co
        cxp = co * rx * y1p / ry
        cyp = -co * ry * x1p / rx
        cx = cosphi * cxp - sinphi * cyp + (p0[0] + p1[0]) / 2.0
        cy = sinphi * cxp + cosphi * cyp + (p0[1] + p1[1]) / 2.0

        def ang(ux, uy, vx, vy):
            dot = ux * vx + uy * vy
            length = math.hypot(ux, uy) * math.hypot(vx, vy)
            a = math.acos(max(-1, min(1, dot / length))) if length > 1e-12 else 0.0
            return a if (ux * vy - uy * vx) >= 0 else -a

        theta1 = ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry)
        dtheta = ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry)
        if not sweep and dtheta > 0:
            dtheta -= 2 * math.pi
        elif sweep and dtheta < 0:
            dtheta += 2 * math.pi
        pts = []
        steps = max(2, int(round(segs * abs(dtheta) / (2 * math.pi))))
        for s in range(1, steps + 1):
            t = theta1 + dtheta * s / steps
            ex = cx + rx * math.cos(t) * cosphi - ry * math.sin(t) * sinphi
            ey = cy + rx * math.cos(t) * sinphi + ry * math.sin(t) * cosphi
            pts.append((ex, ey))
        return pts

    while i < n:
        tok = tokens[i]
        if tok and tok.isalpha():
            cmd = tok
            i += 1
        if cmd is None:
            i += 1
            continue
        c = cmd
        rel = c.islower()
        C = c.upper()
        try:
            if C == "M":
                mx, my = nums(2)
                if rel: mx += x; my += y
                if cur: subpaths.append(cur)
                cur = [(mx, my)]
                x, y = mx, my
                start_x, start_y = x, y
                cmd = "l" if rel else "L"  # subsequent bare coords are implicit lineto
            elif C == "L":
                lx, ly = nums(2)
                if rel: lx += x; ly += y
                cur.append((lx, ly)); x, y = lx, ly
            elif C == "H":
                (lx,) = nums(1)
                if rel: lx += x
                cur.append((lx, y)); x = lx
            elif C == "V":
                (ly,) = nums(1)
                if rel: ly += y
                cur.append((x, ly)); y = ly
            elif C == "Z":
                cur.append((start_x, start_y))
                x, y = start_x, start_y
            elif C == "C":
                x1, y1, x2, y2, ex, ey = nums(6)
                if rel: x1 += x; y1 += y; x2 += x; y2 += y; ex += x; ey += y
                cur.extend(flatten_cubic((x, y), (x1, y1), (x2, y2), (ex, ey)))
                prev_ctrl = (x2, y2); x, y = ex, ey
            elif C == "S":
                x2, y2, ex, ey = nums(4)
                if rel: x2 += x; y2 += y; ex += x; ey += y
                x1, y1 = (2*x - prev_ctrl[0], 2*y - prev_ctrl[1]) if prev_ctrl else (x, y)
                cur.extend(flatten_cubic((x, y), (x1, y1), (x2, y2), (ex, ey)))
                prev_ctrl = (x2, y2); x, y = ex, ey
            elif C == "Q":
                x1, y1, ex, ey = nums(4)
                if rel: x1 += x; y1 += y; ex += x; ey += y
                cur.extend(flatten_quad((x, y), (x1, y1), (ex, ey)))
                prev_ctrl = (x1, y1); x, y = ex, ey
            elif C == "T":
                ex, ey = nums(2)
                if rel: ex += x; ey += y
                x1, y1 = (2*x - prev_ctrl[0], 2*y - prev_ctrl[1]) if prev_ctrl else (x, y)
                cur.extend(flatten_quad((x, y), (x1, y1), (ex, ey)))
                prev_ctrl = (x1, y1); x, y = ex, ey
            elif C == "A":
                rx, ry, rot, laf, sf, ex, ey = nums(7)
                if rel: ex += x; ey += y
                cur.extend(flatten_arc((x, y), rx, ry, rot, laf != 0, sf != 0, (ex, ey)))
                x, y = ex, ey
                prev_ctrl = None
            else:
                i += 1
        except (IndexError, ValueError):
            break
        if C not in ("C", "S", "Q", "T"):
            prev_ctrl = None
    if cur:
        subpaths.append(cur)
    return subpaths


def import_svg(text):
    try:
        root = ET.fromstring(text)
    except ET.ParseError as e:
        raise ValueError(f"Not a valid SVG/XML file: {e}")

    # Coordinate-space height, for the Y-flip back to this app's Y-up world
    # convention (see export_svg()'s docstring for the same flip in
    # reverse).
    vb = root.get("viewBox")
    if vb:
        vbx, vby, vbw, vbh = (float(v) for v in re.split(r"[,\s]+", vb.strip()))
    else:
        def _num(s, default):
            if not s:
                return default
            m = re.match(r"[-\d.]+", s)
            return float(m.group()) if m else default
        vbx, vby = 0.0, 0.0
        vbw = _num(root.get("width"), 100.0)
        vbh = _num(root.get("height"), 100.0)

    def fy(y):
        # Inverse of export_svg()'s fy(): that one reflects a world Y
        # value within [miny, maxy] via (miny+maxy)-y, and sets the
        # viewBox's own min-y (vby) equal to that same miny -- so
        # reflecting back must use the viewBox's full min+max (2*vby+vbh),
        # not just vby+vbh (which is only correct when vby happens to be
        # 0, i.e. the drawing's bounding box starts exactly at the origin).
        return (2 * vby + vbh) - y

    layers_by_name = {}
    layer_order = []

    def get_layer(name):
        name = name or "Imported SVG"
        if name not in layers_by_name:
            new_id = len(layer_order) + 1
            layer_order.append(name)
            layers_by_name[name] = {"id": new_id, "name": name, "visible": True, "color": "#8fa0b3"}
        return layers_by_name[name]

    entities_out = []
    default_layer_name = "Imported SVG"

    def walk(el, mat, layer_name):
        tag = _strip_ns(el.tag)
        # <defs>/<symbol>/etc hold template content that's only ever drawn
        # via a <use> reference (which this importer doesn't resolve) --
        # recursing into them would wrongly import invisible boilerplate
        # as if it were real, visible geometry.
        if tag in ("defs", "symbol", "clipPath", "mask", "pattern", "metadata", "style", "title", "desc"):
            return
        local_mat = _mat_mul(mat, _parse_transform(el.get("transform")))

        if tag in ("g", "svg", "a", "switch"):
            # Illustrator/Inkscape both commonly put one top-level layer
            # per <g>, labelled via inkscape:label or a plain id. The root
            # <svg> itself is a container too (and typically has no such
            # label) -- it just needs to recurse into its children the
            # same way, without switching layers.
            label = el.get("{http://www.inkscape.org/namespaces/inkscape}label") or (el.get("id") if tag == "g" else None)
            child_layer = label if (label and layer_name == default_layer_name) else layer_name
            for child in el:
                walk(child, local_mat, child_layer)
            return

        layer = get_layer(layer_name)

        def tpts(pts):
            return [list(_apply_mat(local_mat, px, py)) for px, py in pts]

        def finalize_chain(pts, closed):
            if len(pts) < 2:
                return
            pts = [[p[0], fy(p[1])] for p in tpts(pts)]
            # A closed <polygon>, a Z-closed <path>, or a <rect>'s implicit
            # closing edge can all end up with the start point repeated at
            # the end -- this app's own convention (see e.g. the Join
            # tool) is that a closed chain's point list does NOT repeat
            # its start point; the closing edge is implied by `closed`.
            if closed and len(pts) > 2 and math.hypot(pts[0][0] - pts[-1][0], pts[0][1] - pts[-1][1]) < 1e-6:
                pts = pts[:-1]
            if len(pts) < 2:
                return
            entities_out.append({"type": "chain", "closed": closed, "points": pts, "layerId": layer["id"]})

        if tag == "line":
            try:
                x1, y1, x2, y2 = (float(el.get(a, 0)) for a in ("x1", "y1", "x2", "y2"))
            except ValueError:
                return
            finalize_chain([(x1, y1), (x2, y2)], False)

        elif tag in ("polyline", "polygon"):
            raw = (el.get("points") or "").strip()
            coords = [float(v) for v in re.split(r"[,\s]+", raw) if v]
            pts = list(zip(coords[0::2], coords[1::2]))
            finalize_chain(pts, tag == "polygon")

        elif tag == "rect":
            try:
                rx0 = float(el.get("x", 0)); ry0 = float(el.get("y", 0))
                rw = float(el.get("width", 0)); rh = float(el.get("height", 0))
            except ValueError:
                return
            if rw <= 0 or rh <= 0:
                return
            finalize_chain([(rx0, ry0), (rx0 + rw, ry0), (rx0 + rw, ry0 + rh), (rx0, ry0 + rh)], True)

        elif tag == "circle":
            try:
                cx = float(el.get("cx", 0)); cy = float(el.get("cy", 0)); r = float(el.get("r", 0))
            except ValueError:
                return
            if r <= 0:
                return
            pts = [(cx + r * math.cos(2 * math.pi * k / 60), cy + r * math.sin(2 * math.pi * k / 60)) for k in range(60)]
            pts = [[p[0], fy(p[1])] for p in tpts(pts)]
            entities_out.append({"type": "circle", "closed": True, "points": pts, "layerId": layer["id"]})

        elif tag == "ellipse":
            try:
                cx = float(el.get("cx", 0)); cy = float(el.get("cy", 0))
                rx = float(el.get("rx", 0)); ry = float(el.get("ry", 0))
            except ValueError:
                return
            if rx <= 0 or ry <= 0:
                return
            pts = [(cx + rx * math.cos(2 * math.pi * k / 60), cy + ry * math.sin(2 * math.pi * k / 60)) for k in range(60)]
            finalize_chain(pts, True)

        elif tag == "path":
            d = el.get("d")
            if not d:
                return
            for sub in _parse_path(d):
                closed = len(sub) > 2 and math.hypot(sub[0][0]-sub[-1][0], sub[0][1]-sub[-1][1]) < 1e-6
                finalize_chain(sub, closed)

    walk(root, (1, 0, 0, 1, 0, 0), default_layer_name)

    layers_out = list(layers_by_name.values()) or [{"id": 1, "name": default_layer_name, "visible": True, "color": "#8fa0b3"}]
    return {"entities": entities_out, "layers": layers_out}
