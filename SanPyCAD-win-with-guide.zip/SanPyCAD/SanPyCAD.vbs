' SanPyCAD.vbs -- double-click launcher for Windows, no command line needed.
'
' This is the Windows equivalent of SanPyCAD.app on macOS: it finds a
' Python 3 interpreter that actually has the packages this app needs
' (numpy, scipy, sympy, scikit-image), then runs app.py in a normal,
' VISIBLE console window (the app's own window, opened by pywebview,
' still appears separately on top of that). If something goes wrong, it
' shows a message box instead of failing silently, and always logs the
' Python-detection steps to SanPyCAD.log next to this file, the same
' idea as the macOS launcher's SanPyCAD.log.
'
' Earlier versions of this launcher ran app.py with its console window
' hidden -- an unsigned script that silently spawns a hidden process is
' exactly the pattern antivirus/SmartScreen heuristics flag as
' suspicious (malware uses the same trick), so some downloads of that
' version got quarantined as a false positive. Keeping the console
' visible here avoids that trigger; run_sanpycad.bat (plain
' double-click, always-visible console) is the other launcher option
' if you'd rather skip .vbs entirely.
'
' Just double-click this file. Don't move it out of the project folder
' (it finds app.py relative to its own location, so the app still works
' if the whole folder is renamed or moved, as long as this file stays
' alongside app.py).

Option Explicit

Dim fso, shell, scriptDir, logPath, appPath
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
logPath = fso.BuildPath(scriptDir, "SanPyCAD.log")
appPath = fso.BuildPath(scriptDir, "app.py")

Sub LogLine(msg)
    Dim f
    Set f = fso.OpenTextFile(logPath, 8, True) ' 8 = ForAppending, True = create if missing
    f.WriteLine Now & "  " & msg
    f.Close
End Sub

Sub Alert(msg)
    MsgBox msg, vbExclamation, "SanPyCAD"
End Sub

' Wraps a candidate python command for safe use inside a "cmd /c ..."
' line: a bare launcher token like "py -3" or "python" is left alone
' (quoting it would make cmd look for a program literally named
' "py -3"), but an actual file path (which may contain spaces, e.g.
' "C:\Program Files\...") gets wrapped in quotes.
Function QuoteIfPath(cand)
    If InStr(cand, "\") > 0 Then
        QuoteIfPath = """" & cand & """"
    Else
        QuoteIfPath = cand
    End If
End Function

If Not fso.FileExists(appPath) Then
    Alert "Could not find app.py next to SanPyCAD.vbs." & vbCrLf & _
          "Don't move this file out of the project folder."
    WScript.Quit 1
End If

LogLine "===== launch ====="

' Candidates roughly in order of how likely each is to be "the" Python
' the required packages were actually installed into. `py -3` is the
' official python.org launcher (version-aware, present on PATH by
' default on any python.org install) so it's tried first; the rest are
' fallbacks for setups where that launcher isn't registered.
Dim candidates, i, cand, cmd, tmpOut, rc, foundExe, found, errText, tf
candidates = Array( _
    "py -3", "py", "python", "python3", _
    shell.ExpandEnvironmentStrings("%LocalAppData%\Programs\Python\Python313\python.exe"), _
    shell.ExpandEnvironmentStrings("%LocalAppData%\Programs\Python\Python312\python.exe"), _
    shell.ExpandEnvironmentStrings("%LocalAppData%\Programs\Python\Python311\python.exe"), _
    shell.ExpandEnvironmentStrings("%LocalAppData%\Programs\Python\Python310\python.exe"), _
    shell.ExpandEnvironmentStrings("%LocalAppData%\Programs\Python\Python39\python.exe"), _
    "C:\Python313\python.exe", "C:\Python312\python.exe", _
    "C:\Python311\python.exe", "C:\Python310\python.exe", "C:\Python39\python.exe", _
    shell.ExpandEnvironmentStrings("%ProgramFiles%\Python313\python.exe"), _
    shell.ExpandEnvironmentStrings("%ProgramFiles%\Python312\python.exe"), _
    shell.ExpandEnvironmentStrings("%ProgramFiles%\Python311\python.exe") _
)

found = False
tmpOut = fso.BuildPath(shell.ExpandEnvironmentStrings("%TEMP%"), "sanpycad_check.txt")

For i = 0 To UBound(candidates)
    cand = candidates(i)
    If Len(cand) > 0 Then
        cmd = "cmd /c " & QuoteIfPath(cand) & _
              " -c ""import numpy, scipy, sympy, skimage"" > """ & tmpOut & """ 2>&1"
        rc = shell.Run(cmd, 0, True)
        If rc = 0 Then
            LogLine "OK: " & cand & " has numpy/scipy/sympy/scikit-image"
            foundExe = cand
            found = True
            Exit For
        Else
            errText = ""
            If fso.FileExists(tmpOut) Then
                Set tf = fso.OpenTextFile(tmpOut, 1)
                If Not tf.AtEndOfStream Then errText = tf.ReadLine
                tf.Close
            End If
            LogLine "skip: " & cand & " -- " & errText
        End If
    End If
Next

If fso.FileExists(tmpOut) Then fso.DeleteFile(tmpOut, True)

If Not found Then
    Alert "SanPyCAD couldn't find a Python 3 with numpy/scipy/sympy/scikit-image " & _
          "installed." & vbCrLf & "See SanPyCAD.log in this folder for what was tried." & _
          vbCrLf & vbCrLf & "Fix: open Command Prompt and run:" & vbCrLf & _
          "    pip install numpy scipy sympy scikit-image pywebview"
    WScript.Quit 42
End If

LogLine "Using: " & foundExe & " (visible console)"

Dim runCmd
' No output redirection here -- the whole point of the visible console
' is to show app.py's own output live, the same as double-clicking
' run_sanpycad.bat. "|| pause" only fires if app.py exits with a
' non-zero code, so the window stays open long enough to read the
' error instead of flashing shut; a normal, successful exit (closing
' the app window) closes this console immediately like any other
' console app.
runCmd = "cmd /c cd /d " & QuoteIfPath(scriptDir) & " && " & _
          QuoteIfPath(foundExe) & " app.py || pause"

' Wait (True) for app.py to actually exit -- same idea as the macOS
' launcher, which runs app.py in the foreground of its own wrapper
' script: it lets us tell the difference between "the window was closed
' normally" and "it crashed on startup", and show an alert for the
' latter. Style 1 = normal, visible window (see the header comment for
' why this changed from hidden (0) -- a hidden-window process spawn is
' exactly what triggers antivirus/SmartScreen false positives).
' pywebview's own app window isn't affected either way, since that's a
' separate window pywebview itself creates once it's running.
rc = shell.Run(runCmd, 1, True)
If rc <> 0 Then
    Alert "SanPyCAD stopped unexpectedly (exit code " & rc & ")." & vbCrLf & _
          "See SanPyCAD.log in this folder for details."
End If
