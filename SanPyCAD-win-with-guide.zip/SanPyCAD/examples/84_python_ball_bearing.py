# Ball bearing
# Real project from the ocad examples notebook.
# A short one: two corner_radius() profiles are combined and cut with
# rotate_extrude() (native OpenSCAD text through fo()) to form the inner
# and outer races, then a ring of sphere() balls is placed with a for loop.

sec=corner_radius(pts1([[31,.5,0],[.5,-.5,0],[9.5,0,1],[0,15,1],[-9.5,0,0],[-.5,-.5,0]]),10)
sec1=corner_radius(pts1([[16,.5,0],[.5,-.5],[9,0,0],[0.5,.5,0],[0,14,0],[-.5,.5,0],[-9,0,0],[-.5,-.5,0]]),10)
sec2=circle(7,[28.5,7.5])

fo(f'''

rotate_extrude($fn=200)
difference(){{
union(){{
polygon({sec});
polygon({sec1});
}}
polygon({sec2});
}}

for(i=[0:360/12:359])
rotate([0,0,i])
translate([28.5,0,7.5])
sphere(6.8,$fn=100);

''')
