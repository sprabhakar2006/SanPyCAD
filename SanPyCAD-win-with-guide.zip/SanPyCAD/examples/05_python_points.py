# Points
# From the "Basics of Drawing and 3D Modeling" tutorial (Python mode, SanPyCAD)

p0=[10,0,0]

# pay attention to the points() function here. Points are shown as cubes --
# in this example a cube of size 0.5 is showing the location of p0
show(color(points([p0],.5),"blue"))
