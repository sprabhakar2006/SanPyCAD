# A computer-mouse-shaped body -- the same model as SanPyCAD's (the
# OpenSCAD-mesh sibling app's) own point-grid version:
#
#   a=cr2dt([[-20,0,15],[40,0,15],[0,40],[5,40,20],[-50,0,20],[5,-40]])
#   b=translate([0,0,-20],sphere(50))
#   s1=prism(a,[[0,0],[15,50]])
#   c=rsz3dc(translate([-12.5,40,35],sphere(25)),[25,50,50])
#   d=flip(mirror_surface(c,[1,0,0],[0,0,0]))
#   show(difference(intersection(swp(s1),swp(b)),swp(c),swp(d)))
#
# rebuilt here with genuine B-rep primitives/booleans throughout instead
# of that app's point-grid-then-triangulate pipeline, so there's no
# facet/seam-line artifacts anywhere except the FINAL display
# tessellation (a rendering-only setting, not a real defect in the
# shape) -- see show()'s tolerance= argument at the bottom.
#
#   - cr2dt(..., s=None) here returns a real Wire with exact circular
#     ARC edges at the rounded corners, not a point-sampled polygon
#     approximation of them the way SanPyCAD's own (point-list-based)
#     cr2dt always is.
#   - s1 (the swept "prism" body) is loft()ed directly -- build123d's
#     native 2-section loft between the base profile and the same
#     profile offset outward by 15 and raised to z=50 is an EXACT
#     equivalent of what openscad4.py's prism(sec, path) computes by
#     hand for a straight 2-station path (see loft()'s own docstring),
#     not an approximation of it.
#   - b (the sphere) and c/d (the two "eye" cutouts, an ellipsoid built
#     by scaling a sphere and its mirror image) are true OCCT analytic
#     surfaces -- their intersection curves with the loft are computed
#     exactly by the real boolean engine, not approximated by two
#     independently-meshed surfaces touching at nearly-but-not-quite
#     coincident points (which is exactly what produced the shading
#     seams SanPyCAD's own mesh viewer needed a separate fix for).
#   - c is built with scale() instead of openscad4's rsz3dc(): scale()
#     scales about the ORIGIN, so the sphere is scaled to an ellipsoid
#     while it's still centered there, then translated into place --
#     same final shape as "resize to [25,50,50], centered", without
#     needing a resize-about-own-center helper.

a = [[-20, 0, 15], [40, 0, 15], [0, 40], [5, 40, 20], [-50, 0, 20], [5, -40]]

# Recenter the rounded profile on its own centroid, same as the original
# script's tx=a_(a).mean(0); a=translate_2d(-tx,a) -- cog() needs a plain
# point list, so get one from a quick point-sampled pass just for that
# math, then apply the resulting offset to the real (s=None) B-rep wire
# built right after.
centroid = cog(cr2dt(a, s=20))
base_wire = translate([-centroid[0], -centroid[1], 0], cr2dt(a, s=None))
base = face_from_wire(base_wire)

top = translate([0, 0, 50], offset(base, 15, kind="arc"))
s1 = loft(base, top)

b = translate([0, 0, -20], sphere(50))

body = intersection(s1, b)

c = translate([-12.5, 40, 35], scale([0.5, 1, 1], sphere(25)))
d = mirror([1, 0, 0], c)

mouse = difference(body, c, d)

# Fine tessellation tolerance on the display mesh only -- the underlying
# shape stays exact B-rep regardless; this just keeps the curved
# sphere/ellipsoid surfaces looking smooth in the viewer rather than
# faceted at the default tolerance.
show(mouse, tolerance=0.05, angular_tolerance=0.1)
