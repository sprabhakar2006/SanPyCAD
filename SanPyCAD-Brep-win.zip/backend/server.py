"""
server.py

Small dependency-free HTTP backend (uses only the Python standard library --
no Flask/FastAPI install required). This app is B-rep only: the one real
third-party dependency anything here needs is build123d (see brep.py), used
via python_eval.py; numpy is the other hard dependency (viewer JSON, STL/OBJ/
SVG/DXF export triangle math).

Routes:
  GET  /                    -> frontend/index.html
  GET  /status               -> {build123d: bool} -- whether build123d is
                                importable, so the frontend can show a clear
                                "pip install build123d" notice instead of
                                every script silently failing with an
                                ImportError.
  GET  /examples            -> list of bundled example scripts (.py)
  GET  /examples/<name>     -> a single example's source
  GET  /functions           -> {functions: [{name, doc, origin}]} -- every
                                name brep.py exposes through python_eval.py's
                                namespace (box()/cylinder()/union()/fillet()/
                                etc), for editor autocomplete, the Shift+Tab
                                doc popup, and the Function Reference panel.
  POST /render              -> {code, csg_resolution?} -> scene JSON
  POST /export/stl          -> {code, csg_resolution?} -> binary STL file
  POST /export/obj          -> {code, csg_resolution?} -> Wavefront OBJ file
  POST /export/svg          -> {code, csg_resolution?} -> SVG isometric
                                wireframe of the model's edges
  POST /export/dxf          -> {code, csg_resolution?} -> DXF (R12) file,
                                one 3DFACE entity per triangle -- this is what
                                the "DWG" export option in the UI actually
                                produces, since true .dwg needs a proprietary
                                SDK; DXF is the open interchange format AutoCAD
                                and every other major CAD tool reads natively.

`csg_resolution` is still accepted for backward call-signature compatibility
with the frontend but is UNUSED by python_eval.py -- B-rep booleans are exact,
there's no facet/voxel resolution to tune.

There is deliberately no OpenSCAD-text-DSL mode, no OpenSCAD CLI dependency,
and no mesh import route in this app -- SanPyCAD-Brep only ever builds real
build123d/OCCT solids (see python_eval.py's module docstring for why).

Also serves anything under frontend/ by path (e.g. GET /vendor/<...> for
the locally-vendored CodeMirror/Three.js copies -- see vendor_assets.py)
via the plain static-file fallback at the bottom of do_GET, same as any
other frontend/ asset -- no separate route needed for that.
"""

import inspect
import json
import math
import os
import struct
import sys
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import vendor_assets
import python_eval as PE
import brep

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(os.path.dirname(BASE_DIR), "frontend")
EXAMPLES_DIR = os.path.join(os.path.dirname(BASE_DIR), "examples")

MIME = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json",
    ".svg": "image/svg+xml",
}


_FUNCTION_DOCS_CACHE = None
_FUNCTION_ORIGIN_CACHE = None


def _doc_for(name, val):
    """`name(signature)` header (when introspectable) followed by the
    docstring, matching Jupyter's own Shift+Tab inspector. If a
    docstring already opens with its own hand-written `name(...)` line,
    it's left alone rather than getting a second, redundant signature
    line stuck above it. If there's no docstring at all, the signature
    alone is still shown -- better than nothing, same as Jupyter falls
    back to."""
    doc = inspect.getdoc(val) or ""
    try:
        sig = str(inspect.signature(val))
    except (TypeError, ValueError):
        sig = ""
    if doc:
        if sig and not doc.startswith(name + "("):
            return f"{name}{sig}\n{doc}"
        return doc
    if sig:
        return f"{name}{sig}\n(no docstring for this function -- signature only)"
    return ""


def python_function_docs():
    """{name: docstring} for every function python_eval.py's namespace
    exposes to a script -- all of it is brep.py (box()/cylinder()/
    union()/fillet()/etc), plus this app's own show()/color()/echo(),
    plus (best-effort) the sibling SanPyCAD app's openscad4.py toolkit,
    reachable via the opt-in `import openscad4` escape hatch (see
    python_eval.py's module docstring). Used for both editor
    autocomplete and the Shift+Tab doc popup -- computed once and
    cached, since none of this changes at runtime.

    Iterates PE.RESERVED_NAMES (not a separately hand-maintained list
    here) specifically so this can't silently drift out of sync with
    make_namespace() -- see the Shift+Tab bug this fixed, back when this
    app still had an openscad4.py mesh layer underneath brep.py's
    overlay and a stale hardcoded name tuple here missed several of
    brep.py's own names entirely."""
    global _FUNCTION_DOCS_CACHE, _FUNCTION_ORIGIN_CACHE
    if _FUNCTION_DOCS_CACHE is not None:
        return _FUNCTION_DOCS_CACHE
    docs = {}
    origins = {}
    # make_namespace() just builds closures (no script is executed), so
    # this is cheap and side-effect-free -- it's the only way to get at
    # these functions' docstrings since they're created fresh per-script
    # rather than defined at module level.
    ns, _shown_flag = PE.make_namespace(csg_resolution=56, scene=[], warnings=[], echo_log=[])
    for name in sorted(PE.RESERVED_NAMES):
        if name in ("np", "numpy", "brep"):
            continue  # not a function
        fn = ns.get(name)
        if fn is not None and callable(fn):
            docs[name] = _doc_for(name, fn)
            origins[name] = "library" if fn is getattr(brep, name, None) else "helper"
    docs.setdefault("np", "numpy, imported as np.")
    docs.setdefault("numpy", "The numpy module.")
    origins.setdefault("np", "external")
    origins.setdefault("numpy", "external")

    # Opt-in mesh escape hatch: a script may `import openscad4 as o4`
    # and call e.g. o4.two_solids_intersection(...) -- surface those
    # functions' docs here too, so Shift+Tab/autocomplete/the Reference
    # panel find them under their bare name (wordAtCursor() in the
    # frontend splits on '.', so `o4.two_tri_intersection(|)` looks up
    # "two_tri_intersection" the same as a plain top-level call would).
    # Best-effort: python_eval.py's sys.path hook only adds the sibling
    # SanPyCAD app's backend/ if that app is actually installed
    # alongside this one, and openscad4.py itself needs scipy -- either
    # missing piece just means this section quietly contributes nothing.
    try:
        import openscad4 as _o4
    except Exception:
        _o4 = None
    if _o4 is not None:
        for name in dir(_o4):
            if name.startswith("_") or name in docs:
                continue  # a brep.py/helper name of the same spelling
                          # always wins -- that's what a bare unqualified
                          # call to that name actually resolves to
            val = getattr(_o4, name)
            if not inspect.isfunction(val) or getattr(val, "__module__", None) != "openscad4":
                continue  # skip classes/constants and anything openscad4.py
                          # itself pulled in via `from numpy import *` etc --
                          # only openscad4.py's OWN functions, please
            doc = _doc_for(name, val)
            if not doc:
                continue
            docs[name] = (
                f"[openscad4 -- needs `import openscad4 as o4` first; "
                f"call as o4.{name}(...)]\n\n" + doc
            )
            origins[name] = "openscad4"

    _FUNCTION_DOCS_CACHE = docs
    _FUNCTION_ORIGIN_CACHE = origins
    return docs


def python_function_origins():
    """{name: "library"|"helper"|"external"} matching python_function_docs()
    one-for-one -- "library" is a real brep.py function, "helper" is one
    of this app's own Python-mode injections (show()/color()/echo()),
    "external" is np/numpy. Computed as a side effect of
    python_function_docs(), so this just makes sure that's run first."""
    python_function_docs()
    return _FUNCTION_ORIGIN_CACHE


def python_function_names():
    """Sorted list of names from python_function_docs(), for callers that
    only need the names (e.g. editor autocomplete's word list)."""
    return sorted(python_function_docs())


def run_any(code, csg_resolution, persist=True):
    """Thin pass-through to python_eval.py -- kept as its own function
    (rather than calling PE.run_python_script directly at every call
    site) purely so a future second scripting mode has one obvious place
    to add a dispatch branch, the same role this played back when this
    app also had an OpenSCAD-text-DSL mode."""
    return PE.run_python_script(code, csg_resolution, persist=persist)


def build_stl_binary(meshes):
    """Concatenate all (visible) meshes into one binary STL blob."""
    tri_count = sum(len(m.F) for m in meshes)
    buf = bytearray()
    buf += b"\x00" * 80
    buf += struct.pack("<I", tri_count)
    for m in meshes:
        V, F = m.V, m.F
        if len(F) == 0:
            continue
        p0 = V[F[:, 0]]
        p1 = V[F[:, 1]]
        p2 = V[F[:, 2]]
        normals = np.cross(p1 - p0, p2 - p0)
        norm_len = np.linalg.norm(normals, axis=1, keepdims=True)
        norm_len[norm_len == 0] = 1.0
        normals = normals / norm_len
        for n, a, b, c in zip(normals, p0, p1, p2):
            buf += struct.pack("<3f", *n)
            buf += struct.pack("<3f", *a)
            buf += struct.pack("<3f", *b)
            buf += struct.pack("<3f", *c)
            buf += struct.pack("<H", 0)
    return bytes(buf)


def build_obj_text(meshes):
    """Concatenate all (visible) meshes into one Wavefront OBJ text blob,
    one `o` group per mesh, 1-indexed faces with a running vertex offset
    (OBJ indices are global across the whole file, not per-object)."""
    lines = ["# Exported from SanPyCAD Brep"]
    vertex_offset = 0
    for i, m in enumerate(meshes):
        V, F = m.V, m.F
        if len(F) == 0:
            continue
        lines.append(f"o object{i + 1}")
        for v in V:
            lines.append(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}")
        for tri in F:
            a = int(tri[0]) + 1 + vertex_offset
            b = int(tri[1]) + 1 + vertex_offset
            c = int(tri[2]) + 1 + vertex_offset
            lines.append(f"f {a} {b} {c}")
        vertex_offset += len(V)
    return ("\n".join(lines) + "\n").encode("utf-8")


def build_svg_text(meshes):
    """A 2D isometric wireframe projection of every mesh's edges, as an SVG
    line drawing. This is deliberately NOT the same thing as OpenSCAD's own
    SVG export, which only works on genuinely flat 2D shapes (the output of
    projection()) -- since most scripts here build real 3D solids, an SVG
    export that only worked on 2D shapes would be useless for almost every
    model. A wireframe projection works for anything."""
    COS30 = math.cos(math.radians(30))
    SIN30 = math.sin(math.radians(30))

    def project(v):
        x, y, z = float(v[0]), float(v[1]), float(v[2])
        return (x - y) * COS30, (x + y) * SIN30 - z

    segments = []  # (p1, p2, "#rrggbb")
    for m in meshes:
        V, F = m.V, m.F
        if len(F) == 0:
            continue
        color = getattr(m, "color", None) or (0.6, 0.6, 0.65)
        hexcolor = "#%02x%02x%02x" % tuple(
            min(255, max(0, int(round(c * 255)))) for c in list(color)[:3]
        )
        edges = set()
        for tri in F:
            a, b, c = int(tri[0]), int(tri[1]), int(tri[2])
            for p, q in ((a, b), (b, c), (c, a)):
                edges.add((min(p, q), max(p, q)))
        for a, b in edges:
            segments.append((project(V[a]), project(V[b]), hexcolor))

    if not segments:
        return b'<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"></svg>\n'

    xs = [pt[0] for seg in segments for pt in seg[:2]]
    ys = [pt[1] for seg in segments for pt in seg[:2]]
    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)
    span = max(max_x - min_x, max_y - min_y, 1.0)
    pad = max(1.0, 0.05 * span)
    width = (max_x - min_x) + 2 * pad
    height = (max_y - min_y) + 2 * pad
    stroke_w = max(0.4, width / 500)

    def to_svg_xy(pt):
        x = pt[0] - min_x + pad
        y = height - (pt[1] - min_y + pad)  # SVG's y grows downward
        return x, y

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width:.3f} {height:.3f}" '
        f'width="{width:.1f}" height="{height:.1f}">',
        "<!-- Exported from SanPyCAD Brep: isometric wireframe projection -->",
        f'<rect x="0" y="0" width="{width:.3f}" height="{height:.3f}" fill="white"/>',
    ]
    for p1, p2, color in segments:
        x1, y1 = to_svg_xy(p1)
        x2, y2 = to_svg_xy(p2)
        parts.append(
            f'<line x1="{x1:.3f}" y1="{y1:.3f}" x2="{x2:.3f}" y2="{y2:.3f}" '
            f'stroke="{color}" stroke-width="{stroke_w:.3f}" stroke-linecap="round"/>'
        )
    parts.append("</svg>")
    return ("\n".join(parts) + "\n").encode("utf-8")


def build_dxf_text(meshes):
    """Minimal ASCII DXF (R12), one 3DFACE entity per triangle, full 3D
    coordinates preserved. This is what the UI's "DWG" export option
    actually writes -- true .dwg is AutoCAD's proprietary binary format
    and needs a paid SDK (Teigha/ODA) to produce; DXF is the open,
    royalty-free interchange format that AutoCAD (and every other major
    CAD/BIM tool) reads natively, so it covers the same "get this into
    AutoCAD" goal without a fake or broken .dwg file."""
    lines = ["0", "SECTION", "2", "ENTITIES"]
    for i, m in enumerate(meshes):
        V, F = m.V, m.F
        layer = f"object{i + 1}"
        for tri in F:
            p0, p1, p2 = V[int(tri[0])], V[int(tri[1])], V[int(tri[2])]
            lines += ["0", "3DFACE", "8", layer]
            # 3DFACE takes 4 corners; repeating the 3rd point as the 4th
            # is the standard way to represent a triangle with it.
            for gx, gy, gz, pt in (
                (10, 20, 30, p0), (11, 21, 31, p1), (12, 22, 32, p2), (13, 23, 33, p2)
            ):
                lines += [str(gx), f"{pt[0]:.6f}", str(gy), f"{pt[1]:.6f}", str(gz), f"{pt[2]:.6f}"]
    lines += ["0", "ENDSEC", "0", "EOF"]
    return ("\n".join(lines) + "\n").encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    server_version = "OpenSCADLikeServer/1.0"

    def log_message(self, fmt, *args):
        pass  # keep console quiet; errors are still printed explicitly

    # -- helpers ----------------------------------------------------------
    def _send_json(self, obj, status=200):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _send_bytes(self, data, content_type, status=200, filename=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        if filename:
            self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)

    def _send_file(self, path):
        if not os.path.isfile(path):
            self._send_json({"error": "not found"}, 404)
            return
        ext = os.path.splitext(path)[1]
        with open(path, "rb") as f:
            data = f.read()
        self._send_bytes(data, MIME.get(ext, "application/octet-stream"))

    def _read_json_body(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw or b"{}")

    # -- routes -------------------------------------------------------
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path == "/":
            self._send_file(os.path.join(FRONTEND_DIR, "index.html"))
        elif path == "/status":
            self._send_json({"build123d": brep._HAVE_BUILD123D})
        elif path == "/examples":
            items = []
            if os.path.isdir(EXAMPLES_DIR):
                for fname in sorted(os.listdir(EXAMPLES_DIR)):
                    if fname.endswith(".py"):
                        items.append(fname)
            self._send_json({"examples": items})
        elif path == "/functions":
            docs = python_function_docs()
            origins = python_function_origins()
            self._send_json({"functions": [
                {"name": n, "doc": docs[n], "origin": origins.get(n, "library")}
                for n in sorted(docs)
            ]})
        elif path == "/kernel_status":
            self._send_json({"persisted_vars": PE.persisted_variable_names()})
        elif path.startswith("/examples/"):
            fname = os.path.basename(path[len("/examples/"):])
            fpath = os.path.join(EXAMPLES_DIR, fname)
            if os.path.isfile(fpath):
                with open(fpath, "r", encoding="utf-8") as f:
                    self._send_json({"name": fname, "code": f.read()})
            else:
                self._send_json({"error": "not found"}, 404)
        else:
            candidate = os.path.join(FRONTEND_DIR, path.lstrip("/"))
            if os.path.isfile(candidate):
                self._send_file(candidate)
            else:
                self._send_json({"error": "not found"}, 404)

    def do_POST(self):
        path = self.path.split("?", 1)[0]
        try:
            body = self._read_json_body()
        except Exception:
            self._send_json({"error": "invalid JSON body"}, 400)
            return

        code = body.get("code", "")
        csg_resolution = int(body.get("csg_resolution", 56))
        csg_resolution = max(16, min(csg_resolution, 160))
        persist = bool(body.get("persist", True))

        if path == "/reset_kernel":
            n = PE.reset_kernel()
            self._send_json({"cleared": n, "persisted_vars": []})
            return

        if path == "/render":
            result, _scene = run_any(code, csg_resolution, persist=persist)
            self._send_json(result)
            return

        if path == "/export/stl":
            result, _scene = run_any(code, csg_resolution)
            if result["error"]:
                self._send_json(result, 400)
                return
            meshes = list(ev_meshes_from_result(result))
            if not meshes:
                self._send_json({"error": "nothing to export (empty scene)"}, 400)
                return
            stl = build_stl_binary(meshes)
            self._send_bytes(stl, "model/stl", filename="model.stl")
            return

        if path == "/export/obj":
            result, _scene = run_any(code, csg_resolution)
            if result["error"]:
                self._send_json(result, 400)
                return
            meshes = list(ev_meshes_from_result(result))
            if not meshes:
                self._send_json({"error": "nothing to export (empty scene)"}, 400)
                return
            obj = build_obj_text(meshes)
            self._send_bytes(obj, "text/plain; charset=utf-8", filename="model.obj")
            return

        if path == "/export/svg":
            result, _scene = run_any(code, csg_resolution)
            if result["error"]:
                self._send_json(result, 400)
                return
            meshes = list(ev_meshes_from_result(result))
            if not meshes:
                self._send_json({"error": "nothing to export (empty scene)"}, 400)
                return
            svg = build_svg_text(meshes)
            self._send_bytes(svg, "image/svg+xml", filename="model.svg")
            return

        if path == "/export/dxf":
            result, _scene = run_any(code, csg_resolution)
            if result["error"]:
                self._send_json(result, 400)
                return
            meshes = list(ev_meshes_from_result(result))
            if not meshes:
                self._send_json({"error": "nothing to export (empty scene)"}, 400)
                return
            dxf = build_dxf_text(meshes)
            self._send_bytes(dxf, "application/dxf", filename="model.dxf")
            return

        self._send_json({"error": "not found"}, 404)


class _SimpleMesh:
    __slots__ = ("V", "F")

    def __init__(self, V, F):
        self.V = np.array(V, dtype=float)
        self.F = np.array(F, dtype=int)


def ev_meshes_from_result(result):
    for m in result["meshes"]:
        yield _SimpleMesh(m["vertices"], m["faces"])


def serve(host="127.0.0.1", port=0):
    httpd = ThreadingHTTPServer((host, port), Handler)
    actual_port = httpd.server_address[1]
    return httpd, actual_port


def print_backend_status():
    if brep._HAVE_BUILD123D:
        print("[SanPyCAD Brep] build123d is installed -- ready to build real B-rep solids.")
    else:
        print("[SanPyCAD Brep] build123d is NOT installed -- every script will fail until "
              "you install it: pip install build123d")

    still_missing = vendor_assets.missing_assets()
    if still_missing:
        # Kick off (or retry) downloading the editor/3D-viewer assets this
        # app needs, in the background -- the app is fully usable right
        # away either way (index.html falls back to the CDN for anything
        # not yet vendored), this just means one more launch with internet
        # access is enough to make every future launch fully offline.
        def _done(remaining):
            if not remaining:
                print("[SanPyCAD Brep] all editor/3D-viewer assets are now stored locally -- "
                      "SanPyCAD Brep can run fully offline from now on.")
            else:
                print(f"[SanPyCAD Brep] {len(remaining)} asset(s) still not available locally "
                      "(no internet access?) -- SanPyCAD Brep will keep loading those from the "
                      "CDN for now and retry on the next launch.")
        print(f"[SanPyCAD Brep] fetching {len(still_missing)} editor/3D-viewer asset(s) in the "
              "background so SanPyCAD Brep can run offline from now on...")
        vendor_assets.ensure_vendor_assets_async(on_done=_done)
    else:
        print("[SanPyCAD Brep] editor/3D-viewer assets are all stored locally -- SanPyCAD Brep can run fully offline.")


if __name__ == "__main__":
    print_backend_status()
    httpd, port = serve(port=8743)
    print(f"OpenSCAD-like server running at http://127.0.0.1:{port}/")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
