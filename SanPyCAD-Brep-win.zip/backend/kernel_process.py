"""
kernel_process.py -- the actual "Jupyter kernel" process for SanPyCAD
Brep: every route that touches build123d/OCCT (running a script,
picking edges/faces, computing max-fillet radii, highlighting a
selection) now runs inside a dedicated CHILD PROCESS, not the HTTP
server's own process. kernel_manager.py owns/supervises this process;
server.py never imports python_eval.py or brep.py directly for any of
that -- it goes through kernel_manager.MANAGER.call(...) instead.

WHY: OCCT (via build123d) is a C++ library, and a script can hang it
forever -- an infinite loop in the user's own Python, a fillet()/
max_fillet_radius() binary search that never converges, a boolean on
degenerate geometry that spins, or (per server.py's old _OCCT_LOCK
comment) an outright native segfault. When all of that ran in-process,
a single stuck script wedged the ENTIRE app: the one Python thread
running exec() never returned, so /reset_kernel -- which used to be
just another route behind the same global lock -- could never even
start running, let alone finish. "Reset Memory" doing nothing during a
hang was that design working exactly as built, not a bug in reset
itself.

Moving execution to a child process fixes this the same way Jupyter's
own "Restart Kernel" does: the HTTP server (this app's main process)
only ever talks to the worker over a pair of multiprocessing.Queues,
and never blocks on anything it can't also walk away from. Restarting
the kernel means SIGKILL-ing (TerminateProcess on Windows) this child
outright and spawning a fresh one -- the OS reclaims a killed process
unconditionally, whether it was in an infinite Python loop, blocked
inside a C extension, or already dead from a segfault, so this works
even in every case the old in-process "just clear a dict" reset
couldn't touch. See kernel_manager.py for the supervising side of this
(the part with the timeout/generation bookkeeping that makes a
restart-while-a-request-is-in-flight resolve cleanly instead of
leaving that request hanging on its own end).

Everything below runs INSIDE the worker process once started. It talks
to kernel_manager.py purely via two plain multiprocessing.Queues of
JSON-safe dicts (no live build123d/OCCT objects ever cross the process
boundary -- those only ever live here, in this process's own
python_eval._PERSISTENT_USER_NS); render()/probe_*() already build
JSON-safe result dicts today (server.py sends them straight to the
frontend as-is), so this file's job is purely dispatch, not
reshaping.
"""

import os
import sys
import traceback

_BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
if _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)


def _probe_pick(PE, brep, cmd):
    """Moved verbatim from server.py's old in-process /probe_pick
    handler -- only the request/response shape changed (a plain dict
    in, a plain dict out, with an extra "_status" key the caller
    pops off to preserve the exact same 400-vs-200 behavior the old
    inline route had; see server.py's do_POST)."""
    var_name = cmd.get("variable", "")
    kind = cmd.get("kind", "edges")
    mode = cmd.get("mode", "inside")
    center = cmd.get("center")
    size = cmd.get("size")
    point = cmd.get("point")

    shape = PE.get_persisted_var(var_name)
    if shape is None:
        return {"_status": 400, "error": (
            f"No variable named '{var_name}' in memory. Render your "
            f"script at least once first (Jupyter-style, its "
            f"variables stay in memory between runs), then try again."
        )}

    if point is not None:
        try:
            px, py, pz = [float(v) for v in point]
            if kind == "faces":
                all_items = list(shape.faces())
                if not all_items:
                    return {"_status": 400, "error": "this shape has no faces"}
                best_i, best_d = None, float("inf")
                for i, f in enumerate(all_items):
                    d = f.distance_to((px, py, pz))
                    if d < best_d:
                        best_d, best_i = d, i
                return {"indices": [best_i], "total": len(all_items), "distance": best_d}
            else:
                all_items = list(shape.edges())
                if not all_items:
                    return {"_status": 400, "error": "this shape has no edges"}
                n_samples = 12
                best_i, best_d = None, float("inf")
                for i, e in enumerate(all_items):
                    for k in range(n_samples + 1):
                        t = k / n_samples
                        p = e.position_at(t)
                        d = ((p.X - px) ** 2 + (p.Y - py) ** 2 + (p.Z - pz) ** 2) ** 0.5
                        if d < best_d:
                            best_d, best_i = d, i
                return {"indices": [best_i], "total": len(all_items), "distance": best_d}
        except Exception as e:
            return {"_status": 400, "error": str(e)}

    try:
        probe = brep.translate(center, brep.box(size, center=True))
        if kind == "faces":
            all_items = list(shape.faces())
            matched = brep.faces_in_box(all_items, probe, mode=mode)
        else:
            all_items = list(shape.edges())
            matched = brep.edges_in_box(all_items, probe, mode=mode)
        matched_ids = {id(e) for e in matched}
        indices = [i for i, e in enumerate(all_items) if id(e) in matched_ids]
        return {"indices": indices, "total": len(all_items)}
    except Exception as e:
        return {"_status": 400, "error": str(e)}


def _probe_max_fillet(PE, brep, cmd):
    """Moved verbatim from server.py's old /probe_max_fillet handler."""
    var_name = cmd.get("variable", "")
    indices = cmd.get("indices", [])
    shape = PE.get_persisted_var(var_name)
    if shape is None:
        return {"radii": [0] * len(indices), "error": (
            f"No variable named '{var_name}' in memory. Render your "
            f"script at least once first, then try again."
        )}
    all_edges = list(shape.edges())
    radii = []
    for i in indices:
        try:
            e = all_edges[int(i)]
            radii.append(brep.max_fillet_radius(shape, [e], max_iterations=20))
        except Exception:
            radii.append(0)
    return {"radii": radii}


def _probe_highlight(PE, brep, cmd):
    """Moved verbatim from server.py's old /probe_highlight handler."""
    var_name = cmd.get("variable", "")
    indices = cmd.get("indices", [])
    kind = cmd.get("kind", "edges")
    shape = PE.get_persisted_var(var_name)
    if shape is None:
        return {"curves": [], "error": (
            f"No variable named '{var_name}' in memory. Render your "
            f"script at least once first, then try again."
        )}
    try:
        if kind == "faces":
            all_items = list(shape.faces())
            selected = [all_items[int(i)] for i in indices]
            edges_to_sample = [e for f in selected for e in f.edges()]
        else:
            all_items = list(shape.edges())
            edges_to_sample = [all_items[int(i)] for i in indices]
        n_samples = 12
        curves = []
        for e in edges_to_sample:
            pts = [e.position_at(k / n_samples) for k in range(n_samples + 1)]
            curves.append([[p.X, p.Y, p.Z] for p in pts])
        return {"curves": curves}
    except Exception as e:
        return {"curves": [], "error": str(e)}


def _drawing(PE, brep, cmd):
    """Runs `cmd["code"]` fresh (same as a normal render) and, unlike
    the "render" op, actually KEEPS the resulting `scene` list this
    process gets back from PE.run_python_script() (the "render" op
    above discards it into `_scene` -- see that function's own
    docstring: it's only ever thrown away because a render reply just
    needs the already-JSON-safe `result` dict for the 3D viewer).
    Every Mesh in `scene` that came from a real B-rep Shape (i.e. every
    show()n object built with brep.py's own cube()/sphere()/etc, NOT
    the raw openscad4 mesh-bridge escape hatch) carries that Shape on
    its own .brep_shape attribute (see python_eval.py's module
    docstring) -- exactly what's needed here, since real hidden-line-
    removal needs genuine B-rep topology, not the already-tessellated
    triangles server.py's /export/* routes work with.

    This is why "drawing" is its own op rather than reusing "render"'s
    reply: the live Shape objects can only be reached from INSIDE this
    process, during/right after the script that produced them actually
    runs -- by the time a reply dict crosses back over the queue to
    server.py, everything left is plain JSON, same as the module
    docstring at the top of this file promises."""
    result, scene = PE.run_python_script(
        cmd.get("code", ""), cmd.get("csg_resolution", 56),
        persist=cmd.get("persist", True),
    )
    if result.get("error"):
        return {"error": result["error"]}
    shapes = [m.brep_shape for m in (scene or []) if getattr(m, "brep_shape", None) is not None]
    if not shapes:
        return {"error": (
            "nothing to draw -- the shown shape(s) don't have real B-rep "
            "geometry to compute hidden-line-removed views from (e.g. they "
            "came from the raw openscad4 mesh-bridge escape hatch rather "
            "than brep.py's own cube()/sphere()/etc)."
        )}
    try:
        views = brep.technical_drawing_views(
            shapes, views=cmd.get("views"),
            custom_views=cmd.get("custom_views"),
            sections=cmd.get("sections"),
        )
    except Exception as e:
        return {"error": str(e)}
    return {"views": views}


def worker_main(cmd_q, result_q):
    """Entry point passed to multiprocessing.Process(target=...) --
    runs forever (until the process is killed by kernel_manager.py, or
    told to stop via the None sentinel) reading one command dict at a
    time off cmd_q and putting exactly one reply dict on result_q for
    each. Deliberately single-threaded/single-request-at-a-time: the
    manager's own call() already serializes callers with a lock before
    a command is ever put here, matching the single-flight guarantee
    server.py's old _OCCT_LOCK used to provide, but scoped to this
    process alone now instead of the whole app.

    python_eval/brep are imported HERE (inside the child), not at
    module level -- this is what gives every fresh kernel (every
    restart) a genuinely clean, from-scratch build123d/OCCT state, the
    same way a real Jupyter kernel restart re-imports everything from
    zero rather than just clearing a namespace inside an already-
    running interpreter."""
    import python_eval as PE
    import brep

    while True:
        try:
            cmd = cmd_q.get()
        except (EOFError, OSError):
            break
        if cmd is None:
            break  # clean-shutdown sentinel (not currently sent anywhere --
                    # restarts kill the process outright -- but harmless to
                    # support for a possible future graceful-stop path)

        op = cmd.get("op")
        try:
            if op == "render":
                result, _scene = PE.run_python_script(
                    cmd.get("code", ""),
                    cmd.get("csg_resolution", 56),
                    persist=cmd.get("persist", True),
                )
                reply = result
            elif op == "kernel_status":
                reply = {"persisted_vars": PE.persisted_variable_names()}
            elif op == "probe_pick":
                reply = _probe_pick(PE, brep, cmd)
            elif op == "probe_max_fillet":
                reply = _probe_max_fillet(PE, brep, cmd)
            elif op == "probe_highlight":
                reply = _probe_highlight(PE, brep, cmd)
            elif op == "drawing":
                reply = _drawing(PE, brep, cmd)
            else:
                reply = {"error": f"unknown kernel op: {op!r}"}
        except Exception as e:
            # Belt-and-suspenders: run_python_script() already catches
            # everything a *script* can throw and reports it in
            # result["error"] instead of raising -- this outer catch is
            # only for a bug in this dispatch code itself (or a probe_*
            # helper) misbehaving, so one bad request can't silently
            # starve result_q of its reply and hang the caller forever.
            traceback.print_exc()
            reply = {"error": f"internal kernel error: {e}"}

        try:
            result_q.put(reply)
        except Exception:
            # If the manager already gave up on us (e.g. a restart
            # raced this exact reply), there's nothing useful to do --
            # this process is about to be killed anyway.
            pass
