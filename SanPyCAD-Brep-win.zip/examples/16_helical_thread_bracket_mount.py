# 16_helical_thread_bracket_mount.py -- a helical "threaded stud" body
# (a small triangular cross-section, built with the opt-in openscad4
# bridge's cr2dt(), swept along a helix() path via sweep_sec2path())
# fitted into a filleted, shelled square housing -- like a threaded
# insert seated in a mounting bracket.
#
# The swept cross-sections come back as a list of per-turn profile
# pieces (c), which get lofted together (loft([mixed_polygon(p) for p
# in c])) into one solid, then clipped to a clean height with two
# split()s against flat planes (surface_from_points_grid() +
# plane_from_equation()) -- 'top' of z=0 keeps everything above the
# base, 'bottom' of z=10 trims the top flush, so the helix doesn't
# taper off mid-thread at either end.
#
# The housing itself is a 20x20x10 cube with a cylindrical bore
# through it (radius 5.9 -- just under the helix's own radius, so the
# thread body sits snugly inside once union()ed in), its outer edges
# rounded (8 edges captured with the app's own Pick tool, fillet r=2),
# then shelled hollow with offset(-0.5, openings=f1) through one
# picked face, before the two solids are combined with union().

import openscad4 as o

a = o.cr2dt([[0, 0.5], [-1, -0.5], [1, -0.5]])
b = o.helix(6, 1, 12, 5)
c = o.sweep_sec2path(a, b, orientation=3)
s1 = translate([0, 0, -1], loft([mixed_polygon(p) for p in c]))
pl1 = surface_from_points_grid(o.plane_from_equation([0, 0, 1, 0], [20, 20]))
s1 = split(s1, pl1, 'top')
pl2 = surface_from_points_grid(o.plane_from_equation([0, 0, 1, 10], [20, 20]))
s1 = split(s1, pl2, 'bottom')
d = translate([-10, -10, 0], cube([20, 20, 10]))
e = cylinder(r=5.9, h=10)
f = difference(d, e)
e1 = [f.edges()[i] for i in [5, 11, 0, 2, 3, 4, 12, 10]]  # <- probe list tool: e1
f = fillet(f, e1, 2)  # <- probe fillet tool: e1
f1 = [f.faces()[i] for i in [1]]  # <- probe list tool: f1
f = offset(f, -0.5, openings=f1)
g = union(f, s1)
show(g)
