# 42_manual_edge_face_selection_shell.py -- picking edges/faces by
# their raw index (rather than a geometric selector) for fillet() and
# offset(), using label_edges()/label_faces() to see which index is
# which before committing.
#
# a.edges()/sol.faces() return real build123d Edge/Face lists in a
# fixed order -- label_edges(b)/label_faces(e2) draws each item's own
# list index right on top of it in the viewer, so you can read off
# exactly which numbers to put in e1 (the edges to fillet) and which
# face to leave open (the offset()/shell() opening) without guessing.
# The commented-out show() calls below are exactly that lookup step --
# uncomment them first on a new shape to find your own index list,
# then comment them back out once you've got the numbers you need.

a = cube(10)
b = a.edges()
show(a, alpha=0.2)
# show(label_edges(b), 'blue')
e1 = [3, 8, 7, 10, 0, 2, 6, 4]
e1 = [b[i] for i in e1]
sol = fillet(a, e1, 2)
# show(sol)
# show(label_edges(sol.edges()), 'blue')
e2 = sol.faces()
show(label_faces(e2), 'blue')
sol = offset(sol, -.5, openings=e2[1])
show(sol)
