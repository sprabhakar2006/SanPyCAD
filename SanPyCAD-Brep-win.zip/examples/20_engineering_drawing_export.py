# 20_engineering_drawing_export.py -- generating a real engineering
# drawing sheet from a B-rep part: FRONT/TOP/RIGHT/ISO views with
# genuine hidden-line-removal (OCCT's HLRBRep_Algo, via build123d's
# Shape.project_to_viewport()), hidden edges dashed, laid out on one
# bordered sheet with a title block.
#
# Same notched-cone shape as brep.py's own bottom-of-file smoke test,
# picked here for the same reason: it has an actual hidden feature (the
# box notch, partly buried inside the cone) worth seeing drawn dashed
# in at least one of the 4 views, not just a plain convex shape where
# "hidden edges" would always come back empty.
#
# export_drawing_svg() does both halves of the work in one call:
# computing the views (technical_drawing_views(), the OCCT-touching
# half) and laying them out onto a sheet (drawing_layout.py's
# build_sheet_svg(), pure Python, no OCCT needed). Split them into two
# calls instead of using export_drawing_svg() directly whenever you
# want the raw per-view point data for something other than an SVG
# file -- e.g. show()ing the FRONT view's own outline back in the 3D
# viewport as a sanity check, or feeding it to a different sheet
# layout entirely.
#
# The toolbar's own "Drawing" button (and Export -> SVG, which is now
# the same thing) generates this exact same sheet for whatever's
# currently show()n, without writing export_drawing_svg() into the
# script at all -- this example is for when you want the file written
# straight to disk as part of the script itself, e.g. in a batch/
# unattended run.
#
# UNVERIFIED against a real build123d install, like every HLR-based
# function in this app so far (see brep.py's own module docstring, and
# technical_drawing_views()'s/_hlr_polylines()'s own docstrings for
# exactly what's assumed and what to check first if a rendered drawing
# looks wrong): the wiring (which build123d calls happen, with what
# arguments) has been checked against a mocked build123d, not the real
# geometry math.

a = cylinder(r1=20, r2=0, h=20)
b = box([10, 10, 40], center=True)
c = difference(a, translate([0, 0, -10], b))
show(c)

export_drawing_svg(c, "notched_cone_drawing.svg", part_name="Notched Cone", author="SanPyCAD Brep")
