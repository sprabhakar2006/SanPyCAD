# 09_notched_ramp_block.py -- an angled ramp/wedge profile (cr2dt()'s
# corner-radius point list, here with plain [x,y] pairs so every corner
# stays sharp) closed into a face with polygon() and extruded into a
# solid, unioned with an offset cube() block sitting on top of it, then
# every resulting edge rounded uniformly with a single fillet(c,
# c.edges(), ...) call -- the simplest way to soften a whole part at
# once when there's no need to single out particular edges.

a=linear_extrude( polygon(cr2dt([[0,0],[10,0],[0,10],[10,0],[0,10],[-20,0]])),10)
b=translate([0,10,8],cube([10,10,12]))
c=union(a,b)
c=fillet(c,c.edges(),0.5)
show(c)
