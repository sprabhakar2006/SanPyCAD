# 21_import_and_section_step_library.py -- importing every .step file
# sitting in this app's own folder, and laying them all out on one
# sheet with a quarter cut away from each so you can see inside.
#
# import_step()/import_brep() are new -- until now this app could only
# WRITE STEP/BREP files (export_step()/export_brep()), never read one
# back in. import_step(path) is build123d's own import_step(), which
# reads the file's real, exact geometry (not a tessellated/faceted
# approximation the way SanPyCAD's mesh-based sibling app would have
# to) and hands it back as a Compound -- a regular Shape, so every
# other function here (split(), fillet(), union(), volume(), etc.)
# just works on it, same as anything you built with cube()/cylinder()/
# etc. directly in a script.
#
# "Sectioning" here means split()-ing off two quarters with a pair of
# perpendicular cutting planes through the part's own center, keeping
# the two remaining quarters -- a standard cutaway view that opens up
# whatever's hidden inside (a cavity, a wall thickness, a thread bore)
# without hiding the rest of the part the way a full bisect would.
#
# Each part gets its own show() call (not bundled into one group()) --
# group() is for export_step()/export_brep() assemblies; show()ing
# each part separately is what keeps each one individually colored/
# selectable in the viewer, per group()'s own docstring.
#
# _safe_quarter_cut() below recomputes the cutting plane's position
# from the shape's CURRENT bounding box immediately before every cut,
# rather than reusing one center computed before any cuts happened --
# on an asymmetric part, cutting away most of the material on one axis
# can easily leave a remainder that no longer straddles the ORIGINAL
# box's own center in a different axis, and cutting with a plane that
# misses the (now-smaller) shape entirely raises build123d's
# "ValueError: Null TopoDS_Shape object" instead of just not cutting
# anything. It also falls back to leaving a part uncut (rather than
# crashing the whole batch) if a cut genuinely can't land on it, which
# can still happen on a multi-body assembly like lamp.step (41
# separate solids in one Compound, per its own STEP header) if the
# bounding box's geometric center happens to fall in an empty gap
# between two disconnected solids rather than inside any material --
# no single plane position is guaranteed to intersect every
# disconnected piece of an assembly at once.

STEP_DIR = "/Users/sanjeevprabhakar/SanPyCAD-Brep"

STEP_FILES = [
    "trial.step", "hollow_box.step", "mobile_stand.step", "sin_wave.step",
    "flat_rounded_plate.step", "wall_hook.step", "extracting_slider.step",
    "m1.step", "dome.step", "hollow_cube_with_threads.step", "lamp.step",
    "filleted_cut_sphere.step", "rounded_box.step", "sol2.step",
    "example_cap_wire.step", "sinewave.step",
]

NCOLS = 4       # 4 parts per row on the layout grid
MARGIN = 15.0   # gap between neighboring parts' bounding boxes


def _safe_quarter_cut(shape, normal, keep, label):
    """Cut `shape` with a plane through ITS OWN current bounding-box
    center along `normal`, keeping `keep` -- see the module comment
    above for why "current" (recomputed right before this specific
    cut) matters, and why this can still legitimately fail on a
    disconnected multi-body assembly. On failure, skip this one cut
    (return the shape unchanged) and say so, rather than losing the
    whole part -- or the whole batch -- to one awkward cut."""
    box = shape.bounding_box()
    mid = box.center()
    span = max(box.size.X, box.size.Y, box.size.Z) * 3  # comfortably bigger than the part
    cut = plane(normal, size=span, intercept=(mid.X, mid.Y, mid.Z))
    try:
        return split(shape, bisect_by=cut, keep=keep)
    except ValueError as e:
        echo(f"  (skipped a section cut on {label} -- {e})")
        return shape


# pass 1: just import + measure each part, so the grid's cell size can
# be sized off the single largest footprint in the whole set before
# anything gets cut or moved
loaded = [(fname, import_step(f"{STEP_DIR}/{fname}")) for fname in STEP_FILES]
loaded = [(fname, shape, shape.bounding_box()) for fname, shape in loaded]
cell = max(max(box.size.X, box.size.Y) for _, _, box in loaded) + MARGIN

# pass 2: section + place + show each part individually
for i, (fname, shape, box) in enumerate(loaded):
    size = box.size

    # cut away the +Y quarter, then the -Z quarter of what's left --
    # two perpendicular planes, each through THIS shape's own center
    # AT THAT MOMENT (see _safe_quarter_cut()), so the remaining 3/4
    # of the part shows 2 fresh cut faces straight through its middle,
    # wherever the interior actually is.
    shape = _safe_quarter_cut(shape, [0, 1, 0], "bottom", fname)
    shape = _safe_quarter_cut(shape, [0, 0, 1], "top", fname)

    col, row = i % NCOLS, i // NCOLS
    dx = col * cell - box.min.X
    dy = -row * cell - box.min.Y
    dz = -box.min.Z
    shape = translate([dx, dy, dz], shape)

    show(shape)
    echo(f"{fname}: {round(size.X, 1)} x {round(size.Y, 1)} x {round(size.Z, 1)}")
