# 19_draft_undercut_check.py -- draft/undercut analysis on the
# filleted sphere/cube cavity part (same shape as 08_filleted_cube_
# sphere_cut.py). Checks every point sampled across the shape against
# a chosen pull direction (here the same diagonal direction used as
# the slider's own pull direction in 17_slider_extraction_from_cavity_
# wall.py) and color-codes each one: red = undercut (negative draft --
# the tool would have to pass back through material to release, needs
# a slider/side-action), orange = insufficient draft (releases, but
# shallower than the 1 degree minimum given here), green = ok.
#
# Uses draft_check_markers() (small colored dot markers, one per
# SAMPLE POINT) rather than draft_check() (one status for an entire
# FACE) -- on a shape with a big curved face like this sphere, whose
# normal sweeps through a huge range of directions across that one
# single face, draft_check()'s per-face worst-case would mark the
# WHOLE curved surface as one uniform status even though roughly half
# of it is actually fine. draft_check_markers() keeps each point's own
# true status instead, so the red/green boundary actually follows the
# real geometry.
#
# tolerance=.2 (not a finer value like .01) -- checking every point
# across a whole sphere at high mesh density is noticeably slow,
# .2 is a reasonable balance of speed vs how fine a bad patch it can
# still catch; tighten it only if you need to resolve something small.
#
# The final line3d() just draws the pull direction itself as a visible
# line through the model, for a sanity check on which way "up" is for
# this particular draft check.

import openscad4 as o

a = cube(10)
b = sphere(10)
c = difference(b, a)
e1 = [c.edges()[i] for i in [4, 5, 6]]  # <- probe list tool: e1
c = fillet(c, e1, 1)  # <- probe fillet tool: e1
e2 = [c.edges()[i] for i in [0, 2, 3, 6, 7, 15]]  # <- probe list tool: e2
c = fillet(c, e2, 1)  # <- probe fillet tool: e2
show(c)
# export_step(c,"filleted_cut_sphere.step")
markers = draft_check_markers(c, o.rot('y-45z45', [1, 0, 0]), 1, .2)
colors = {"undercut": "red", "insufficient": "orange", "ok": "green"}
for status, m in markers.items():
    if m is not None:
        show(color(m, colors[status]))
# Direction of opening
l1 = o.vector2line(o.rot('y-45z45', [20, 0, 0]))
show(line3d(l1))
