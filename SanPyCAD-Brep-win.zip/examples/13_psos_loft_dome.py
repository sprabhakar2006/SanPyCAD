import openscad4 as o

a = o.prism(o.circle(20, s=50), o.arc_2p([-20, -20], [-20, 20], 20, -1, 50))
b = o.plane_from_equation([0, 0, 1, 0.001], [50, 50])
c = o.psos(b, a, [0, 0, 1], unidirection=1)
b = loft([cap_wire(p) for p in c], ruled=True)
show(b)
export_step(b, "dome.step")
