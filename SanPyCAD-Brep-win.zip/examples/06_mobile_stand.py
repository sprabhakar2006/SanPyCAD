# 06_mobile_stand.py -- 3-panel tiered mobile/tablet stand: the same
# arc_3p() curved rail closed into a flat panel with polygon(), reused
# for a wide base panel (a) and two progressively narrower fins (b, c),
# each fin tilted further back with axis_rot_1() rotating about a point
# on its own bottom edge -- unioned into one part, then rounded
# edge-by-edge with fillet(), using the app's own Pick tool (Click-to-
# Pick and manual index entry) to capture each named edge group
# (e1..e6) at its own radius.

a=arc_3p([10,150],[0,75],[10,0],s=10)
a=polygon(a+[[150,0],[150,150]])
a=linear_extrude(a,5)
b=arc_3p([10,150],[0,75],[10,0],s=10)
b=translate([65,0,0],axis_rot_1(polygon(b+[[60,0],[60,150]]),[0,1,0],[60,0,5],60))
b=linear_extrude(b,5)
c=arc_3p([10,150],[0,75],[10,0],s=10)
c=translate([133,0,0],axis_rot_1( polygon(c+[[17,0],[17,150]]),[0,1,0],[17,0,5],60))
c=linear_extrude(c,5)
d=union(a,b,c)
e1 = [d.edges()[i] for i in [61]]  # <- probe list tool: e1
d=fillet(d,e1,1)
e2 = [d.edges()[i] for i in [29]]  # <- probe list tool: e2
d=fillet(d,e2,5)
e3 = [d.edges()[i] for i in [0, 1, 3, 5, 7, 8, 9, 10, 12, 13, 17, 20, 22, 34, 38, 46, 47, 48, 49, 63, 66, 67, 68, 70, 71, 77, 79, 82, 84, 85, 86, 87, 88, 89, 91, 92, 94, 95, 113]]  # <- probe list tool: e3
d=fillet(d,e3,2)
e4 = [d.edges()[i] for i in [8, 10, 41]]  # <- probe list tool: e4
d=fillet(d,e4,2)
e5 = [d.edges()[i] for i in [50]]  # <- probe list tool: e5
d=fillet(d,e5,1)
e6 = [d.edges()[i] for i in [23, 25]]  # <- probe list tool: e6
d=fillet(d,e6,2)
show(d)
