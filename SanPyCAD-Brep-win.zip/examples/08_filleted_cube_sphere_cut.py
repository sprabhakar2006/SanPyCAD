# 08_filleted_cube_sphere_cut.py -- the simplest possible fillet-list
# demo: a sphere with a corner cube() bite taken out of it
# (difference()), then the two resulting rings of edges (where the
# cube's flat faces meet the sphere's curved one, and the cube's own
# 3 cut edges) rounded separately by radius -- edge indices captured
# with the app's own Pick tool (Click-to-Pick / manual index entry),
# not guessed by hand.

a=cube(10)
b=sphere(10)
c=difference(b,a)
e1 = [c.edges()[i] for i in [4, 5, 6]]  # <- probe list tool: e1
c=fillet(c,e1,1)
e2 = [c.edges()[i] for i in [0, 2, 3, 6, 7, 15]]  # <- probe list tool: e2
c=fillet(c,e2,1)
show(c)
export_step(c,"filleted_cut_sphere.step")
