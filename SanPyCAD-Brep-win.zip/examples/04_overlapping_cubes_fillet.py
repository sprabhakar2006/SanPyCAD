# 04_overlapping_cubes_fillet.py -- fillet() on the seam edges of two
# overlapping cubes fused with union(), edges picked by raw index
# (found via label_edges() the same way as 03_manual_edge_face_
# selection_shell.py).

a = cube(10)
b = translate([5, 5, 5], a)
c = union(a, b)
show(c, alpha=0.2)
show(label_edges(c.edges()), 'blue')
e1 = [9, 16, 17, 12, 13, 8]
e1 = [c.edges()[i] for i in e1]
sol = fillet(c, e1, 2)
show(sol)
