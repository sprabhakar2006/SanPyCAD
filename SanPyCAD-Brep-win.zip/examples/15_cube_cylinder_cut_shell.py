# 15_cube_cylinder_cut_shell.py -- a cube with an off-center cylindrical
# hole drilled through it (translate()d before the difference() so the
# hole doesn't land dead-center), three separate edge-treatment passes
# picked with the app's own Pick tool (indices captured as the e1/e2/e3
# "# <- probe ... tool" comments -- see 03_manual_edge_face_selection_
# shell.py for the manual, no-Pick-tool version of the same workflow):
# a group fillet() on 4 of the hole's/cube's edges together, a second
# fillet() on one more edge on its own, then a chamfer() on yet another
# edge -- fillet() and chamfer() take the same (shape, edges, radius)
# signature, so switching between them is a one-word change once the
# edges are picked. Finished off with offset(-0.5, openings=f1) to
# shell the whole thing hollow, leaving the one picked face (f1) open
# as the shell's opening.

a=cube(20)
b=translate([10,10,0],cylinder(r=5,h=21))
c=difference(a,b)
e1 = [c.edges()[i] for i in [5, 11, 0, 2]]  # <- probe list tool: e1
c = fillet(c, e1, 2)  # <- probe fillet tool: e1
e2 = [c.edges()[i] for i in [20]]  # <- probe list tool: e2
c = fillet(c, e2, 2)  # <- probe fillet tool: e2
e3 = [c.edges()[i] for i in [26]]  # <- probe list tool: e3
c = chamfer(c, e3, 2)  # <- probe fillet tool: e3
f1 = [c.faces()[i] for i in [15]]  # <- probe list tool: f1
c=offset(c,-0.5,openings=f1)
show(c)
