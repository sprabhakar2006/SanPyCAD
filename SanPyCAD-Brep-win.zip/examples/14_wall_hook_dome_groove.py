# 14_wall_hook_dome_groove.py -- a wall hook: a sphere/box-intersection
# dome with a fillet_line_circle()-shaped silhouette (built via the
# opt-in openscad4 bridge) extruded and subtracted out of it, the
# resulting rim edges rounded in two passes (radii 9 then 1, edge
# indices captured with the app's own Pick tool), then a spline-based
# groove (cr3dt() + equidistant_path() + loft() between two copies of
# the same cross-section) cut across it and its own edges rounded too --
# scale() applied non-uniformly right after that last fillet to correct
# the groove's proportions without disturbing the rest of the shape.
# Exports to STEP.

import openscad4 as o
a=o.sphere(20)
pl1=o.plane_from_equation([0,0,1,4])
l1=contiguous_chains( o.surface_solid_open_intersection(pl1,a))[0]
c1=o.circle(3,[-4,0])
l2=o.point_vector([15,-20],[0,40])
a1=o.fillet_line_circle(l2,c1,20,3)
a2=o.fillet_line_circle(l2,c1,20,1)
s1=[[-30,-20]]+o.flip(a1)+o.trim_sec_ip(o.flip(c1),a1[0],a2[0])[1:-1]+a2+[[-30,20]]
s1=interp_spline( o.equidistant_path(s1,50),1)
sol1=translate([0,0,4],linear_extrude(cap_wire(s1),25))
a=sphere(20)
b=translate([-30,-30,0],cube([60,60,25]))
c=intersection(a,b)
d=difference(c,sol1)
e1 = [d.edges()[i] for i in [4]]  # <- probe list tool: e1
d=fillet(d,e1,9)
e2 = [d.edges()[i] for i in [3]]  # <- probe list tool: e2
d=fillet(d,e2,1)
l1=cr3dt([[-30,0,4.5],[35,0,0],[5,0,5.5],[-3,0,6],[-7,0,1],[-7,0,-1],[-23,0,0]])
l1=o.equidistant_path(l1,pitch=5)
l2=cap_wire(interp_spline(l1,1))
l2=loft([translate([0,i,0],l2) for i in [-30,30]])
d=difference(d,l2).clean()
e3 = [d.edges()[i] for i in [15, 18]]  # <- probe list tool: e3
d=scale([1,30/40,15/20],fillet(d,e3,.8))
show(d)
export_step(d,'wall_hook.step')
