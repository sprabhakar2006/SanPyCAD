# 38_mirror_surface_demo.py -- mirror_surface(): mirrors a real shape
# across an arbitrary plane (any normal, any offset point), unlike
# mirror(v, shape) which always mirrors through the origin.

s1 = translate([0, -30, 0], sphere(10))
s2 = mirror_surface(s1, [1, 1, 0], [0, -20, 0])

show(s1)
show(color(s2, "cyan"))
