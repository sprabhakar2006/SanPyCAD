"""
kernel_breadcrumb.py -- a tiny, deliberately-dumb disk-backed "what was
the kernel worker doing right before it died" recorder, sitting
underneath kernel_process.py (the writer, running inside the worker
child) and kernel_manager.py (the reader, running in the main server
process, only ever consulted right after detecting the worker died on
its own -- see kernel_manager.py's own call()).

WHY THIS NEEDS TO BE A FILE, NOT A QUEUE MESSAGE: the whole point is
surviving exactly the failure kernel_manager.py's own docstring
describes -- a native OCCT segfault, which kills the worker process
outright with NO chance to put a final "here's what I was doing"
message on result_q (the process is just gone, mid-instruction, no
unwind, no except/finally runs). A plain file, written synchronously
(open+write+close, then os.replace() for an atomic rename so a reader
can never observe a half-written breadcrumb) survives that
unconditionally -- the same reason a crash reporter writes its state
to disk rather than trying to flush one last network message on the
way down.

WHY LINE-LEVEL, NOT JUST "a render was running": a render script is
usually one real CAD operation per top-level line (a fillet() here, a
difference() there) -- knowing WHICH line was executing when the
worker stopped responding is the difference between "the kernel
crashed, try again" and "the kernel crashed on line 14 (had reached
`f3 = fillet(sol, edges, 3)`)", which is what actually lets a user go
fix the offending call instead of blindly re-running the same crash.
See install_line_tracer() below for how that's captured without
slowing every render down -- a Python function call two frames deep
into build123d/OCCT is NOT traced, only line boundaries inside the
user's own top-level script are.

Deliberately best-effort throughout: every public function here is
wrapped so a bug or permissions error in the BREADCRUMB MACHINERY
ITSELF can never break, slow down, or change the result of the real
operation it's instrumenting -- a diagnostic aid that could itself
crash or hang the kernel would defeat its own purpose.
"""

import json
import os
import sys
import tempfile
import time

_PATH = os.path.join(tempfile.gettempdir(), "sanpycad_brep_kernel_breadcrumb.json")


def write(op, line=None, detail=None):
    """Records what the worker is about to do (called on every
    dispatched command) or is CURRENTLY doing (called from the line
    tracer on every top-level script line during a render) -- so
    whatever's on disk at the moment the process dies is always its
    most recent one. Best-effort: swallows every exception, since a
    disk hiccup here must never take down the real operation."""
    try:
        data = {"op": op, "line": line, "pid": os.getpid(), "ts": time.time()}
        if detail:
            data["detail"] = str(detail)[:200]
        tmp = f"{_PATH}.{os.getpid()}.tmp"
        with open(tmp, "w") as f:
            json.dump(data, f)
        os.replace(tmp, _PATH)  # atomic on POSIX and Windows alike
    except Exception:
        pass


def read():
    """The last breadcrumb written, as a dict, or None if there isn't
    one (a fresh install, or nothing has run since the last clear())."""
    try:
        with open(_PATH) as f:
            return json.load(f)
    except Exception:
        return None


def clear():
    """Called after a reply is safely delivered, so a stale breadcrumb
    from an earlier, since-completed op never gets blamed for a LATER
    crash it had nothing to do with."""
    try:
        os.remove(_PATH)
    except Exception:
        pass


def install_line_tracer(script_code_obj):
    """Turns on sys.settrace() scoped to ONLY `script_code_obj`'s own
    top-level line boundaries. The global tracer fires once per Python
    function CALL anywhere in the process; it returns None (meaning
    "don't trace inside this frame at all") for every frame except the
    exact compiled script object itself, so a call one level deeper --
    into brep.py, openscad4.py, build123d, or OCCT's own Python
    bindings -- is never traced. Cost is therefore one cheap global-
    tracer call per Python-level call in the whole process, plus one
    write() per TOP-LEVEL script line (only during a render) -- not one
    callback per line of library code, which would be a real slowdown.

    Caller is responsible for calling sys.settrace(None) afterwards
    (see python_eval.py's own try/finally around this) -- leaving a
    tracer installed after the render this was set up for has finished
    would keep tracing (and mis-attributing breadcrumbs to) whatever
    Python runs next in this same worker process.
    """
    def _local_tracer(frame, event, arg):
        if event == "line":
            write("render", line=frame.f_lineno)
        return _local_tracer

    def _global_tracer(frame, event, arg):
        if event == "call" and frame.f_code is script_code_obj:
            return _local_tracer
        return None

    try:
        sys.settrace(_global_tracer)
    except Exception:
        pass


def uninstall_line_tracer():
    try:
        sys.settrace(None)
    except Exception:
        pass
