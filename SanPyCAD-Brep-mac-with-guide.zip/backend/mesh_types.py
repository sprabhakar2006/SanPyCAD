"""
mesh_types.py -- the triangle-mesh container used purely for DISPLAY in
SanPyCAD-Brep. Every script builds real B-rep solids (via brep.py); a
Mesh here only ever holds a disposable tessellation of one, just so the
(necessarily triangle-based, since that's all WebGL can draw) viewer
has something to render. See Mesh.brep_shape's own comment below for
why the exact geometry is kept alongside it, and why that's what
STL/OBJ/SVG/DXF export write triangles from, while STEP/BREP export
(brep.py's export_step()/export_brep()) write the real geometry
instead, not a re-derivation from this display mesh.

Split out from what used to be scad_eval.py (the OpenSCAD-text-DSL
evaluator, removed from this B-rep-only app) since this Mesh class and
the color table are the one piece of that module python_eval.py still
needs -- everything else there was mesh/CSG evaluation logic with no
place in a B-rep-only app.
"""

import numpy as np


# subset of OpenSCAD/SVG named colors -- used by color()'s `c=` argument
COLOR_NAMES = {
    "red": (1, 0, 0), "green": (0, 0.5, 0), "lime": (0, 1, 0), "blue": (0, 0, 1),
    "yellow": (1, 1, 0), "cyan": (0, 1, 1), "magenta": (1, 0, 1), "white": (1, 1, 1),
    "black": (0, 0, 0), "gray": (0.5, 0.5, 0.5), "grey": (0.5, 0.5, 0.5),
    "orange": (1, 0.647, 0), "purple": (0.5, 0, 0.5), "pink": (1, 0.753, 0.796),
    "brown": (0.647, 0.165, 0.165), "silver": (0.753, 0.753, 0.753),
    "gold": (1, 0.843, 0), "navy": (0, 0, 0.5), "teal": (0, 0.5, 0.5),
    "indigo": (0.294, 0, 0.510), "violet": (0.933, 0.510, 0.933),
    "skyblue": (0.529, 0.808, 0.922), "steelblue": (0.275, 0.510, 0.706),
    "salmon": (0.980, 0.502, 0.447), "khaki": (0.941, 0.902, 0.549),
    "coral": (1, 0.498, 0.314), "turquoise": (0.251, 0.878, 0.816),
    "plum": (0.867, 0.627, 0.867), "orchid": (0.855, 0.439, 0.839),
    "beige": (0.961, 0.961, 0.863), "ivory": (1, 1, 0.941),
    "darkgreen": (0, 0.392, 0), "darkblue": (0, 0, 0.545),
    "darkred": (0.545, 0, 0), "lightgray": (0.827, 0.827, 0.827),
    "lightgrey": (0.827, 0.827, 0.827), "lightblue": (0.678, 0.847, 0.902),
    "lightgreen": (0.565, 0.933, 0.565), "maroon": (0.5, 0, 0),
    "olive": (0.5, 0.5, 0), "aqua": (0, 1, 1), "fuchsia": (1, 0, 1),
}
DEFAULT_COLOR = (0.85, 0.68, 0.15)  # a neutral CAD-preview yellow-gold


class Mesh:
    __slots__ = ("V", "F", "color", "alpha", "brep_shape", "source_var")

    def __init__(self, V, F, color=None, alpha=1.0, brep_shape=None, source_var=None):
        self.V = np.asarray(V, dtype=float).reshape(-1, 3) if len(V) else np.zeros((0, 3))
        self.F = np.asarray(F, dtype=int).reshape(-1, 3) if len(F) else np.zeros((0, 3), dtype=int)
        self.color = color
        self.alpha = alpha
        # The original exact build123d Shape this mesh is just a
        # tessellation of (see brep.py / python_eval.py's _as_mesh()) --
        # V/F are only a disposable triangle approximation for the
        # viewer; this is the real geometry, and it's what
        # export_step()/export_brep() actually write. Cleared by
        # copy_with() whenever geometry actually changes (e.g. a future
        # mesh-level edit), since at that point this Mesh no longer
        # corresponds to that exact shape.
        self.brep_shape = brep_shape
        # The script variable name this mesh came from, e.g. "sol1" for
        # a plain `show(sol1)` call -- None if the show() call wasn't a
        # simple bare-name argument (show(union(a, b)), show(a, 'red')
        # is still fine -- only the FIRST arg needs to be a bare name),
        # or the mesh was auto-shown rather than passed to show() at all
        # (see run_python_script()'s own single-candidate auto-show
        # fallback, which also sets this). Purely a UI convenience for
        # the viewer's click-to-pick tools (Pick Edges, 3D Dimension) so
        # clicking a shape can look up which script variable it belongs
        # to automatically instead of requiring it typed in by hand --
        # never used by any geometry operation, so getting it wrong or
        # leaving it None never affects correctness, only that
        # convenience. Metadata like color/alpha, not geometry -- always
        # carried through copy_with() regardless of whether V/F changed.
        self.source_var = source_var

    def copy_with(self, V=None, F=None):
        geometry_changed = V is not None or F is not None
        return Mesh(V if V is not None else self.V,
                     F if F is not None else self.F,
                     self.color, self.alpha,
                     brep_shape=None if geometry_changed else self.brep_shape,
                     source_var=self.source_var)

    def is_empty(self):
        return len(self.V) == 0 or len(self.F) == 0
