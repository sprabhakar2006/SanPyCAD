"""
kernel_manager.py -- owns the one running kernel_process.py worker
process and is the ONLY thing server.py talks to for anything that
used to touch build123d/OCCT directly in-process (see
kernel_process.py's module docstring for the full "why a subprocess"
rationale). server.py should never import python_eval.py or brep.py
itself anymore for request handling -- only MANAGER.call(...) and
MANAGER.restart().

The one property every method here is built around: restart() must
NEVER be blocked by an in-flight call(), no matter what that call is
stuck doing. That's the actual fix for "Reset Memory doesn't work
during a hang" -- restart() doesn't send the worker a message and wait
for a reply (a hung worker would never answer); it just kills the OS
process directly and replaces it, which the OS honors unconditionally.
"""

import queue
import threading
import time
import multiprocessing as mp

import kernel_process
import kernel_breadcrumb


class KernelManager:
    def __init__(self):
        self._call_lock = threading.Lock()   # serializes call() <-> call() only
        self._restart_lock = threading.Lock()  # serializes restart()/start() <-> each other
        self._generation = 0
        self._last_persisted_vars = []
        self.proc = None
        self.cmd_q = None
        self.result_q = None
        # NOTE: deliberately NOT spawning a worker here. See start()'s
        # docstring -- constructing this object must be a pure, side-
        # effect-free import-time thing (MANAGER = KernelManager() below
        # runs the instant anything does `import kernel_manager`/`import
        # server`), or multiprocessing's 'spawn' start method (the
        # default on macOS/Windows) breaks it, hard, every single time.

    # -- process lifecycle -------------------------------------------------
    def start(self):
        """Make sure a worker is running, spawning one if this is the
        first call. Safe to call repeatedly (a no-op once a worker
        exists) and safe to call from multiple threads at once.

        WHY THIS CAN'T JUST HAPPEN IN __init__ (this bit the very first
        real run on macOS): multiprocessing's 'spawn' start method --
        the default on macOS and Windows, unlike Linux's 'fork' --
        launches a child by re-running this app's OWN entry script
        (app.py) top to bottom in a fresh interpreter, specifically as
        if `__name__ == "__mp_main__"` rather than "__main__", so that
        `if __name__ == "__main__": main()` guards do NOT fire again.
        But app.py's `import server` line sits ABOVE that guard --
        every module it pulls in (this one included) gets imported
        during that bootstrap too, no way around it. If constructing
        MANAGER eagerly spawned a worker, then every worker's own
        bootstrap would itself try to spawn ANOTHER worker before it
        had even finished bootstrapping -- which Python explicitly
        forbids and raises RuntimeError(\"An attempt has been made to
        start a new process before the current process has finished
        its bootstrapping phase\") for, precisely to stop this kind of
        runaway recursive spawning. That's exactly what was happening:
        every worker died instantly on startup, before kernel_process.
        worker_main() ever ran a single line, and call()'s "the worker
        died on its own" path (meant for a genuine native OCCT crash)
        kept catching that and reporting it as one.

        Deferring the actual mp.Process().start() to here instead means
        merely IMPORTING this module (an unavoidable side effect of a
        bootstrapping child re-running app.py) does nothing -- a worker
        is only ever actually launched from app.py's main() (behind its
        own `if __name__ == "__main__":` guard, so it can only run in
        the real, once-per-launch app process) or lazily on this
        process's own first real call()/restart()."""
        with self._restart_lock:
            if self.proc is None:
                self._spawn()

    def _spawn(self):
        """Start a brand-new worker process with fresh Queues. Only
        ever called from inside _restart_lock (start() or restart()),
        so this itself doesn't need its own locking."""
        cmd_q = mp.Queue()
        result_q = mp.Queue()
        proc = mp.Process(
            target=kernel_process.worker_main,
            args=(cmd_q, result_q),
            daemon=True,  # dies with the main app; never an orphaned process
        )
        proc.start()
        self.proc, self.cmd_q, self.result_q = proc, cmd_q, result_q

    def restart(self):
        """Hard-kill the current worker (whatever it's doing -- stuck in
        an infinite loop, blocked deep inside OCCT, or already crashed)
        and replace it with a fresh one. Returns the number of
        variables that were kept in memory just before the restart
        (best-effort: the count as of the last completed call(), since
        a genuinely hung worker can't be asked "how many vars do you
        have" -- that would just be another stuck call).

        Deliberately ALWAYS a hard kill+respawn, even when the worker
        isn't stuck -- this is the same choice Jupyter's own "Restart
        Kernel" makes (it doesn't try to detect "is this one actually
        hung" first), so there's exactly one restart code path to
        trust rather than a fast "graceful" one that's well-tested and
        a rare "force" fallback that isn't."""
        with self._restart_lock:
            cleared = len(self._last_persisted_vars)
            old_proc, old_cmd_q, old_result_q = self.proc, self.cmd_q, self.result_q

            if old_proc is not None:
                try:
                    old_proc.kill()  # SIGKILL on POSIX / TerminateProcess on Windows --
                                      # unlike terminate()/SIGTERM, a stuck script
                                      # cannot catch, block, or outrun this.
                except Exception:
                    pass
                try:
                    old_proc.join(timeout=2)
                except Exception:
                    pass

            # Bump the generation BEFORE spawning the replacement, so any
            # call() currently polling against the old queues (see below)
            # notices on its very next poll and stops waiting on a queue
            # nothing will ever answer again.
            self._generation += 1
            self._last_persisted_vars = []
            self._spawn()

            for q in (old_cmd_q, old_result_q):
                try:
                    q.close()
                except Exception:
                    pass

            return cleared

    # -- request/response ----------------------------------------------
    def call(self, op, payload, poll_interval=0.15):
        """Send one {"op": op, **payload} command to the current worker
        and block until its reply arrives -- but "block" here means
        "poll in a loop that also notices a restart", not "wait on the
        queue forever": if restart() runs while this call is still
        waiting (someone hit Reset Memory mid-hang), this returns a
        clean error promptly instead of hanging the HTTP request that
        called it forever.

        Held under _call_lock so two concurrent callers (e.g. a Render
        racing the Pick panel's background highlight lookup) can't have
        their requests/replies cross-matched on the shared queues --
        the same single-flight-per-worker guarantee server.py's old
        _OCCT_LOCK gave the whole app, just scoped to actual
        worker traffic now instead of every route including
        /reset_kernel."""
        self.start()  # no-op once a worker is already running; a safety
                       # net in case app.py's own warm-up call() didn't
                       # run for some reason (e.g. this ever gets reused
                       # from a different entry point later)
        with self._call_lock:
            my_gen = self._generation
            cmd_q, result_q = self.cmd_q, self.result_q
            proc = self.proc

            try:
                cmd_q.put({"op": op, **payload})
            except Exception as e:
                return {"error": f"kernel is unavailable: {e}"}

            while True:
                if self._generation != my_gen:
                    return {"error": (
                        "Kernel was reset while this was still running -- "
                        "its result was discarded. Try again."
                    )}
                try:
                    reply = result_q.get(timeout=poll_interval)
                    break
                except queue.Empty:
                    if not proc.is_alive() and self._generation == my_gen:
                        # The worker died on its own -- most likely a native
                        # crash (segfault) inside OCCT, the exact failure
                        # mode server.py's old _OCCT_LOCK comment warned
                        # about. Previously that took the ENTIRE app down
                        # with it; now it only takes the worker down, and
                        # the app can recover on its own instead of the
                        # user having to relaunch.
                        # Read BEFORE restart() -- restart() doesn't touch
                        # the breadcrumb file itself (a fresh worker only
                        # overwrites it on its own first dispatched
                        # command), but reading first keeps the "crashed
                        # worker's last breadcrumb" and "trigger the
                        # restart" steps in the obvious order regardless.
                        crumb = kernel_breadcrumb.read()
                        kernel_breadcrumb.clear()
                        self.restart()
                        where = ""
                        if crumb and crumb.get("op") == "render" and crumb.get("line"):
                            where = f" (last reached script line {crumb['line']} before it went down)"
                        elif crumb and crumb.get("op"):
                            where = f" (was handling a {crumb['op']!r} request)"
                        return {"error": (
                            "The geometry kernel crashed while running this "
                            "(most likely a native crash in build123d/OCCT, "
                            f"often from invalid/degenerate geometry){where} "
                            "and has been automatically restarted. Variables "
                            "kept in memory were lost -- Render again."
                        )}
                    continue

            if op in ("render", "kernel_status") and isinstance(reply, dict):
                names = reply.get("persisted_vars")
                if names is not None:
                    self._last_persisted_vars = names
            return reply


# One shared kernel for the whole app -- this app only ever has one
# script editor/one "notebook" open at a time (see python_eval.py's own
# _PERSISTENT_USER_NS docstring), so a single module-level instance
# here matches that, the same way _PERSISTENT_USER_NS itself used to be
# a single module-level dict.
MANAGER = KernelManager()
