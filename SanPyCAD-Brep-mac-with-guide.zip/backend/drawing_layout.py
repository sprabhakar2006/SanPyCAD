"""
drawing_layout.py -- lays a set of already-computed 2D views out onto one
engineering-drawing sheet (a border, a title block, and one labeled
quadrant per view). Deliberately pure Python with ZERO build123d/OCCT
dependency: the actual hidden-line-removal happens in brep.py (inside the
kernel worker process, where the live B-rep Shape objects are -- see
kernel_process.py's "drawing" op), which reduces every view down to plain
JSON-safe 2D polyline point lists before it ever gets here. This module's
only job is arranging those polylines -- it's the same "OCCT-touching code
stays in the kernel process, everything else is plain data" split this app
already uses for build_svg_text()/build_dxf_text() in server.py (mesh
triangle data in, SVG/DXF text out, no OCCT needed there either).

Being OCCT-free is also why this lives in its own module rather than
inside brep.py or server.py directly: it's safe to import from BOTH sides
of the process boundary -- brep.py's own export_drawing_svg() (a script-
callable convenience that writes a drawing straight to a file, run INSIDE
the kernel worker process) and server.py's /drawing, /export/svg, and
/drawing_data routes (run in the app's main process, receiving already-
JSON-safe view data back over the kernel_manager queue) all need this
same layout logic, and neither one is a process the other side's code can
safely run in.

Two ways to consume a layout, both built on the same compute_layout():
  - build_sheet_svg(): a finished, flat SVG file -- what /export/svg and
    the toolbar's "Drawing" button (one-click, no editor) hand back.
  - layout_for_frontend(): plain JSON (quadrant rects + transform numbers,
    NOT already-applied to the polylines) -- what /drawing_data hands the
    browser's own interactive 2D Drawing tab, which draws the views AND
    lets you click points/circles/edges to add real-unit dimensions of
    its own (linear/radius/angle/center-distance) before downloading a
    dimensioned SVG -- see index.html's own drawing-tab code for that
    half. Sending transform NUMBERS instead of pre-transformed points
    means the browser can convert a click back to the shape's own real-
    world coordinates (screen pixels alone can't give you a meaningful
    "12.50mm" dimension) using the exact same math this module used to
    place things on the page, not a second guess at it.

Expected input shape (the same for every caller): a `views` dict keyed by
view label ("FRONT", "TOP", "RIGHT", "ISO", or any other labels a caller
wants), each value a dict:
    {"visible": [polyline, polyline, ...], "hidden": [polyline, polyline, ...]}
where a polyline is a flat list of [x, y] pairs (already real-world 2D
coordinates in that view's own local frame -- NOT yet scaled/positioned
onto the sheet; this module figures out each view's own bounding box and
fits it into its own quadrant independently). "visible" edges are drawn
as solid lines, "hidden" edges (behind the surface from that view's own
camera angle) as dashed lines -- the standard drafting convention.
"""

import datetime
import math
import re


# 4 quadrants, in reading order (top-left, top-right, bottom-left,
# bottom-right). This loosely follows a standard 3-view + isometric
# drawing sheet (FRONT top-left, TOP below it, RIGHT beside FRONT, ISO
# in the remaining corner) WITHOUT attempting true 1st/3rd-angle
# projection ALIGNMENT between views (each quadrant independently
# fits/centers its own view) -- getting views to share a common scale
# and register edge-to-edge the way a drafter's board would is a
# meaningfully bigger project on top of this (matching scale across
# views with very different bounding boxes, aligning shared axes"); this
# gives 4 correctly-labeled, correctly-shaped views on one sheet, not a
# fully registered drafting-standard layout yet.
_QUADRANT_ORDER = ["FRONT", "RIGHT", "TOP", "ISO"]


def _bbox_of_polylines(polylines):
    xs = [p[0] for line in polylines for p in line]
    ys = [p[1] for line in polylines for p in line]
    if not xs:
        return None
    return min(xs), min(ys), max(xs), max(ys)


def _fit_transform_params(bbox, cell_x, cell_y, cell_w, cell_h, pad_frac=0.08):
    """The numbers behind fitting a view's own bbox into a cell rect,
    uniformly scaled (never stretched) with `pad_frac` breathing room on
    every side -- returned as a plain dict (scale/off_x/off_y/draw_h/
    min_x/min_y) rather than an already-applied closure, so BOTH
    build_sheet_svg() (applies it immediately, server-side, to build a
    flat SVG) and layout_for_frontend() (ships the numbers as JSON so
    the browser applies them itself, live, to arbitrary points a user
    clicks) can use the exact same fit. See apply_transform() for how
    these 6 numbers turn an (x, y) point into an SVG-space one --
    that's the one piece of math that must stay identical between the
    Python side and index.html's own JS copy of it."""
    if bbox is None:
        # No geometry at all for this view -- degenerate but valid: every
        # point maps to the cell's own center, scale is irrelevant (no
        # points to scale) but kept positive so downstream division by
        # it (e.g. converting a screen-pixel measurement back to real-
        # world units) never divides by zero.
        return {
            "scale": 1.0, "off_x": cell_x + cell_w / 2, "off_y": cell_y + cell_h / 2,
            "draw_h": 0.0, "min_x": 0.0, "min_y": 0.0,
        }
    min_x, min_y, max_x, max_y = bbox
    span_x = max(max_x - min_x, 1e-6)
    span_y = max(max_y - min_y, 1e-6)
    pad_x = cell_w * pad_frac
    pad_y = cell_h * pad_frac
    avail_w = cell_w - 2 * pad_x
    avail_h = cell_h - 2 * pad_y
    scale = min(avail_w / span_x, avail_h / span_y)
    draw_w = span_x * scale
    draw_h = span_y * scale
    off_x = cell_x + (cell_w - draw_w) / 2
    off_y = cell_y + (cell_h - draw_h) / 2
    return {"scale": scale, "off_x": off_x, "off_y": off_y, "draw_h": draw_h,
            "min_x": min_x, "min_y": min_y}


def apply_transform(x, y, t):
    """(x, y) in a view's own real-world local frame -> (svg_x, svg_y) on
    the sheet, using the 6 numbers from _fit_transform_params(). Y is
    flipped (SVG's y grows downward; every view here is computed in a
    math/CAD-style y-grows-upward frame) -- index.html's own JS has an
    identical function for exactly this reason; if the two ever drift
    apart, dimensions added in the browser will land in the wrong place
    relative to the geometry, so keep them matching if either changes."""
    sx = t["off_x"] + (x - t["min_x"]) * t["scale"]
    sy = t["off_y"] + t["draw_h"] - (y - t["min_y"]) * t["scale"]
    return sx, sy


def _extra_label_sort_key(label):
    """Sort key for a non-standard (custom-view or section) quadrant
    label -- its OWN trailing "-N" counter (e.g. "VIEW-3" -> 3,
    "SECTION-2 (Z=5.0)" -> 2, matching index.html's own auto-generated
    `VIEW-${n}`/`SECTION-${n} (...)` naming), NOT `views`' raw dict
    insertion order.

    Why this matters (a real, reproduced bug, not a hypothetical):
    technical_drawing_views() builds its own returned dict by processing
    ALL custom_views first, THEN ALL sections -- a fixed loop order, with
    no relationship to which the user actually added first. Sorting
    `labels` by plain dict-insertion order (what this function replaced)
    meant adding a NEW custom view while an OLDER section view already
    existed would insert that new view's key into the dict BEFORE the
    older section's key, purely because of that fixed processing
    sequence -- which silently moved the section into a different grid
    cell (see compute_layout()'s own comment for why cell/transform
    STABILITY matters: index.html's tryIncrementalViewUpdate() checks
    for exactly this and, correctly, refuses an unsafe in-place update
    the moment anything existing has moved -- falling back to a full,
    dimension-clearing rebuild instead). Confirmed directly against this
    function: 2 renders, only difference is ONE more custom view added,
    and an existing section's own cell moved from row 2/col 1 to row
    2/col 2.

    Sorting by each label's own counter instead recovers TRUE creation
    order regardless of which processing loop touches it first -- but
    only holds as long as VIEW-N and SECTION-N are drawn from ONE
    shared, ever-incrementing counter on the frontend (so, e.g., VIEW-1,
    SECTION-2, VIEW-3 in creation order, not VIEW-1/VIEW-2 and
    SECTION-1/SECTION-2 as 2 independent sequences) -- see index.html's
    own `extraViewCounter`. Falls back to a large sentinel (pushes it to
    the end, but via Python's stable sort otherwise preserves original
    relative dict order among any such labels) for anything that
    doesn't end in "-<digits>" -- shouldn't normally happen since every
    auto-generated name does, but not worth ever crashing over."""
    m = re.search(r"-(\d+)", label)
    return int(m.group(1)) if m else float("inf")


def compute_layout(views, sheet_w=1000.0, cell_h=290.0, titleblock_h=90.0, margin=16.0):
    """The shared geometry-placement step behind both build_sheet_svg()
    and layout_for_frontend(): which views go in which quadrant, and
    each quadrant's own fit-to-cell transform. Returns (labels,
    quadrants, sheet) where:
      labels: view labels in the order they're drawn (reading order --
        see _QUADRANT_ORDER's own docstring)
      quadrants: {label: {"cell": {"x","y","w","h"}, "transform": {...
        the 6 _fit_transform_params() numbers}}}
      sheet: {"width", "height", "margin", "titleblock_y", "titleblock_h"}

    FIXED cell size, always 2 columns, however many rows the label
    count needs (grid_rows = ceil(n / 2)) -- the sheet's own HEIGHT
    grows to fit, rather than shrinking every cell to keep a constant
    overall sheet size the way an earlier version of this function did
    (fitting N views into one fixed-size sheet, cells getting smaller
    as N grew). That earlier approach reflowed EVERY quadrant's own
    cell/transform any time the view COUNT changed at all -- meaning
    the Drawing tab's own "Add View"/Section tool couldn't add or
    remove a view without invalidating every dimension already placed
    on EVERY OTHER view too (their svg-space coordinates are tied to
    the exact cell/transform they were placed against). With a fixed
    cell size, labels earlier in `labels`' own ordering (see
    _QUADRANT_ORDER below -- FRONT/RIGHT/TOP/ISO always come first, any
    extra labels sorted by TRUE creation order -- see
    _extra_label_sort_key()'s own docstring for why that needs its own
    sort rather than just trusting `views`' raw dict order) keep the
    EXACT SAME cell/transform regardless of how many more get appended
    after them, or removed from the end -- which is what index.html's
    own tryIncrementalViewUpdate() checks for before deciding it's safe
    to add/remove just the ONE changed quadrant in place instead of
    rebuilding (and so clearing every placed dimension on) the whole
    sheet.
    """
    labels = [lbl for lbl in _QUADRANT_ORDER if lbl in views]
    labels += sorted(
        (lbl for lbl in views if lbl not in _QUADRANT_ORDER),
        key=_extra_label_sort_key,
    )  # any extra/custom-view/section labels, in TRUE creation order (see that function's own docstring)

    inner_x = margin
    inner_y = margin
    grid_cols = 2
    inner_w = sheet_w - 2 * margin
    cell_w = inner_w / grid_cols

    n = max(1, len(labels))
    grid_rows = math.ceil(n / grid_cols)

    quadrants = {}
    for i, label in enumerate(labels):
        row, col = divmod(i, grid_cols)
        cx = inner_x + col * cell_w
        cy = inner_y + row * cell_h
        view = views.get(label, {})
        bbox = _bbox_of_polylines(view.get("visible", []) + view.get("hidden", []))
        transform = _fit_transform_params(bbox, cx, cy, cell_w, cell_h)
        quadrants[label] = {
            "cell": {"x": cx, "y": cy, "w": cell_w, "h": cell_h},
            "transform": transform,
        }

    sheet_h = margin * 2 + grid_rows * cell_h + titleblock_h
    sheet = {
        "width": sheet_w, "height": sheet_h, "margin": margin,
        "titleblock_y": sheet_h - margin - titleblock_h, "titleblock_h": titleblock_h,
    }
    return labels, quadrants, sheet


def layout_for_frontend(views, part_name="Part", author=None, date=None,
                         sheet_w=1000.0, cell_h=290.0, titleblock_h=90.0):
    """Plain-JSON version of a drawing layout, for index.html's own
    interactive 2D Drawing tab (see /drawing_data in server.py) --
    everything build_sheet_svg() would draw, as numbers instead of an
    already-rendered SVG: each view's own REAL-WORLD polylines
    (unchanged from `views` -- NOT pre-transformed to sheet coordinates,
    so the browser can convert a click back to real units) plus its
    quadrant/transform, the sheet's own overall dimensions, and the
    title block text. The browser applies apply_transform() itself
    (see that function's own docstring on why the two copies of this
    math need to stay identical) to actually draw things and to convert
    a mouse click's sheet-space position back into the real-world units
    a dimension needs to report.
    """
    if date is None:
        date = datetime.datetime.utcnow().strftime("%Y-%m-%d")
    labels, quadrants, sheet = compute_layout(views, sheet_w, cell_h, titleblock_h)

    def _view_out(lbl):
        v = views.get(lbl, {})
        out = {"visible": v.get("visible", []), "hidden": v.get("hidden", [])}
        # A custom/section view that couldn't be computed (e.g. a
        # section plane that missed every shape) still gets a labeled,
        # empty quadrant with "error" set, rather than silently
        # vanishing from the sheet -- see brep.py's
        # technical_drawing_views() for where this comes from.
        if v.get("error"):
            out["error"] = v["error"]
        if v.get("warning"):
            out["warning"] = v["warning"]
        return out

    return {
        "labels": labels,
        "views": {lbl: _view_out(lbl) for lbl in labels},
        "quadrants": quadrants,
        "sheet": sheet,
        "title": {"part_name": part_name, "author": author, "date": date},
    }


def _polyline_path(points, t):
    if len(points) < 2:
        return None
    pts = [apply_transform(p[0], p[1], t) for p in points]
    d = "M " + " L ".join(f"{x:.3f},{y:.3f}" for x, y in pts)
    return d


def build_sheet_svg(views, part_name="Part", author=None, date=None,
                     sheet_w=1000.0, cell_h=290.0, titleblock_h=90.0):
    """Builds one complete drawing-sheet SVG (border + title block + one
    quadrant per view in `views`) and returns it as a UTF-8 encoded
    bytes object, ready to write to a file or send as an HTTP response
    body -- same return convention as server.py's own build_svg_text()/
    build_dxf_text().

    `views`: dict of view-label -> {"visible": [...], "hidden": [...]}
    (see this module's own docstring for the exact polyline format).
    Only labels present in `views` get drawn -- a caller that only
    computed 1 view (or wants a custom label set) still gets a valid
    sheet back, just with fewer/relabeled quadrants, not an error.

    `part_name`/`author`/`date`: title block text. `date` defaults to
    today (UTC) if not given. There's no computed engineering SCALE
    value in the title block yet -- each view is independently fit to
    its own quadrant (see _QUADRANT_ORDER's docstring above), so a
    single meaningful "1:N" ratio across every view doesn't exist yet;
    the title block says "SCALE: NTS" (Not To Scale) instead of a
    number that would be misleading.
    """
    if date is None:
        date = datetime.datetime.utcnow().strftime("%Y-%m-%d")

    labels, quadrants, sheet = compute_layout(views, sheet_w, cell_h, titleblock_h)
    margin = sheet["margin"]
    sheet_h = sheet["height"]  # computed, grows with row count -- see compute_layout()'s own docstring

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {sheet_w:.1f} {sheet_h:.1f}" '
        f'width="{sheet_w:.1f}" height="{sheet_h:.1f}">',
        "<!-- Exported from SanPyCAD Brep: engineering drawing (multi-view, hidden-line-removed) -->",
        f'<rect x="0" y="0" width="{sheet_w:.1f}" height="{sheet_h:.1f}" fill="white"/>',
        f'<rect x="{margin:.1f}" y="{margin:.1f}" width="{sheet_w - 2 * margin:.1f}" '
        f'height="{sheet_h - 2 * margin:.1f}" fill="none" stroke="black" stroke-width="1.2"/>',
    ]

    stroke_w = max(0.5, sheet_w / 900)
    font_size = max(9.0, sheet_w / 70)

    for label in labels:
        q = quadrants[label]
        cx, cy, cell_w, cell_h = q["cell"]["x"], q["cell"]["y"], q["cell"]["w"], q["cell"]["h"]
        t = q["transform"]
        view = views.get(label, {})
        visible = view.get("visible", [])
        hidden = view.get("hidden", [])

        parts.append(
            f'<rect x="{cx:.2f}" y="{cy:.2f}" width="{cell_w:.2f}" height="{cell_h:.2f}" '
            f'fill="none" stroke="#bbbbbb" stroke-width="{stroke_w * 0.6:.3f}"/>'
        )
        # Hidden edges first (dashed), visible edges drawn on top (solid) --
        # standard drafting convention, and means a visible edge that
        # happens to sit exactly on top of a hidden one (common, e.g. a
        # through-hole's far rim lining up with its near rim in some views)
        # reads as the solid line, not a dash pattern fighting with itself.
        for line in hidden:
            d = _polyline_path(line, t)
            if d:
                parts.append(
                    f'<path d="{d}" fill="none" stroke="#888888" '
                    f'stroke-width="{stroke_w * 0.7:.3f}" stroke-dasharray="{stroke_w * 3:.2f},{stroke_w * 2:.2f}"/>'
                )
        for line in visible:
            d = _polyline_path(line, t)
            if d:
                parts.append(
                    f'<path d="{d}" fill="none" stroke="black" '
                    f'stroke-width="{stroke_w:.3f}" stroke-linecap="round" stroke-linejoin="round"/>'
                )
        parts.append(
            f'<text x="{cx + 6:.2f}" y="{cy + font_size + 4:.2f}" '
            f'font-family="monospace" font-size="{font_size:.2f}" fill="#333333">{label}</text>'
        )

    # -- title block: bottom strip, a few labeled cells --------------------
    tb_y = sheet["titleblock_y"]
    tb_w = sheet_w - 2 * margin
    parts.append(
        f'<rect x="{margin:.1f}" y="{tb_y:.1f}" width="{tb_w:.1f}" height="{titleblock_h:.1f}" '
        f'fill="none" stroke="black" stroke-width="1.2"/>'
    )
    name_col_w = tb_w * 0.5
    parts.append(
        f'<line x1="{margin + name_col_w:.1f}" y1="{tb_y:.1f}" '
        f'x2="{margin + name_col_w:.1f}" y2="{tb_y + titleblock_h:.1f}" stroke="black" stroke-width="0.8"/>'
    )
    mid_y = tb_y + titleblock_h / 2
    parts.append(
        f'<line x1="{margin + name_col_w:.1f}" y1="{mid_y:.1f}" '
        f'x2="{sheet_w - margin:.1f}" y2="{mid_y:.1f}" stroke="black" stroke-width="0.8"/>'
    )
    right_col_x = margin + name_col_w
    right_col_w = tb_w - name_col_w
    parts.append(
        f'<line x1="{right_col_x + right_col_w / 2:.1f}" y1="{tb_y:.1f}" '
        f'x2="{right_col_x + right_col_w / 2:.1f}" y2="{mid_y:.1f}" stroke="black" stroke-width="0.8"/>'
    )
    title_font = max(12.0, sheet_w / 55)
    label_font = max(8.0, sheet_w / 90)
    parts.append(
        f'<text x="{margin + 10:.1f}" y="{tb_y + title_font + 8:.1f}" '
        f'font-family="sans-serif" font-size="{title_font:.2f}" font-weight="bold">{_esc(part_name)}</text>'
    )
    parts.append(
        f'<text x="{margin + 10:.1f}" y="{tb_y + titleblock_h - 10:.1f}" '
        f'font-family="sans-serif" font-size="{label_font:.2f}" fill="#555555">'
        f'SanPyCAD Brep -- multi-view engineering drawing (hidden lines dashed)</text>'
    )
    if author:
        parts.append(
            f'<text x="{right_col_x + 8:.1f}" y="{tb_y + label_font + 6:.1f}" '
            f'font-family="sans-serif" font-size="{label_font:.2f}">AUTHOR: {_esc(author)}</text>'
        )
    parts.append(
        f'<text x="{right_col_x + right_col_w / 2 + 8:.1f}" y="{tb_y + label_font + 6:.1f}" '
        f'font-family="sans-serif" font-size="{label_font:.2f}">DATE: {_esc(date)}</text>'
    )
    parts.append(
        f'<text x="{right_col_x + 8:.1f}" y="{mid_y + label_font + 6:.1f}" '
        f'font-family="sans-serif" font-size="{label_font:.2f}">SCALE: NTS</text>'
    )
    parts.append(
        f'<text x="{right_col_x + right_col_w / 2 + 8:.1f}" y="{mid_y + label_font + 6:.1f}" '
        f'font-family="sans-serif" font-size="{label_font:.2f}">SHEET 1 OF 1</text>'
    )

    parts.append("</svg>")
    return ("\n".join(parts) + "\n").encode("utf-8")


def _esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))
