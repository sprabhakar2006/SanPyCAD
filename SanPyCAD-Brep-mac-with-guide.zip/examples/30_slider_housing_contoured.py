# slider_housing() -- builds a mold-base block around a slider
# (mesh_cap_ribbon()'s own output), with the block's own outer wall
# following the slider's TRUE organic profile (a real OCCT curve-
# offset of its 3D boundary, via mesh_boundary_loop() -- the same
# exact-edge technique mesh_cap_ribbon() itself uses), not a generic
# bounding rectangle. Same mouse-body geometry as example 26 (copied
# verbatim) so this is directly comparable.
#
# Top and bottom are cut at DIFFERENT parting planes here (pp/pp1) --
# a deliberate deviation from slider_housing()'s own "same plane_point
# for both sides" advice, just to show the two don't have to match;
# each housing is still self-consistent, they just won't share one
# flush parting face the way a same-pp pair would.
#
# `direction` stays [0, 0, 1] for BOTH the top and bottom calls, in
# both mesh_cap_ribbon() and slider_housing() -- side="top"/"bottom"
# is what picks which half, not direction. Passing [0, 0, -1] for the
# bottom slider_housing() call (instead of matching the [0, 0, 1] used
# to build bot_slider itself) reads a completely different boundary
# loop than the one bot_slider was actually cut from, so the wall and
# the pocket end up misaligned -- confirmed by testing.
#
# `wall_points=16` (down from the 80 default) mainly to keep the
# housing's own final difference(housing, slider) boolean fast while
# iterating -- raise it again once you're just re-rendering a known-
# good result.

t1 = o.time.time()

a = o.cr2dt([[-20, 0, 15], [40, 0, 15], [0, 40], [5, 40, 20], [-50, 0, 20], [5, -40]])
tx = o.a_(a).mean(0)
a = o.translate_2d(-tx, a)
b = o.translate([0, 0, -20], o.sphere(50))
p1 = [[0, 0], [15, 50]]
s1 = o.prism(a, p1)
l1 = o.translate_2d([-25, 3], o.sinewave(50, 1.5, 3, 50))
l1 = o.mirror_line(l1, [0, 1, 0], [0, 0, 0])
l2 = o.translate_2d([0, -20], o.circle(50))
l3 = o.rot2d(30, [[0, 0], [-10, 0]])
l3 = o.rot('x90z-90', o.flip(o.line2length(o.flip(o.line2length(
    o.cir_line_tangent(l2, l3), 50)), 100)))
s2 = o.sweep_sec2path(l1, l3)
b = o.psos(s2, b, [0, 0, -1] @ o.xrot(-30), 1e7, 1, 3)
b = [o.bspline_closed(p, 3, 50) for p in b]

l1 = o.equidistant_pathc(o.contiguous_chains(o.two_solids_intersection(b, s1))[0], 100)
l2 = o.o_3d(l1, b, 7, outside=0)
l3 = o.o_3d(l1, s1, -3, outside=0)
f3 = o.convert_3lines2fillet(l3, l2, l1, closed_loop=1)
f3 = o.solid_from_fillet_closed(f3, -3)

s1 = loft([cap_wire(mixed_wire(p)) for p in s1])
b = solid_from_closed_rings(b, ruled=True)
sol = intersection(s1, b)

f3 = solid_from_wedge_grid(f3, ruled=True, max_stations=50)
sol = difference(sol, f3)

pp = [0, 0, 40]
pp1 = [0, 0, -40]

top_slider = mesh_cap_ribbon(sol, [0, 0, 1], side="top", plane_point=pp)
bot_slider = mesh_cap_ribbon(sol, [0, 0, 1], side="bottom", plane_point=pp1)

top_h = slider_housing(sol, [0, 0, 1], side="top", plane_point=pp,
                        margin=8, backing=8, slider=top_slider,
                        wall_points=16)
bot_h = slider_housing(sol, [0, 0, 1], side="bottom", plane_point=pp1,
                        margin=8, backing=8, slider=bot_slider,
                        wall_points=16)

# Pulled apart along Z purely for display -- top_h/top_slider share
# one translation, bot_h/bot_slider share the other, so their own
# relative alignment (the actual thing worth checking) is unchanged.
show(translate([0, 0, 60], top_h), 'red', alpha=0.6)
show(translate([0, 0, -60], bot_h), 'grey', alpha=0.6)

show(translate([0, 0, 60], top_slider), 'yellow')
show(translate([0, 0, -60], bot_slider), 'green')

t2 = o.time.time()
t2 - t1
