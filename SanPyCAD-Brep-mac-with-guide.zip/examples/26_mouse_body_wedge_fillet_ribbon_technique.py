# The literal port of SanPyCAD's own mouse-body example
# (102_python_fillet_prism_sculpted_sphere_intersection.py), using the
# offset-curve/ribbon fillet technique (convert_3lines2fillet() +
# solid_from_wedge_grid()) instead of a native fillet() -- the seam
# between s1 and b doesn't chain into one clean OCCT edge loop, so a
# plain fillet() call isn't viable here.

t1 = o.time.time()

a = o.cr2dt([[-20, 0, 15], [40, 0, 15], [0, 40], [5, 40, 20], [-50, 0, 20], [5, -40]])
tx = o.a_(a).mean(0)
a = o.translate_2d(-tx, a)
b = o.translate([0, 0, -20], o.sphere(50))
p1 = [[0, 0], [15, 50]]
s1 = o.prism(a, p1)
l1 = o.translate_2d([-25, 3], o.sinewave(50, 1.5, 3, 50))
l1 = o.mirror_line(l1, [0, 1, 0], [0, 0, 0])
l2 = o.translate_2d([0, -20], o.circle(50))
l3 = o.rot2d(30, [[0, 0], [-10, 0]])
l3 = o.rot('x90z-90', o.flip(o.line2length(o.flip(o.line2length(
    o.cir_line_tangent(l2, l3), 50)), 100)))
s2 = o.sweep_sec2path(l1, l3)
b = o.psos(s2, b, [0, 0, -1] @ o.xrot(-30), 1e7, 1, 3)
b = [o.bspline_closed(p, 3, 50) for p in b]

l1 = o.equidistant_pathc(o.contiguous_chains(o.two_solids_intersection(b, s1))[0], 100)
l2 = o.o_3d(l1, b, 7, outside=0)
l3 = o.o_3d(l1, s1, -3, outside=0)
f3 = o.convert_3lines2fillet(l3, l2, l1, closed_loop=1)
f3 = o.solid_from_fillet_closed(f3, -3)

s1 = loft([cap_wire(mixed_wire(p)) for p in s1])
b = solid_from_closed_rings(b, ruled=True)
sol = intersection(s1, b)

f3 = solid_from_wedge_grid(f3, ruled=True, max_stations=50)
sol = difference(sol, f3)

show(sol, alpha=1)
# export_step(sol, 'mouse_surface.step')

t2 = o.time.time()
t2 - t1
