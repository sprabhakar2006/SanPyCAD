# organic_fillet() -- the same mouse-body ribbon-fillet technique as
# example 26, but as ONE call instead of 5 hand-assembled mesh-domain
# lines plus a separate solid_from_wedge_grid() conversion at the end.
# Identical geometry setup (copied verbatim from example 26) so the
# two examples are directly comparable; only the fillet step itself
# changes.
#
# Two differences from example 26 worth calling out:
#   1. organic_fillet(b, s1, radius_a=7, radius_b=-3, thickness=-3,
#      closed_loop=True, ...) replaces example 26's own 6 lines
#      (equidistant_pathc/contiguous_chains/two_solids_intersection +
#      2x o_3d + convert_3lines2fillet + solid_from_fillet_closed +
#      solid_from_wedge_grid) -- same steps, same values, just packaged
#      as one call so there's no chance of mixing up which line goes
#      into which of convert_3lines2fillet()'s 3 positional slots (see
#      organic_fillet()'s own docstring for that gotcha).
#   2. ruled=False here (organic_fillet()'s own default) instead of
#      example 26's ruled=True -- ruled=True is very likely why that
#      example's own mouse-body reads as densely faceted rather than
#      smoothly filleted once opened in an external viewer (every wedge
#      station becomes its own flat facet instead of blending into its
#      neighbors); ruled=False lofts a smooth blended surface through
#      the same station grid instead, at some extra compute cost.
#      Pass ruled=True yourself if you want the faceted look back (or
#      need the speed).

a = o.cr2dt([[-20, 0, 15], [40, 0, 15], [0, 40], [5, 40, 20], [-50, 0, 20], [5, -40]])
tx = o.a_(a).mean(0)
a = o.translate_2d(-tx, a)
b = o.translate([0, 0, -20], o.sphere(50))
p1 = [[0, 0], [15, 50]]
s1 = o.prism(a, p1)
l1 = o.translate_2d([-25, 3], o.sinewave(50, 1.5, 3, 50))
l1 = o.mirror_line(l1, [0, 1, 0], [0, 0, 0])
l2 = o.translate_2d([0, -20], o.circle(50))
l3 = o.rot2d(30, [[0, 0], [-10, 0]])
l3 = o.rot('x90z-90', o.flip(o.line2length(o.flip(o.line2length(
    o.cir_line_tangent(l2, l3), 50)), 100)))
s2 = o.sweep_sec2path(l1, l3)
b = o.psos(s2, b, [0, 0, -1] @ o.xrot(-30), 1e7, 1, 3)
b = [o.bspline_closed(p, 3, 50) for p in b]

f3 = organic_fillet(b, s1, radius_a=7, radius_b=-3, thickness=-3,
                     closed_loop=True, max_stations=50)  # ruled=False default

s1_solid = loft([cap_wire(mixed_wire(p)) for p in s1])
b_solid = solid_from_closed_rings(b, ruled=True)
sol = intersection(s1_solid, b_solid)
sol = difference(sol, f3)

show(sol, alpha=1)
