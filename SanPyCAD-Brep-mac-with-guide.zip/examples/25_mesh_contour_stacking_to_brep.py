# slice_mesh_to_rings() / solid_from_mesh_slices() -- turning an
# arbitrary, unstructured triangle mesh back into a real B-rep solid
# by "contour stacking": cut the mesh with a stack of parallel planes,
# take the closed intersection-loop ("ring") at each height, and fit a
# surface through the whole stack of rings (the same real OCCT
# ThruSections engine surface_from_closed_rings() already uses
# elsewhere in this app).
#
# Why this matters: there's no raw mesh IMPORTER in this app (no STL/
# OBJ reader -- only import_step()/import_brep() for real B-rep
# formats), and there's no general "reconstruct exact faces/edges from
# arbitrary triangle soup" function either (nor does one really exist
# anywhere, in general -- an arbitrary mesh doesn't carry the design
# intent a real B-rep solid needs). Contour stacking sidesteps that
# entirely: instead of trying to reconstruct faces from triangles
# directly, it reduces the problem to the one this app already solves
# well -- fitting a surface through a stack of ordered rings.
#
# Genuinely useful WITHIN this app even without an external mesh file,
# any time you end up holding a triangle mesh instead of a real Shape
# and want a Shape back: to_triangles()/to_mesh()'ing a shape built via
# two_solids_intersection() (the mesh-based fallback for when a real
# B-rep boolean is too fragile), a coarsely-tessellated import_step()
# model, or literally any mesh computed by other means.
#
# CONFIRMED (this app, a real build123d install) three real gotchas
# along the way that slice_mesh_to_rings()/solid_from_mesh_slices() now
# handle/document:
#   1. slice_mesh_to_rings() computes every height's ring completely
#      independently -- consecutive rings can come back winding
#      opposite directions and starting at unrelated angular positions,
#      which twists a lofted surface into a self-intersecting mess.
#      solid_from_mesh_slices() re-winds/re-aligns every ring
#      automatically now (see _align_ring_stack() in brep.py).
#   2. Even with aligned rings, the SMOOTHED surface fit
#      (surface_from_closed_rings()'s default ruled=False) can still
#      silently self-intersect -- no exception raised at all -- when
#      adjacent rings change shape a lot over relatively few stations
#      (confirmed directly, on an earlier version of the blob below at
#      n=10: a technically-successful but badly self-intersecting Shell
#      that took a viewer's tessellation over 6 minutes to choke on).
#      ruled=True instead connects each ring to the next with straight
#      (faceted) patches -- more robust, visible seam at each station,
#      confirmed clean and fast (well under a second) on the exact same
#      rings. solid_from_mesh_slices() exposes `ruled` for exactly this
#      -- try True first on a mesh with real shape variation station to
#      station, or raise `n` and switch back to the smoother False.
#   3. A cross-section that genuinely BRANCHES into two separate lobes
#      at some height (not just changes shape) can't be represented by
#      one ring per station at all -- slice_mesh_to_rings() keeps only
#      the larger loop and drops the other(s) (see its own docstring),
#      which silently deletes real geometry if that second loop is
#      substantial rather than just a stray mesh sliver. Confirmed
#      directly on an EARLIER, more overlapping placement of the three
#      spheres below: the small sphere's own dome poked up as a genuine
#      second lobe near the top, ~2/3 the size of the main loop at that
#      height, and quietly vanished from the result with a visible tear
#      where it used to be. slice_mesh_to_rings() now prints a loud
#      console warning whenever a dropped loop is substantial (not just
#      noise) rather than staying silent -- but the sphere placement
#      below was specifically adjusted (more overlap, less separation)
#      so this particular demo doesn't branch at all; a genuinely
#      forked/branching mesh needs its branches sliced and lofted
#      separately over their own height ranges instead.

blob = union(
    sphere(30),
    translate([15, 0, 0], sphere(24)),
    translate([-5, 12, -4], sphere(15)),
)

v, f = to_mesh(blob, tolerance=1.0)  # coarse on purpose -- visibly faceted

smooth = solid_from_mesh_slices(v, f, axis=[0, 0, 1], n=40, ring_points=48,
                                 ruled=True)  # see gotcha #2 above --
# ruled=True always leaves a visible facet seam at every station (no
# smoothing between them), but with more, closer-together stations
# those facets get small enough that the shape reads as smooth anyway
# -- the same reason a 40-sided polygon looks like a circle. Raise
# ring_points to match n going up, since a smoother outer silhouette
# needs finer in-ring resolution too, not just more stations.

show(translate([70, 0, 0], smooth))
