# 22_wave_washer_closed_loop_sweep.py -- a wavy washer built by
# sweeping a small rounded cross-section along a path that GENUINELY
# closes into one continuous loop -- the direct, robust way to close a
# swept loop, instead of building it open and trying to stitch/close it
# after the fact.
#
# The path: sinewave() rotated onto a vertical plane (rot('x90', ...)),
# then carried all the way around a full circle (arc(0, 360, s=49)) via
# extrude_wave2path() -- the same wavy-washer path this app's own
# surface_from_points_grid_closed() was built to help close (see its
# docstring in brep.py). That approach works by fitting/ruling a
# surface through an OPEN grid of cross-sections and closing the loop
# geometrically afterward -- it gets there, but for a case like this
# one it's more machinery than necessary, and left one un-filletable
# seam edge behind (a real, expected outcome for that technique, not a
# bug -- see max_fillet_radius()'s own docstring on seam edges).
#
# THIS script takes the more direct route, and needs no separate
# closed-surface step at all:
#
#   1. interp_spline(c, 1) turns the raw path point list into one real,
#      GENUINELY PERIODIC B-rep Edge (build123d's own
#      Spline(..., periodic=True) under the hood) instead of an
#      ordinary open curve.
#   2. sweep_sec2path()'s own closed_loop=1 sweeps a REAL 2D section
#      (cap_wire(cr2dt(...)), a small rounded-rectangle profile -- not
#      a degenerate 2-point ribbon) around that periodic path in ONE
#      native OCCT pipe-shell operation (BRepOffsetAPI_MakePipeShell
#      already supports a closed path directly).
#
# The result is one genuinely watertight, seamless solid -- no grid
# fitting, no duplicate-row seam, and no leftover un-filletable edge,
# because the corner rounding (radius .49 on each corner of the cross-
# section) is baked directly into the swept profile itself instead of
# being fillet()ed onto the solid afterward.
#
# The lesson for next time: when a loop needs to genuinely close, reach
# for sweep_sec2path(..., closed_loop=1) with a periodic path curve
# (interp_spline(path, closed=True)) and a real 2D section FIRST --
# it's more robust than building an open shape and closing/filleting it
# after the fact, and it's usually less code too.

import openscad4 as o

a = o.rot('x90', o.sinewave(50, 3, 2, 50))
b = o.c23(o.arc(10, 0, 360, s=49))
c = o.extrude_wave2path(a, b)
path = interp_spline(c, 1)
sec = cap_wire(cr2dt([[-2, 0, .49], [4, 0, .49], [0, 1, .49], [-4, 0, .49]], 10))
sol = sweep_sec2path(sec, path, orientation=1, closed_loop=1)
show(sol)
export_step(sol, 'wave_washer.step')
