# smooth_mesh() -- Laplacian/Taubin smoothing on an arbitrary [V, F]
# triangle mesh, slotted in between to_mesh() and 25's own
# solid_from_mesh_slices() as the missing "clean up the mesh before
# rebuilding it into a smooth B-rep solid" step.
#
# Same union-of-3-spheres blob as example 25, tessellated coarsely
# (tolerance=2.0) so the raw faceting itself is the thing being
# smoothed -- no synthetic noise injected on top. IMPORTANT gotcha
# this sidesteps, confirmed directly in this app: to_mesh() does NOT
# return an index-welded mesh (each Face tessellates independently,
# so two triangles from adjacent faces sharing a real 3D edge get
# their own separate-but-coincident copies of it). Adding INDEPENDENT
# per-vertex noise straight onto to_mesh()'s own output (as an earlier
# version of this example did) decorrelates those coincident seam
# duplicates from each other before smooth_mesh() ever sees them --
# no amount of smoothing can put a seam back together once its two
# sides have already been torn apart by unrelated random offsets.
# smooth_mesh()'s own weld_tol handles the (extremely common) case of
# genuinely-coincident duplicate seam vertices just fine on its own;
# it can't fix a seam that real per-copy noise already pulled apart.
#
# smooth_mesh() uses the Taubin lambda/mu variant by default
# (mu=-0.53), which removes high-frequency roughness WITHOUT the
# shrinking a plain Laplacian smooth would introduce -- confirmed on a
# synthetic test mesh (unrelated to this file, including one with
# real coincident-but-separately-indexed seam vertices matching
# to_mesh()'s own output shape) to keep mean radius within 0.3% of
# the original while cutting RMS surface roughness by ~64% over 15
# iterations, with the mesh staying watertight (seams stay at a
# floating-point-exact 0 gap) throughout; see smooth_mesh()'s own
# docstring for the full numbers.

blob = union(
    sphere(30),
    translate([15, 0, 0], sphere(24)),
    translate([-5, 12, -4], sphere(15)),
)

v, f = to_mesh(blob, tolerance=2.0)  # deliberately coarse/faceted --
# this faceting itself is the roughness smooth_mesh() below cleans up

v_smooth = smooth_mesh(v, f, iterations=15)  # Taubin by default

# Rebuild both the raw-faceted and the smoothed mesh back into real
# B-rep solids via example 25's own contour-stacking technique, side
# by side, so the difference is visible directly in the viewer rather
# than just asserted here.
rough = solid_from_mesh_slices(v, f, axis=[0, 0, 1], n=40,
                                ring_points=48, ruled=True)
smooth = solid_from_mesh_slices(v_smooth, f, axis=[0, 0, 1], n=40,
                                 ring_points=48, ruled=True)

show(translate([-40, 0, 0], rough))
show(translate([40, 0, 0], smooth))
