# 23_closed_loop_grid_surface_cap_fillet.py -- a large organic shell
# (headrest/backrest-style form) built almost entirely with openscad4's
# point-list toolkit (arcs, waves, projections, offsets), then turned
# into one real, watertight, filletable B-rep solid at the very end.
#
# The pipeline, in short:
#   1. Everything through `surf3`/`surf4`/`sol1` is pure point-list math
#      (o.arc_2p_3d(), o.surface_from_4_lines(), o.slice_surface(),
#      o.psos(), o.mirror_surface(), ...) -- no B-rep involved yet, just
#      building up a rectangular grid of 3D points describing the outer
#      wall (surf3) and an inset inner wall (surf4).
#   2. sol1 = o.solid_from_2surfaces(surf3, surf4) turns that pair of
#      point grids into a list of closed CROSS-SECTION rings (one ring
#      per station along the sweep).
#   3. Each ring gets smoothed into a genuinely closed curve
#      (o.bspline_closed() + o.equidistant_pathc()), then the OTHER
#      direction (station-to-station, along the sweep) gets smoothed too
#      (o.bspline_open() + o.equidistant_path(), via o.cpo() to work
#      across that axis) -- deliberately OPEN here, since the sweep
#      itself has two real ends, only the ring direction should close.
#   4. surface_from_points_grid_closed(o.cpo(sol2)) fits the whole grid
#      into one real B-rep Shell, genuinely closed all the way around
#      the ring direction (see its own docstring in brep.py for why a
#      plain surface_from_points_grid() can't do this -- it only ever
#      fits an OPEN surface, even if you hand it a pre-closed grid, and
#      leaves a fake "flush but not welded" seam behind). Note the
#      o.cpo() transpose right before this call -- this function closes
#      along whichever axis is its ROW direction, which is the sweep
#      axis in sol2's own [sweep][ring] layout, so the grid has to be
#      transposed first to close the RING axis instead.
#   5. That Shell is open at its two sweep-direction ends (each end's
#      boundary is one real closed edge, since the ring direction is a
#      genuine periodic curve now) -- cap_wire() turns each boundary
#      edge into a flat end Face, and solid_from_faces() sews the wall
#      Shell plus both caps into one watertight Solid.
#   6. Two probe-picked edges (via the Pick Edges/Faces panel's "probe
#      list tool" -- the `# <- probe ... tool: eN` comments are exactly
#      what that panel inserts) get fillet()ed directly on the finished
#      solid.
#
# Also a good example of just how much of a shape's shape-defining work
# can happen entirely in point-list space (openscad4, via `o.`) before
# ever touching real B-rep -- see this app's own bare (non-`o.`)
# functions (cap_wire, solid_from_faces, surface_from_points_grid_closed,
# fillet) for the small number of places this script actually needs
# native build123d.

import openscad4 as o

l1=o.cr2dt([[0,800],[0,-300],[0,-500/o.cos(o.d2r(30)),0]@o.rt(30), [400,0],
         [100,0,0]@o.rt(30),[0,70,0]@o.rt(30)])
l2=o.path_offset(l1[:2],-30)
a=o.arc_2p(l1[-1],l1[2],400,-1)
b=o.arc_2p(l1[2],l1[1],375,-1)
c=o.two_cir_tarc(a,b,100,s=10)
d=o.fillet_line_circle(l2,b,100,o=3)
l3=o.lineFromStartTillPoint(a,c[0],5)+c[1:]+ \
o.lineFromPointToPointOnLine(b,c[-1],d[0],5)[1:]+d+[l2[0]]
p0,p1,p2,p3=o.translate([0,0,100],l1[0]),o.translate([0,0,180],l1[1]), \
o.translate([0,0,110],l1[2]), o.translate([0,0,220],l1[3])
a1=o.arc_2p_3d([1,0,0],p0,p1,700)
a2=o.arc_2p_3d([1,0,0]@o.rt(30),p1,p2,800)
a3=o.arc_2p_3d([0,1,0],p2,p3,800)
x1,x2,x3=o.extend_arc3d(a3,15),o.extend_arc3d(o.flip(a1),10),o.flip(a2)
x4=o.fit_pline2line(x3,[x1[-1],x2[-1]])
s1=o.surface_from_4_lines(x1,x2,x3,x4)
l3p=o.plos(s1,o.c23(l3),[0,0,1],1,3)
a1m=o.mirror_line(a1,[0,0,1],[0,0,0])
a2m=o.mirror_line(a2,[0,0,1],[0,0,0])
a3m=o.mirror_line(a3,[0,0,1],[0,0,0])
l4=o.cr2dt([[0,0],[30,0],[50,-50],[50,0],[50,50],[30,0]])
l4m=o.mirror_line(l4,[1,0,0],[0,0,0])
l4=o.rot('y90z30',o.bspline_open(o.flip(l4m)+l4[1:],deg=3,s=20))
p4=o.c23(o.movePointOnLine(l1,l1[4],40))
l4=o.move(l4,p4,[0,0,0])
pl1=o.plane([0,1,0],[1000,1000],[700,0,0])
l4p=o.plos(pl1,l4,[-1,0,0]@o.rt(30),1,3)
x1,x2=l4p,l4
x3=o.plos(s1,o.equidistant_path([x1[0],x2[0]],10),[0,0,1],0,3)
x4=o.mirror_line(x3,[0,0,1],[0,0,0])
s2=o.slice_surface(o.surface_from_4_lines(x1,x2,x3,x4),20)
a2c=o.c23(o.bezier([[0,450],[150,100],[240,0]],20))
s3=o.slice_surface(o.convert_3lines2surface(a2,a2c,a2m,s=19),40)
x1,x2=s3[-1],s2[0]
x3=o.lineFromStartTillPoint(a3,x2[0],10)
x4=o.mirror_line(x3,[0,0,1],[0,0,0])
s4=o.slice_surface(o.surface_from_4_lines(x1,x2,x3,x4),40)
x1,x2,x3,x4=o.equidistant_path([a1[0],a1m[0]],19),s3[0],a1,a1m
s5=o.slice_surface(o.surface_from_4_lines(x1,x2,x3,x4),40)
surf1=s5+s3[1:]+s4[1:]+s2[1:]
x1=o.cpo(surf1)[0]
x2=o.path2path1(x1,o.flip(l3p))
s6=o.psos(s1,o.slice_sol([x2,x1],10),[0,0,1],1e7,1,3)
s7=o.flip(o.mirror_surface(s6,[0,0,1],[0,0,0]))
surf2=o.cpo(s6+o.cpo(surf1)[1:]+s7[1:])
surf3=o.cpo([ o.equidistant_path(line,100) for line in o.cpo(surf2)])
surf4=[ o.path_offset3d(p,-30) for p in surf3]
sol1=o.solid_from_2surfaces(surf3,surf4)
sol2=[ o.equidistant_pathc(o.bspline_closed(o.homogenise(p,30),3,200),200) for p in sol1]
sol2=o.cpo([o.equidistant_path(o.bspline_open(o.homogenise(p,30),3,200),200) for p in o.cpo(sol2)])
sol2=surface_from_points_grid_closed(o.cpo(sol2))
e1 = [sol2.edges()[i] for i in [400]]  # <- probe list tool: e1
a=cap_wire(e1)
e2 = [sol2.edges()[i] for i in [0]]  # <- probe list tool: e2
b=cap_wire(e2)
sol3=solid_from_faces(sol2,a,b)
e3 = [sol3.edges()[i] for i in [400]]  # <- probe list tool: e3
sol3 = fillet(sol3, e3, 14.7)  # <- probe fillet tool: e3
e4 = [sol3.edges()[i] for i in [440]]  # <- probe list tool: e4
sol3 = fillet(sol3, e4, 14.2)  # <- probe fillet tool: e4
show(sol3)
