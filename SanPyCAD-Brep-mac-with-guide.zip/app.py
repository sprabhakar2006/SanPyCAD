#!/usr/bin/env python3
"""
app.py -- launches SanPyCAD Brep, the OpenSCAD-like desktop application.

This is the B-rep-first copy of SanPyCAD: unlike the main app and
SanPyCAD Experimental (both mesh-based -- everything ends up as
triangle soup), scripts here build on backend/brep.py, which wraps
build123d/OpenCASCADE (OCCT) to produce genuine boundary-representation
(B-rep) solids -- exact analytic/NURBS surfaces, exact booleans, real
STEP file export. The 3D viewer still renders triangles (that's all
WebGL can ever draw), but they're a disposable tessellation generated
just for display -- the actual model stays exact B-rep the whole time.
Its window title, launcher names, and console/log output are all
labeled "SanPyCAD Brep" specifically so it's never confused with the
other two when installed side by side.

This starts the local geometry backend (backend/server.py, built on
build123d via backend/brep.py) and opens it in its own application window
using pywebview, so this behaves like a normal desktop app rather than "go
start a server and open your browser". If pywebview isn't installed, it
transparently falls back to opening your default browser instead -- the
app still works, just as a browser tab.

Normally you don't need to run this file directly -- just double-click
SanPyCAD Brep.app (in the same folder as this file) to launch it
like any other desktop app, no Terminal/command line needed. This is
what that shortcut actually runs under the hood; it's still runnable by
hand too if you ever want to:
    python3 app.py

To get the native window (recommended), install pywebview first:
    pip install pywebview
"""

import json
import keyword
import os
import re
import sys
import socket
import threading
import time
import traceback
import webbrowser

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(BASE_DIR, "backend"))

import server  # noqa: E402


def find_free_port():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def wait_for_server(url, timeout=5.0):
    import urllib.request
    start = time.time()
    while time.time() - start < timeout:
        try:
            urllib.request.urlopen(url, timeout=0.5)
            return True
        except Exception:
            time.sleep(0.05)
    return False


class Api:
    """Exposed to the frontend as `window.pywebview.api` (see js_api= below).

    export_file(): the native desktop window has no address bar, tabs, or
    back button, so the normal browser trick of building a Blob and
    clicking a hidden <a download> link doesn't work here: pywebview's
    underlying WKWebView (on macOS) doesn't honor the HTML5 download
    attribute, and instead just navigates the whole window to the blob's
    raw content -- which looks like the app "breaking" into a wall of
    vertex/face text with no way back except quitting and relaunching.
    Building the file here in Python and handing it to webview's own
    native Save panel avoids that entirely; the frontend only falls back
    to the Blob/<a download> approach when running as a plain browser tab
    (no window.pywebview), where it already works fine.

    save_script()/open_script(): same native-dialog approach, but for the
    script's own source code (.py) rather than rendered geometry -- this
    is the app's equivalent of a normal text editor's File > Save/Save
    As/Open, so a design can be closed and reopened later instead of only
    ever exported as a one-way STL/OBJ/etc snapshot.
    """

    def export_file(self, code, kind):
        try:
            if kind in ("svg", "drawing"):
                # Both are the same real, hidden-line-removed engineering
                # drawing now (see server.py's generate_drawing_svg()) --
                # NOT a plain triangle-mesh wireframe, so this branches
                # BEFORE the run_any()/meshes path below: a drawing needs
                # the live B-rep Shape objects, only reachable by re-
                # running the script through the kernel's own "drawing"
                # op (generate_drawing_svg() does that itself), not the
                # already-tessellated `meshes` this function's mesh-based
                # kinds (stl/obj/dxf) share below.
                data, error = server.generate_drawing_svg(code, csg_resolution=56)
                if error:
                    return {"error": error}
                default_name = "drawing.svg"
            else:
                result, _scene = server.run_any(code, csg_resolution=56)
                if result.get("error"):
                    return {"error": result["error"]}
                meshes = list(server.ev_meshes_from_result(result))
                if not meshes:
                    return {"error": "nothing to export (empty scene)"}

                builders = {
                    "stl": (server.build_stl_binary, "model.stl"),
                    "obj": (server.build_obj_text, "model.obj"),
                    "dxf": (server.build_dxf_text, "model.dxf"),
                }
                if kind not in builders:
                    return {"error": f"unknown export kind: {kind}"}
                builder, default_name = builders[kind]
                data = builder(meshes)

            window = webview.windows[0]
            save_dialog = getattr(getattr(webview, "FileDialog", None), "SAVE", None)
            if save_dialog is None:
                save_dialog = webview.SAVE_DIALOG  # older pywebview versions
            chosen = window.create_file_dialog(save_dialog, save_filename=default_name)
            if not chosen:
                return {"canceled": True}
            path = chosen[0] if isinstance(chosen, (list, tuple)) else chosen

            is_binary = isinstance(data, (bytes, bytearray))
            mode_flag = "wb" if is_binary else "w"
            # Explicit utf-8 for the text formats (OBJ/SVG/DXF) rather than
            # relying on the platform's default text encoding -- Windows'
            # default is a locale codepage (e.g. cp1252), not utf-8, so a
            # model with a non-ASCII color name or similar could otherwise
            # fail to save there even though the exact same script exports
            # fine on macOS/Linux.
            with open(path, mode_flag, **({} if is_binary else {"encoding": "utf-8"})) as f:
                f.write(data)
            return {"path": path}
        except Exception as e:
            traceback.print_exc()
            return {"error": str(e)}

    def save_script(self, code, path=None, sketch_data=None):
        """Writes `code` to `path` directly if given (plain "Save", once a
        file's already been saved to/opened from once this session), else
        prompts a native Save dialog first (plain "Save As", or the first
        "Save" of a brand new, never-yet-saved script).

        `sketch_data`, if given, is the JSON text of any "2D Sketch"
        shapes currently sent to this script (see index.html's
        sketchSessions) -- written to a small sidecar file next to the
        script itself (`<path>.sketch.json`) rather than into the
        script's own text, so reopening it later can silently re-inject
        those variables and restore the original editable sketch(es)
        WITHOUT ever having spliced a big literal points list into the
        code the user actually wrote and sees. Ported from the sibling
        SanPyCAD app's own save_script() -- same sidecar filename/shape,
        so a script saved from either app restores its sketches the same
        way (minus that app's separate guifn_data sidecar, since this
        app has no "GUI Functions" panel). If there's nothing to save
        (every sketch was removed from the script since it was last
        saved, or it never had one), any stale sidecar left over from an
        earlier save is cleaned up rather than left around pointing at
        shapes the script no longer uses -- this is also why a script
        saved here BEFORE this fix (no sidecar ever written) genuinely
        has no sketch data to recover: there was nowhere for it to have
        been kept."""
        try:
            if not path:
                default_name = "model.py"
                window = webview.windows[0]
                save_dialog = getattr(getattr(webview, "FileDialog", None), "SAVE", None)
                if save_dialog is None:
                    save_dialog = webview.SAVE_DIALOG  # older pywebview versions
                chosen = window.create_file_dialog(save_dialog, save_filename=default_name)
                if not chosen:
                    return {"canceled": True}
                path = chosen[0] if isinstance(chosen, (list, tuple)) else chosen
            with open(path, "w", encoding="utf-8") as f:
                f.write(code)
            sidecar_path = path + ".sketch.json"
            if sketch_data:
                with open(sidecar_path, "w", encoding="utf-8") as f:
                    f.write(sketch_data)
            else:
                try:
                    os.remove(sidecar_path)
                except OSError:
                    pass  # no sidecar existed -- nothing to clean up
            return {"path": path}
        except Exception as e:
            traceback.print_exc()
            return {"error": str(e)}

    def open_script(self):
        try:
            window = webview.windows[0]
            open_dialog = getattr(getattr(webview, "FileDialog", None), "OPEN", None)
            if open_dialog is None:
                open_dialog = webview.OPEN_DIALOG  # older pywebview versions
            chosen = window.create_file_dialog(
                open_dialog,
                file_types=(
                    "SanPyCAD Brep scripts (*.py)",
                    "All files (*.*)",
                ),
            )
            if not chosen:
                return {"canceled": True}
            path = chosen[0] if isinstance(chosen, (list, tuple)) else chosen
            with open(path, "r", encoding="utf-8") as f:
                code = f.read()
            result = {"path": path, "code": code}
            # See save_script()'s sidecar comment above -- if this script
            # was saved (with this fix in place) with one or more "2D
            # Sketch" shapes attached, hand its JSON straight back so the
            # frontend can silently re-inject those variables (no
            # NameError on Render) and restore the original editable
            # sketch(es) in the panel.
            sidecar_path = path + ".sketch.json"
            if os.path.exists(sidecar_path):
                try:
                    with open(sidecar_path, "r", encoding="utf-8") as f:
                        result["sketch_data"] = f.read()
                except OSError:
                    pass  # non-fatal -- the script itself still opened fine
            return result
        except Exception as e:
            traceback.print_exc()
            return {"error": str(e)}


# Names that would be actively dangerous for the generated starter
# script (below) to clobber via globals()[name] = <imported shape> --
# every one of these is a real geometry/kernel function this app's own
# scripts commonly call; overwriting one with an imported Shape object
# would silently break the very next call to it in the same script.
# Not exhaustive (this app's real reserved-name set lives inside the
# encrypted python_eval.py, not worth importing/warming up the kernel
# just to build a starter script) -- just the common/likely-to-collide
# ones, since a SanPyCAD variable name landing here at all is already
# a rare coincidence.
_UNSAFE_STARTER_NAMES = {
    "cube", "cylinder", "sphere", "cone", "prism", "sweep_sec2path",
    "show", "import_step", "import_brep", "export_step", "export_stl",
    "export_brep", "fillet", "chamfer", "union", "difference",
    "intersection", "translate", "rotate", "scale", "color", "mirror",
    "hull", "text", "polygon", "circle", "square",
}


def _sanitize_starter_var_name(raw, used):
    """Turns an arbitrary SanPyCAD variable name into a safe, unique
    Python identifier for the generated starter script (see
    _pending_import_from_env()) to assign an imported shape to --
    almost always a no-op, since a SanPyCAD name is itself already a
    valid Python identifier (that's where it came from). Only kicks in
    for the rare edge cases: a Python keyword, a name that would
    shadow a builtin geometry function (see _UNSAFE_STARTER_NAMES
    above), or a name already used by an earlier shape in this same
    import (STEP body names aren't guaranteed unique the way Python
    identifiers are)."""
    name = re.sub(r"\W|^(?=\d)", "_", str(raw or "")).strip("_") or "shape"
    if keyword.iskeyword(name) or name in _UNSAFE_STARTER_NAMES:
        name += "_shape"
    base, n = name, 2
    while name in used:
        name = f"{base}_{n}"
        n += 1
    return name


def _pending_import_from_env():
    """"Send to SanPyCAD-Brep" handoff: the sibling SanPyCAD app (a
    separate process) launches a brand-new SanPyCAD-Brep instance with
    SANPYCAD_BREP_IMPORT set to a .step file it just wrote (see its own
    backend/brep_bridge.py for why an env var and not a CLI argument --
    it survives every one of this app's own launchers, none of which
    touch argv today, with zero changes needed to any of them). Turns
    that into a ready-to-run starter script instead of the usual blank
    default one; returns None for a normal launch with nothing to
    import (the overwhelmingly common case).

    A `<path>.names.json` sidecar next to the .step file (written by
    SanPyCAD's own send_to_brep(), same idea as the "2D Sketch"
    panel's own `.sketch.json` sidecar) carries each body's ORIGINAL
    SanPyCAD variable name, in the same order the shapes were written
    -- so the generated script below can name each imported solid the
    same thing it was called in SanPyCAD, instead of a meaningless
    s1/s2/.... Missing, unreadable, or short-by-one sidecar just means
    fewer (or zero) of the imported solids get a real name -- the rest
    still fall back to s{n}, same as before this existed."""
    path = os.environ.get("SANPYCAD_BREP_IMPORT")
    if not path:
        return None
    if not os.path.isfile(path):
        print(f"[SanPyCAD Brep] SANPYCAD_BREP_IMPORT={path!r} does not exist -- ignoring")
        return None

    names = []
    names_path = path + ".names.json"
    if os.path.isfile(names_path):
        try:
            with open(names_path, "r", encoding="utf-8") as f:
                names = [str(n) for n in json.load(f).get("names", []) if n]
        except Exception:
            names = []  # sidecar missing/corrupt -- fall back to s1/s2/... below

    used = set()
    safe_names = []
    for n in names:
        safe = _sanitize_starter_var_name(n, used)
        used.add(safe)
        safe_names.append(safe)

    return (
        "# Imported from SanPyCAD -- these are real build123d/OCCT B-rep\n"
        "# solids (an exact STEP import, not a re-tessellation), named the\n"
        "# same as their SanPyCAD variables where possible. Edit freely.\n"
        f"_imported = import_step(r{path!r})\n"
        "_solids = _imported.solids()\n"
        f"_names = {safe_names!r}\n"
        "for _i, _s in enumerate(_solids):\n"
        "    _nm = _names[_i] if _i < len(_names) else f's{_i + 1}'\n"
        "    globals()[_nm] = _s\n"
        "    show(_s)\n"
    )


def main():
    server.print_backend_status()

    pending_import = _pending_import_from_env()
    if pending_import is not None:
        server.set_pending_import(pending_import)

    # Warm up the geometry kernel worker process now, in the background,
    # rather than waiting for the first /render. Deliberately done HERE
    # (inside main(), behind this file's own `if __name__ == "__main__":`
    # guard below) and not as an import-time side effect of `import
    # server` above -- see kernel_manager.py's start()/KernelManager
    # docstrings for why doing it eagerly at import time breaks
    # multiprocessing's 'spawn' start method (the macOS/Windows default)
    # on every single launch.
    server.MANAGER.start()

    port = find_free_port()
    httpd, port = server.serve(host="127.0.0.1", port=port)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()

    url = f"http://127.0.0.1:{port}/"
    wait_for_server(url)
    print(f"[SanPyCAD Brep] backend running at {url}")

    try:
        global webview
        import webview
        api = Api()
        window = webview.create_window(
            "SanPyCAD Brep", url, width=1400, height=900, min_size=(900, 600),
            js_api=api,
        )
        # debug=True enables "Inspect Element" in the app window, so JS
        # errors can be diagnosed the same way as in a regular browser if
        # something ever goes wrong -- but on some platforms/backends
        # (notably Windows' WebView2/EdgeChromium backend), it doesn't
        # just make that available on request: it pops the whole DevTools
        # panel open automatically, every single launch. That's a
        # developer/troubleshooting tool, not something anyone needs for
        # normal use, so it's off unless explicitly asked for.
        debug_mode = bool(os.environ.get("SANPYCAD_DEBUG"))
        webview.start(debug=debug_mode)
    except ImportError:
        print("[SanPyCAD Brep] pywebview not installed -- opening your default "
              "browser instead. For a real app window, run: pip install pywebview")
        webbrowser.open(url)
        print("[SanPyCAD Brep] press Ctrl+C here to stop the app")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass

    httpd.shutdown()


if __name__ == "__main__":
    main()
