# Simple coil spring
# Real project from the openscad4 examples notebook.
# The coil path itself is just a plain Python list comprehension (a spiral
# parametrised by angle, growing linearly in radius and dropping in z) drawn
# with p_line3d(), shown next to a tapered cylinder() for scale/context.
# A good minimal example of building a path with plain math instead of a
# helper like helix().

coil=array([i/360*array([cos(d2r(i)),sin(d2r(i)),-1]) for i in linspace(0,3600,720)]).tolist()
cyl1=translate([0,0,-10],cylinder(r1=10,r2=0.1,h=10))
fo(f'''
translate([0,0,10]){{
color("blue")p_line3d({coil},.05);
%{swp(cyl1)}
}}
    ''')
