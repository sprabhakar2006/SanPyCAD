# Shield surface / partial surface between two solids
# Real project from the openscad4 examples notebook.
# Demonstrates shield() and partial_surface() - given two solids (a large
# disc-like prism and a boss sticking out of it), these compute a filleted
# transition surface patch between them and return raw
# polyhedron()-style vertex/face data, which is passed straight to
# OpenSCAD's polyhedron() inside fo().

sec1=circle(55)
path1=corner_radius(pts1([[-50,0],[50,0,.2],[0,30,3],[6,1,3],[0,6,3],[-4,2,3],[0,22,6],[8,2,6],[0,10,.2],[-50,0]]),10)
sec2=circle(7.5)
path2=corner_radius(pts1([[-5,0],[5,0,5],[0,35,2],[-5,0]]),10)
path2=equidistant_path(path2,50)
sol1=prism(sec1,path1)
sol2=translate([57.5,0,37],prism(sec2,path2))
sol2=axis_rot_o([0,0,1],sol2,180)

s1=shield(sol1,sol2,50,10,4,135)
v,f1=partial_surface(sol1,prism_center(sol2),50)


fo(f'''
%{swp(sol1)}
%{swp(sol2)}

color("blue")for(p={s1})for(p1=p)p_line3dc(p1,.2,rec=1);
polyhedron({v},{f1});

''')
