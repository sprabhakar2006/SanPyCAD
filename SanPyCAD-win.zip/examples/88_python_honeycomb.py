# Honeycomb pattern with point-in-polygon filtering
# Real project from the openscad4 examples notebook.
# Short but instructive: honeycomb() generates a hex-grid point set, and
# pies1() (point-in-enclosed-section test) filters that grid down to only
# the points fully inside an arbitrary boundary profile.

sec4=honeycomb(1,6,15)
sec=corner_radius(pts1([[3,2,1],[8,3,3],[5,7,1],[-8,0,2],[-5,20,1]]),30)
pnts1=[p for p in sec4 if len(pies1(sec,p))==6]
fo(f'''
for(p={sec4})p_line(p,.1);
color("blue")p_line({sec},.1);
color("cyan")for(p={pnts1})p_line(p,.1);
''')
