# Tumbler / drinking glass
# Real project from the openscad4 examples notebook.
# The tapered glass wall is built with prism() along a corner_radius()
# profile, then align_sol_1() + slice_sol() re-resample it so the rim can
# be joined cleanly to a wider top ring (prism() again) with
# convert_3lines2fillet(), and the whole thing is finished with a slanted
# o_solid() cutting plane to trim the base flat.

r=15
a1=1/20 #taper of the glass
h1=20
h2=20
s1=10
cir1=circle(r,s=s1+1)
path1=corner_radius(pts1([[-1,0],[1,0,1],[a1*h1,h1]]),10)
sol1=prism(cir1,path1)
sol1=align_sol_1([equidistant_pathc(p,200) for p in sol1])
sol1=slice_sol(sol1,30)
cir2=circle((r+a1*h1)/cos(d2r(360/(s1+1)/4)),s=201)
path2=corner_radius(pts1([[0,h1+.25],[a1*h2,h2,.49],[-1,0,.49],[-a1*h2,-h2,.5],[-.5,-.5,.5],[-a1*(h1-3),-(h1-3),1],[-2,0]]),10)
sol2=prism(cir2,path2)
sol3=sol1+sol2
p0=sol1[-1]; p1=sol2[0]; p2=sol1[-2]
fill=convert_3lines2fillet(p2,p1,p0,s=30)
fill=fill+[fill[0]]
sec=square(100,center=True)
cut1=o_solid([0,-1,0],sec,100,theta=[0,0,10])
fo(f'''
difference(){{
union(){{
{swp(sol3)}
{swp_c(fill)}
}}
{swp(cut1)}
}}
''')
