#!/usr/bin/env python3
"""
app.py -- launches SanPyCAD, the OpenSCAD-like desktop application.

This starts the local geometry backend (backend/server.py, built on your
openscad4.py library) and opens it in its own application window using
pywebview, so this behaves like a normal desktop app rather than "go start
a server and open your browser". If pywebview isn't installed, it
transparently falls back to opening your default browser instead -- the
app still works, just as a browser tab.

Normally you don't need to run this file directly -- just double-click
SanPyCAD.app (in the same folder as this file) to launch SanPyCAD like
any other desktop app, no Terminal/command line needed. This is what
that shortcut actually runs under the hood; it's still runnable by hand
too if you ever want to:
    python3 app.py

To get the native window (recommended), install pywebview first:
    pip install pywebview
"""

import os
import sys
import socket
import threading
import time
import traceback
import webbrowser

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(BASE_DIR, "backend"))

import server  # noqa: E402


def find_free_port():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def wait_for_server(url, timeout=5.0):
    import urllib.request
    start = time.time()
    while time.time() - start < timeout:
        try:
            urllib.request.urlopen(url, timeout=0.5)
            return True
        except Exception:
            time.sleep(0.05)
    return False


class Api:
    """Exposed to the frontend as `window.pywebview.api` (see js_api= below).

    export_file(): the native desktop window has no address bar, tabs, or
    back button, so the normal browser trick of building a Blob and
    clicking a hidden <a download> link doesn't work here: pywebview's
    underlying WKWebView (on macOS) doesn't honor the HTML5 download
    attribute, and instead just navigates the whole window to the blob's
    raw content -- which looks like the app "breaking" into a wall of
    vertex/face text with no way back except quitting and relaunching.
    Building the file here in Python and handing it to webview's own
    native Save panel avoids that entirely; the frontend only falls back
    to the Blob/<a download> approach when running as a plain browser tab
    (no window.pywebview), where it already works fine.

    import_pick_file(): same idea in reverse -- a native Open panel to
    pick a file to import(), instead of the browser-only <input type=file>
    + upload-the-bytes dance the frontend falls back to when there's no
    pywebview (see /import/save in server.py). Since this process already
    has direct filesystem access, there's no need to copy the chosen file
    anywhere first -- its real path is handed straight to import().

    save_script()/open_script(): same native-dialog approach, but for the
    script's own source code (.py/.scad) rather than rendered geometry --
    this is the app's equivalent of a normal text editor's File > Save/
    Save As/Open, so a design can be closed and reopened later instead of
    only ever exported as a one-way STL/OBJ/etc snapshot.
    """

    def export_file(self, code, mode, csg_resolution, kind):
        try:
            csg_resolution = max(16, min(int(csg_resolution), 160))
            result, _ev = server.run_any(code, csg_resolution, mode)
            if result.get("error"):
                return {"error": result["error"]}
            meshes = list(server.ev_meshes_from_result(result))
            if not meshes:
                return {"error": "nothing to export (empty scene)"}

            builders = {
                "stl": (server.build_stl_binary, "model.stl"),
                "obj": (server.build_obj_text, "model.obj"),
                "svg": (server.build_svg_text, "model.svg"),
                "dxf": (server.build_dxf_text, "model.dxf"),
            }
            if kind not in builders:
                return {"error": f"unknown export kind: {kind}"}
            builder, default_name = builders[kind]
            data = builder(meshes)

            window = webview.windows[0]
            save_dialog = getattr(getattr(webview, "FileDialog", None), "SAVE", None)
            if save_dialog is None:
                save_dialog = webview.SAVE_DIALOG  # older pywebview versions
            chosen = window.create_file_dialog(save_dialog, save_filename=default_name)
            if not chosen:
                return {"canceled": True}
            path = chosen[0] if isinstance(chosen, (list, tuple)) else chosen

            is_binary = isinstance(data, (bytes, bytearray))
            mode_flag = "wb" if is_binary else "w"
            # Explicit utf-8 for the text formats (OBJ/SVG/DXF) rather than
            # relying on the platform's default text encoding -- Windows'
            # default is a locale codepage (e.g. cp1252), not utf-8, so a
            # model with a non-ASCII color name or similar could otherwise
            # fail to save there even though the exact same script exports
            # fine on macOS/Linux.
            with open(path, mode_flag, **({} if is_binary else {"encoding": "utf-8"})) as f:
                f.write(data)
            return {"path": path}
        except Exception as e:
            traceback.print_exc()
            return {"error": str(e)}

    def import_pick_file(self):
        try:
            window = webview.windows[0]
            open_dialog = getattr(getattr(webview, "FileDialog", None), "OPEN", None)
            if open_dialog is None:
                open_dialog = webview.OPEN_DIALOG  # older pywebview versions
            chosen = window.create_file_dialog(
                open_dialog,
                file_types=(
                    "Importable files (*.stl;*.obj;*.off;*.svg)",
                    "Mesh files (*.stl;*.obj;*.off)",
                    "SVG files (*.svg)",
                    "All files (*.*)",
                ),
            )
            if not chosen:
                return {"canceled": True}
            path = chosen[0] if isinstance(chosen, (list, tuple)) else chosen
            return {"path": path}
        except Exception as e:
            traceback.print_exc()
            return {"error": str(e)}

    def save_script(self, code, mode, path=None):
        """Writes `code` to `path` directly if given (plain "Save", once a
        file's already been saved to/opened from once this session), else
        prompts a native Save dialog first (plain "Save As", or the first
        "Save" of a brand new, never-yet-saved script)."""
        try:
            if not path:
                ext = "py" if mode == "python" else "scad"
                default_name = f"model.{ext}"
                window = webview.windows[0]
                save_dialog = getattr(getattr(webview, "FileDialog", None), "SAVE", None)
                if save_dialog is None:
                    save_dialog = webview.SAVE_DIALOG  # older pywebview versions
                chosen = window.create_file_dialog(save_dialog, save_filename=default_name)
                if not chosen:
                    return {"canceled": True}
                path = chosen[0] if isinstance(chosen, (list, tuple)) else chosen
            with open(path, "w", encoding="utf-8") as f:
                f.write(code)
            return {"path": path}
        except Exception as e:
            traceback.print_exc()
            return {"error": str(e)}

    def open_script(self):
        try:
            window = webview.windows[0]
            open_dialog = getattr(getattr(webview, "FileDialog", None), "OPEN", None)
            if open_dialog is None:
                open_dialog = webview.OPEN_DIALOG  # older pywebview versions
            chosen = window.create_file_dialog(
                open_dialog,
                file_types=(
                    "SanPyCAD scripts (*.py;*.scad)",
                    "Python files (*.py)",
                    "OpenSCAD files (*.scad)",
                    "All files (*.*)",
                ),
            )
            if not chosen:
                return {"canceled": True}
            path = chosen[0] if isinstance(chosen, (list, tuple)) else chosen
            with open(path, "r", encoding="utf-8") as f:
                code = f.read()
            return {"path": path, "code": code}
        except Exception as e:
            traceback.print_exc()
            return {"error": str(e)}

    def pick_openscad_path(self):
        """Native file picker for the Settings panel's 'OpenSCAD path'
        field. On macOS this is filtered to show .app bundles -- native
        Open panels (and Finder) present OpenSCAD.app as a single,
        non-navigable item rather than something you'd have to dig inside
        of to find the real executable, and the backend already knows how
        to resolve a .app path to the actual binary inside it (see
        openscad_cli._resolve_app_bundle). On Windows/Linux this filters
        to executables/all files instead, since there's no bundle concept
        there."""
        try:
            window = webview.windows[0]
            open_dialog = getattr(getattr(webview, "FileDialog", None), "OPEN", None)
            if open_dialog is None:
                open_dialog = webview.OPEN_DIALOG  # older pywebview versions
            if sys.platform == "darwin":
                file_types = ("Applications (*.app)", "All files (*.*)")
            elif sys.platform.startswith("win"):
                file_types = ("Executable files (*.exe)", "All files (*.*)")
            else:
                file_types = ("All files (*.*)",)
            chosen = window.create_file_dialog(open_dialog, file_types=file_types)
            if not chosen:
                return {"canceled": True}
            path = chosen[0] if isinstance(chosen, (list, tuple)) else chosen
            return {"path": path}
        except Exception as e:
            traceback.print_exc()
            return {"error": str(e)}


def main():
    server.print_backend_status()
    port = find_free_port()
    httpd, port = server.serve(host="127.0.0.1", port=port)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()

    url = f"http://127.0.0.1:{port}/"
    wait_for_server(url)
    print(f"[SanPyCAD] backend running at {url}")

    try:
        global webview
        import webview
        api = Api()
        window = webview.create_window(
            "SanPyCAD", url, width=1400, height=900, min_size=(900, 600),
            js_api=api,
        )
        # debug=True enables "Inspect Element" in the app window, so JS
        # errors can be diagnosed the same way as in a regular browser if
        # something ever goes wrong -- but on some platforms/backends
        # (notably Windows' WebView2/EdgeChromium backend), it doesn't
        # just make that available on request: it pops the whole DevTools
        # panel open automatically, every single launch. That's a
        # developer/troubleshooting tool, not something anyone needs for
        # normal use, so it's off unless explicitly asked for.
        debug_mode = bool(os.environ.get("SANPYCAD_DEBUG"))
        webview.start(debug=debug_mode)
    except ImportError:
        print("[SanPyCAD] pywebview not installed -- opening your default "
              "browser instead. For a real app window, run: pip install pywebview")
        webbrowser.open(url)
        print("[SanPyCAD] press Ctrl+C here to stop the app")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            pass

    httpd.shutdown()


if __name__ == "__main__":
    main()
