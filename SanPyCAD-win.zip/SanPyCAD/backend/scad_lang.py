"""
scad_lang.py

A tokenizer + recursive-descent parser for a practical subset of the
OpenSCAD language. Produces an AST that scad_eval.py walks to build
geometry using the user's `openscad4.py` library.

Supported language features:
  - comments: // line, /* block */
  - literals: numbers, strings, true/false/undef, vectors [a,b,c], ranges [a:b] / [a:s:b]
  - operators: + - * / % (arith), == != < <= > >= (compare), && || ! (bool),
               ?: (ternary), unary -  +, indexing v[i], string/vector concat via +
  - variables: x = 5;  (including special vars like $fn = 50;)
  - function literals: function f(x) = x*2;
  - control flow: for (i = [0:5]) { ... }   if (cond) { ... } else { ... }
  - module definitions: module foo(a, b=1) { ... }
  - module instantiation / children blocks: foo(1,2) { ... }  or foo(1,2);
  - modifier characters prefixing a module call: % # ! *
  - built in modules mapped to the geometry library:
        cube, sphere, cylinder, polyhedron, circle, square, polygon,
        translate, rotate, scale, mirror, color, resize,
        linear_extrude, rotate_extrude,
        union, difference, intersection, hull,
        import (STL/OBJ/OFF as 3D shapes, SVG as a 2D shape usable
                inside linear_extrude/rotate_extrude -- see mesh_import.py),
        echo, children (basic)
"""

import re

# --------------------------------------------------------------------------
# AST node
# --------------------------------------------------------------------------

class Node:
    __slots__ = ("type", "attrs")

    def __init__(self, type, **attrs):
        self.type = type
        self.attrs = attrs

    def __getattr__(self, name):
        try:
            return self.attrs[name]
        except KeyError:
            raise AttributeError(name)

    def __repr__(self):
        return f"<{self.type} {self.attrs}>"


class ScadSyntaxError(Exception):
    def __init__(self, msg, line=None):
        self.line = line
        super().__init__(f"line {line}: {msg}" if line else msg)


# --------------------------------------------------------------------------
# Lexer
# --------------------------------------------------------------------------

TOKEN_SPEC = [
    ("SKIP",      r"[ \t\r]+"),
    ("NEWLINE",   r"\n"),
    ("BLOCKCOMMENT", r"/\*.*?\*/"),
    ("LINECOMMENT",  r"//[^\n]*"),
    ("NUMBER",    r"\d+\.\d+([eE][+-]?\d+)?|\.\d+([eE][+-]?\d+)?|\d+([eE][+-]?\d+)?"),
    ("STRING",    r'"(?:\\.|[^"\\])*"'),
    ("IDENT",     r"\$?[A-Za-z_][A-Za-z0-9_]*"),
    ("LE",        r"<="),
    ("GE",        r">="),
    ("EQ",        r"=="),
    ("NE",        r"!="),
    ("AND",       r"&&"),
    ("OR",        r"\|\|"),
    ("HASH",      r"#"),
    ("OP",        r"[+\-*/%^]"),
    ("ASSIGN",    r"="),
    ("LT",        r"<"),
    ("GT",        r">"),
    ("NOT",       r"!"),
    ("QUESTION",  r"\?"),
    ("COLON",     r":"),
    ("LBRACE",    r"\{"),
    ("RBRACE",    r"\}"),
    ("LPAREN",    r"\("),
    ("RPAREN",    r"\)"),
    ("LBRACK",    r"\["),
    ("RBRACK",    r"\]"),
    ("COMMA",     r","),
    ("SEMI",      r";"),
    ("DOT",       r"\."),
    ("MISMATCH",  r"."),
]

MASTER_RE = re.compile("|".join(f"(?P<{n}>{p})" for n, p in TOKEN_SPEC), re.DOTALL)


class Token:
    __slots__ = ("kind", "value", "line")

    def __init__(self, kind, value, line):
        self.kind = kind
        self.value = value
        self.line = line

    def __repr__(self):
        return f"Token({self.kind},{self.value!r})"


def tokenize(src):
    tokens = []
    line = 1
    pos = 0
    n = len(src)
    while pos < n:
        m = MASTER_RE.match(src, pos)
        if not m:
            raise ScadSyntaxError(f"unexpected character {src[pos]!r}", line)
        kind = m.lastgroup
        value = m.group()
        if kind == "NEWLINE":
            line += 1
        elif kind in ("SKIP", "LINECOMMENT"):
            pass
        elif kind == "BLOCKCOMMENT":
            line += value.count("\n")
        elif kind == "MISMATCH":
            raise ScadSyntaxError(f"unexpected character {value!r}", line)
        else:
            tokens.append(Token(kind, value, line))
        pos = m.end()
    tokens.append(Token("EOF", "", line))
    return tokens


# --------------------------------------------------------------------------
# Parser
# --------------------------------------------------------------------------

MODULE_MODIFIERS = {"HASH": "highlight", "NOT": "root_only"}
MODULE_MODIFIER_OPS = {"%": "background", "*": "disable"}


class Parser:
    def __init__(self, tokens):
        self.toks = tokens
        self.i = 0

    # -- token helpers ----------------------------------------------------
    def peek(self, k=0):
        j = self.i + k
        if j >= len(self.toks):
            return self.toks[-1]
        return self.toks[j]

    def at(self, *kinds):
        return self.peek().kind in kinds

    def advance(self):
        t = self.peek()
        if t.kind != "EOF":
            self.i += 1
        return t

    def expect(self, kind, msg=None):
        t = self.peek()
        if t.kind != kind:
            raise ScadSyntaxError(msg or f"expected {kind} but got {t.kind} ({t.value!r})", t.line)
        return self.advance()

    # -- entry point --------------------------------------------------
    def parse_program(self):
        stmts = []
        while not self.at("EOF"):
            stmts.append(self.parse_statement())
        return Node("program", body=stmts)

    # -- statements -----------------------------------------------------
    def parse_block(self):
        self.expect("LBRACE")
        stmts = []
        while not self.at("RBRACE"):
            if self.at("EOF"):
                raise ScadSyntaxError("unterminated block, expected '}'", self.peek().line)
            stmts.append(self.parse_statement())
        self.expect("RBRACE")
        return stmts

    def parse_statement(self):
        t = self.peek()

        if t.kind == "SEMI":
            self.advance()
            return Node("noop")

        if t.kind == "LBRACE":
            body = self.parse_block()
            return Node("block", body=body)

        # module / function definitions
        if t.kind == "IDENT" and t.value == "module":
            return self.parse_module_def()
        if t.kind == "IDENT" and t.value == "function":
            return self.parse_function_def()
        if t.kind == "IDENT" and t.value == "for":
            return self.parse_for()
        if t.kind == "IDENT" and t.value == "if":
            return self.parse_if()
        if t.kind == "IDENT" and t.value == "let":
            return self.parse_let_stmt()

        # modifier prefix (# % ! *) before a module call. Checked here
        # (statement-start position) rather than in the lexer, so these
        # characters keep their normal operator meaning (modulo, negation,
        # multiplication) everywhere else.
        modifier = None
        if t.kind in MODULE_MODIFIERS:
            modifier = MODULE_MODIFIERS[t.kind]
            self.advance()
            t = self.peek()
        elif t.kind == "OP" and t.value in MODULE_MODIFIER_OPS:
            modifier = MODULE_MODIFIER_OPS[t.value]
            self.advance()
            t = self.peek()

        if t.kind == "IDENT":
            # lookahead: IDENT '=' -> assignment ; IDENT '(' -> call
            nxt = self.peek(1)
            if nxt.kind == "ASSIGN":
                name = self.advance().value
                self.advance()  # '='
                expr = self.parse_expr()
                self.expect("SEMI")
                return Node("assign", name=name, expr=expr, line=t.line)
            if nxt.kind == "LPAREN":
                return self.parse_call_stmt(modifier)

        raise ScadSyntaxError(f"unexpected token {t.kind} ({t.value!r})", t.line)

    def parse_module_def(self):
        self.advance()  # 'module'
        name = self.expect("IDENT").value
        params = self.parse_param_list_def()
        body = self.parse_block()
        return Node("module_def", name=name, params=params, body=body)

    def parse_function_def(self):
        self.advance()  # 'function'
        name = self.expect("IDENT").value
        params = self.parse_param_list_def()
        self.expect("ASSIGN")
        expr = self.parse_expr()
        self.expect("SEMI")
        return Node("function_def", name=name, params=params, expr=expr)

    def parse_param_list_def(self):
        self.expect("LPAREN")
        params = []
        while not self.at("RPAREN"):
            pname = self.expect("IDENT").value
            default = None
            if self.at("ASSIGN"):
                self.advance()
                default = self.parse_expr()
            params.append((pname, default))
            if self.at("COMMA"):
                self.advance()
        self.expect("RPAREN")
        return params

    def parse_for(self):
        self.advance()  # 'for'
        self.expect("LPAREN")
        var = self.expect("IDENT").value
        self.expect("ASSIGN")
        rng = self.parse_expr()
        self.expect("RPAREN")
        body = self.parse_body_or_stmt()
        return Node("for", var=var, range=rng, body=body)

    def parse_if(self):
        self.advance()  # 'if'
        self.expect("LPAREN")
        cond = self.parse_expr()
        self.expect("RPAREN")
        then = self.parse_body_or_stmt()
        else_ = None
        if self.at("IDENT") and self.peek().value == "else":
            self.advance()
            else_ = self.parse_body_or_stmt()
        return Node("if", cond=cond, then=then, else_=else_)

    def parse_let_stmt(self):
        # let(a=1,b=2) <stmt>  -- treat as an inline scope
        self.advance()
        self.expect("LPAREN")
        binds = []
        while not self.at("RPAREN"):
            name = self.expect("IDENT").value
            self.expect("ASSIGN")
            expr = self.parse_expr()
            binds.append((name, expr))
            if self.at("COMMA"):
                self.advance()
        self.expect("RPAREN")
        body = self.parse_body_or_stmt()
        return Node("let", binds=binds, body=body)

    def parse_body_or_stmt(self):
        if self.at("LBRACE"):
            return self.parse_block()
        return [self.parse_statement()]

    def parse_call_stmt(self, modifier):
        name = self.expect("IDENT").value
        line = self.peek().line
        args = self.parse_arg_list()
        children = []
        if self.at("LBRACE"):
            children = self.parse_block()
        elif self.at("SEMI"):
            self.advance()
        else:
            children = [self.parse_statement()]
        return Node("call", name=name, args=args, children=children,
                    modifier=modifier, line=line)

    def parse_arg_list(self):
        self.expect("LPAREN")
        args = []  # list of (name_or_None, expr)
        while not self.at("RPAREN"):
            if self.at("IDENT") and self.peek(1).kind == "ASSIGN":
                pname = self.advance().value
                self.advance()
                expr = self.parse_expr()
                args.append((pname, expr))
            else:
                expr = self.parse_expr()
                args.append((None, expr))
            if self.at("COMMA"):
                self.advance()
        self.expect("RPAREN")
        return args

    # -- expressions (precedence climbing) -------------------------------
    def parse_expr(self):
        return self.parse_ternary()

    def parse_ternary(self):
        cond = self.parse_or()
        if self.at("QUESTION"):
            self.advance()
            a = self.parse_expr()
            self.expect("COLON")
            b = self.parse_expr()
            return Node("ternary", cond=cond, a=a, b=b)
        return cond

    def parse_or(self):
        left = self.parse_and()
        while self.at("OR"):
            self.advance()
            right = self.parse_and()
            left = Node("binop", op="||", left=left, right=right)
        return left

    def parse_and(self):
        left = self.parse_equality()
        while self.at("AND"):
            self.advance()
            right = self.parse_equality()
            left = Node("binop", op="&&", left=left, right=right)
        return left

    def parse_equality(self):
        left = self.parse_relational()
        while self.at("EQ", "NE"):
            op = self.advance().kind
            right = self.parse_relational()
            left = Node("binop", op=("==" if op == "EQ" else "!="), left=left, right=right)
        return left

    def parse_relational(self):
        left = self.parse_additive()
        while self.at("LT", "GT", "LE", "GE"):
            op = self.advance()
            sym = {"LT": "<", "GT": ">", "LE": "<=", "GE": ">="}[op.kind]
            right = self.parse_additive()
            left = Node("binop", op=sym, left=left, right=right)
        return left

    def parse_additive(self):
        left = self.parse_mult()
        while self.at("OP") and self.peek().value in ("+", "-"):
            op = self.advance().value
            right = self.parse_mult()
            left = Node("binop", op=op, left=left, right=right)
        return left

    def parse_mult(self):
        left = self.parse_unary()
        while self.at("OP") and self.peek().value in ("*", "/", "%"):
            op = self.advance().value
            right = self.parse_unary()
            left = Node("binop", op=op, left=left, right=right)
        return left

    def parse_unary(self):
        if self.at("OP") and self.peek().value in ("-", "+"):
            op = self.advance().value
            operand = self.parse_unary()
            return Node("unop", op=op, operand=operand)
        if self.at("NOT"):
            self.advance()
            operand = self.parse_unary()
            return Node("unop", op="!", operand=operand)
        return self.parse_postfix()

    def parse_postfix(self):
        node = self.parse_primary()
        while True:
            if self.at("LBRACK"):
                self.advance()
                idx = self.parse_expr()
                self.expect("RBRACK")
                node = Node("index", target=node, index=idx)
            elif self.at("DOT"):
                self.advance()
                field = self.expect("IDENT").value
                node = Node("field", target=node, field=field)
            else:
                break
        return node

    def parse_primary(self):
        t = self.peek()
        if t.kind == "NUMBER":
            self.advance()
            return Node("num", value=float(t.value))
        if t.kind == "STRING":
            self.advance()
            return Node("str", value=_unescape(t.value[1:-1]))
        if t.kind == "LPAREN":
            self.advance()
            e = self.parse_expr()
            self.expect("RPAREN")
            return e
        if t.kind == "LBRACK":
            return self.parse_vector_or_range()
        if t.kind == "IDENT":
            if t.value == "let":
                return self.parse_let_expr()
            self.advance()
            if t.value in ("true",):
                return Node("bool", value=True)
            if t.value in ("false",):
                return Node("bool", value=False)
            if t.value in ("undef",):
                return Node("undef")
            if self.at("LPAREN"):
                args = self.parse_arg_list()
                return Node("funcall", name=t.value, args=args)
            return Node("var", name=t.value)
        raise ScadSyntaxError(f"unexpected token {t.kind} ({t.value!r}) in expression", t.line)

    def parse_let_expr(self):
        self.advance()  # 'let'
        self.expect("LPAREN")
        binds = []
        while not self.at("RPAREN"):
            name = self.expect("IDENT").value
            self.expect("ASSIGN")
            expr = self.parse_expr()
            binds.append((name, expr))
            if self.at("COMMA"):
                self.advance()
        self.expect("RPAREN")
        body = self.parse_expr()
        return Node("let_expr", binds=binds, body=body)

    def parse_vector_or_range(self):
        self.expect("LBRACK")
        if self.at("RBRACK"):
            self.advance()
            return Node("vector", items=[])
        first = self.parse_expr()
        if self.at("COLON"):
            parts = [first]
            while self.at("COLON"):
                self.advance()
                parts.append(self.parse_expr())
            self.expect("RBRACK")
            if len(parts) == 2:
                return Node("range", start=parts[0], step=Node("num", value=1.0), end=parts[1])
            return Node("range", start=parts[0], step=parts[1], end=parts[2])
        items = [first]
        while self.at("COMMA"):
            self.advance()
            if self.at("RBRACK"):
                break
            items.append(self.parse_expr())
        self.expect("RBRACK")
        return Node("vector", items=items)


def _unescape(s):
    return (s.replace("\\n", "\n").replace("\\t", "\t")
             .replace('\\"', '"').replace("\\\\", "\\"))


def parse(src):
    tokens = tokenize(src)
    p = Parser(tokens)
    return p.parse_program()
