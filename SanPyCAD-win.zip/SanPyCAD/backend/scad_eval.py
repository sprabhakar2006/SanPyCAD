"""
scad_eval.py

Walks the AST produced by scad_lang.parse() and evaluates it into a scene
(list of triangle meshes), using openscad4.py for all actual geometry
generation:

  - cube / sphere / cylinder / linear_extrude / circle / square are called
    directly from openscad4.py
  - openscad4.triangulate_solid_open() (which itself uses earclip_3d) turns
    every generated "sol" (list-of-cross-sections) into a watertight
    triangle soup -- this is what gives capped, solid meshes instead of
    open tubes
  - openscad4.points_inside_solid()'s ray-parity technique is reused
    (generalized in csg.py) to implement union/difference/intersection
  - openscad4.convex_hull-style reasoning is used for hull() via scipy

Transforms (translate/rotate/scale/mirror/resize) are applied directly to
the resulting vertex arrays with numpy so they compose uniformly whether
the mesh came straight from the library or out of a boolean/hull op.
"""

import numpy as np
import math
import os

import openscad4 as oscad
import csg
import mesh_import
from geom_bridge import sol_to_mesh
from scad_lang import parse, ScadSyntaxError, Node


# --------------------------------------------------------------------------
# color table (subset of OpenSCAD/SVG named colors)
# --------------------------------------------------------------------------

COLOR_NAMES = {
    "red": (1, 0, 0), "green": (0, 0.5, 0), "lime": (0, 1, 0), "blue": (0, 0, 1),
    "yellow": (1, 1, 0), "cyan": (0, 1, 1), "magenta": (1, 0, 1), "white": (1, 1, 1),
    "black": (0, 0, 0), "gray": (0.5, 0.5, 0.5), "grey": (0.5, 0.5, 0.5),
    "orange": (1, 0.647, 0), "purple": (0.5, 0, 0.5), "pink": (1, 0.753, 0.796),
    "brown": (0.647, 0.165, 0.165), "silver": (0.753, 0.753, 0.753),
    "gold": (1, 0.843, 0), "navy": (0, 0, 0.5), "teal": (0, 0.5, 0.5),
    "indigo": (0.294, 0, 0.510), "violet": (0.933, 0.510, 0.933),
    "skyblue": (0.529, 0.808, 0.922), "steelblue": (0.275, 0.510, 0.706),
    "salmon": (0.980, 0.502, 0.447), "khaki": (0.941, 0.902, 0.549),
    "coral": (1, 0.498, 0.314), "turquoise": (0.251, 0.878, 0.816),
    "plum": (0.867, 0.627, 0.867), "orchid": (0.855, 0.439, 0.839),
    "beige": (0.961, 0.961, 0.863), "ivory": (1, 1, 0.941),
    "darkgreen": (0, 0.392, 0), "darkblue": (0, 0, 0.545),
    "darkred": (0.545, 0, 0), "lightgray": (0.827, 0.827, 0.827),
    "lightgrey": (0.827, 0.827, 0.827), "lightblue": (0.678, 0.847, 0.902),
    "lightgreen": (0.565, 0.933, 0.565), "maroon": (0.5, 0, 0),
    "olive": (0.5, 0.5, 0), "aqua": (0, 1, 1), "fuchsia": (1, 0, 1),
}
DEFAULT_COLOR = (0.85, 0.68, 0.15)  # OpenSCAD's default preview yellow-gold-ish


class ScadRuntimeError(Exception):
    def __init__(self, msg, line=None):
        self.line = line
        super().__init__(f"line {line}: {msg}" if line else msg)


class Mesh:
    __slots__ = ("V", "F", "color", "alpha", "modifier", "raw_scad", "vertex_labels")

    def __init__(self, V, F, color=None, alpha=1.0, modifier=None, raw_scad=None, vertex_labels=None):
        self.V = np.asarray(V, dtype=float).reshape(-1, 3) if len(V) else np.zeros((0, 3))
        self.F = np.asarray(F, dtype=int).reshape(-1, 3) if len(F) else np.zeros((0, 3), dtype=int)
        self.color = color
        self.alpha = alpha
        self.modifier = modifier
        # If this mesh came straight from openscad4's swp()/swp_c()/
        # swp_surf()/swp_triangles() text (Python mode only), the exact
        # original polyhedron(...) source is kept here so a later CSG op
        # can hand it to real OpenSCAD verbatim instead of re-deriving
        # (and possibly mis-deriving) face connectivity from V/F. Cleared
        # by copy_with() whenever geometry actually changes.
        self.raw_scad = raw_scad
        # Parallel to V (same length, one entry per vertex) when this
        # mesh came straight from a Python-mode "sol" variable that was
        # show()n directly: each entry is a string like "sol1[0][10]"
        # naming exactly which cross-section/point of that variable this
        # vertex is, or None where no such correspondence could be
        # pin-pointed (e.g. end-cap points introduced by triangulation,
        # or this mesh isn't V/F-identical to a single named sol at all
        # -- a union()/difference()/etc result, for instance). Lets the
        # viewer's vertex-measure tool show the underlying Python
        # reference for a clicked point, not just its coordinates.
        # Cleared by copy_with() whenever geometry actually changes.
        self.vertex_labels = vertex_labels

    def copy_with(self, V=None, F=None):
        geometry_changed = V is not None or F is not None
        return Mesh(V if V is not None else self.V,
                     F if F is not None else self.F,
                     self.color, self.alpha, self.modifier,
                     raw_scad=None if geometry_changed else self.raw_scad,
                     vertex_labels=None if geometry_changed else self.vertex_labels)

    def is_empty(self):
        return len(self.V) == 0 or len(self.F) == 0


class Env:
    """Chained variable scope."""
    __slots__ = ("vars", "parent")

    def __init__(self, parent=None):
        self.vars = {}
        self.parent = parent

    def get(self, name, default=None):
        e = self
        while e is not None:
            if name in e.vars:
                return e.vars[name]
            e = e.parent
        return default

    def has(self, name):
        e = self
        while e is not None:
            if name in e.vars:
                return True
            e = e.parent
        return False

    def set(self, name, value):
        self.vars[name] = value

    def child(self):
        return Env(parent=self)


MAX_STEPS = 400_000  # guard against runaway for-loops / recursive modules


class Evaluator:
    def __init__(self, csg_resolution=56, max_steps=MAX_STEPS):
        self.modules = {}
        self.functions = {}
        self.global_env = Env()
        self.warnings = []
        self.echo_log = []
        self.steps = 0
        self.max_steps = max_steps
        self.csg_resolution = csg_resolution
        self.children_stack = []  # list of (children_ast, caller_env)

    # ---- top level ------------------------------------------------------
    def run(self, source):
        ast = parse(source)
        self._collect_defs(ast.body)
        meshes = self._eval_stmts(ast.body, self.global_env)
        return meshes

    def _collect_defs(self, stmts):
        for s in stmts:
            if s.type == "module_def":
                self.modules[s.name] = s
            elif s.type == "function_def":
                self.functions[s.name] = s
            elif s.type == "block":
                self._collect_defs(s.body)
            elif s.type in ("for", "if", "let"):
                # nested defs inside control structures are uncommon but
                # harmless to pick up defensively
                pass

    def _tick(self, line=None):
        self.steps += 1
        if self.steps > self.max_steps:
            raise ScadRuntimeError("script exceeded the maximum step budget "
                                    "(likely an infinite loop or runaway recursion)", line)

    # ---- statements -------------------------------------------------
    def _eval_stmts(self, stmts, env):
        out = []
        for s in stmts:
            out.extend(self._eval_stmt(s, env))
        return out

    def _eval_stmt(self, s, env):
        self._tick(getattr(s, "attrs", {}).get("line"))
        t = s.type

        if t in ("noop", "module_def", "function_def"):
            return []

        if t == "assign":
            env.set(s.name, self._eval_expr(s.expr, env))
            return []

        if t == "block":
            return self._eval_stmts(s.body, env.child())

        if t == "for":
            return self._eval_for(s, env)

        if t == "if":
            cond = truthy(self._eval_expr(s.cond, env))
            body = s.then if cond else s.else_
            if body is None:
                return []
            return self._eval_stmts(body, env.child())

        if t == "let":
            child = env.child()
            for name, expr in s.binds:
                child.set(name, self._eval_expr(expr, env))
            return self._eval_stmts(s.body, child)

        if t == "call":
            return self._eval_call(s, env)

        raise ScadRuntimeError(f"cannot evaluate statement of type {t}", None)

    def _eval_for(self, s, env):
        rng = self._eval_range_or_list(s.range, env)
        out = []
        for val in rng:
            child = env.child()
            child.set(s.var, val)
            out.extend(self._eval_stmts(s.body, child))
        return out

    def _eval_range_or_list(self, node, env):
        if node.type == "range":
            start = num(self._eval_expr(node.start, env))
            step = num(self._eval_expr(node.step, env))
            end = num(self._eval_expr(node.end, env))
            if step == 0:
                return [start]
            vals = []
            n = 0
            cur = start
            # cap iterations defensively
            while (step > 0 and cur <= end + 1e-9) or (step < 0 and cur >= end - 1e-9):
                vals.append(cur)
                n += 1
                if n > 200_000:
                    raise ScadRuntimeError("for-range produced too many iterations")
                cur = start + n * step
            return vals
        val = self._eval_expr(node, env)
        if isinstance(val, list):
            return val
        return [val]

    # ---- calls (module instantiation) -----------------------------------
    def _eval_call(self, s, env):
        name = s.name
        line = s.attrs.get("line")

        if name in TRANSFORM_BUILTINS:
            meshes = self._eval_transform(name, s, env)
        elif name in ("union", "difference", "intersection"):
            meshes = self._eval_boolean(name, s, env)
        elif name == "hull":
            meshes = self._eval_hull(s, env)
        elif name in PRIMITIVE_BUILTINS:
            meshes = [self._eval_primitive(name, s, env)]
        elif name == "import":
            result = self._eval_import(s, env)
            meshes = [result] if result is not None else []
        elif name in ("linear_extrude", "rotate_extrude"):
            meshes = [self._eval_extrude(name, s, env)]
        elif name == "echo":
            self._eval_echo(s, env)
            meshes = []
        elif name == "children":
            meshes = self._eval_children_call(s, env)
        elif name in self.modules:
            meshes = self._eval_user_module(name, s, env)
        elif name in ("circle", "square", "polygon"):
            self.warnings.append(
                f"line {line}: {name}() is a 2D shape -- it only renders inside "
                f"linear_extrude() or rotate_extrude() in this tool, so it was skipped here")
            meshes = []
        else:
            self.warnings.append(f"line {line}: unknown module '{name}()' ignored")
            meshes = []

        meshes = [m for m in meshes if m is not None]

        if s.modifier == "disable":
            return []
        if s.modifier == "background":
            for m in meshes:
                m.alpha = min(m.alpha, 0.35)
        if s.modifier == "highlight":
            for m in meshes:
                m.color = (1.0, 0.0, 0.0)
        return meshes

    def _eval_children_call(self, s, env):
        if not self.children_stack:
            self.warnings.append("children() called outside of a module body")
            return []
        children_ast, caller_env = self.children_stack[-1]
        # children(i) selects a single indexed child; children() = all
        if s.args:
            idx = int(num(self._eval_expr(s.args[0][1], env)))
            if 0 <= idx < len(children_ast):
                return self._eval_stmt(children_ast[idx], caller_env)
            return []
        return self._eval_stmts(children_ast, caller_env)

    def _eval_user_module(self, name, s, env):
        mod = self.modules[name]
        call_env = self.global_env.child()
        bound = bind_args(s.args, mod.params, env, self)
        for k, v in bound.items():
            call_env.set(k, v)
        self.children_stack.append((s.children, env))
        try:
            result = self._eval_stmts(mod.body, call_env)
        finally:
            self.children_stack.pop()
        return result

    def _eval_echo(self, s, env):
        parts = []
        for name, expr in s.args:
            v = self._eval_expr(expr, env)
            if name:
                parts.append(f"{name} = {fmt_val(v)}")
            else:
                parts.append(fmt_val(v))
        self.echo_log.append("ECHO: " + ", ".join(parts))

    # ---- transforms -------------------------------------------------
    def _eval_transform(self, name, s, env):
        children = self._eval_stmts(s.children, env.child())
        args = args_dict(s.args, env, self)

        if name == "translate":
            v = as_vec3(pos_or_named(args, s.args, env, self, 0, "v", [0, 0, 0]))
            for m in children:
                if not m.is_empty():
                    m.V = m.V + np.array(v)
            return children

        if name == "rotate":
            a = pos_or_named(args, s.args, env, self, 0, "a", 0)
            axis = args.get("v")
            R = rotation_matrix(a, axis)
            for m in children:
                if not m.is_empty():
                    m.V = m.V @ R.T
            return children

        if name == "scale":
            v = pos_or_named(args, s.args, env, self, 0, "v", [1, 1, 1])
            sx, sy, sz = as_vec3(v, fill=v if not isinstance(v, list) else 1)
            for m in children:
                if not m.is_empty():
                    m.V = m.V * np.array([sx, sy, sz])
            return children

        if name == "mirror":
            v = pos_or_named(args, s.args, env, self, 0, "v", [1, 0, 0])
            n = np.array(as_vec3(v), dtype=float)
            norm = np.linalg.norm(n)
            if norm > 1e-12:
                n = n / norm
                for m in children:
                    if not m.is_empty():
                        d = m.V @ n
                        m.V = m.V - 2.0 * np.outer(d, n)
                        # mirroring flips winding; reverse each triangle
                        m.F = m.F[:, ::-1]
            return children

        if name == "color":
            c, a = resolve_color(args, s.args, env, self)
            for m in children:
                if c is not None:
                    m.color = c
                if a is not None:
                    m.alpha = a
            return children

        if name == "resize":
            newsize = pos_or_named(args, s.args, env, self, 0, "newsize", [0, 0, 0])
            nx, ny, nz = as_vec3(newsize)
            for m in children:
                if m.is_empty():
                    continue
                lo = m.V.min(axis=0)
                hi = m.V.max(axis=0)
                dims = np.maximum(hi - lo, 1e-9)
                factors = np.array([
                    nx / dims[0] if nx else 1.0,
                    ny / dims[1] if ny else 1.0,
                    nz / dims[2] if nz else 1.0,
                ])
                center = (lo + hi) / 2.0
                m.V = (m.V - center) * factors + center
            return children

        raise ScadRuntimeError(f"unhandled transform '{name}'")

    # ---- boolean / hull -----------------------------------------------
    def _eval_boolean(self, name, s, env):
        line = s.attrs.get("line")
        children = self._eval_stmts(s.children, env.child())
        real = [m for m in children if not m.is_empty()]
        if not real:
            self.warnings.append(f"line {line}: {name}() has no non-empty children, skipped")
            return []
        if len(real) == 1 and name != "difference":
            # nothing to combine with -- pass the single child straight
            # through instead of round-tripping it through voxelization
            return [real[0]]
        color = next((m.color for m in real if m.color), None)
        alpha = real[0].alpha
        pairs = [(m.V, m.F) for m in real]
        V, F = csg.boolean_op(pairs, name, resolution=self.csg_resolution, notes=self.warnings)
        if len(V) == 0:
            self.warnings.append(
                f"line {line}: {name}() produced an empty result -- the operands may not "
                f"overlap as expected, or 'CSG detail' may be too low to resolve them")
            return []
        return [Mesh(V, F, color=color, alpha=alpha)]

    def _eval_hull(self, s, env):
        line = s.attrs.get("line")
        children = self._eval_stmts(s.children, env.child())
        real = [m for m in children if not m.is_empty()]
        if not real:
            self.warnings.append(f"line {line}: hull() has no non-empty children, skipped")
            return []
        color = next((m.color for m in real if m.color), None)
        pairs = [(m.V, m.F) for m in real]
        V, F = csg.hull_op(pairs, notes=self.warnings)
        if len(V) == 0:
            self.warnings.append(f"line {line}: hull() produced an empty result")
            return []
        return [Mesh(V, F, color=color, alpha=real[0].alpha)]

    # ---- primitives -------------------------------------------------
    def _eval_primitive(self, name, s, env):
        args = args_dict(s.args, env, self)
        fn = getattr(env, "get")  # not used, placeholder for clarity
        segs = self._segments(args, env)

        if name == "cube":
            size = pos_or_named(args, s.args, env, self, 0, "size", 1)
            sx, sy, sz = as_vec3(size, fill=size if not isinstance(size, list) else 1)
            center = bool(args.get("center", False))
            sol = oscad.cube([sx, sy, sz], center=center)
            return self._sol_to_mesh(sol)

        if name == "sphere":
            r = radius_from(args, s.args, env, self)
            sol = oscad.sphere(r=r, s=segs)
            return self._sol_to_mesh(sol)

        if name == "cylinder":
            h = get_named_or_pos(args, s.args, env, self, 0, "h", 1)
            r = args.get("r")
            r1 = args.get("r1")
            r2 = args.get("r2")
            d = args.get("d")
            d1 = args.get("d1")
            d2 = args.get("d2")
            center = bool(args.get("center", False))
            kwargs = dict(h=num(h), s=segs, center=center)
            if r is not None:
                kwargs["r"] = num(r)
            if r1 is not None:
                kwargs["r1"] = num(r1)
            if r2 is not None:
                kwargs["r2"] = num(r2)
            if d is not None:
                kwargs["d"] = num(d)
            if d1 is not None:
                kwargs["d1"] = num(d1)
            if d2 is not None:
                kwargs["d2"] = num(d2)
            if "r" not in kwargs and "r1" not in kwargs and "d" not in kwargs and "d1" not in kwargs:
                kwargs["r1"] = 1.0
            if "r" not in kwargs and "r2" not in kwargs and "d" not in kwargs and "d2" not in kwargs:
                kwargs["r2"] = 1.0
            sol = oscad.cylinder(**kwargs)
            return self._sol_to_mesh(sol)

        if name == "polyhedron":
            pts = args.get("points") or get_positional(s.args, 0, env, self)
            faces = args.get("faces") or args.get("triangles") or get_positional(s.args, 1, env, self)
            V = np.array(pts, dtype=float)
            F = triangulate_face_list(faces)
            return Mesh(V, F)

        raise ScadRuntimeError(f"unhandled primitive '{name}'")

    def _sol_to_mesh(self, sol):
        """Convert an openscad4 'sol' (list of equal-length cross sections)
        into a watertight (V,F) mesh -- see geom_bridge.sol_to_mesh()."""
        V, F = sol_to_mesh(oscad, sol)
        return Mesh(V, F)

    def _eval_import(self, s, env):
        """import("model.stl") / import("model.obj") / import("model.off")
        -- like OpenSCAD's own import(), pulls in an external mesh file as
        a shape usable with translate()/color()/union()/etc. Relative
        paths resolve against the imports/ folder next to this app (see
        mesh_import.py); absolute paths are used as-is.

        import("shape.svg") is a 2D format -- same deal as circle()/
        square()/polygon(), it only actually produces something inside
        linear_extrude()/rotate_extrude() (see _try_eval_2d below); called
        anywhere else it just warns and produces nothing, which is why
        this returns None here instead of a Mesh."""
        line = s.attrs.get("line")
        args = args_dict(s.args, env, self)
        path = args.get("file")
        if path is None:
            path = get_positional(s.args, 0, env, self)
        if path is None:
            raise ScadRuntimeError(
                'import() needs a file path, e.g. import("model.stl")', line)
        path = str(path)
        ext = os.path.splitext(path)[1].lower()
        if ext in mesh_import.SUPPORTED_2D_EXTENSIONS:
            self.warnings.append(
                f'line {line}: import("{path}") is a 2D shape -- it only renders '
                f"inside linear_extrude()/rotate_extrude() in this tool, so it was skipped here")
            return None
        try:
            V, F = mesh_import.read_mesh_file(path)
        except (FileNotFoundError, ValueError, OSError) as e:
            raise ScadRuntimeError(str(e), line)
        return Mesh(V, F)

    def _segments(self, args, env):
        if "$fn" in args and args["$fn"]:
            n = int(num(args["$fn"]))
            return max(n, 3)
        if env.has("$fn"):
            v = env.get("$fn")
            if v:
                return max(int(num(v)), 3)
        return 50

    # ---- extrusion ----------------------------------------------------
    def _eval_extrude(self, name, s, env):
        args = args_dict(s.args, env, self)
        profiles = self._eval_2d_profiles(s.children, env)
        profiles = [p for p in (profiles or []) if p is not None and len(p) >= 3]
        if not profiles:
            self.warnings.append(f"line {s.attrs.get('line')}: {name}() needs a 2D "
                                  f"child shape (circle/square/polygon/import)")
            return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=int))

        sols = []
        if name == "linear_extrude":
            h = num(get_named_or_pos(args, s.args, env, self, 0, "height", args.get("h", 1)))
            twist = num(args.get("twist", 0))
            center = bool(args.get("center", False))
            steps = int(num(args.get("slices", max(2, abs(twist) // 6 + 2))))
            for profile in profiles:
                sol = oscad.linear_extrude(profile, h=h, a=twist, steps=steps)
                if center:
                    sol = oscad.translate([0, 0, -h / 2], sol)
                sols.append(sol)
        elif name == "rotate_extrude":
            angle = num(args.get("angle", 360))
            segs = self._segments(args, env)
            for profile in profiles:
                sols.append(revolve_profile(profile, angle, segs=segs))
        else:
            raise ScadRuntimeError(f"unhandled extrude '{name}'")

        meshes = [self._sol_to_mesh(sol) for sol in sols]
        if len(meshes) == 1:
            return meshes[0]
        # More than one separate 2D shape came out of the same child block
        # -- typically a multi-part SVG import() (e.g. a flower's several
        # petal paths/ellipses, each its own closed shape since this
        # app's profiles are single-contour with no hole support). Each
        # was extruded on its own above; union them into one solid here,
        # the same CSG engine an explicit union() would use.
        color = next((m.color for m in meshes if m.color), None)
        pairs = [(m.V, m.F) for m in meshes]
        V, F = csg.boolean_op(pairs, "union", resolution=self.csg_resolution, notes=self.warnings)
        return Mesh(V, F, color=color)

    def _eval_2d_profiles(self, children_ast, env):
        """Evaluate a small set of 2D-producing children into a LIST of
        polygon outlines (each a points list). Only the first meaningful
        2D primitive/import is used; translate_2d-style wrapping is
        honored. Usually a single-element list -- more than one shows up
        when a child is a multi-part SVG import() (e.g. several separate
        petal shapes). This does not support 2D boolean ops within one
        shape (holes) -- see README for the recommended pattern (extrude
        solid, then 3D-difference a hole)."""
        for c in children_ast:
            pts_list = self._try_eval_2d_multi(c, env)
            if pts_list is not None:
                return pts_list
        return None

    def _apply_2d_transform(self, name, args, node_args, env, pts):
        """translate()/rotate()/scale() math shared between the
        single-profile and multi-profile 2D evaluators."""
        if name == "translate":
            v = pos_or_named(args, node_args, env, self, 0, "v", [0, 0])
            tx, ty = (v + [0, 0])[:2] if isinstance(v, list) else (v, 0)
            return [[p[0] + tx, p[1] + ty] for p in pts]
        if name == "scale":
            v = pos_or_named(args, node_args, env, self, 0, "v", [1, 1])
            sx, sy = (v + [1, 1])[:2] if isinstance(v, list) else (v, v)
            return [[p[0] * sx, p[1] * sy] for p in pts]
        if name == "rotate":
            a = math.radians(num(pos_or_named(args, node_args, env, self, 0, "a", 0)))
            ca, sa = math.cos(a), math.sin(a)
            return [[p[0] * ca - p[1] * sa, p[0] * sa + p[1] * ca] for p in pts]
        return pts  # "union" wrapper -- no transform of its own

    def _try_eval_2d_multi(self, node, env):
        """Like _try_eval_2d but always returns a LIST of profiles (or
        None) -- the only case that's ever more than one element is
        import() of an SVG with several separate closed shapes."""
        if node.type == "block":
            for c in node.body:
                r = self._try_eval_2d_multi(c, env)
                if r is not None:
                    return r
            return None
        if node.type != "call":
            return None
        name = node.name
        args = args_dict(node.args, env, self)
        if name == "import":
            path = args.get("file") or get_positional(node.args, 0, env, self)
            if path is None:
                return None
            path = str(path)
            ext = os.path.splitext(path)[1].lower()
            if ext not in mesh_import.SUPPORTED_2D_EXTENSIONS:
                # a 3D-format import() here isn't a 2D shape -- let the
                # normal "needs a 2D child shape" warning handle it
                return None
            try:
                _kind, profiles = mesh_import.read_import_file_multi(path)
            except (FileNotFoundError, ValueError, OSError) as e:
                self.warnings.append(f'line {node.attrs.get("line")}: import("{path}"): {e}')
                return None
            return profiles
        if name in ("translate", "rotate", "scale", "union"):
            inner = self._eval_2d_profiles(node.children, env)
            if inner is None:
                return None
            return [self._apply_2d_transform(name, args, node.args, env, p) for p in inner]
        single = self._try_eval_2d(node, env)
        return [single] if single is not None else None

    def _try_eval_2d(self, node, env):
        if node.type == "block":
            for c in node.body:
                pts = self._try_eval_2d(c, env)
                if pts is not None:
                    return pts
            return None
        if node.type != "call":
            return None
        name = node.name
        args = args_dict(node.args, env, self)
        if name == "circle":
            r = radius_from(args, node.args, env, self)
            segs = self._segments(args, env)
            return oscad.circle(r, s=segs)
        if name == "square":
            size = pos_or_named(args, node.args, env, self, 0, "size", 1)
            center = bool(args.get("center", False))
            return oscad.square(as_vec2(size), center=center)
        if name == "polygon":
            pts = args.get("points") or get_positional(node.args, 0, env, self)
            return [list(p) for p in pts]
        if name in ("translate", "rotate", "scale", "union"):
            # apply simple 2D transforms around a nested 2D primitive
            inner = self._eval_2d_profile_single(node.children, env)
            if inner is None:
                return None
            return self._apply_2d_transform(name, args, node.args, env, inner)
        return None

    def _eval_2d_profile_single(self, children_ast, env):
        """Single-profile counterpart of _eval_2d_profiles(), used only by
        _try_eval_2d()'s own translate/rotate/scale/union recursion
        (which never deals with import(), so it can never see more than
        one profile anyway)."""
        for c in children_ast:
            pts = self._try_eval_2d(c, env)
            if pts is not None:
                return pts
        return None

    # ---- expressions --------------------------------------------------
    def _eval_expr(self, node, env):
        t = node.type
        if t == "num":
            return node.value
        if t == "str":
            return node.value
        if t == "bool":
            return node.value
        if t == "undef":
            return None
        if t == "var":
            if not env.has(node.name):
                if node.name in ("PI",):
                    return math.pi
                return None
            return env.get(node.name)
        if t == "vector":
            return [self._eval_expr(i, env) for i in node.items]
        if t == "range":
            return self._eval_range_or_list(node, env)
        if t == "unop":
            v = self._eval_expr(node.operand, env)
            if node.op == "-":
                return neg(v)
            if node.op == "+":
                return v
            if node.op == "!":
                return not truthy(v)
        if t == "binop":
            return self._eval_binop(node, env)
        if t == "ternary":
            return self._eval_expr(node.a if truthy(self._eval_expr(node.cond, env)) else node.b, env)
        if t == "index":
            target = self._eval_expr(node.target, env)
            idx = self._eval_expr(node.index, env)
            try:
                return target[int(idx)]
            except Exception:
                return None
        if t == "let_expr":
            child = env.child()
            for name, expr in node.binds:
                child.set(name, self._eval_expr(expr, env))
            return self._eval_expr(node.body, child)
        if t == "funcall":
            return self._eval_funcall(node, env)
        raise ScadRuntimeError(f"cannot evaluate expression of type {t}")

    def _eval_binop(self, node, env):
        op = node.op
        if op == "&&":
            return truthy(self._eval_expr(node.left, env)) and truthy(self._eval_expr(node.right, env))
        if op == "||":
            return truthy(self._eval_expr(node.left, env)) or truthy(self._eval_expr(node.right, env))
        a = self._eval_expr(node.left, env)
        b = self._eval_expr(node.right, env)
        if op == "+":
            return vec_op(a, b, lambda x, y: x + y) if is_vec(a) or is_vec(b) else \
                (a + b if not isinstance(a, str) and not isinstance(b, str) else str(a) + str(b))
        if op == "-":
            return vec_op(a, b, lambda x, y: x - y) if is_vec(a) or is_vec(b) else a - b
        if op == "*":
            if is_vec(a) and is_vec(b):
                return float(np.dot(np.array(a, dtype=float), np.array(b, dtype=float)))
            return vec_op(a, b, lambda x, y: x * y) if is_vec(a) or is_vec(b) else a * b
        if op == "/":
            return vec_op(a, b, lambda x, y: x / y) if is_vec(a) or is_vec(b) else a / b
        if op == "%":
            return math.fmod(a, b)
        if op == "==":
            return a == b
        if op == "!=":
            return a != b
        if op == "<":
            return a < b
        if op == "<=":
            return a <= b
        if op == ">":
            return a > b
        if op == ">=":
            return a >= b
        raise ScadRuntimeError(f"unknown operator {op}")

    def _eval_funcall(self, node, env):
        name = node.name
        args = [self._eval_expr(a[1], env) for a in node.args]
        if name in MATH_FUNCS:
            return MATH_FUNCS[name](*args)
        if name in self.functions:
            fdef = self.functions[name]
            fenv = self.global_env.child()
            bound = bind_args(node.args, fdef.params, env, self)
            for k, v in bound.items():
                fenv.set(k, v)
            return self._eval_expr(fdef.expr, fenv)
        self.warnings.append(f"unknown function '{name}()' -> undef")
        return None


# --------------------------------------------------------------------------
# builtin dispatch tables
# --------------------------------------------------------------------------

TRANSFORM_BUILTINS = {"translate", "rotate", "scale", "mirror", "color", "resize"}
PRIMITIVE_BUILTINS = {"cube", "sphere", "cylinder", "polyhedron"}

MATH_FUNCS = {
    "sin": lambda x: math.sin(math.radians(x)),
    "cos": lambda x: math.cos(math.radians(x)),
    "tan": lambda x: math.tan(math.radians(x)),
    "asin": lambda x: math.degrees(math.asin(x)),
    "acos": lambda x: math.degrees(math.acos(x)),
    "atan": lambda x: math.degrees(math.atan(x)),
    "atan2": lambda y, x: math.degrees(math.atan2(y, x)),
    "sqrt": math.sqrt,
    "abs": abs,
    "pow": pow,
    "min": lambda *a: min(a[0]) if len(a) == 1 and isinstance(a[0], list) else min(a),
    "max": lambda *a: max(a[0]) if len(a) == 1 and isinstance(a[0], list) else max(a),
    "floor": lambda x: math.floor(x),
    "ceil": lambda x: math.ceil(x),
    "round": lambda x: round(x),
    "ln": math.log,
    "log": lambda x: math.log10(x),
    "exp": math.exp,
    "sign": lambda x: (x > 0) - (x < 0),
    "len": lambda x: len(x) if x is not None else 0,
    "concat": lambda *a: [i for sub in a for i in (sub if isinstance(sub, list) else [sub])],
    "str": lambda *a: "".join(fmt_val(x) for x in a),
    "norm": lambda v: float(np.linalg.norm(np.array(v, dtype=float))),
}


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------

def num(v, default=0.0):
    if v is None:
        return default
    return float(v)


def truthy(v):
    if v is None:
        return False
    if isinstance(v, (int, float)):
        return v != 0
    if isinstance(v, (list, str)):
        return len(v) > 0
    return bool(v)


def neg(v):
    if isinstance(v, list):
        return [neg(x) for x in v]
    return -v


def is_vec(v):
    return isinstance(v, list)


def vec_op(a, b, f):
    if is_vec(a) and is_vec(b):
        return [f(x, y) for x, y in zip(a, b)]
    if is_vec(a):
        return [f(x, b) for x in a]
    if is_vec(b):
        return [f(a, y) for y in b]
    return f(a, b)


def fmt_val(v):
    if v is None:
        return "undef"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float):
        if v == int(v):
            return str(int(v))
        return f"{v:g}"
    return str(v)


def as_vec3(v, fill=0):
    if isinstance(v, list):
        v = v + [fill] * (3 - len(v))
        return float(v[0]), float(v[1]), float(v[2])
    return float(v), float(v), float(v)


def as_vec2(v):
    if isinstance(v, list):
        if len(v) == 1:
            return [v[0], v[0]]
        return [v[0], v[1]]
    return [v, v]


def rotation_matrix(a, axis_val):
    if axis_val is not None:
        axis = np.array(as_vec3(axis_val), dtype=float)
        n = np.linalg.norm(axis)
        if n < 1e-12:
            return np.eye(3)
        axis = axis / n
        theta = math.radians(num(a))
        return axis_angle_matrix(axis, theta)
    if isinstance(a, list):
        rx, ry, rz = as_vec3(a)
        Rx = axis_angle_matrix(np.array([1.0, 0, 0]), math.radians(rx))
        Ry = axis_angle_matrix(np.array([0, 1.0, 0]), math.radians(ry))
        Rz = axis_angle_matrix(np.array([0, 0, 1.0]), math.radians(rz))
        return Rz @ Ry @ Rx
    theta = math.radians(num(a))
    return axis_angle_matrix(np.array([0.0, 0.0, 1.0]), theta)


def axis_angle_matrix(axis, theta):
    x, y, z = axis
    c = math.cos(theta)
    s = math.sin(theta)
    C = 1 - c
    return np.array([
        [x * x * C + c, x * y * C - z * s, x * z * C + y * s],
        [y * x * C + z * s, y * y * C + c, y * z * C - x * s],
        [z * x * C - y * s, z * y * C + x * s, z * z * C + c],
    ])


def triangulate_face_list(faces):
    out = []
    for f in faces:
        f = list(f)
        if len(f) == 3:
            out.append(f)
        elif len(f) > 3:
            for i in range(1, len(f) - 1):
                out.append([f[0], f[i], f[i + 1]])
    return np.array(out, dtype=int) if out else np.zeros((0, 3), dtype=int)


def revolve_profile(profile, angle, segs=50):
    """Revolve a 2D profile (x = radius, y = height) around the Z axis.
    Not present in openscad4.py verbatim, so implemented directly with
    numpy, matching the same 'sol' cross-section convention (list of
    equal-length rings) so it plugs into triangulate_solid_open()."""
    pts = np.array(profile, dtype=float)
    n = max(int(segs * abs(angle) / 360.0), 2)
    thetas = np.linspace(0, math.radians(angle), n + 1)
    sol = []
    for th in thetas:
        ring = np.stack([
            pts[:, 0] * math.cos(th),
            pts[:, 0] * math.sin(th),
            pts[:, 1],
        ], axis=1)
        sol.append(ring.tolist())
    return sol


def resolve_color(args, args_ast, env, ev):
    c = None
    # alpha can come from the `alpha=` keyword, OR OpenSCAD's own
    # color(c, alpha) signature -- a bare *second positional* argument,
    # e.g. color("blue", 0.2) -- which pos_or_named's index=1 covers and
    # args.get("alpha") alone did not.
    a = pos_or_named(args, args_ast, env, ev, 1, "alpha", None)
    val = pos_or_named(args, args_ast, env, ev, 0, "c", None)
    if isinstance(val, str):
        c = COLOR_NAMES.get(val.lower())
    elif isinstance(val, list):
        if len(val) >= 4 and a is None:
            a = val[3]
        if len(val) >= 3:
            c = (val[0], val[1], val[2])
    return c, (float(a) if a is not None else None)


def radius_from(args, args_ast, env, ev):
    r = args.get("r")
    d = args.get("d")
    if r is None:
        r = get_positional(args_ast, 0, env, ev)
    if d is not None:
        return num(d) / 2.0
    return num(r, 1.0)


def get_positional(args_ast, index, env, ev):
    positional = [a for a in args_ast if a[0] is None]
    if index < len(positional):
        return ev._eval_expr(positional[index][1], env)
    return None


def get_named_or_pos(args, args_ast, env, ev, index, name, default):
    if name in args and args[name] is not None:
        return args[name]
    v = get_positional(args_ast, index, env, ev)
    return v if v is not None else default


def pos_or_named(args, args_ast, env, ev, index, name, default):
    v = get_positional(args_ast, index, env, ev)
    if v is not None:
        return v
    if name in args and args[name] is not None:
        return args[name]
    return default


def args_dict(args_ast, env, ev):
    out = {}
    for name, expr in args_ast:
        if name is not None:
            out[name] = ev._eval_expr(expr, env)
    return out


def bind_args(args_ast, params, env, ev):
    positional = [a for a in args_ast if a[0] is None]
    named = {a[0]: a[1] for a in args_ast if a[0] is not None}
    result = {}
    pi = 0
    for pname, default in params:
        if pname in named:
            result[pname] = ev._eval_expr(named[pname], env)
        elif pi < len(positional):
            result[pname] = ev._eval_expr(positional[pi][1], env)
            pi += 1
        elif default is not None:
            result[pname] = ev._eval_expr(default, ev.global_env)
        else:
            result[pname] = None
    for key in ("$fn", "$fa", "$fs"):
        if key in named:
            result[key] = ev._eval_expr(named[key], env)
    return result
