"""
csg.py

Boolean CSG (union / difference / intersection) and hull() for triangle
meshes produced by scad_eval.py / python_eval.py.

Two backends, tried in this order:

1. **Real OpenSCAD** (openscad_cli.py), if it's installed -- the exact
   same CGAL-based boolean engine your existing swp()/fo() workflow
   already relies on. Each operand is emitted as a polyhedron() (exactly
   what openscad4.swp() produces), wrapped in the requested operator, and
   rendered headless. Exact, sharp results.

2. **Voxel sample + marching-cubes**, used automatically as a fallback if
   OpenSCAD isn't found (or a given call to it fails):
     a. build a 3D grid over the bounding box of the operands
     b. classify each grid point as inside/outside each operand mesh using
        a vectorized ray-parity test (the same technique
        openscad4.points_inside_solid() uses, generalized here to work on
        plain (vertices, faces) triangle soup)
     c. combine the inside/outside grids per the boolean operator
     d. run skimage.measure.marching_cubes (a dependency openscad4.py
        already uses) to extract the surface, then smooth it
   This trades sharpness for having zero extra dependencies/installs
   beyond what openscad4.py already needs.

hull() prefers OpenSCAD's native hull() too, falling back to
scipy.spatial.ConvexHull (also exact, just a different implementation).
"""

import numpy as np
from skimage import measure

import openscad_cli


def points_inside_mesh(pts, V, F, direction=None):
    """
    Vectorized point-in-triangle-mesh test via ray casting + parity count.
    pts: (N,3) query points
    V: (M,3) mesh vertices
    F: (K,3) mesh triangle indices (into V)
    Returns a boolean array of length N (True = inside).

    Same core math as openscad4.points_inside_solid (Moeller-Trumbore style
    ray/triangle intersection solved via Cramer's rule on the [-dir, e1, e2]
    system) but indexed directly off a face array instead of a
    cross-section "sol" list, so it works on arbitrary triangle soup.
    """
    if len(F) == 0 or len(pts) == 0:
        return np.zeros(len(pts), dtype=bool)

    if direction is None:
        # a slightly irrational direction avoids axis-aligned degeneracies
        direction = np.array([1.0, 1e-6, 1e-7])
    d = direction / np.linalg.norm(direction)

    V = np.asarray(V, dtype=float)
    tri = V[np.asarray(F, dtype=int)]
    p0, p1, p2 = tri[:, 0], tri[:, 1], tri[:, 2]
    e1 = p1 - p0
    e2 = p2 - p0

    pts = np.asarray(pts, dtype=float)
    inside = np.zeros(len(pts), dtype=bool)

    eps = 1e-9
    h = np.cross(d[None, :], e2)                     # (K,3)
    a = np.einsum('kj,kj->k', e1, h)                  # (K,)
    with np.errstate(divide='ignore', invalid='ignore'):
        f = np.where(np.abs(a) > 1e-12, 1.0 / a, 0.0)  # (K,)
    valid = np.abs(a) > 1e-12

    # chunk to bound memory: (n_pts_chunk x n_tris x 3)
    chunk = max(1, int(2_000_000 / max(1, len(tri))))
    for start in range(0, len(pts), chunk):
        block = pts[start:start + chunk]
        s = block[:, None, :] - p0[None, :, :]                       # (B,K,3)
        u = f[None, :] * np.einsum('bkj,kj->bk', s, h)                # (B,K)
        q = np.cross(s, e1[None, :, :])                               # (B,K,3)
        v = f[None, :] * np.einsum('bkj,j->bk', q, d)                 # (B,K)
        t = f[None, :] * np.einsum('bkj,kj->bk', q, e2)               # (B,K)
        hit = valid[None, :] & (u >= -eps) & (u <= 1 + eps) & \
              (v >= -eps) & (u + v <= 1 + eps) & (t > eps)
        count = hit.sum(axis=1)
        inside[start:start + chunk] = (count % 2) == 1
    return inside


def _bbox(V):
    V = np.asarray(V)
    return V.min(axis=0), V.max(axis=0)


def _combined_bbox(meshes, pad_frac=0.03):
    mins = np.array([1e18, 1e18, 1e18])
    maxs = np.array([-1e18, -1e18, -1e18])
    for V, F in meshes:
        if len(V) == 0:
            continue
        lo, hi = _bbox(V)
        mins = np.minimum(mins, lo)
        maxs = np.maximum(maxs, hi)
    size = np.maximum(maxs - mins, 1e-6)
    pad = size * pad_frac + 1e-6
    return mins - pad, maxs + pad


def taubin_smooth(V, F, iterations=12, lam=0.5, mu=-0.53):
    """
    Smooth mesh vertex positions (topology/F unchanged) to remove the
    'staircase' look that marching_cubes produces on a voxel grid.
    Alternates a shrink step (+lam) with a slightly larger inflate step
    (mu, |mu| > lam) using the umbrella (neighbor-average) operator, which
    -- unlike plain Laplacian smoothing -- doesn't visibly shrink the
    shape even after many iterations. Pure numpy, no new dependencies.
    """
    V = np.asarray(V, dtype=float).copy()
    F = np.asarray(F, dtype=int)
    n = len(V)
    if n == 0 or len(F) == 0:
        return V

    edges = np.concatenate([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]], axis=0)
    edges = np.concatenate([edges, edges[:, ::-1]], axis=0)
    src, dst = edges[:, 0], edges[:, 1]

    deg = np.zeros(n)
    np.add.at(deg, src, 1.0)
    deg[deg == 0] = 1.0
    deg = deg[:, None]

    for i in range(iterations):
        factor = lam if i % 2 == 0 else mu
        neighbor_sum = np.zeros_like(V)
        np.add.at(neighbor_sum, src, V[dst])
        avg = neighbor_sum / deg
        V = V + factor * (avg - V)
    return V


def boolean_op(meshes, op, resolution=56, smooth_iterations=12, notes=None, raw_operands=None):
    """
    meshes: list of (V, F) numpy arrays (one per operand, in evaluation order)
    op: 'union' | 'difference' | 'intersection'
    resolution: voxel grid detail, only used by the fallback path
    notes: optional list to append human-readable backend notes to (e.g.
           when falling back from OpenSCAD to the voxel approximation)
    raw_operands: optional list, same length/order as `meshes` -- for any
           index where this is a non-None string (the exact text
           swp()/swp_c()/swp_surf()/swp_triangles() returned for that
           operand), the real-OpenSCAD path uses that text verbatim for
           the operand instead of re-deriving a polyhedron() from (V, F).
           Ignored by the voxel fallback, which only ever works off (V, F).
    Returns (V, F) of the resulting surface, or (empty, empty) if nothing
    remains.
    """
    real_meshes = []
    real_raw = []
    for i, (V, F) in enumerate(meshes):
        if len(V) > 0 and len(F) > 0:
            real_meshes.append((np.asarray(V, dtype=float), np.asarray(F, dtype=int)))
            real_raw.append(raw_operands[i] if raw_operands is not None else None)
    if not real_meshes:
        return np.zeros((0, 3)), np.zeros((0, 3), dtype=int)
    if len(real_meshes) == 1 and op != 'difference':
        return real_meshes[0]

    if openscad_cli.is_available():
        try:
            return openscad_cli.boolean_op(real_meshes, op, notes=notes, raw_operands=real_raw)
        except openscad_cli.OpenSCADCliError as e:
            if notes is not None:
                notes.append(f"OpenSCAD failed on this {op}(), fell back to the "
                              f"approximate voxel method: {e}")
    elif notes is not None:
        notes.append(f"OpenSCAD not found -- used the approximate voxel method for "
                      f"this {op}(). Install OpenSCAD for exact results.")

    return _voxel_boolean_op(real_meshes, op, resolution=resolution,
                              smooth_iterations=smooth_iterations)


def _voxel_boolean_op(meshes, op, resolution=56, smooth_iterations=12):
    """meshes is assumed already filtered to non-empty (V,F) pairs by boolean_op()."""
    lo, hi = _combined_bbox(meshes)
    dims = hi - lo
    longest = float(dims.max())
    voxel = longest / max(8, resolution)
    nx, ny, nz = [max(4, int(np.ceil(d / voxel)) + 1) for d in dims]
    # guard against pathological huge grids
    max_cells = 200 * 200 * 200
    while nx * ny * nz > max_cells:
        voxel *= 1.25
        nx, ny, nz = [max(4, int(np.ceil(d / voxel)) + 1) for d in dims]

    xs = lo[0] + np.arange(nx) * voxel
    ys = lo[1] + np.arange(ny) * voxel
    zs = lo[2] + np.arange(nz) * voxel
    gx, gy, gz = np.meshgrid(xs, ys, zs, indexing='ij')
    pts = np.stack([gx.ravel(), gy.ravel(), gz.ravel()], axis=1)

    inside_grids = []
    for V, F in meshes:
        ins = points_inside_mesh(pts, V, F)
        inside_grids.append(ins.reshape(nx, ny, nz))

    if op == 'union':
        result = inside_grids[0]
        for g in inside_grids[1:]:
            result = result | g
    elif op == 'intersection':
        result = inside_grids[0]
        for g in inside_grids[1:]:
            result = result & g
    elif op == 'difference':
        result = inside_grids[0]
        for g in inside_grids[1:]:
            result = result & (~g)
    else:
        raise ValueError(f"unknown boolean op {op!r}")

    volume = result.astype(np.float32)
    # pad the volume with a shell of zeros so marching_cubes closes the
    # surface even when the shape touches the sample grid boundary
    volume = np.pad(volume, 1, mode='constant', constant_values=0)
    if volume.max() <= 0:
        # legitimately empty result (e.g. difference() that removes
        # everything, or intersection() of non-overlapping shapes)
        return np.zeros((0, 3)), np.zeros((0, 3), dtype=int)

    # NOTE: intentionally not swallowing exceptions here. An earlier
    # version caught everything and silently returned an empty mesh,
    # which made real bugs look like "the CSG op just produced nothing"
    # with no error anywhere -- let it propagate so scad_eval.py /
    # server.py can report the real cause.
    verts, faces, _normals, _values = measure.marching_cubes(volume, level=0.5)

    # undo the padding offset, convert index space -> world space
    verts = verts - 1.0
    world = lo + verts * voxel
    if smooth_iterations > 0:
        world = taubin_smooth(world, faces, iterations=smooth_iterations)
    return world, faces


def hull_op(meshes, notes=None, raw_operands=None):
    """3D convex hull of `meshes`. Prefers OpenSCAD's native hull(), falls
    back to scipy.spatial.ConvexHull -- both exact, either is fine."""
    real_meshes = []
    real_raw = []
    for i, (V, F) in enumerate(meshes):
        if len(V) > 0:
            real_meshes.append((np.asarray(V, dtype=float), np.asarray(F, dtype=int)))
            real_raw.append(raw_operands[i] if raw_operands is not None else None)
    if not real_meshes:
        return np.zeros((0, 3)), np.zeros((0, 3), dtype=int)

    if openscad_cli.is_available():
        try:
            return openscad_cli.hull_op(real_meshes, notes=notes, raw_operands=real_raw)
        except openscad_cli.OpenSCADCliError as e:
            if notes is not None:
                notes.append(f"OpenSCAD failed on this hull(), fell back to "
                              f"scipy's convex hull: {e}")

    return _scipy_hull_op(real_meshes)


def _scipy_hull_op(meshes):
    from scipy.spatial import ConvexHull
    pts = [V for V, _F in meshes if len(V)]
    if not pts:
        return np.zeros((0, 3)), np.zeros((0, 3), dtype=int)
    allpts = np.concatenate(pts, axis=0)
    if len(allpts) < 4:
        return allpts, np.zeros((0, 3), dtype=int)
    h = ConvexHull(allpts)  # let failures (e.g. coplanar input) propagate as real errors
    used = np.unique(h.simplices.ravel())
    remap = -np.ones(allpts.shape[0], dtype=int)
    remap[used] = np.arange(len(used))
    V = allpts[used]
    F = remap[h.simplices]
    return V, F
