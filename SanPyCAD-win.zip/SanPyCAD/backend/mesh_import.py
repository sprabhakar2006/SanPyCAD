"""
mesh_import.py

Readers for external files, so `import("model.stl")` in DSL scripts (and
`import_mesh()`/`import_profile()` in Python-mode scripts, since `import`
is a reserved word there) can pull in geometry made elsewhere -- the same
job OpenSCAD's own import() does.

Supported 3D (mesh) formats: STL (binary and ASCII, auto-detected), OBJ
(v/f lines; n-gon faces are fan-triangulated), OFF.

Supported 2D (profile) formats: SVG -- <path> (M/L/H/V/C/S/Q/T/A/Z,
including relative lowercase variants), <rect>, <circle>, <ellipse>,
<polygon>, nested <g> with `transform` (translate/scale/rotate/matrix/
skewX/skewY, composed). Only CLOSED shapes count (an unclosed <path> or a
<polyline>/<line> can't be extruded); if the file has more than one closed
shape, the single largest one (by area) is used and the rest are noted as
skipped -- multi-part 2D shapes (e.g. a shape with holes) aren't merged.
Like circle()/square()/polygon(), a 2D import() only actually produces
something inside linear_extrude()/rotate_extrude().

Anything else raises a clear error naming what IS supported, rather than
failing cryptically deep inside a parser.
"""

import math
import os
import re
import struct
import xml.etree.ElementTree as ET

import numpy as np

# Files can be referred to by filename alone (resolved against this
# folder, created on first use) instead of needing a full path -- mirrors
# how OpenSCAD's import() resolves paths relative to the .scad file's own
# folder, which doesn't really apply here since scripts aren't backed by
# a file on disk.
IMPORTS_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "imports"
)

SUPPORTED_3D_EXTENSIONS = (".stl", ".obj", ".off")
SUPPORTED_2D_EXTENSIONS = (".svg",)
SUPPORTED_EXTENSIONS = SUPPORTED_3D_EXTENSIONS + SUPPORTED_2D_EXTENSIONS


def resolve_import_path(path):
    """Absolute paths (or paths that already resolve relative to the
    backend's current working directory) are used as-is; anything else is
    looked up in IMPORTS_DIR -- drop a file there and refer to it by
    filename."""
    path = str(path)
    if os.path.isabs(path):
        if os.path.isfile(path):
            return path
        raise FileNotFoundError(f"import(): no such file: {path}")
    if os.path.isfile(path):
        return os.path.abspath(path)
    os.makedirs(IMPORTS_DIR, exist_ok=True)
    candidate = os.path.join(IMPORTS_DIR, path)
    if os.path.isfile(candidate):
        return candidate
    raise FileNotFoundError(
        f"import(): couldn't find {path!r}. Put the file in the imports "
        f"folder next to this app ({IMPORTS_DIR}) and refer to it by "
        f"filename, or use a full absolute path."
    )


def _weld_vertices(points, decimals=6):
    """De-duplicate a flat list of (x,y,z) points by rounding, returning
    (unique_vertices_array, index_for_each_input_point). STL stores three
    fresh vertices per triangle with no shared indices, so without this
    every triangle would be a disconnected island."""
    index_of = {}
    unique = []
    indices = []
    for p in points:
        key = (round(p[0], decimals), round(p[1], decimals), round(p[2], decimals))
        i = index_of.get(key)
        if i is None:
            i = len(unique)
            index_of[key] = i
            unique.append(p)
        indices.append(i)
    arr = np.array(unique, dtype=float) if unique else np.zeros((0, 3))
    return arr, indices


def _read_stl_binary(data):
    if len(data) < 84:
        raise ValueError("import(): STL file is too short to be valid")
    count = struct.unpack("<I", data[80:84])[0]
    raw_pts = []
    offset = 84
    for _ in range(count):
        chunk = data[offset:offset + 50]
        if len(chunk) < 50:
            break
        vs = struct.unpack("<9f", chunk[12:48])
        raw_pts.append(vs[0:3])
        raw_pts.append(vs[3:6])
        raw_pts.append(vs[6:9])
        offset += 50
    V, idx = _weld_vertices(raw_pts)
    F = np.array(idx, dtype=int).reshape(-1, 3) if idx else np.zeros((0, 3), dtype=int)
    return V, F


def _read_stl_ascii(data):
    text = data.decode("utf-8", errors="replace")
    nums = re.findall(
        r"vertex\s+([-+0-9.eE]+)\s+([-+0-9.eE]+)\s+([-+0-9.eE]+)", text
    )
    raw_pts = [(float(a), float(b), float(c)) for a, b, c in nums]
    if len(raw_pts) % 3 != 0:
        raw_pts = raw_pts[: (len(raw_pts) // 3) * 3]
    V, idx = _weld_vertices(raw_pts)
    F = np.array(idx, dtype=int).reshape(-1, 3) if idx else np.zeros((0, 3), dtype=int)
    return V, F


def _read_stl(data):
    # Binary STL has a fixed layout: 80-byte header + 4-byte triangle
    # count + count*50 bytes. Some binary STLs also start with the text
    # "solid" (technically against spec but common), so length-checking
    # the binary layout first is more reliable than just sniffing the
    # header text.
    if len(data) >= 84:
        count = struct.unpack("<I", data[80:84])[0]
        if 84 + count * 50 == len(data):
            return _read_stl_binary(data)
    return _read_stl_ascii(data)


def _read_obj(data):
    text = data.decode("utf-8", errors="replace")
    verts = []
    faces = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        tag = parts[0]
        if tag == "v" and len(parts) >= 4:
            verts.append((float(parts[1]), float(parts[2]), float(parts[3])))
        elif tag == "f" and len(parts) >= 4:
            idxs = []
            for tok in parts[1:]:
                vi = tok.split("/")[0]  # "v", "v/vt", "v/vt/vn", "v//vn"
                if not vi:
                    continue
                vi = int(vi)
                idxs.append((len(verts) + vi) if vi < 0 else (vi - 1))  # OBJ is 1-indexed
            for k in range(1, len(idxs) - 1):  # fan-triangulate n-gons
                faces.append((idxs[0], idxs[k], idxs[k + 1]))
    V = np.array(verts, dtype=float) if verts else np.zeros((0, 3))
    F = np.array(faces, dtype=int) if faces else np.zeros((0, 3), dtype=int)
    return V, F


def _read_off(data):
    text = data.decode("utf-8", errors="replace")
    lines = [l.strip() for l in text.splitlines() if l.strip() and not l.strip().startswith("#")]
    if not lines:
        raise ValueError("import(): empty OFF file")
    header = lines[0]
    if not header.upper().startswith("OFF"):
        raise ValueError("import(): not a valid OFF file (missing OFF header)")
    rest = lines[1:]
    counts_line = header[3:].strip()
    if not counts_line:
        counts_line = rest[0]
        rest = rest[1:]
    parts = counts_line.split()
    nv, nf = int(parts[0]), int(parts[1])
    verts = []
    for i in range(nv):
        p = rest[i].split()
        verts.append((float(p[0]), float(p[1]), float(p[2])))
    faces = []
    for i in range(nf):
        p = rest[nv + i].split()
        n = int(p[0])
        idxs = [int(x) for x in p[1:1 + n]]
        for k in range(1, n - 1):
            faces.append((idxs[0], idxs[k], idxs[k + 1]))
    V = np.array(verts, dtype=float) if verts else np.zeros((0, 3))
    F = np.array(faces, dtype=int) if faces else np.zeros((0, 3), dtype=int)
    return V, F


def read_mesh_bytes(data, ext):
    ext = ext.lower()
    if ext == ".stl":
        V, F = _read_stl(data)
    elif ext == ".obj":
        V, F = _read_obj(data)
    elif ext == ".off":
        V, F = _read_off(data)
    elif ext in SUPPORTED_2D_EXTENSIONS:
        raise ValueError(
            f"import(): {ext} is a 2D format -- use import_profile() (Python "
            f"mode) instead of import_mesh(), or import(\"...\") inside "
            f"linear_extrude()/rotate_extrude() (DSL mode)."
        )
    else:
        raise ValueError(
            f"import(): unsupported file type {ext!r} -- only "
            f"{', '.join(SUPPORTED_EXTENSIONS)} are supported right now."
        )
    if len(V) == 0 or len(F) == 0:
        raise ValueError("import(): file contains no usable geometry")
    return V, F


def read_mesh_file(path):
    """path can be an absolute path, a path relative to the backend's
    working directory, or a bare filename inside IMPORTS_DIR. 3D formats
    only -- see read_import_file() for a format-agnostic entry point."""
    resolved = resolve_import_path(path)
    ext = os.path.splitext(resolved)[1]
    with open(resolved, "rb") as f:
        data = f.read()
    return read_mesh_bytes(data, ext)


# --------------------------------------------------------------------------
# SVG (2D profile) support
# --------------------------------------------------------------------------

_NUM_RE = re.compile(r"[-+]?(\d+\.\d*|\.\d+|\d+)(?:[eE][-+]?\d+)?")


def _flatten_cubic(p0, p1, p2, p3, n=16):
    pts = []
    for i in range(n + 1):
        t = i / n
        mt = 1 - t
        x = mt**3 * p0[0] + 3 * mt**2 * t * p1[0] + 3 * mt * t**2 * p2[0] + t**3 * p3[0]
        y = mt**3 * p0[1] + 3 * mt**2 * t * p1[1] + 3 * mt * t**2 * p2[1] + t**3 * p3[1]
        pts.append((x, y))
    return pts


def _flatten_quadratic(p0, p1, p2, n=12):
    pts = []
    for i in range(n + 1):
        t = i / n
        mt = 1 - t
        x = mt**2 * p0[0] + 2 * mt * t * p1[0] + t**2 * p2[0]
        y = mt**2 * p0[1] + 2 * mt * t * p1[1] + t**2 * p2[1]
        pts.append((x, y))
    return pts


def _svg_arc_to_points(x1, y1, rx, ry, phi_deg, large_arc, sweep, x2, y2, n=24):
    """Standard SVG endpoint-to-center arc parameterization (spec F.6.5),
    sampled into n line segments."""
    if rx == 0 or ry == 0 or (x1 == x2 and y1 == y2):
        return [(x2, y2)]
    rx, ry = abs(rx), abs(ry)
    phi = math.radians(phi_deg)
    cos_phi, sin_phi = math.cos(phi), math.sin(phi)
    dx2, dy2 = (x1 - x2) / 2.0, (y1 - y2) / 2.0
    x1p = cos_phi * dx2 + sin_phi * dy2
    y1p = -sin_phi * dx2 + cos_phi * dy2

    lam = (x1p**2) / (rx**2) + (y1p**2) / (ry**2)
    if lam > 1:
        s = math.sqrt(lam)
        rx *= s
        ry *= s

    den = rx**2 * y1p**2 + ry**2 * x1p**2
    num = rx**2 * ry**2 - rx**2 * y1p**2 - ry**2 * x1p**2
    sign = -1 if large_arc == sweep else 1
    co = sign * math.sqrt(max(num, 0) / den) if den != 0 else 0.0
    cxp = co * (rx * y1p / ry)
    cyp = co * (-ry * x1p / rx)
    cx = cos_phi * cxp - sin_phi * cyp + (x1 + x2) / 2.0
    cy = sin_phi * cxp + cos_phi * cyp + (y1 + y2) / 2.0

    def _angle(ux, uy, vx, vy):
        length = math.hypot(ux, uy) * math.hypot(vx, vy)
        if length == 0:
            return 0.0
        cosv = max(-1.0, min(1.0, (ux * vx + uy * vy) / length))
        a = math.acos(cosv)
        return -a if (ux * vy - uy * vx) < 0 else a

    theta1 = _angle(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry)
    dtheta = _angle((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry)
    if not sweep and dtheta > 0:
        dtheta -= 2 * math.pi
    elif sweep and dtheta < 0:
        dtheta += 2 * math.pi

    pts = []
    for i in range(1, n + 1):
        t = theta1 + dtheta * i / n
        x = cx + rx * math.cos(t) * cos_phi - ry * math.sin(t) * sin_phi
        y = cy + rx * math.cos(t) * sin_phi + ry * math.sin(t) * cos_phi
        pts.append((x, y))
    return pts


def _parse_path_d(d):
    """Parse an SVG <path> `d` attribute into a list of subpaths, each a
    flattened list of (x,y) points (curves/arcs sampled into line
    segments). A subpath explicitly closed with Z/z has its start point
    appended so it's a proper closed ring."""
    i, n = 0, len(d)
    subpaths, cur = [], []
    cx = cy = sx = sy = 0.0
    last_cmd = None
    prev_ctrl = None  # reflected control point, for S/s and T/t
    CMD_CHARS = set("MmLlHhVvCcSsQqTtAaZz")

    def skip_ws(j):
        while j < n and (d[j].isspace() or d[j] == ","):
            j += 1
        return j

    def read_num(j):
        j = skip_ws(j)
        m = _NUM_RE.match(d, j)
        if not m:
            raise ValueError(f"import(): couldn't parse SVG path data near {d[max(0, j - 10):j + 10]!r}")
        return float(m.group(0)), m.end()

    def read_flag(j):
        j = skip_ws(j)
        if j < n and d[j] in "01":
            return int(d[j]), j + 1
        val, j2 = read_num(j)
        return int(val), j2

    while i < n:
        i = skip_ws(i)
        if i >= n:
            break
        ch = d[i]
        if ch in CMD_CHARS:
            last_cmd = ch
            i += 1
        elif last_cmd is None:
            raise ValueError("import(): SVG path data must start with a moveto (M/m) command")
        cmd = last_cmd
        rel = cmd.islower()
        C = cmd.upper()

        if C == "M":
            x, i = read_num(i)
            y, i = read_num(i)
            if rel:
                x += cx
                y += cy
            if cur:
                subpaths.append(cur)
            cur = [(x, y)]
            cx = cy = sx = sy = None  # set below
            cx, cy, sx, sy = x, y, x, y
            last_cmd = "l" if rel else "L"  # subsequent implicit pairs are lineto
            prev_ctrl = None
        elif C == "L":
            x, i = read_num(i)
            y, i = read_num(i)
            if rel:
                x += cx
                y += cy
            cur.append((x, y))
            cx, cy = x, y
            prev_ctrl = None
        elif C == "H":
            x, i = read_num(i)
            if rel:
                x += cx
            cur.append((x, cy))
            cx = x
            prev_ctrl = None
        elif C == "V":
            y, i = read_num(i)
            if rel:
                y += cy
            cur.append((cx, y))
            cy = y
            prev_ctrl = None
        elif C == "C":
            x1, i = read_num(i); y1, i = read_num(i)
            x2, i = read_num(i); y2, i = read_num(i)
            x, i = read_num(i); y, i = read_num(i)
            if rel:
                x1 += cx; y1 += cy; x2 += cx; y2 += cy; x += cx; y += cy
            cur.extend(_flatten_cubic((cx, cy), (x1, y1), (x2, y2), (x, y))[1:])
            prev_ctrl = (x2, y2)
            cx, cy = x, y
        elif C == "S":
            x2, i = read_num(i); y2, i = read_num(i)
            x, i = read_num(i); y, i = read_num(i)
            if rel:
                x2 += cx; y2 += cy; x += cx; y += cy
            x1, y1 = (2 * cx - prev_ctrl[0], 2 * cy - prev_ctrl[1]) if prev_ctrl else (cx, cy)
            cur.extend(_flatten_cubic((cx, cy), (x1, y1), (x2, y2), (x, y))[1:])
            prev_ctrl = (x2, y2)
            cx, cy = x, y
        elif C == "Q":
            x1, i = read_num(i); y1, i = read_num(i)
            x, i = read_num(i); y, i = read_num(i)
            if rel:
                x1 += cx; y1 += cy; x += cx; y += cy
            cur.extend(_flatten_quadratic((cx, cy), (x1, y1), (x, y))[1:])
            prev_ctrl = (x1, y1)
            cx, cy = x, y
        elif C == "T":
            x, i = read_num(i)
            y, i = read_num(i)
            if rel:
                x += cx
                y += cy
            x1, y1 = (2 * cx - prev_ctrl[0], 2 * cy - prev_ctrl[1]) if prev_ctrl else (cx, cy)
            cur.extend(_flatten_quadratic((cx, cy), (x1, y1), (x, y))[1:])
            prev_ctrl = (x1, y1)
            cx, cy = x, y
        elif C == "A":
            rx, i = read_num(i); ry, i = read_num(i)
            rot, i = read_num(i)
            laf, i = read_flag(i); sf, i = read_flag(i)
            x, i = read_num(i); y, i = read_num(i)
            if rel:
                x += cx
                y += cy
            cur.extend(_svg_arc_to_points(cx, cy, rx, ry, rot, laf, sf, x, y))
            cx, cy = x, y
            prev_ctrl = None
        elif C == "Z":
            if cur and (cx, cy) != (sx, sy):
                cur.append((sx, sy))
            cx, cy = sx, sy
            if cur:
                subpaths.append(cur)
            cur = []
            last_cmd = None
            prev_ctrl = None
        else:
            raise ValueError(f"import(): unsupported SVG path command {cmd!r}")

    if cur:
        subpaths.append(cur)
    return subpaths


def _identity_matrix():
    return (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)  # (a, b, c, d, e, f): x'=ax+cy+e, y'=bx+dy+f


def _mat_mul(m1, m2):
    a1, b1, c1, d1, e1, f1 = m1
    a2, b2, c2, d2, e2, f2 = m2
    return (
        a1 * a2 + c1 * b2, b1 * a2 + d1 * b2,
        a1 * c2 + c1 * d2, b1 * c2 + d1 * d2,
        a1 * e2 + c1 * f2 + e1, b1 * e2 + d1 * f2 + f1,
    )


def _apply_matrix(m, pts):
    a, b, c, d, e, f = m
    return [(a * x + c * y + e, b * x + d * y + f) for x, y in pts]


_TRANSFORM_FN_RE = re.compile(r"(\w+)\s*\(([^)]*)\)")


def _parse_transform(s):
    m = _identity_matrix()
    if not s:
        return m
    for name, argstr in _TRANSFORM_FN_RE.findall(s):
        args = [float(x.group(0)) for x in _NUM_RE.finditer(argstr)]
        if name == "translate":
            t = (1, 0, 0, 1, args[0] if args else 0, args[1] if len(args) > 1 else 0)
        elif name == "scale":
            sx = args[0] if args else 1
            sy = args[1] if len(args) > 1 else sx
            t = (sx, 0, 0, sy, 0, 0)
        elif name == "rotate":
            ang = math.radians(args[0] if args else 0)
            ca, sa = math.cos(ang), math.sin(ang)
            if len(args) >= 3:
                cxr, cyr = args[1], args[2]
                t = _mat_mul(_mat_mul((1, 0, 0, 1, cxr, cyr), (ca, sa, -sa, ca, 0, 0)),
                              (1, 0, 0, 1, -cxr, -cyr))
            else:
                t = (ca, sa, -sa, ca, 0, 0)
        elif name == "matrix" and len(args) == 6:
            t = tuple(args)
        elif name == "skewX":
            t = (1, 0, math.tan(math.radians(args[0] if args else 0)), 1, 0, 0)
        elif name == "skewY":
            t = (1, math.tan(math.radians(args[0] if args else 0)), 0, 1, 0, 0)
        else:
            continue
        m = _mat_mul(m, t)
    return m


def _num_attr(el, name, default=0.0):
    v = el.get(name)
    if v is None:
        return default
    m = _NUM_RE.match(v.strip())
    return float(m.group(0)) if m else default


def _svg_tag(el):
    t = el.tag
    return t.split("}")[-1] if "}" in t else t


def _rect_points(el):
    x, y = _num_attr(el, "x"), _num_attr(el, "y")
    w, h = _num_attr(el, "width"), _num_attr(el, "height")
    if w <= 0 or h <= 0:
        return None
    return [(x, y), (x + w, y), (x + w, y + h), (x, y + h), (x, y)]


def _circle_points(el, n=48):
    cx, cy, r = _num_attr(el, "cx"), _num_attr(el, "cy"), _num_attr(el, "r")
    if r <= 0:
        return None
    return [(cx + r * math.cos(2 * math.pi * i / n), cy + r * math.sin(2 * math.pi * i / n))
            for i in range(n + 1)]


def _ellipse_points(el, n=48):
    cx, cy = _num_attr(el, "cx"), _num_attr(el, "cy")
    rx, ry = _num_attr(el, "rx"), _num_attr(el, "ry")
    if rx <= 0 or ry <= 0:
        return None
    return [(cx + rx * math.cos(2 * math.pi * i / n), cy + ry * math.sin(2 * math.pi * i / n))
            for i in range(n + 1)]


def _poly_points(el):
    raw = el.get("points", "")
    nums = [float(x.group(0)) for x in _NUM_RE.finditer(raw)]
    pts = list(zip(nums[0::2], nums[1::2]))
    return pts if len(pts) >= 3 else None


# Elements whose subtree is never directly rendered -- only referenced
# indirectly (<use href="#id">, fill="url(#id)", clip-path="url(#id)").
# Icon SVGs very commonly wrap their real artwork in a <clipPath> (or
# <mask>) containing a canvas-sized <rect> just to crop it to the icon's
# bounding box -- if that rect's subtree isn't skipped, it's frequently
# the single largest shape in the file and silently wins over the actual
# artwork, so importing e.g. a flower icon just produces a plain square.
_NON_RENDERED_TAGS = {"defs", "symbol", "clipPath", "mask"}


def _is_hidden(el):
    return el.get("display") == "none" or el.get("visibility") == "hidden"


def _collect_svg_polygons(el, matrix, out):
    tag = _svg_tag(el)
    if tag in _NON_RENDERED_TAGS or _is_hidden(el):
        return
    local_matrix = _mat_mul(matrix, _parse_transform(el.get("transform", "")))
    if tag == "path":
        d = el.get("d")
        if d:
            for sub in _parse_path_d(d):
                if len(sub) >= 3:
                    out.append(_apply_matrix(local_matrix, sub))
    elif tag == "rect":
        pts = _rect_points(el)
        if pts:
            out.append(_apply_matrix(local_matrix, pts))
    elif tag == "circle":
        pts = _circle_points(el)
        if pts:
            out.append(_apply_matrix(local_matrix, pts))
    elif tag == "ellipse":
        pts = _ellipse_points(el)
        if pts:
            out.append(_apply_matrix(local_matrix, pts))
    elif tag == "polygon":
        pts = _poly_points(el)
        if pts:
            out.append(_apply_matrix(local_matrix, pts))
    # <polyline>/<line>/<text> intentionally skipped -- not closed shapes
    for child in el:
        _collect_svg_polygons(child, local_matrix, out)


def _polygon_area(pts):
    a = 0.0
    n = len(pts)
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        a += x1 * y2 - x2 * y1
    return abs(a) / 2.0


def _fix_svg_orientation(pts):
    # SVG's y-axis grows downward (y=0 is the top of the image); this
    # app's 2D profiles (circle()/square()/polygon(), and this shape once
    # extruded) use an ordinary y-up plane. Without correcting for that,
    # an imported shape comes out flipped upside-down compared to how it
    # actually looks in a browser/vector editor. Negating y fixes the
    # orientation, but a mirror also reverses the polygon's winding
    # direction -- reversing the point order after negating cancels that
    # back out, so the winding still matches what circle()/square()/
    # polygon() themselves produce (keeps cap/normal behavior consistent
    # with every other 2D shape in this app).
    flipped = [[x, -y] for x, y in pts]
    flipped.reverse()
    return flipped


def read_svg_profiles(data):
    """Returns a list of closed 2D profiles (each a list of [x,y]
    points) -- every closed shape found in the SVG (largest first),
    skipping non-rendered subtrees (<defs>/<symbol>/<clipPath>/<mask>,
    display:none/visibility:hidden). A file with several separate shapes
    -- e.g. a flower icon's individual petals, each its own <path> or
    <ellipse> -- has to stay as several profiles, since this app's 2D
    shapes are simple (single-contour, no holes): the caller extrudes
    each one and 3D-unions the results into one solid, rather than this
    function trying to merge them into a single outline itself. Raises
    ValueError if the SVG can't be parsed or has no closed shapes at
    all."""
    try:
        root = ET.fromstring(data)
    except ET.ParseError as e:
        raise ValueError(f"import(): couldn't parse SVG file: {e}")
    polygons = []
    _collect_svg_polygons(root, _identity_matrix(), polygons)
    if not polygons:
        raise ValueError(
            "import(): no closed shapes found in this SVG -- only <path> "
            "(ending in Z/closepath), <rect>, <circle>, <ellipse>, and "
            "<polygon> are read; open paths, <polyline>/<line>, and text "
            "aren't usable as an extrudable outline."
        )
    polygons.sort(key=_polygon_area, reverse=True)
    return [_fix_svg_orientation(p) for p in polygons]


def read_svg_profile(data):
    """Single-shape convenience wrapper around read_svg_profiles() --
    just the largest one. Prefer read_svg_profiles() (plural) for
    anything that might have more than one part (icons/multi-piece
    artwork); this one silently drops everything but the biggest shape,
    which is fine for a simple single-outline SVG but wrong for
    something like a flower made of several petals."""
    return read_svg_profiles(data)[0]


def read_import_file_multi(path):
    """Like read_import_file() but 2D formats come back as ('profiles',
    list_of_points_lists) -- every closed shape, not just the largest.
    3D formats still come back as a single ('mesh', (V, F)), since
    STL/OBJ/OFF are already one connected mesh each."""
    resolved = resolve_import_path(path)
    ext = os.path.splitext(resolved)[1].lower()
    with open(resolved, "rb") as f:
        data = f.read()
    if ext in SUPPORTED_2D_EXTENSIONS:
        return "profiles", read_svg_profiles(data)
    if ext in SUPPORTED_3D_EXTENSIONS:
        return "mesh", read_mesh_bytes(data, ext)
    raise ValueError(
        f"import(): unsupported file type {ext!r} -- only "
        f"{', '.join(SUPPORTED_EXTENSIONS)} are supported right now."
    )


def read_import_file(path):
    """Format-agnostic entry point: returns ('mesh', (V, F)) for 3D
    formats or ('profile', points) for 2D formats (SVG) -- just the
    largest shape if there's more than one; see read_import_file_multi()
    for every shape."""
    resolved = resolve_import_path(path)
    ext = os.path.splitext(resolved)[1].lower()
    with open(resolved, "rb") as f:
        data = f.read()
    if ext in SUPPORTED_2D_EXTENSIONS:
        return "profile", read_svg_profile(data)
    if ext in SUPPORTED_3D_EXTENSIONS:
        return "mesh", read_mesh_bytes(data, ext)
    raise ValueError(
        f"import(): unsupported file type {ext!r} -- only "
        f"{', '.join(SUPPORTED_EXTENSIONS)} are supported right now."
    )
