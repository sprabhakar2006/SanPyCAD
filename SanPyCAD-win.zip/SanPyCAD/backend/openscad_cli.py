"""
openscad_cli.py

Exact CSG via the real OpenSCAD application, run headless -- this is the
same operation your existing swp()/fo() workflow already relies on
(write polyhedron() text, let OpenSCAD's CGAL-based boolean engine do the
union/difference/intersection/hull), just automated instead of opening
the app by hand.

Each mesh operand is emitted as its own `polyhedron(points=..., faces=...,
convexity=10);` -- exactly what openscad4.swp() produces -- wrapped in the
requested operator, written to a temp .scad file, rendered with
`openscad -o out.stl in.scad`, and the resulting STL is read back in as
(vertices, faces).

If OpenSCAD isn't installed/found, `is_available()` returns False and
csg.py automatically falls back to the voxel/marching-cubes approximation
instead -- this module is a strict quality upgrade when available, not a
hard requirement.
"""

import json
import os
import platform
import shutil
import struct
import subprocess
import tempfile

import numpy as np

_CACHED_BINARY = None
_SEARCHED = False
_LAST_SEARCH = []  # [(candidate, resolved_or_None), ...] from the most recent find_binary() search


def _project_root():
    # this file lives in backend/, so the project root (where app.py and
    # sanpycad_config.json live) is one level up.
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _config_path():
    return os.path.join(_project_root(), "sanpycad_config.json")


def _read_config():
    try:
        with open(_config_path(), "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def get_configured_path():
    """The OpenSCAD path explicitly set via the app's Settings panel (the
    'OpenSCAD path' field -- see /set_openscad_path in server.py), or None
    if nothing's been set there. Persisted in sanpycad_config.json next to
    app.py, so it survives restarts; takes priority over everything else
    find_binary() tries, including the SANPYCAD_OPENSCAD_PATH/
    OPENSCAD_PATH environment variables (this is the friendlier,
    no-terminal-needed equivalent of that same override)."""
    return _read_config().get("openscad_path") or None


def set_configured_path(path):
    """Persist `path` (or clear it, if path is falsy) to
    sanpycad_config.json, and forget any previously cached find_binary()
    result so the very next call re-searches -- including this new path --
    immediately, with no restart needed."""
    data = _read_config()
    data["openscad_path"] = path or None
    with open(_config_path(), "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    reset_search()


def reset_search():
    """Forget the cached find_binary() result, so the next call to
    find_binary()/is_available()/search_diagnostics() re-runs the whole
    search from scratch. Called automatically by set_configured_path();
    exposed on its own too in case anything else ever needs to force a
    re-check (e.g. "OpenSCAD was just installed, check again" without
    restarting the app)."""
    global _CACHED_BINARY, _SEARCHED, _LAST_SEARCH
    _CACHED_BINARY = None
    _SEARCHED = False
    _LAST_SEARCH = []


def _resolve_app_bundle(path):
    """macOS only: if `path` points at an OpenSCAD.app bundle (what you'd
    naturally pick in a file-open dialog, or drag in from /Applications --
    Finder and native Open panels present it as a single opaque item, not
    something you'd navigate into), resolve it to the actual executable
    inside. Passed straight through unchanged for anything else (an
    already-correct binary path, or a non-.app path on any platform)."""
    if path and path.rstrip("/").lower().endswith(".app") and os.path.isdir(path):
        inner = os.path.join(path, "Contents", "MacOS", "OpenSCAD")
        if os.path.isfile(inner):
            return inner
    return path


def validate_path(path):
    """Checked when the user sets a path via the Settings panel's OpenSCAD
    path field: resolves a macOS .app bundle to its real binary if needed,
    confirms a file actually exists there, and confirms it's really
    runnable as OpenSCAD (spawns it with --version and checks the output
    mentions OpenSCAD) -- catches "that path doesn't exist" and "that's
    some other program" before saving it, rather than only finding out
    on the next render. Returns (ok: bool, message: str) -- message is
    either the version banner (ok) or a human-readable reason (not ok)."""
    if not path or not path.strip():
        return False, "No path given"
    resolved = _resolve_app_bundle(path.strip())
    if not os.path.isfile(resolved):
        return False, f"No file found at {resolved}"
    try:
        result = subprocess.run([resolved, "--version"], capture_output=True,
                                 text=True, timeout=10)
    except Exception as e:
        return False, f"Couldn't run it: {e}"
    banner = ((result.stdout or "") + (result.stderr or "")).strip()
    if "openscad" not in banner.lower():
        return False, f"That ran, but doesn't look like OpenSCAD (got: {banner[:200]!r})"
    return True, banner


def _candidate_paths():
    # The Settings panel's saved path, then the environment-variable
    # override, then everything else below -- in that priority order.
    configured = get_configured_path()
    if configured:
        yield _resolve_app_bundle(configured)

    override = os.environ.get("SANPYCAD_OPENSCAD_PATH") or os.environ.get("OPENSCAD_PATH")
    if override:
        yield _resolve_app_bundle(override)

    yield "openscad"  # PATH
    system = platform.system()
    if system == "Darwin":
        yield "/Applications/OpenSCAD.app/Contents/MacOS/OpenSCAD"
        yield os.path.expanduser("~/Applications/OpenSCAD.app/Contents/MacOS/OpenSCAD")
    elif system == "Windows":
        # Env vars rather than hardcoded "C:\..." so this still works on a
        # non-C: system drive or a non-English Windows install (both change
        # the literal folder name/drive but not these variables). Checked
        # under both Program Files (the standard "install for all users"
        # installer default) and LocalAppData\Programs (what a growing
        # number of Windows installers -- and OpenSCAD's own installer, if
        # "install for me only" is picked -- use instead, specifically so
        # installing doesn't need admin rights).
        program_files = os.environ.get("ProgramFiles", r"C:\Program Files")
        program_files_x86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
        local_app_data = os.environ.get("LocalAppData", "")
        for base in (program_files, program_files_x86):
            yield os.path.join(base, "OpenSCAD", "openscad.exe")
            yield os.path.join(base, "OpenSCAD (Nightly)", "openscad.exe")
        if local_app_data:
            yield os.path.join(local_app_data, "Programs", "OpenSCAD", "openscad.exe")
            yield os.path.join(local_app_data, "Programs", "OpenSCAD (Nightly)", "openscad.exe")
            yield os.path.join(local_app_data, "OpenSCAD", "openscad.exe")
    else:
        yield "/usr/bin/openscad"
        yield "/usr/local/bin/openscad"
        yield "/snap/bin/openscad"


def find_binary():
    global _CACHED_BINARY, _SEARCHED, _LAST_SEARCH
    if _SEARCHED:
        return _CACHED_BINARY
    _SEARCHED = True
    _LAST_SEARCH = []
    is_windows = platform.system() == "Windows"
    for candidate in _candidate_paths():
        # "/" is accepted alongside os.sep so a manually-set override path
        # still gets treated as a literal path even if someone writes it
        # with forward slashes on Windows (both work fine there).
        looks_like_path = os.sep in candidate or "/" in candidate or os.path.isabs(candidate)
        if not looks_like_path:
            resolved = shutil.which(candidate)
        elif os.path.isfile(candidate):
            # Windows has no POSIX-style executable permission bit to
            # check (os.access's X_OK there is unreliable/not meaningful --
            # every ordinary file reads as "executable"), so just existing
            # as a file is enough there; elsewhere, still require the
            # execute bit like before.
            resolved = candidate if (is_windows or os.access(candidate, os.X_OK)) else None
        else:
            resolved = None
        _LAST_SEARCH.append((candidate, resolved))
        if resolved and _CACHED_BINARY is None:
            _CACHED_BINARY = resolved
    return _CACHED_BINARY


def search_diagnostics():
    """[(candidate, resolved_path_or_None), ...] from the most recent
    find_binary() search -- every location that was actually checked, and
    whether anything was found there. Meant for surfacing in /status so
    "OpenSCAD isn't found" is self-diagnosable (which exact folders got
    checked) instead of a guessing game, and to make the
    SANPYCAD_OPENSCAD_PATH/OPENSCAD_PATH override discoverable when none
    of the built-in guesses pan out."""
    find_binary()  # make sure a search has actually run at least once
    return list(_LAST_SEARCH)


def is_available():
    return find_binary() is not None


def _format_polyhedron(V, F):
    V = np.round(np.asarray(V, dtype=float), 5)
    F = np.asarray(F, dtype=int)
    pts = "[" + ",".join(f"[{x},{y},{z}]" for x, y, z in V.tolist()) + "]"
    faces = "[" + ",".join("[" + ",".join(str(i) for i in tri) + "]" for tri in F.tolist()) + "]"
    return f"polyhedron(points={pts},faces={faces},convexity=10);"


def _read_binary_stl(path):
    with open(path, "rb") as f:
        data = f.read()
    if data[:5] == b"solid" and b"facet normal" in data[:200]:
        return _read_ascii_stl_bytes(data)
    count = struct.unpack_from("<I", data, 80)[0]
    verts = np.empty((count * 3, 3), dtype=float)
    faces = np.arange(count * 3, dtype=int).reshape(-1, 3)
    offset = 84
    for i in range(count):
        # 12 floats: normal(3) + v0(3) + v1(3) + v2(3), then 2 attr bytes
        vals = struct.unpack_from("<12f", data, offset)
        verts[i * 3 + 0] = vals[3:6]
        verts[i * 3 + 1] = vals[6:9]
        verts[i * 3 + 2] = vals[9:12]
        offset += 50
    return verts, faces


def _read_ascii_stl_bytes(data):
    lines = data.decode("utf-8", errors="ignore").splitlines()
    verts = []
    for line in lines:
        s = line.strip()
        if s.startswith("vertex"):
            parts = s.split()
            verts.append([float(parts[1]), float(parts[2]), float(parts[3])])
    V = np.array(verts, dtype=float)
    F = np.arange(len(V)).reshape(-1, 3)
    return V, F


class OpenSCADCliError(Exception):
    pass


def _operand_body(meshes, raw_operands):
    """Build the .scad text for each operand: verbatim raw text (e.g. from
    swp_c()/swp_surf()/swp_triangles(), whose face connectivity we must
    not touch) where available, otherwise a polyhedron() rebuilt from
    (V, F)."""
    parts = []
    for i, (V, F) in enumerate(meshes):
        raw = raw_operands[i] if raw_operands is not None and i < len(raw_operands) else None
        parts.append(raw if raw else _format_polyhedron(V, F))
    return "".join(parts)


def boolean_op(meshes, op, timeout=120, notes=None, raw_operands=None):
    """meshes: list of (V,F). op: 'union'|'difference'|'intersection'."""
    binary = find_binary()
    if not binary:
        raise OpenSCADCliError("OpenSCAD binary not found")
    body = _operand_body(meshes, raw_operands)
    scad_src = f"{op}(){{{body}}}"
    return _run(binary, scad_src, timeout, notes=notes)


def hull_op(meshes, timeout=120, notes=None, raw_operands=None):
    binary = find_binary()
    if not binary:
        raise OpenSCADCliError("OpenSCAD binary not found")
    body = _operand_body(meshes, raw_operands)
    scad_src = f"hull(){{{body}}}"
    return _run(binary, scad_src, timeout, notes=notes)


def render_scad_text(scad_src, timeout=120, notes=None):
    """Render arbitrary raw OpenSCAD source text (e.g. exactly what
    openscad4.fo()'s `txt` argument would contain -- polyhedron() calls
    from swp() wrapped in union()/difference()/resize()/etc) and return
    (V, F). Unlike boolean_op()/hull_op(), this doesn't build the .scad
    text itself -- the caller already has real OpenSCAD source, this just
    runs it and reads back the result."""
    binary = find_binary()
    if not binary:
        raise OpenSCADCliError("OpenSCAD binary not found")
    return _run(binary, scad_src, timeout, notes=notes)


def _run(binary, scad_src, timeout, notes=None):
    with tempfile.TemporaryDirectory(prefix="openscad_app_") as tmp:
        scad_path = os.path.join(tmp, "op.scad")
        stl_path = os.path.join(tmp, "op.stl")
        with open(scad_path, "w", encoding="utf-8") as f:
            f.write(scad_src)
        # --backend=Manifold: OpenSCAD's newer boolean engine, used
        # explicitly rather than leaving it to whatever the user's local
        # preferences happen to have selected. The older CGAL Nef-polyhedron
        # engine (this app's first choice, briefly) is prone to internal
        # assertion crashes on otherwise-valid geometry -- most often two
        # operands that touch along an exactly-coincident seam, which is a
        # completely normal thing to have (e.g. a lofted patch meeting a
        # solid it's meant to blend into) -- and it has no real repair path
        # when that happens, it just aborts the whole operation ("CGAL error:
        # assertion violation ... Current top level object is empty").
        # Manifold uses a different algorithm that's both faster and much
        # more robust to exactly that case. It's stricter about requiring
        # genuinely closed input, which used to surface real defects in this
        # app's own (now-fixed) re-triangulation -- with operands passed
        # through verbatim via swp()/swp_c()/swp_surf()/swp_triangles() text,
        # that's no longer a false positive. Older OpenSCAD builds don't
        # have the --backend flag at all, so if it's rejected outright we
        # retry once without it rather than hard-failing on an old install.
        def _invoke(args):
            try:
                return subprocess.run(args, capture_output=True, text=True, timeout=timeout)
            except subprocess.TimeoutExpired:
                raise OpenSCADCliError(f"OpenSCAD timed out after {timeout}s")

        proc = _invoke([binary, "--backend=Manifold", "-o", stl_path, scad_path])
        if proc.returncode != 0 and "backend" in (proc.stderr or "").lower() \
                and not os.path.isfile(stl_path):
            proc = _invoke([binary, "-o", stl_path, scad_path])

        # OpenSCAD often exits 0 (success) while still printing WARNING/
        # ERROR lines to stderr -- most commonly "... is not a valid
        # 2-manifold" for a polyhedron() operand, which CGAL then quietly
        # treats as empty/ignored during a boolean op even though the
        # *same* polyhedron renders fine standalone (no manifold check
        # needed just to display raw triangles). That silent-drop is
        # exactly what makes "my shape works alone but vanishes from a
        # union()" so confusing, so surface these every time, not just on
        # a hard failure.
        stderr_text = proc.stderr or ""
        if notes is not None:
            for line in stderr_text.splitlines():
                s = line.strip()
                if s and ("WARNING" in s.upper() or "ERROR" in s.upper()):
                    notes.append(f"OpenSCAD: {s}")

        if proc.returncode != 0 or not os.path.isfile(stl_path):
            stderr = stderr_text.strip()[-2000:]
            raise OpenSCADCliError(f"OpenSCAD failed (exit {proc.returncode}): {stderr}")
        if os.path.getsize(stl_path) == 0:
            # a valid, empty result (e.g. difference() that removes everything)
            return np.zeros((0, 3)), np.zeros((0, 3), dtype=int)
        return _read_binary_stl(stl_path)
