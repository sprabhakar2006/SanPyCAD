"""
geom_bridge.py

The one bit of glue shared by both ways of writing a script in this app
(the OpenSCAD-style language in scad_eval.py, and the plain-Python mode in
python_eval.py): turning an openscad4.py "sol" (a list of equal-length
cross sections -- what cube()/sphere()/cylinder()/linear_extrude()/etc all
return) into a watertight (vertices, faces) triangle mesh.

This calls straight into openscad4.triangulate_solid_open(), which itself
uses openscad4.earclip_3d() to cap the ends -- see that function's
docstring for why a plain mesh_vf() isn't enough (it only returns the side
walls, not the caps).
"""

import ast
import re

import numpy as np


def parse_polyhedron_text(text):
    """Parse an OpenSCAD polyhedron(...) call -- exactly what
    openscad4.swp() / swp_c() / swp_surf() / swp_triangles() all return
    (same `polyhedron(points, faces, convexity=10);` shape, just with
    different face connectivity for the geometry each is meant for: swp()
    caps both ends, swp_c() leaves them open for a closed loop, swp_surf()
    is a triangulated open surface, swp_triangles() is a raw explicit
    triangle list). Returns (V, F) numpy arrays for display/fallback-CSG
    use (any face with more than 3 vertices -- swp()'s single-n-gon end
    caps -- is fan-triangulated), or None if `text` isn't a polyhedron(...)
    call at all.

    The caller is expected to also hang on to the original `text` (see
    scad_eval.Mesh.raw_scad) so that when this shape is used as a real-
    OpenSCAD CSG operand, the *exact* original face connectivity can be
    passed through verbatim instead of whatever this function derived --
    re-deriving/re-triangulating a shape that was deliberately built with
    e.g. swp_c() (no end caps, for a closed-loop tube) using swp()-style
    capping logic is exactly what produces a non-manifold mesh that real
    OpenSCAD then rejects during a boolean op, even though the same mesh
    displays fine on its own.
    """
    m = re.search(r'polyhedron\s*\(', text)
    if not m:
        return None
    start = m.end() - 1  # index of the opening '('
    depth = 0
    end = None
    for i in range(start, len(text)):
        if text[i] == '(':
            depth += 1
        elif text[i] == ')':
            depth -= 1
            if depth == 0:
                end = i
                break
    if end is None:
        return None

    # split the call's arguments at top-level commas only (bracket-depth
    # aware, since points/faces are themselves comma-full nested lists)
    inner = text[start + 1:end]
    args = []
    bracket_depth = 0
    cur = ''
    for ch in inner:
        if ch in '[(':
            bracket_depth += 1
        elif ch in '])':
            bracket_depth -= 1
        if ch == ',' and bracket_depth == 0:
            args.append(cur)
            cur = ''
        else:
            cur += ch
    if cur.strip():
        args.append(cur)

    points = None
    faces = None
    for a in args:
        a = a.strip()
        try:
            if a.startswith('points'):
                points = ast.literal_eval(a.split('=', 1)[1].strip())
            elif a.startswith('faces'):
                faces = ast.literal_eval(a.split('=', 1)[1].strip())
            elif a.startswith('convexity') or a.startswith('$fn') or not a:
                continue
            elif points is None:
                points = ast.literal_eval(a)
            elif faces is None:
                faces = ast.literal_eval(a)
        except (ValueError, SyntaxError):
            return None
    if points is None or faces is None:
        return None

    V = np.asarray(points, dtype=float)
    tris = []
    for f in faces:
        if len(f) == 3:
            tris.append(f)
        elif len(f) > 3:
            for i in range(1, len(f) - 1):
                tris.append([f[0], f[i], f[i + 1]])
    F = np.asarray(tris, dtype=int) if tris else np.zeros((0, 3), dtype=int)
    return V, F


def sol_to_mesh(oscad, sol):
    """sol -> (V, F) numpy arrays. Returns empty arrays for degenerate input."""
    if sol is None or len(sol) == 0:
        return np.zeros((0, 3)), np.zeros((0, 3), dtype=int)
    soup = oscad.triangulate_solid_open(sol)
    soup = np.asarray(soup, dtype=float)
    if soup.size == 0:
        return np.zeros((0, 3)), np.zeros((0, 3), dtype=int)
    V = soup.reshape(-1, 3)
    F = np.arange(len(V)).reshape(-1, 3)
    return V, F


def looks_like_sol(x):
    """Heuristic: is `x` an openscad4-style 'sol' (list of cross sections,
    each a list of [x,y] or [x,y,z] points) rather than already-converted
    mesh data or something unrelated? Used by python_eval.py to decide
    whether a value passed to union()/difference()/show()/etc needs
    triangulating first.

    Many openscad4.py functions return plain nested lists (most do a
    final .tolist()), but not all of them do -- some return numpy arrays
    directly. Both are accepted here so a 'sol' fresh out of any library
    function works the same way regardless of which form it came back as.
    """
    try:
        if isinstance(x, np.ndarray):
            return x.ndim == 3 and x.shape[-1] in (2, 3) and x.shape[0] >= 1 and x.shape[1] >= 3
        if not isinstance(x, (list, tuple)) or len(x) == 0:
            return False
        first = x[0]
        if isinstance(first, np.ndarray):
            return first.ndim == 2 and first.shape[-1] in (2, 3) and first.shape[0] >= 1
        if not isinstance(first, (list, tuple)) or len(first) == 0:
            return False
        inner = first[0]
        if not isinstance(inner, (list, tuple, np.ndarray)):
            return False
        return len(inner) in (2, 3)
    except Exception:
        return False
