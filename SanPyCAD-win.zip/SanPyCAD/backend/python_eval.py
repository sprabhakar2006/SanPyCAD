"""
python_eval.py

The "write it the way I already write it" mode: instead of the
OpenSCAD-style text language in scad_lang.py/scad_eval.py, this runs the
user's own plain Python -- calling openscad4.py functions directly,
exactly like their existing notebook workflow (`from openscad4 import *`,
then cube()/cylinder()/translate()/etc), except instead of ending with

    fo(f'''
    difference(){{
    {swp(a)}
    {swp(b)}
    }}
    ''')

to hand a .scad file to real OpenSCAD, scripts here end with a call to
show() (or, for a script with exactly one top-level shape and no show()
call, that shape is used automatically). union()/difference()/
intersection()/hull() are provided as ordinary Python functions that take
one or more shapes -- either a raw "sol" straight out of cube()/sphere()/
cylinder()/etc, or the result of another union()/difference()/etc call --
and run them through the same voxel-CSG engine (csg.py) the OpenSCAD-style
mode uses.

NOTE on union(): openscad4.py already defines a function called `union()`
(2D pattern generation, unrelated to CSG). Scripts run through this module
get a *different* `union()` -- the CSG boolean one -- because that name is
far more useful/expected in this context and matches the OpenSCAD-style
mode. The original is still reachable as `openscad4.union(...)` if needed.

Trust model: this executes the script's Python directly (no sandboxing
beyond a plain exec() namespace) -- the same trust level as running it in
your own notebook. Don't run scripts you don't trust.
"""

import ast
import io
import contextlib
import functools
import math
import re
import threading
import traceback

import numpy as np
from scipy.spatial import cKDTree

import openscad4 as oscad
import csg
import openscad_cli
import mesh_import
from geom_bridge import sol_to_mesh, looks_like_sol, parse_polyhedron_text
from scad_eval import Mesh, COLOR_NAMES, DEFAULT_COLOR


class PythonScriptError(Exception):
    def __init__(self, msg, line=None):
        self.line = line
        super().__init__(msg)


RESERVED_NAMES = {
    "union", "difference", "intersection", "hull", "color", "show", "echo",
    "resize", "fo", "import_mesh", "import_profile", "import_profiles",
    "points", "p_line3d",
    "openscad4", "np", "numpy",
}


# ---------------------------------------------------------------------
# Persistent kernel state (Jupyter-style): variables a script assigns
# survive from one Render to the next, even if the line that computed
# them gets commented out afterwards -- exactly the "compute the heavy
# thing once, then comment it out and keep iterating on the rest" flow
# a Jupyter notebook supports. This is a plain module-level dict rather
# than anything per-session/per-tab, since this app only ever talks to
# one script editor at a time; a lock just guards against two /render
# (or /reset_kernel) requests landing back-to-back on the threaded HTTP
# server.
_PERSIST_LOCK = threading.Lock()
_PERSISTENT_USER_NS = {}


def reset_kernel():
    """Forget every persisted variable -- the Python-mode equivalent of
    Jupyter's 'Restart Kernel'. The next Render starts from a completely
    fresh namespace again."""
    with _PERSIST_LOCK:
        n = len(_PERSISTENT_USER_NS)
        _PERSISTENT_USER_NS.clear()
    return n


def persisted_variable_names():
    """Sorted names currently held in the persistent kernel namespace, for
    a small "N vars in memory" status indicator in the UI."""
    with _PERSIST_LOCK:
        return sorted(_PERSISTENT_USER_NS)


def _save_persisted_vars(ns, lib_snapshot):
    """After a run, decide what belongs in the persistent namespace: any
    name that isn't a dunder, isn't one of this app's own per-run helper
    closures (RESERVED_NAMES -- these must always be rebuilt fresh next
    time, since they close over *this* run's scene/warnings/echo_log),
    and either wasn't part of the fresh library baseline at all (a real
    user variable) or now points to a different object than that
    baseline did (the user reassigned a library name, e.g. `pi = 3`).

    Untouched library/helper functions are deliberately left out --
    they're cheap to rebuild every run and keeping them around would
    only risk pinning stale closures. Note this also naturally keeps a
    variable that a previous run set and this run's code never mentions
    at all (its line got commented out): it was merged into `ns` before
    exec ran, exec never removed it, so it's still sitting there
    untouched, with no `lib_snapshot` entry to match -- so it's kept."""
    new_persisted = {}
    for k, v in ns.items():
        if k.startswith("__"):
            continue
        if k in RESERVED_NAMES:
            continue
        if k in lib_snapshot and ns[k] is lib_snapshot[k]:
            continue
        new_persisted[k] = v
    with _PERSIST_LOCK:
        _PERSISTENT_USER_NS.clear()
        _PERSISTENT_USER_NS.update(new_persisted)
    return new_persisted


def _as_mesh(x, what="argument"):
    if isinstance(x, Mesh):
        return x
    if isinstance(x, str):
        # the literal text swp()/swp_c()/swp_surf()/swp_triangles() return
        # -- use it as the shape's exact geometry (see parse_polyhedron_text's
        # docstring for why re-deriving this ourselves from a raw sol is the
        # wrong move for anything but plain swp()-shaped solids)
        parsed = parse_polyhedron_text(x)
        if parsed is None:
            raise PythonScriptError(
                f"{what} is a string but doesn't look like a polyhedron(...) call "
                f"(what swp()/swp_c()/swp_surf()/swp_triangles() return) -- got: "
                f"{x[:120]!r}")
        V, F = parsed
        return Mesh(V, F, raw_scad=x)
    if looks_like_sol(x):
        V, F = sol_to_mesh(oscad, x)
        return Mesh(V, F)
    raise PythonScriptError(
        f"{what} must be a shape -- whatever cube()/sphere()/cylinder()/etc returns, "
        f"the text swp()/swp_c()/swp_surf()/swp_triangles() return, or the result of "
        f"union()/difference()/intersection()/hull()/color() -- got {type(x).__name__}")


def _concat_meshes(sols):
    """internal: turn a list of raw openscad4 'sol's (each ALREADY its
    own separate little shape -- one marker, one tube segment) into a
    single Mesh, by triangulating each one on its own and concatenating
    the resulting V/F arrays (with a running vertex-index offset).

    Deliberately NOT a union() of the markers/segments -- these are
    disjoint, disposable debug geometry that never needs to be one
    watertight solid, so a real CSG boolean between them (which is what
    union() does, one operand pair at a time, real or voxel) is pure
    wasted work, and for a list with many points/segments (a densely-
    sampled curve, say) a chain of N booleans is genuinely slow -- the
    exact same "don't union disjoint debug geometry" lesson
    SanPyCAD-Brep's own points()/line3d() apply via build123d's
    Compound() (see their docstrings) -- there's no lightweight
    "just group these, don't solve anything" container in this app's
    voxel-CSG world, so plain V/F array concatenation is that same
    trick here: no CSG solve of any kind, just stacking triangle soups
    into one Mesh."""
    all_V, all_F, offset = [], [], 0
    for sol in sols:
        V, F = sol_to_mesh(oscad, sol)
        if len(V) == 0:
            continue
        all_V.append(V)
        all_F.append(F + offset)
        offset += len(V)
    if not all_V:
        return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=int))
    return Mesh(np.concatenate(all_V, axis=0), np.concatenate(all_F, axis=0))


def _align_z_to(v):
    """internal: 3x3 rotation matrix mapping [0,0,1] onto the unit
    vector `v` (Rodrigues' rotation formula) -- used by p_line3d() to
    orient a Z-axis cylinder() sol along an arbitrary 3D segment
    direction, the hand-rolled equivalent of the origin/z_dir Plane
    trick SanPyCAD-Brep's own line3d()/surface_line_vector() use via
    build123d (this app has no such Plane primitive, so this is the
    plain-numpy version of the same idea)."""
    z = np.array([0.0, 0.0, 1.0])
    dot = float(np.dot(z, v))
    if dot > 1 - 1e-9:
        return np.eye(3)
    if dot < -1 + 1e-9:
        return np.diag([1.0, -1.0, -1.0])  # 180 deg flip
    axis = np.cross(z, v)
    axis = axis / np.linalg.norm(axis)
    angle = np.arccos(np.clip(dot, -1.0, 1.0))
    K = np.array([[0, -axis[2], axis[1]],
                  [axis[2], 0, -axis[0]],
                  [-axis[1], axis[0], 0]])
    return np.eye(3) + np.sin(angle) * K + (1 - np.cos(angle)) * (K @ K)


def points(pts, d=0.5, shape="cube"):
    """points(pts, d=0.5, shape="cube") -> shape
    A small marker (cube, or sphere if shape="sphere") of size `d` at
    every point in `pts` -- a flat list of [x,y] or [x,y,z] points
    (2D points are placed at z=0) -- so you can show() a raw point list
    (cr2dt()/turtle2d()/bezier() output, anything) straight into the
    viewer and see exactly where its points land, with NO f-string/
    fo()/real-OpenSCAD round trip needed:

        l2 = cr2dt([[0,0],[10,0],[0,10],[-10,0]])
        show(points(l2, .5), "blue")
        show(p_line3d(l2, .2), "magenta")

    This is the direct Python-mode equivalent of writing
    `fo(f'color("blue") points({l2},.5); ...')` by hand -- same visual
    result, but `l2` is used as a real Python value (no {}
    interpolation, no separate .scad text, no real-OpenSCAD subprocess:
    the markers are built and triangulated directly)."""
    pt_list = list(pts)
    if not pt_list:
        raise PythonScriptError("points(): need at least one point")
    key = str(shape).lower()
    if key not in ("cube", "sphere"):
        raise PythonScriptError(f'points(): shape must be "cube" or "sphere", got {shape!r}')
    sols = []
    for p in pt_list:
        x, y = float(p[0]), float(p[1])
        z = float(p[2]) if len(p) > 2 else 0.0
        if key == "sphere":
            sols.append(oscad.sphere(d / 2, cp=[x, y, z], s=16))
        else:
            # cube()'s own size-type branching only handles a plain
            # int or a [x,y,z] list (a bare float size silently falls
            # through with no return at all -- a pre-existing quirk of
            # cube() itself) -- pass [d,d,d] to sidestep that reliably
            # regardless of what type `d` happens to be.
            sols.append(oscad.translate([x, y, z], oscad.cube([d, d, d], center=True)))
    return _concat_meshes(sols)


def p_line3d(path, d=1, closed=0, s=12):
    """p_line3d(path, d=1, closed=0, s=12) -> shape
    A polyline of round tube segments (diameter `d`) connecting each
    consecutive point in `path` -- a flat list of [x,y] or [x,y,z]
    points (2D points placed at z=0) -- the direct Python-mode
    equivalent of `p_line3d()`/`p_line3dc()` in the classic OpenSCAD-
    text library, but built straight into the viewer with no {}
    interpolation or fo()/real-OpenSCAD step:

        l2 = cr2dt([[0,0],[10,0],[0,10],[-10,0]])
        show(p_line3d(l2, .2), "magenta")

    `closed=1` also connects the last point back to the first (same
    convention as the classic p_line3dc()). `s` is the number of
    segments around each tube's own circular cross-section (passed
    straight through to cylinder()) -- lower it (e.g. s=6) for a
    faster, chunkier look on a path with many points.

    No rounded end caps (unlike SanPyCAD-Brep's own p_line3d(), a real
    B-rep sweep) -- each segment is a plain cylinder() sol, concatenated
    with its neighbors same as points() above, so adjacent segments
    meet edge-to-edge at a flat joint rather than a smoothly blended
    one. Fine for a debug/reference line; for a real printable rope/
    tube, sweep a circle() profile along the path with
    linear_extrude()/rotate_extrude() (2D-only) or your own swp()-based
    construction instead."""
    pts = [(float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0) for p in path]
    if len(pts) < 2:
        raise PythonScriptError("p_line3d(): need at least 2 points")
    pairs = list(zip(pts, pts[1:]))
    if closed:
        pairs.append((pts[-1], pts[0]))
    r = float(d) / 2.0
    sols = []
    for p0, p1 in pairs:
        v = np.array(p1) - np.array(p0)
        length = float(np.linalg.norm(v))
        if length < 1e-9:
            continue
        Rm = _align_z_to(v / length)
        base_sol = oscad.cylinder(r=r, h=length, s=int(s))  # along +Z from origin
        oriented = [(np.array(ring) @ Rm.T + np.array(p0)).tolist() for ring in base_sol]
        sols.append(oriented)
    if not sols:
        raise PythonScriptError("p_line3d(): all consecutive points coincide")
    return _concat_meshes(sols)


def _looks_like_shape(x):
    """True if `x` is something show()/color()/union()/etc would accept
    as a shape -- a Mesh, a raw sol straight out of cube()/sphere()/etc,
    OR (this one's easy to miss, and was a real bug here once already)
    the literal polyhedron(...) TEXT swp()/swp_c()/swp_surf()/
    swp_triangles() return, which _as_mesh() has always accepted as a
    shape directly -- see e.g. show(swp_c(f1), "orange"). Used by
    show()'s *args form to tell "another shape to add" apart from a
    trailing color name/hex string/[r,g,b] list, which is never
    shape-like (and, critically, never a valid polyhedron(...) string
    either) -- so show(swp_c(f1), swp_c(f2)) is correctly recognized as
    TWO shapes, not one shape plus a (garbage, silently-dropped) 'color'
    string that happens to be the second polyhedron's entire text."""
    if isinstance(x, Mesh) or looks_like_sol(x):
        return True
    if isinstance(x, str):
        return parse_polyhedron_text(x) is not None
    return False


def _first_color(meshes):
    for m in meshes:
        if m.color:
            return m.color
    return None


def _is_degenerate(m):
    """True if m has literally zero triangles, OR every triangle is
    effectively zero-area/zero-volume (e.g. every point coincides, which
    is what a broken upstream computation -- like a triangulation that
    silently collapsed -- tends to produce; that's not caught by a plain
    is_empty() check since the triangle *count* can still be nonzero)."""
    if m.is_empty():
        return True
    lo = m.V.min(axis=0)
    hi = m.V.max(axis=0)
    return bool(np.all((hi - lo) < 1e-9))


def _find_var_name(ns, x):
    """Identity search (not equality -- `is`) through the script's own
    namespace for whichever variable currently holds the exact object
    `x`, so a shape can be labeled with the same name you'd use to refer
    to it in your own script (e.g. show(sol1) -> "sol1"). Only variables
    assigned *before* this point in the script are visible here (ns is
    populated incrementally as exec() runs the script line by line),
    which matches the usual `a = cube(10); show(a)` pattern. Returns
    None if `x` isn't (yet, or ever) bound to any script-level name --
    e.g. an inline `show(cube(10))` with no variable at all."""
    for name, val in ns.items():
        if name in RESERVED_NAMES or name.startswith("_"):
            continue
        if val is x:
            return name
    return None


def _flatten_sol_points(sol, name):
    """[(x,y,z), "name[i][j]"), ...] for every point of every cross
    section in `sol` -- the raw material both vertex-labeling paths
    (direct show() of a sol, and swp()/swp_c()/swp_surf()/
    swp_triangles() text used with fo()) build their coordinate ->
    label lookup from. Returns (None, None) if `sol` doesn't look like
    a plain list of equal-shaped [x,y,z] cross sections."""
    try:
        pts = []
        labels = []
        for i, section in enumerate(sol):
            arr = np.asarray(section, dtype=float)
            if arr.ndim != 2 or arr.shape[1] != 3:
                return None, None
            for j in range(len(arr)):
                pts.append(arr[j])
                labels.append(f"{name}[{i}][{j}]")
        if not pts:
            return None, None
        return np.asarray(pts), labels
    except Exception:
        return None, None


def _labels_via_kdtree(points, labels, V, tol=None):
    """For each row of `V`, find the nearest point in `points` (a small
    tolerance, not exact equality) and report its label, or None if
    nothing was close enough. A tolerance-based nearest-neighbor match
    (rather than exact/rounded coordinate equality) is what makes this
    robust to the small amounts of floating-point drift that creep in
    along the way -- e.g. triangulate_solid_open()'s own internal
    0.00001-degree "avoid exactly-coincident geometry" rotation trick
    when a sol is show()n directly, or an STL export's 32-bit-float
    round trip (and whatever OpenSCAD's own geometry engine does
    internally before that export) when a swp()-built shape goes
    through real OpenSCAD via fo().

    `tol` defaults to whichever is larger: a small fraction of the
    point cloud's own span (so it scales up for a building-sized model,
    where float32 STL export loses more absolute precision), or a fixed
    floor comfortably above swp()/swp_c()'s own `.round(4)` on the
    points they embed as text (up to 5e-5 of rounding error right
    there, before OpenSCAD or STL export even get involved) -- a purely
    relative tolerance would be far too tight for a small model (a
    r=0.01 cylinder has a tiny span, so a relative-only tolerance could
    end up smaller than swp()'s own rounding error). Returns None if
    there's nothing to match against at all."""
    if points is None or len(points) == 0 or len(V) == 0:
        return None
    if tol is None:
        span = float(np.ptp(points, axis=0).max()) if len(points) > 1 else 0.0
        tol = max(span * 1e-4, 2e-3)
    tree = cKDTree(points)
    dists, idxs = tree.query(V, k=1)
    return [labels[idxs[i]] if dists[i] <= tol else None for i in range(len(V))]


def _label_sol_vertices(sol, V, name):
    """Best-effort map from each row of the final triangulated mesh `V`
    back to "name[i][j]" -- which cross-section i, point j of the
    original openscad4-style `sol` (list of equal-length cross
    sections) it came from -- so the viewer's vertex-measure tool can
    show that instead of a bare coordinate. Used when a raw sol is
    show()n/color()d directly (not via fo() -- see _register_sol_labels
    for that path).

    openscad4.triangulate_solid_open() gathers the final soup's *side-
    wall* vertices straight out of `rot('y.00001', sol)` (a tiny
    numerical-robustness rotation it applies internally before
    triangulating) via plain numpy fancy-indexing, so replicating that
    same rotation here first gets side-wall vertices very close to an
    exact match. End-cap vertices (only present for solids whose first/
    last cross-section isn't already a single closed point) go through
    an extra flatten/ear-clip/unflatten round trip inside earclip_3d()
    and drift a little further, which is exactly what the tolerance in
    _labels_via_kdtree() is for.

    Returns None if anything about `sol` looks unexpected -- this is a
    "nice to have" label, not something that should ever break
    rendering."""
    try:
        rotated = oscad.rot('y.00001', sol)
    except Exception:
        return None
    points, labels = _flatten_sol_points(rotated, name)
    return _labels_via_kdtree(points, labels, V)


def _resolve_color_arg(c):
    if c is None:
        return None
    if isinstance(c, str):
        s = c.strip()
        if s.startswith('#'):
            hexs = s[1:]
            if len(hexs) in (3, 4):
                hexs = ''.join(ch * 2 for ch in hexs[:3])
            if len(hexs) >= 6:
                try:
                    return tuple(int(hexs[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
                except ValueError:
                    return None
            return None
        return COLOR_NAMES.get(s.lower())
    if isinstance(c, (list, tuple)) and len(c) >= 3:
        return (float(c[0]), float(c[1]), float(c[2]))
    return None


def _split_top_level_statements(text):
    """Split OpenSCAD source into top-level statements (bracket-depth aware,
    skipping over string literals and comments so brackets/semicolons
    inside them don't confuse the split). Each returned chunk is either a
    `...;` simple statement or a `...{...}` block instantiation, exactly as
    written -- used so fo()'s color()-tagged top-level statements can be
    identified and rendered as separate (correctly colored) objects, since
    none of OpenSCAD's mesh export formats (including STL) preserve
    color() through the command-line render."""
    stmts = []
    depth = 0
    start = 0
    i = 0
    n = len(text)
    while i < n:
        c = text[i]
        if c in '"\'':
            quote = c
            i += 1
            while i < n and text[i] != quote:
                if text[i] == '\\':
                    i += 1
                i += 1
        elif text[i:i + 2] == '//':
            comment_start = i
            nl = text.find('\n', i)
            if depth == 0 and not text[start:comment_start].strip():
                # nothing but whitespace between the last statement boundary
                # and this comment -- i.e. a whole line commented out, like
                # `// color("red") shape();` -- so it's pure boilerplate,
                # not a prefix of whatever statement follows. Drop it,
                # otherwise it stays glued onto the next real statement's
                # text (nothing else ever resets `start`), which makes
                # _extract_leading_color_alpha() see that next statement as
                # starting with `//` and silently miss its own color() call.
                start = (nl + 1) if nl != -1 else n
            i = nl if nl != -1 else n
            if nl == -1:
                break
        elif text[i:i + 2] == '/*':
            comment_start = i
            end = text.find('*/', i + 2)
            if depth == 0 and not text[start:comment_start].strip():
                start = (end + 2) if end != -1 else n
            i = end + 2 if end != -1 else n
            continue
        elif c in '([{':
            depth += 1
        elif c in ')]':
            depth -= 1
        elif c == '}':
            # only a closing BRACE can end a statement (a block
            # instantiation like `color(...) { ... }` or `for(...) { }`)
            # -- a closing paren/bracket returning to depth 0 just means
            # one of possibly several chained `name(...)` prefixes ended
            # (e.g. `color("blue") for(p=[1,2]) x();` has two before the
            # terminating `;`), not the whole statement.
            depth -= 1
            if depth == 0:
                stmts.append(text[start:i + 1])
                start = i + 1
        elif c == ';' and depth == 0:
            stmts.append(text[start:i + 1])
            start = i + 1
        i += 1
    tail = text[start:].strip()
    if tail:
        stmts.append(tail)
    return [s.strip() for s in stmts if s.strip()]


def _split_top_level_args(inner):
    """Bracket-depth-aware comma split, for a function call's argument
    list (e.g. the inside of `color("red", 0.5)`)."""
    args = []
    depth = 0
    cur = ''
    for ch in inner:
        if ch in '([{':
            depth += 1
        elif ch in ')]}':
            depth -= 1
        if ch == ',' and depth == 0:
            args.append(cur)
            cur = ''
        else:
            cur += ch
    if cur.strip():
        args.append(cur)
    return args


_PREFIX_CLAUSE_RE = re.compile(
    r'(for|if|intersection_for|translate|rotate|scale|mirror|resize|multmatrix)\s*\('
)


def _split_leading_prefix(s):
    """Repeatedly match leading for(...)/if(...)/intersection_for(...)/
    translate(...)/rotate(...)/scale(...)/mirror(...)/resize(...)/
    multmatrix(...) clauses -- none of these open a {} block of their
    own when they're only wrapping one single child statement (valid
    OpenSCAD either way: `translate(v) color("blue") shape();` needs no
    braces, same as `for(i=..) color(...) shape();`), so a statement
    starting with one of these still counts as the same top-level
    statement. Returns (prefix_source, remainder) -- unlike
    _strip_prefix_clauses(), the matched prefix chain's own source is
    kept (not discarded), so a caller can re-wrap a *different*
    remainder in the exact same prefix chain (see
    _expand_wrapper_children() below)."""
    s = s.lstrip()
    pos = 0
    while True:
        m = _PREFIX_CLAUSE_RE.match(s, pos)
        if not m:
            break
        start = m.end() - 1
        depth = 0
        end = None
        for i in range(start, len(s)):
            if s[i] in '([{':
                depth += 1
            elif s[i] in ')]}':
                depth -= 1
                if depth == 0:
                    end = i
                    break
        if end is None:
            break
        pos = end + 1
        while pos < len(s) and s[pos].isspace():
            pos += 1
    return s[:pos], s[pos:]


def _strip_prefix_clauses(s):
    """Discard-the-prefix convenience wrapper around
    _split_leading_prefix() -- see there for what counts as a prefix
    clause and why. This is what lets a color() that isn't the very
    first token but still applies to the whole statement -- e.g.
    `for(i=..)for(j=..)color("magenta")..text(..);` (what a for-loop-
    driven color() call compiles to, see e.g. openscad4.track_points_surf()),
    or `translate([0,0,10]) color("blue") p_line3d(...);` -- still get
    found, instead of silently losing its color the moment anything
    (most commonly translate()) comes between it and color()."""
    return _split_leading_prefix(s)[1]


def _expand_wrapper_children(stmt):
    """If `stmt` is a for/if/translate/rotate/scale/mirror/resize/
    multmatrix chain immediately followed by a brace block `{ ... }`
    containing MORE THAN ONE child statement, return (prefix,
    [raw_child_statement, ...]) -- else None.

    Why this matters: _extract_leading_color_alpha() only ever finds a
    color() that applies to an *entire* statement. A wrapper block with
    several differently-colored children (the exact shape of a common
    real pattern -- `translate(v){ color("blue") a(); %b(); }`, a
    colored shape shown next to a translucent reference one) has no
    single such color, so without this, the whole block would render
    as one uncolored/default-colored object, silently losing every
    color() actually written inside it. Splitting it into one
    statement per child -- each individually re-wrapped in the exact
    same prefix chain, e.g. `translate(v){ color("blue") a(); }` and
    `translate(v){ %b(); }` -- doesn't change the resulting geometry at
    all (translate/rotate/scale/mirror/resize/multmatrix/for/if are
    purely positional/repetition constructs, not boolean CSG that
    needs its operands evaluated together the way union()/difference()/
    etc do), just which separate OpenSCAD render call ends up drawing
    each child and with which color attached -- letting
    _color_group_for_statement() recurse into each child and resolve
    its own color/modifier independently."""
    prefix, remainder = _split_leading_prefix(stmt)
    if not prefix:
        return None
    remainder = remainder.lstrip()
    stripped = remainder.rstrip()
    if not (remainder.startswith('{') and stripped.endswith('}')):
        return None
    inner = stripped[1:-1]
    children = _split_top_level_statements(inner)
    if len(children) <= 1:
        return None
    return prefix, children


def _extract_leading_color_alpha(stmt):
    """If `stmt` (a single top-level OpenSCAD statement) starts with
    color(...) -- or starts with one or more for(...)/if(...)/
    translate(...)/rotate(...)/scale(...)/mirror(...)/resize(...)/
    multmatrix(...) clauses that themselves lead straight into a
    color(...), e.g. a for-loop that colors everything it emits, or a
    color()-tagged shape that's then translate()d/rotate()d -- return
    the (rgb_or_None, alpha_or_None) it specifies. Alpha matches OpenSCAD's own
    color(c, alpha) signature: a second positional argument
    (color("blue", 0.2)), an `alpha=` keyword (color("blue", alpha=0.2)),
    or embedded in a 4-element color array (color([1,0,0,0.2])) -- else
    (None, None)."""
    s = stmt.lstrip()
    m = re.match(r'color\s*\(', s)
    if not m:
        stripped = _strip_prefix_clauses(s)
        m2 = re.match(r'color\s*\(', stripped)
        if m2:
            s, m = stripped, m2
    if not m:
        return None, None
    start = m.end() - 1
    depth = 0
    end = None
    for i in range(start, len(s)):
        if s[i] in '([{':
            depth += 1
        elif s[i] in ')]}':
            depth -= 1
            if depth == 0:
                end = i
                break
    if end is None:
        return None, None
    args = _split_top_level_args(s[start + 1:end])
    if not args:
        return None, None

    color = None
    alpha = None
    positional_index = 0
    for a in args:
        a = a.strip()
        if a.startswith('alpha'):
            try:
                alpha = float(ast.literal_eval(a.split('=', 1)[1].strip()))
            except (ValueError, SyntaxError, IndexError):
                pass
            continue
        if a.startswith('c=') or a.startswith('c ='):
            try:
                color = _resolve_color_arg(ast.literal_eval(a.split('=', 1)[1].strip()))
            except (ValueError, SyntaxError):
                pass
            continue
        try:
            val = ast.literal_eval(a)
        except (ValueError, SyntaxError):
            positional_index += 1
            continue
        if positional_index == 0:
            color = _resolve_color_arg(val)
            if isinstance(val, (list, tuple)) and len(val) >= 4 and alpha is None:
                try:
                    alpha = float(val[3])
                except (TypeError, ValueError):
                    pass
        elif positional_index == 1 and alpha is None:
            try:
                alpha = float(val)
            except (TypeError, ValueError):
                pass
        positional_index += 1
    return color, alpha


_MODIFIER_CHARS = set('%#!*')
# match OpenSCAD's own preview semantics for these where practical:
#   % (background) -- ghosted/translucent, and (unlike real OpenSCAD's CLI
#     export, which excludes %-marked geometry entirely since it's a
#     preview-only aid) still included here, just faded, since a debug
#     visualization that silently vanishes is worse than one that's easy
#     to tell apart from the "real" geometry
#   # (highlight)   -- forced to a distinct color so it's easy to spot,
#     matching this app's DSL-mode evaluator's existing treatment of #
#   *  (disable)     -- omitted entirely, same as real OpenSCAD
#   !  (root)        -- no isolated meaning here (each fo() color-group is
#     already rendered as its own single-statement file with nothing else
#     to hide), so it's treated the same as no modifier at all
_HIGHLIGHT_COLOR = (1.0, 0.0, 0.0)
_BACKGROUND_ALPHA = 0.25


_ASSIGNMENT_RE = re.compile(r'^\$?[A-Za-z_]\w*\s*=(?!=)')


def _color_group_for_statement(stmt):
    """Resolve one top-level geometry statement into a list of
    (color_or_None, alpha, source) entries -- normally just one entry
    for itself, but if it's a wrapper block with more than one child
    and no color/modifier of its own, each child is recursively
    resolved instead (see _expand_wrapper_children()), so
    `translate(v){ color("blue") a(); %b(); }` yields two separately-
    colored entries instead of one uncolored one covering both.
    `source` never includes the leading %/#/* modifier character
    itself (real OpenSCAD gets a plain, unmodified statement -- the
    modifier's *meaning* is applied here instead, via color/alpha,
    since none of it survives OpenSCAD's own CLI/STL export anyway)."""
    s = stmt.lstrip()
    modifier = None
    if s and s[0] in _MODIFIER_CHARS:
        modifier = s[0]
        rest = s[1:].lstrip()
    else:
        rest = stmt
    if modifier == '*':
        return []

    color, alpha = _extract_leading_color_alpha(rest)

    if color is None and modifier in (None, '!'):
        expanded = _expand_wrapper_children(rest)
        if expanded:
            prefix, children = expanded
            out = []
            for child in children:
                for c_color, c_alpha, c_src in _color_group_for_statement(child):
                    out.append((c_color, c_alpha, f'{prefix}{{\n{c_src}\n}}'))
            return out

    if modifier == '%':
        if alpha is None:
            alpha = _BACKGROUND_ALPHA
        else:
            alpha = min(alpha, _BACKGROUND_ALPHA)
    elif modifier == '#':
        color = _HIGHLIGHT_COLOR
        if alpha is None:
            alpha = 1.0

    return [(color, 1.0 if alpha is None else alpha, rest)]


def _group_statements_by_color(txt):
    """Split `txt` into top-level statements and resolve each geometry
    statement's own color()/%/# combination. Returns a list of
    (color_or_None, alpha, single_statement_source) -- ONE ENTRY PER
    TOP-LEVEL STATEMENT (deliberately *not* merged by color -- see below),
    each with any leading %/#/! modifier character stripped (OpenSCAD's
    own CLI export would otherwise drop % geometry entirely, since that
    modifier means "preview only").

    Why not merge same-colored statements into one OpenSCAD call (which
    this function used to do, purely to cut down on subprocess calls):
    OpenSCAD's STL/CLI export implicitly unions every top-level object in
    the file, which requires building a CGAL Nef polyhedron -- this is
    real OpenSCAD's F6/Render behavior, not F5/Preview (which just draws
    each root object's raw PolySet directly, no CGAL involved at all, so
    non-manifold geometry shows up there exactly as given). That implicit
    union silently drops (or corrupts) any non-manifold operand caught up
    in it -- most commonly an open surface from swp_surf(), which is
    *supposed* to have no caps -- even though the exact same polyhedron()
    exports perfectly fine completely on its own (a single top-level
    object never needs Nef-polyhedron construction just to export its own
    triangles). So if two unrelated statements merely happened to share a
    color and got batched into one OpenSCAD call together, one of them
    could silently vanish from the viewer for a reason that has nothing
    to do with color at all -- exactly the "visible in F5, gone in F6"
    symptom real OpenSCAD itself would show for the same geometry.
    Rendering every statement through its own separate OpenSCAD call
    avoids that: each one only goes through real CSG evaluation for
    whatever boolean ops *it itself* explicitly contains (a
    `difference(){...}` block, say -- which legitimately needs it, same
    as real OpenSCAD's own F6), never because it happened to be exported
    alongside something else that had nothing to do with it. The viewer
    doesn't care that same-colored shapes now arrive as separate Mesh
    objects instead of one merged one -- they render identically either
    way, just as (possibly) more OpenSCAD subprocess calls per render.

    Plain variable assignments (`name = value;`) are treated as shared
    context rather than a statement of their own -- they don't produce
    geometry, but a later statement might reference them (e.g.
    openscad4.track_points_surf() returns `s1 = [...]; for(i=..)
    for(j=..) color(...)....;` as two separate top-level statements), and
    since each statement is now rendered as its own fully independent
    OpenSCAD call with no shared state between them, an assignment left
    out of a statement that needs it would render as a real OpenSCAD
    error ("ignoring unknown variable"). So every assignment is included
    alongside every geometry statement instead."""
    stmts = _split_top_level_statements(txt)
    if not stmts:
        return [(None, 1.0, txt)]

    shared = []
    geometry_stmts = []
    for stmt in stmts:
        if _ASSIGNMENT_RE.match(stmt.lstrip()):
            shared.append(stmt)
        else:
            geometry_stmts.append(stmt)

    shared_src = "\n".join(shared)
    result = []
    for stmt in geometry_stmts:
        for color, alpha, rest in _color_group_for_statement(stmt):
            src = (shared_src + "\n" + rest) if shared_src else rest
            result.append((color, alpha, src))

    if not result:
        # every top-level statement was an assignment (or disabled with
        # *) -- nothing to render, but don't just vanish silently
        return [(None, 1.0, shared_src)] if shared_src else []

    return result


def _statement_modifier_and_body(stmt, chars):
    """For one already-split OpenSCAD statement, return (modifier_or_
    None, rest_after_stripping_it, body_or_None) -- `body` is the
    substring inside the statement's own {...} block if it has one
    (a block instantiation like `difference(){...}`), or None for a
    plain `...;` statement with nothing to recurse into."""
    s = _strip_prefix_clauses(stmt)
    modifier = None
    if s and s[0] in chars:
        modifier = s[0]
        s = s[1:].lstrip()
    body = None
    if s.rstrip().endswith('}'):
        brace = s.find('{')
        if brace != -1:
            body = s[brace + 1:s.rfind('}')]
    return modifier, s, body


def _find_nested_modifiers(txt, chars='#%', _is_top=True):
    """Recursively find every %/# modifier anywhere inside `txt`'s
    nested {...} blocks -- e.g. the #swp(b) in
        difference(){
            swp(a);
            #swp(b);
        }
    -- NOT ones leading a genuinely top-level statement of `txt` itself,
    since _group_statements_by_color() already handles those as their
    own separately-colored render (there's no separate "normal" result
    to overlay them on top of in that case). Real OpenSCAD's own
    preview draws a %/#-marked object as an extra highlighted/
    translucent overlay on top of the normal result regardless of how
    deeply it's nested in the CSG tree -- e.g. a `#`-marked subtrahend
    of a difference() still fully participates in the subtraction *and*
    gets drawn highlighted so you can see what got cut away -- and the
    CLI/STL export this app uses for the "normal" render doesn't carry
    any trace of that extra visual (nor does STL export change how the
    boolean itself is computed just because of a %/# on one operand),
    so it has to be reconstructed and rendered separately here.

    A top-level wrapper block (translate/rotate/.../for/if) with more
    than one child is a special case, though: _group_statements_by_color()
    (via _color_group_for_statement()/_expand_wrapper_children()) already
    splits *that* into one independently-colored/alpha'd render per
    child, wrapper reapplied around each -- so those children must NOT
    also be treated as "nested" here, or a %/#-marked one among them
    would render twice: once correctly there (with the wrapper's
    translate()/rotate()/etc actually reapplied), and once more here
    from `body`'s bare inner text, which never gets the wrapper
    reapplied at all -- landing the second copy at the wrong place
    while a correct copy also exists right on top of it, i.e. showing
    up twice (most visibly with % translucency, since then both copies
    are visible at once instead of one opaque copy fully hiding the
    other). Checking whether _color_group_for_statement() actually
    split a given top-level statement (rather than re-deriving that
    same decision separately here) is what keeps this in sync with it.

    Returns [(modifier_char, child_source_text), ...] -- `child_source_
    text` is exactly the child statement's own source (ready to render
    standalone + the usual trailing helper-module boilerplate)."""
    found = []
    for stmt in _split_top_level_statements(txt):
        if _is_top and len(_color_group_for_statement(stmt)) > 1:
            continue

        modifier, rest, body = _statement_modifier_and_body(stmt, chars)
        if modifier and not _is_top:
            found.append((modifier, rest))
        if body is not None:
            found.extend(_find_nested_modifiers(body, chars, _is_top=False))
    return found


def make_namespace(csg_resolution, scene, warnings, echo_log):
    ns = {k: v for k, v in vars(oscad).items() if not k.startswith("_")}
    ns["openscad4"] = oscad
    ns["np"] = np
    ns["numpy"] = np

    shown_flag = {"any": False}

    # ---------------------------------------------------------------
    # Vertex labels for the fo() workflow: swp()/swp_c()/swp_surf()/
    # swp_triangles() each flatten their input sol into a polyhedron()
    # "points" list via the same simple `points[i*width+j] = sol[i][j]`
    # scheme (no rotation trick, unlike triangulate_solid_open -- see
    # each function's source). So every time the script calls one of
    # these with a sol that's bound to a variable, record that sol's
    # points (tagged "name[i][j]") here; once fo() gets real OpenSCAD's
    # STL back, its vertices get matched against everything recorded
    # here (tolerance-based, since an STL export's 32-bit floats won't
    # exactly bit-match the original values) to label the viewer's
    # picked vertices, the same idea as the direct-show() path in
    # _label_sol_vertices.
    sol_label_points = []
    sol_label_names = []

    def _register_sol_labels(sol, name):
        points, labels = _flatten_sol_points(sol, name)
        if points is not None:
            sol_label_points.append(points)
            sol_label_names.extend(labels)

    def _wrap_swp_fn(real_fn):
        @functools.wraps(real_fn)  # keeps the real signature/docstring for Shift+Tab
        def wrapper(sol, *args, **kwargs):
            text = real_fn(sol, *args, **kwargs)
            try:
                if looks_like_sol(sol):
                    name = _find_var_name(ns, sol)
                    if name:
                        _register_sol_labels(sol, name)
            except Exception:
                pass  # a label is a nice-to-have; never let this break fo()
            return text
        return wrapper

    for _swp_name in ("swp", "swp_c", "swp_surf", "swp_triangles"):
        if _swp_name in ns and callable(ns[_swp_name]):
            ns[_swp_name] = _wrap_swp_fn(ns[_swp_name])

    def _labels_for_fo_mesh(V):
        """Vertex labels for a mesh fo() just got back from real
        OpenSCAD, built from everything swp()/swp_c()/swp_surf()/
        swp_triangles() recorded so far in this script run. None if
        nothing's been recorded (e.g. the fo() text wasn't built from
        any of those, or none of their arguments were script
        variables)."""
        if not sol_label_points:
            return None
        points = np.concatenate(sol_label_points, axis=0)
        labels = _labels_via_kdtree(points, sol_label_names, V)
        if labels is not None and not any(labels):
            # We *did* record candidate points (so swp()/etc was called
            # on a named variable), but not one of them ended up close
            # enough to any of the rendered mesh's actual vertices --
            # most likely real OpenSCAD's geometry engine moved/merged/
            # re-triangulated things more than the matching tolerance
            # allows for. Surfaced as a warning (once) rather than
            # silently showing no labels, so this is diagnosable instead
            # of just "the labels don't work."
            warnings.append(
                "fo(): vertex labels (sol1[i][j]-style) couldn't be matched to any "
                "point in the rendered geometry -- OpenSCAD's own processing likely "
                "moved the coordinates more than expected. Clicking vertices in the "
                "viewer will still work, just without that label.")
        return labels

    def _combine(op, args, fname):
        if len(args) == 0:
            raise PythonScriptError(f"{fname}() needs at least one shape argument")
        all_meshes = [_as_mesh(a, f"{fname}() argument {i+1}") for i, a in enumerate(args)]
        meshes = []
        for i, m in enumerate(all_meshes):
            if _is_degenerate(m):
                warnings.append(
                    f"{fname}() argument {i+1} came out empty or degenerate (all its "
                    f"points coincide) and was dropped -- if that shape came from a "
                    f"chain of function calls, check each step didn't quietly return "
                    f"nothing (e.g. print(len(x)) on it before passing it in here)")
            else:
                meshes.append(m)
        if not meshes:
            warnings.append(f"{fname}() had no non-empty shapes, returned nothing")
            return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=int))
        if len(meshes) == 1:
            return meshes[0]
        color = _first_color(meshes)
        alpha = meshes[0].alpha
        pairs = [(m.V, m.F) for m in meshes]
        raw_operands = [m.raw_scad for m in meshes]
        V, F = csg.boolean_op(pairs, op, resolution=csg_resolution, notes=warnings,
                               raw_operands=raw_operands)
        if len(V) == 0:
            warnings.append(
                f"{fname}() produced an empty result -- the shapes may not overlap as "
                f"expected, or csg_resolution may be too low to resolve them")
        # If every operand had its own exact OpenSCAD source (raw_scad --
        # a literal swp()/swp_c()/swp_surf()/swp_triangles() polyhedron(),
        # OR another union()/difference()/intersection()/hull() result
        # that itself qualified here), this result's OWN source is just
        # those wrapped in one more {op}(){...} block -- so a further
        # boolean built on top of THIS result can embed the whole nested
        # tree verbatim in a single real-OpenSCAD call, instead of
        # re-deriving a polyhedron from this step's already-reimported
        # (STL-round-tripped, 5-decimal-rounded) V/F and running a
        # SECOND, separate CGAL evaluation on top of that. That second,
        # separate evaluation is exactly what let a chained
        # difference(intersection(swp(s1), swp(b)), swp(c), swp(d)) come
        # out with tiny sliver-triangle artifacts right where c/d cut
        # close to the intersection's own boundary, even though OpenSCAD
        # itself reported no error at either step -- the equivalent
        # single nested fo() call (which only ever does ONE evaluation
        # for the whole tree) didn't have the extra round-trip to
        # introduce that mismatch in the first place.
        combined_raw = f"{op}(){{{''.join(raw_operands)}}}" if all(raw_operands) else None
        return Mesh(V, F, color=color, alpha=alpha, raw_scad=combined_raw)

    def union(*args):
        """union(*shapes) -> shape
        Boolean union of two or more shapes. Each argument can be a raw
        sol (whatever cube()/sphere()/cylinder()/etc returns), the text
        swp()/swp_c()/swp_surf()/swp_triangles() returns, or the result of
        another union()/difference()/intersection()/hull()/color() call.
        Uses real OpenSCAD's exact boolean engine when it's installed,
        otherwise an approximate voxel method."""
        return _combine("union", args, "union")

    def difference(*args):
        """difference(base, *subtract) -> shape
        Subtracts every shape after the first from the first. Same
        argument types as union()."""
        if len(args) == 1:
            return _as_mesh(args[0], "difference() argument 1")
        return _combine("difference", args, "difference")

    def intersection(*args):
        """intersection(*shapes) -> shape
        Boolean intersection (the overlap) of two or more shapes. Same
        argument types as union()."""
        return _combine("intersection", args, "intersection")

    def hull(*args):
        """hull(*shapes) -> shape
        Convex hull enclosing all the given shapes. Same argument types
        as union()."""
        if len(args) == 0:
            raise PythonScriptError("hull() needs at least one shape argument")
        all_meshes = [_as_mesh(a, f"hull() argument {i+1}") for i, a in enumerate(args)]
        meshes = []
        for i, m in enumerate(all_meshes):
            if m.is_empty():
                warnings.append(f"hull() argument {i+1} came out empty (0 triangles) and was dropped")
            else:
                meshes.append(m)
        if not meshes:
            warnings.append("hull() had no non-empty shapes, returned nothing")
            return Mesh(np.zeros((0, 3)), np.zeros((0, 3), dtype=int))
        color = _first_color(meshes)
        pairs = [(m.V, m.F) for m in meshes]
        raw_operands = [m.raw_scad for m in meshes]
        V, F = csg.hull_op(pairs, notes=warnings, raw_operands=raw_operands)
        if len(V) == 0:
            warnings.append("hull() produced an empty result")
        # Same reasoning as _combine()'s combined_raw -- lets a further
        # boolean built on top of this hull() embed the whole nested tree
        # in one real-OpenSCAD call instead of round-tripping through
        # this step's reimported V/F first.
        combined_raw = f"hull(){{{''.join(raw_operands)}}}" if all(raw_operands) else None
        return Mesh(V, F, color=color, alpha=meshes[0].alpha, raw_scad=combined_raw)

    def import_mesh(path):
        """import_mesh(path) -> shape
        Loads an external STL/OBJ/OFF mesh file and returns it as a shape
        you can translate()/color()/union()/show() etc, same as whatever
        cube()/sphere()/cylinder() return -- this is Python mode's
        equivalent of OpenSCAD's import() (named import_mesh instead of
        import since that's a reserved word in Python). A bare filename
        is looked up in the imports/ folder next to this app; a full path
        is used as-is. For a 2D file (.svg), use import_profile() instead."""
        try:
            V, F = mesh_import.read_mesh_file(path)
        except (FileNotFoundError, ValueError, OSError) as e:
            raise PythonScriptError(str(e))
        return Mesh(V, F)

    def import_profile(path):
        """import_profile(path) -> 2D point list
        Loads an external 2D file (currently .svg) as a flat [[x,y], ...]
        profile -- the exact same shape circle()/square() return, so you
        can pass it straight into linear_extrude()/rotate_extrude(), e.g.
        show(linear_extrude(import_profile("logo.svg"), h=5)). If the SVG
        has more than one separate closed shape (e.g. a flower icon's
        petals), only the single largest one is used here -- see
        import_profiles() (plural) to get all of them. A bare filename is
        looked up in the imports/ folder next to this app; a full path is
        used as-is."""
        try:
            kind, data = mesh_import.read_import_file(path)
        except (FileNotFoundError, ValueError, OSError) as e:
            raise PythonScriptError(str(e))
        if kind != "profile":
            raise PythonScriptError(
                f"import_profile(): {path!r} is a 3D format -- use import_mesh() instead")
        return data

    def import_profiles(path):
        """import_profiles(path) -> list of 2D point lists
        Like import_profile(), but returns EVERY separate closed shape in
        the SVG instead of just the largest -- for artwork made of more
        than one piece (e.g. a flower icon's individual petals, each its
        own <path>/<ellipse>). Extrude each one and union() them into a
        single solid:
            profiles = import_profiles("flower.svg")
            show(union(*[linear_extrude(p, h=5) for p in profiles]))
        """
        try:
            kind, data = mesh_import.read_import_file_multi(path)
        except (FileNotFoundError, ValueError, OSError) as e:
            raise PythonScriptError(str(e))
        if kind != "profiles":
            raise PythonScriptError(
                f"import_profiles(): {path!r} is a 3D format -- use import_mesh() instead")
        return data

    def _attach_sol_labels(out, x):
        """If `x` (the value just passed to color()/show()) is a raw sol
        bound to a script variable, attach sol1[i][j]-style vertex labels
        to `out` (see _label_sol_vertices) for the viewer's vertex-
        measure tool. Shared by color() and show() since `show(color(a,
        "blue"))` is a common pattern -- color()'s own copy_with() call
        doesn't touch V/F, so labels attached here survive unchanged
        through to show()'s own copy_with() right after."""
        if looks_like_sol(x):
            name = _find_var_name(ns, x)
            if name:
                out.vertex_labels = _label_sol_vertices(x, out.V, name)

    def color(x, c=None, alpha=1.0):
        """color(shape, c=None, alpha=1.0) -> shape
        Returns a copy of `shape` tagged with a color and/or opacity for
        display -- doesn't change the geometry. `c` is a color name
        ("red", "blue", ...), a hex string ("#ff0000"), or an [r,g,b]
        list (0..1 each). Doesn't itself add anything to the scene --
        wrap the result in show() (or return it from a union()/etc that
        eventually gets shown)."""
        m = _as_mesh(x, "color() first argument")
        out = m.copy_with()
        rgb = _resolve_color_arg(c)
        if rgb is not None:
            out.color = rgb
        out.alpha = float(alpha)
        _attach_sol_labels(out, x)
        return out

    def _maybe_exact_reimport(m, what):
        """When real OpenSCAD is installed and `m` carries its own exact
        polyhedron(...) source (`raw_scad` -- set by _as_mesh() for any
        shape built via swp()/swp_c()/swp_surf()/swp_triangles()),
        reimport it through real OpenSCAD's CGAL/Manifold engine before
        adding it to the scene -- the same processing fo() already always
        applies, and that union()/difference()/hull() already apply once
        there are 2+ operands to combine. Without this, a single shape
        just built from swp()-style text and passed straight to show()
        displayed the raw, purely analytical polyhedron untouched, which
        can look visibly rougher/less clean than the exact same shape
        rendered via fo() -- confirmed directly on a closed-loop
        sweep_sec2path() torus, where the two ended up looking
        noticeably different even though both describe the same
        geometry.

        Deliberately does NOT attempt this for a plain raw sol (no
        `raw_scad` at all -- cube()/sphere()/a chain of other library
        calls) or for an already-combined Mesh (a union()/difference()
        result, whose `raw_scad` is cleared by copy_with() once real
        geometry replaces it): guessing which of swp()/swp_c()/swp_surf()
        an arbitrary sol "should" have been built with in order to
        reimport it is exactly the kind of wrong-convention guess that
        can silently produce a broken shape (capped when it shouldn't be,
        or vice versa) -- see parse_polyhedron_text()'s own docstring.
        Only a shape that already carries its own verbatim, unambiguous
        OpenSCAD source is eligible."""
        if not m.raw_scad or not openscad_cli.is_available():
            return m
        try:
            V, F = openscad_cli.render_scad_text(m.raw_scad, timeout=180, notes=warnings)
        except openscad_cli.OpenSCADCliError as e:
            warnings.append(
                f"{what}: couldn't reimport through real OpenSCAD for exact "
                f"tessellation, showing the raw (still geometrically valid) "
                f"result instead: {e}")
            return m
        if len(V) == 0:
            return m
        return m.copy_with(V=V, F=F)

    def _show_one(x, c, alpha, what="show() argument"):
        m = _as_mesh(x, what)
        m = _maybe_exact_reimport(m, what)
        if _is_degenerate(m):
            warnings.append("show() was called on an empty or degenerate shape (0 "
                             "triangles, or every point coincides) -- nothing "
                             "meaningful was added to the scene for this call")
        out = m.copy_with()
        rgb = _resolve_color_arg(c)
        if rgb is not None:
            out.color = rgb
        if alpha is not None:
            out.alpha = float(alpha)
        # Best-effort "which Python variable/index is this vertex" labels
        # for the viewer's vertex-measure tool -- only possible when `x`
        # is a raw sol straight out of cube()/sphere()/etc (not already a
        # Mesh from union()/etc, which has no such 1:1 correspondence)
        # and it's actually bound to a script variable. If `x` is itself
        # already a Mesh with labels (e.g. show(color(a, "blue"))), those
        # survive copy_with() unchanged and this is just a no-op.
        _attach_sol_labels(out, x)
        scene.append(out)
        shown_flag["any"] = True
        return x

    def show(*args):
        """show(shape, c=None, alpha=None) -> shape
        show(*shapes) -> None
        Adds one or more shapes to the viewer scene. This is what
        actually makes something appear -- everything else (union(),
        cube(), translate(), points(), ...) just builds/combines
        geometry. If a script has exactly one shape-like variable and
        never calls show(), that one is shown automatically.

        Called with a single shape (optionally followed by a color
        and/or alpha, exactly as always -- show(a), show(a, "blue"),
        show(a, "blue", .5)) this behaves exactly like before.

        Called with two or more actual shapes instead, EVERY one of
        them is added in this one call -- show(a, b, c) is the same as
        show(a); show(b); show(c), just without repeating show() for
        each object:

            l2 = cr2dt([[0,0],[10,0],[0,10],[-10,0]])
            show(
                color(points(l2, .5), "blue"),
                color(p_line3d(l2, .2), "magenta"),
            )

        Each shape in the multi-shape form uses whatever color it
        already carries (set with color(shape, "blue") beforehand, as
        above) or the default color if none was set -- there's no
        separate c=/alpha= override in this form, since it's not clear
        which of several shapes it would apply to; use color() on each
        shape individually instead.

        The multi-shape form returns None (unlike the single-shape
        form, which still returns the shape you passed in, same as
        always) -- deliberately, so a bare show(a, b, c) left as a
        script's last line doesn't get auto-displayed to the console
        (this app's Jupyter-style "bare expression -> shown in console"
        feature only skips None/a single shape, not a list of them; a
        multi-shape show() used to slip through that check and dump
        every shape's raw coordinates to the console instead of
        silently just adding them to the scene).

        The two forms are told apart by whether the 2nd argument is
        itself shape-like (a Mesh, or a raw sol straight out of
        cube()/sphere()/etc) -- a color name/hex string/[r,g,b] list is
        never shape-like, so show(a, "blue") is never mistaken for the
        multi-shape form, no matter how many shapes you go on to pass
        elsewhere in the script."""
        if len(args) == 0:
            raise PythonScriptError("show() needs at least one shape argument")
        multi = len(args) > 1 and any(_looks_like_shape(a) for a in args[1:])
        if not multi:
            x = args[0]
            c = args[1] if len(args) > 1 else None
            alpha = args[2] if len(args) > 2 else None
            return _show_one(x, c, alpha)
        for i, x in enumerate(args):
            _show_one(x, None, None, f"show() argument {i+1}")
        return None

    def echo(*args):
        """echo(*values) -> None
        Prints each value to this app's console panel (same idea as
        OpenSCAD's echo(), or a print() that shows up in the UI instead
        of the terminal)."""
        warnings_text = ", ".join(_fmt_echo(a) for a in args)
        echo_log.append("ECHO: " + warnings_text)

    def fo(txt='', fname='trial.scad'):
        """Your original fo() -- still writes the .scad file exactly as
        before (so your existing swp()/fo() -> real OpenSCAD workflow
        keeps working unchanged) -- but ALSO renders that file through
        real OpenSCAD right now and drops the result into this app's
        viewer, so you don't have to separately call show()/union() on
        the same shapes to see them here. This is what actually gets
        rendered when a script's only "output" call is fo(f'''...''') --
        previously that case fell through to a fragile guess at which
        leftover variable to auto-show, which could show the wrong thing
        (or the wrong *part* of a multi-shape scene) with no indication
        anything was off.

        Rendering the *file* (not just `txt`) matters: openscad4.fo()
        always appends a block of helper module/function definitions after
        `txt` -- p_line(), p_line3d(), p_line3dc(), points(), swp(),
        swp_c(), swp_surf(), cpo(), etc, as native OpenSCAD code -- and
        `txt` is free to call any of those (e.g. `p_line3dc(p, 0.3)` to
        sketch a closed 3D polyline). Rendering `txt` alone would hit
        "unknown module" for any of them.

        color() is handled specially: none of OpenSCAD's mesh export
        formats (including STL, which is what a single render_scad_text()
        call reads back) preserve color() at all -- it's a real OpenSCAD
        CLI limitation, not something specific to this app. So instead of
        one render, `txt` is split into its individual top-level statements
        and EACH ONE is rendered as its own separate OpenSCAD call (with
        the same trailing helper modules appended to each), producing one
        separately colored/faded/highlighted Mesh per statement -- the
        color()-splitting part is the same workaround used by third-party
        tools like colorscad/pycolorscad for OpenSCAD's own CLI-export
        color limitation; % and # are given a viewer-only approximation of
        their real-OpenSCAD-preview look (see _group_statements_by_color)
        -- including when nested inside a shared block, e.g. a #-marked
        subtrahend of a difference() (`difference(){ swp(a); #swp(b);
        }`) still gets subtracted normally *and* drawn as a separate
        highlight overlay so you can see what it cut away, the same
        idea as OpenSCAD's own debug/highlight preview (see
        _find_nested_modifiers).

        Statements are deliberately rendered one at a time, even when two
        of them happen to share the same color, rather than batched
        together into fewer OpenSCAD calls: real OpenSCAD's STL/CLI export
        always implicitly unions every top-level object in the file (this
        is what F6/Render does -- unlike F5/Preview, which just draws each
        object's raw geometry with no CGAL involved, so open/non-manifold
        surfaces show up fine there). That implicit union needs a valid
        CGAL Nef polyhedron, and silently drops any non-manifold operand
        caught up in it -- most commonly an open surface from swp_surf(),
        which is *supposed* to have no caps -- even though it exports
        perfectly fine completely on its own. Two statements merely
        sharing a color used to get batched into one call for that reason,
        which could make one of them vanish from the viewer for a reason
        that had nothing to do with color -- exactly the "visible in F5,
        gone in F6" symptom real OpenSCAD itself shows for the same
        geometry. One call per statement avoids that: each only goes
        through real CSG evaluation for whatever boolean ops it itself
        explicitly contains, never because it happened to share a file
        with something else.

        If `txt` builds its geometry with swp()/swp_c()/swp_surf()/
        swp_triangles() called on a script variable (e.g. `swp(sol1)`),
        the viewer's vertex-measure tool can label a picked vertex with
        exactly which point that came from (e.g. "sol1[0][10]") -- see
        _register_sol_labels/_labels_for_fo_mesh."""
        oscad.fo(txt, fname=fname)
        if not txt or not txt.strip():
            warnings.append("fo() was called with empty text -- wrote the file, but there's nothing to show in the viewer")
            return
        if not openscad_cli.is_available():
            warnings.append(
                "fo() wrote the .scad file, but OpenSCAD isn't installed/found so this "
                "app can't render it in the viewer too -- open the file in OpenSCAD "
                "directly, or install OpenSCAD so this app can show it here as well.")
            return
        try:
            with open(fname, "r", encoding="utf-8") as f:
                full_src = f.read()
        except OSError as e:
            warnings.append(f"fo() wrote the .scad file, but couldn't read it back to "
                             f"render in the viewer: {e}")
            return
        boilerplate = full_src[len(txt):]
        groups = _group_statements_by_color(txt)

        added = []
        for color, alpha, stmt_src in groups:
            try:
                V, F = openscad_cli.render_scad_text(stmt_src + boilerplate, timeout=180, notes=warnings)
            except openscad_cli.OpenSCADCliError as e:
                warnings.append(f"fo() wrote the .scad file, but OpenSCAD failed to render "
                                 f"{'the ' + str(color) + ' colored part' if color else 'part'} "
                                 f"of it for the viewer: {e}")
                continue
            if len(V) == 0:
                continue
            m = Mesh(V, F, color=color, alpha=alpha, vertex_labels=_labels_for_fo_mesh(V))
            scene.append(m)
            added.append(m)

        # %/# modifiers nested inside a shared block (e.g. a #-marked
        # subtrahend of a difference()) don't show up as anything special
        # in the group(s) rendered above -- they still fully (%) or
        # normally (#) participate in that boolean result exactly like
        # real OpenSCAD's own CLI export would, which is correct, but
        # real OpenSCAD's *preview* would also draw that marked child as
        # an extra highlighted/translucent overlay on top, which the
        # CLI/STL path can't carry -- so render each one found standalone
        # and add it to the scene as that same kind of extra overlay.
        for modifier, child_src in _find_nested_modifiers(txt):
            color = _HIGHLIGHT_COLOR if modifier == '#' else None
            alpha = _BACKGROUND_ALPHA if modifier == '%' else 1.0
            try:
                V, F = openscad_cli.render_scad_text(child_src + boilerplate, timeout=180, notes=warnings)
            except openscad_cli.OpenSCADCliError as e:
                kind = "highlighted (#)" if modifier == '#' else "background (%)"
                warnings.append(f"fo(): couldn't separately render the {kind} part for the "
                                 f"viewer's debug overlay: {e}")
                continue
            if len(V) == 0:
                continue
            m = Mesh(V, F, color=color, alpha=alpha, vertex_labels=_labels_for_fo_mesh(V))
            scene.append(m)
            added.append(m)

        if not added:
            warnings.append(
                "fo() wrote the .scad file, but OpenSCAD rendered it to an empty result "
                "(0 triangles) -- check the geometry/booleans in the text passed to fo() "
                "(e.g. do the operands actually overlap for a difference()/intersection()?)")
            return None
        shown_flag["any"] = True
        return added[0] if len(added) == 1 else None

    def resize(x, newsize):
        """Rescale x's bounding box to `newsize` = [w,h,d] (a 0 in any
        axis means 'leave that axis alone'), same semantics as OpenSCAD's
        resize(). Works on any shape, including the result of a
        union()/difference()/etc, not just a single primitive."""
        m = _as_mesh(x, "resize() first argument")
        out = m.copy_with()
        if out.is_empty():
            warnings.append("resize() was called on an empty (0-triangle) shape, nothing to resize")
            return out
        nx, ny, nz = (list(newsize) + [0, 0, 0])[:3]
        lo = out.V.min(axis=0)
        hi = out.V.max(axis=0)
        dims = np.maximum(hi - lo, 1e-9)
        factors = np.array([
            nx / dims[0] if nx else 1.0,
            ny / dims[1] if ny else 1.0,
            nz / dims[2] if nz else 1.0,
        ])
        center = (lo + hi) / 2.0
        out.V = (out.V - center) * factors + center
        # out.V just changed but was set directly (not via copy_with(V=...)),
        # so raw_scad -- the original swp()/swp_c()/etc text, if any -- and
        # vertex_labels -- the sol1[i][j]-style labels, if any -- are now
        # both stale (still describe the pre-resize positions/shape) and
        # must not be trusted anymore.
        out.raw_scad = None
        out.vertex_labels = None
        return out

    ns.update({
        "union": union,
        "difference": difference,
        "intersection": intersection,
        "hull": hull,
        "color": color,
        "resize": resize,
        "show": show,
        "echo": echo,
        "fo": fo,
        "import_mesh": import_mesh,
        "import_profile": import_profile,
        "import_profiles": import_profiles,
        "points": points,
        "p_line3d": p_line3d,
    })
    return ns, shown_flag


def _fmt_echo(v):
    if isinstance(v, float):
        return f"{v:g}"
    if looks_like_sol(v) or isinstance(v, Mesh):
        return "<shape>"
    return str(v)


def _wrap_toplevel_bare_expressions(tree):
    """Jupyter-notebook-style "just type it to inspect it": rewrite every
    top-level bare expression statement in `tree` (e.g. `len(a)`, `a.shape`,
    `type(a)`) into a call to `__display__(...)` so its value gets echoed
    to this app's console, the same way a Jupyter cell auto-displays a
    bare expression's value -- without needing to wrap it in echo()/
    print() yourself. Only *top-level* statements are rewritten (matching
    Jupyter, which only does this for a cell's own top-level lines, not
    ones nested inside a function/for/if you define in the script) --
    everything else in the tree is left untouched, including assignments
    (`a = len(x)` stays a plain assignment, nothing displayed for it).

    A bare string-literal statement (a triple-quoted note left on its own
    line -- a common way to leave a comment in a cell) is left alone
    rather than echoed, since that's almost always meant as a comment,
    not a value someone wants to see printed.

    __display__ itself (defined in run_python_script) additionally
    suppresses None (matching Jupyter, which never shows `Out: None`) and
    shape objects (a Mesh, or a raw sol straight out of cube()/sphere()/
    etc) -- so a bare top-level `show(x)`/`color(x)`/`union(a, b)` call
    (all of which return a shape, not None) doesn't spam "<shape>" into
    the console on every single script that uses the normal show()-based
    workflow; this is purely for inspecting plain values like numbers,
    strings, lists, lengths, etc."""
    for i, node in enumerate(tree.body):
        if not isinstance(node, ast.Expr):
            continue
        if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            continue  # bare string statement -- treat as a comment, not a value to show
        new_node = ast.Expr(value=ast.Call(
            func=ast.Name(id="__display__", ctx=ast.Load()),
            args=[node.value], keywords=[]))
        ast.copy_location(new_node, node)
        ast.copy_location(new_node.value, node)
        ast.fix_missing_locations(new_node)
        tree.body[i] = new_node
    return tree


def run_python_script(code, csg_resolution=56, persist=True):
    """Always returns (result_dict, meshes_or_None), same contract as
    server.run_script() for the OpenSCAD-style mode, so both modes share
    the rest of the HTTP/response plumbing.

    persist=True (the default) gives the script a Jupyter-style kernel:
    variables from the last run that assigned them are merged back in
    before this run starts, so a heavy computation whose line has since
    been commented out doesn't need to re-run -- its result is still
    sitting in the namespace. Whatever the script's own top-level names
    are after this run (added, changed, or just carried over untouched)
    become the new persisted set, win or lose (a script that errors
    partway through still keeps whatever it assigned before the error,
    same as a Jupyter cell would). Pass persist=False for a one-off run
    that shouldn't read from or write to that shared memory."""
    result = {"meshes": [], "warnings": [], "echo": [], "error": None, "error_line": None}
    scene = []
    warnings = []
    echo_log = []
    ns, shown_flag = make_namespace(csg_resolution, scene, warnings, echo_log)
    lib_snapshot = dict(ns)  # fresh library/helper baseline -- before persisted vars or exec
    if persist:
        with _PERSIST_LOCK:
            ns.update(_PERSISTENT_USER_NS)

    def __display__(v):
        if v is None or _looks_like_shape(v):
            return
        echo_log.append(_fmt_echo(v))
    ns["__display__"] = __display__

    stdout_buf = io.StringIO()
    try:
        tree = _wrap_toplevel_bare_expressions(ast.parse(code, "<script>", "exec"))
        compiled = compile(tree, "<script>", "exec")
        with contextlib.redirect_stdout(stdout_buf):
            exec(compiled, ns)
    except PythonScriptError as e:
        result["error"] = str(e)
        result["error_line"] = e.line if e.line is not None else _extract_user_line(e)
        result["persisted_vars"] = sorted(_save_persisted_vars(ns, lib_snapshot)) if persist else []
        return result, None
    except SyntaxError as e:
        result["error"] = f"{e.msg} (line {e.lineno})"
        result["error_line"] = e.lineno
        result["persisted_vars"] = persisted_variable_names() if persist else []
        return result, None
    except Exception as e:
        line = _extract_user_line(e)
        result["error"] = "".join(traceback.format_exception_only(type(e), e)).strip()
        result["error_line"] = line
        result["persisted_vars"] = sorted(_save_persisted_vars(ns, lib_snapshot)) if persist else []
        traceback.print_exc()
        return result, None

    printed = stdout_buf.getvalue()
    if printed.strip():
        echo_log.extend(line for line in printed.splitlines() if line.strip())

    if not shown_flag["any"]:
        candidates = [
            (name, val) for name, val in ns.items()
            if name not in RESERVED_NAMES and not name.startswith("_")
            and (isinstance(val, Mesh) or looks_like_sol(val))
        ]
        if len(candidates) == 1:
            name, val = candidates[0]
            if isinstance(val, Mesh):
                m = val
            else:
                V, F = sol_to_mesh(oscad, val)
                m = Mesh(V, F, vertex_labels=_label_sol_vertices(val, V, name))
            scene.append(m)
            warnings.append(
                f"show() was never called -- auto-showing the only shape-like "
                f"variable '{name}'. Call show({name}) explicitly to silence this.")
        elif len(candidates) > 1:
            warnings.append(
                "show() was never called, and there's more than one shape-like "
                "variable (" + ", ".join(n for n, _ in candidates) + ") so nothing "
                "was rendered -- call show(x) on whichever one(s) you want to see.")
        else:
            warnings.append("show() was never called and no shapes were found -- "
                             "call show(x) on the shape(s) you want to render.")

    result["warnings"] = warnings
    result["echo"] = echo_log
    result["persisted_vars"] = sorted(_save_persisted_vars(ns, lib_snapshot)) if persist else []
    for m in scene:
        if m.is_empty():
            continue
        result["meshes"].append({
            "vertices": np.round(m.V, 5).tolist(),
            "faces": m.F.tolist(),
            "color": list(m.color) if m.color else list(DEFAULT_COLOR),
            "alpha": m.alpha,
            "vertex_labels": m.vertex_labels,
        })
    return result, scene


def _extract_user_line(exc):
    tb = exc.__traceback__
    line = None
    while tb is not None:
        if tb.tb_frame.f_code.co_filename == "<script>":
            line = tb.tb_lineno
        tb = tb.tb_next
    return line
