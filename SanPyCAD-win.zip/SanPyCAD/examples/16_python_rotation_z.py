# Rotation about the z-axis
# From the "Basics of Drawing and 3D Modeling" tutorial (Python mode, SanPyCAD)

l1=sinewave(100,2,10,100)
l2=rot('z90',l1) # l1 rotated by 90 deg along z-axis
fo(f'''
// original line 'l1'
color("blue") p_line3d({l1},1);
//rotated line
color("magenta") p_line3d({l2},1);

''')
