# Fillet (tangent arc) between two circles
# From the "Basics of Drawing and 3D Modeling" tutorial (Python mode, SanPyCAD)

# fillet between 2 circles
c1=circle(20)
c2=circle(15,[25,25])
f1=two_cir_tarc(c2,c1,r=10)
f2=two_cir_tarc(c1,c2,r=10)
fo(f'''
color("blue") p_line3dc({c1},.3);
color("cyan") p_line3dc({c2},.3);
color("magenta") p_line3d({f1},.3);
color("brown") p_line3d({f2},.3);
''')
