# Points
# From the "Basics of Drawing and 3D Modeling" tutorial (Python mode, SanPyCAD)

p0=[10,0,0]
fo(f'''
// pay attention to the points module here. Points are shown as cube
// In this example cube of size 0.5 is showing the location of the p0
color("blue") points({[p0]},.5);
''')
