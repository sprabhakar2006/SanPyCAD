# Lines
# From the "Basics of Drawing and 3D Modeling" tutorial (Python mode, SanPyCAD)

l1=[[10,0,0],[10,0,10]]
fo(f'''
color("blue") points({l1},.5);

// p_line3d module is used for showing lines or polylines 
// in this example line "l1" of diameter 0.2 mm is shown

color("magenta") p_line3d({l1},.2);
''')
