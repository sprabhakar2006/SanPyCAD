# Wrap a surface around a path
# From the "Basics of Drawing and 3D Modeling" tutorial (Python mode, SanPyCAD)

c1=translate_2d([0,20.1],circle(20))
s1=h_lines_sec(c1,100)
path=rot('y90',circle(40.2/(2*pi)+.2))
c2=wrap_around(c1,path)
s2=[wrap_around(p,path) for p in s1]
fo(f'''
color("blue") p_line3d({c1},.2);
color("cyan") p_line3d({path},.2);
color("magenta") p_line3d({c2},.2);

color("blue") for(p={s1}) p_line3d(p,.1,1);
color("magenta") for(p={s2}) p_line3d(p,.1,1);
''')
