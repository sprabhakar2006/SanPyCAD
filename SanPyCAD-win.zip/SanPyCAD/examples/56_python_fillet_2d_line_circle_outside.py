# Fillet between a line and a circle (outside)
# From the "Basics of Drawing and 3D Modeling" tutorial (Python mode, SanPyCAD)

# fillet between line and circle (outside)
h=12
line=[[-10,h],[30,h]]
cir1=circle(10,[10,10])
r2=5
s=20
fillet1=fillet_line_circle(line,cir1,r2,1)
fillet2=fillet_line_circle(line,cir1,r2,2)
fillet3=fillet_line_circle(line,cir1,r2,3)
fillet4=fillet_line_circle(line,cir1,r2,4)
fo(f'''
color("blue",.1)p_line3dc({line},.3);
color("violet",.2)p_line3dc({cir1},.3);
color("cyan")p_line3d({fillet1},.3);
color("blue")p_line3d({fillet2},.3);
color("magenta")p_line3d({fillet3},.3);
color("green")p_line3d({fillet4},.3);
''')
