# Offset of a 2D section
# From the "Basics of Drawing and 3D Modeling" tutorial (Python mode, SanPyCAD)

sec=square(10)
sec1=offset(sec,-3)
sec2=offset(sec,3)
fo(f'''
//original square
color("blue") p_line3dc({sec},.2);
// offset inwards by 3mm
color("magenta") p_line3dc({sec1},.2);
// offset outwards 3mm
color("cyan") p_line3dc({sec2},.2);

''')
