# Business card holder
# Real project from the openscad4 examples notebook.
# A compact example: a rounded-rectangle tray wall built by extruding the
# difference of an outer and inner offset() profile, plus a slanted back
# support prism(), combined with render() to force full CSG evaluation.

sec=corner_radius(pts1([[0,0,1],[95,0,1],[0,10,1],[-95,0,1]]),10)

sol2=linear_extrude(offset(sec,1),1)

sec1=corner_radius(pts1([[10,0,5],[50,0,5],[10,30],[-70,0]]),10)

sol3=translate([12.5,2,21],rot("x90",linear_extrude(sec1,5)))

fo(f'''

render(){{
difference(){{
linear_extrude(50)
difference(){{
polygon({offset(sec,1)});
polygon({sec});
}}

{swp(sol3)}
}}
{swp(sol2)}
}}
''')
