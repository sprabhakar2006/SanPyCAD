# Offset of a path / polyline
# From the "Basics of Drawing and 3D Modeling" tutorial (Python mode, SanPyCAD)

s1=square(10)
s2=path_offset(s1,-3)
s3=path_offset(s1,3)

fo(f'''
//original polyline
color("blue") p_line3d({s1},.2);
// offset inwards by 3mm
color("magenta") p_line3d({s2},.2);
// offset outwards 3mm
color("cyan") p_line3d({s3},.2);

''')
