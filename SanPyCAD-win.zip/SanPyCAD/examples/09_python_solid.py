# Solid
# From the "Basics of Drawing and 3D Modeling" tutorial (Python mode, SanPyCAD)

l2=cr2dt([[0,0],[10,0],[0,10],[-10,0]])
s1=linear_extrude(l2,10)
fo(f'''
color("blue") for(p={s1}) points(p,.5);
color("magenta")for(p={s1}) p_line3dc(p,.2);
{swp(s1)}

''')
