# Intersection between a polyline (circle) and a line
# From the "Basics of Drawing and 3D Modeling" tutorial (Python mode, SanPyCAD)

c1=circle(20)
l1=point_vector([-20,-20],[50,20])
p0=s_int1([l1]+seg(c1))
fo(f'''
color("blue") for(p={[l1,c1]}) p_line3d(p,.2);
color("magenta") points({p0},.5);

''')
