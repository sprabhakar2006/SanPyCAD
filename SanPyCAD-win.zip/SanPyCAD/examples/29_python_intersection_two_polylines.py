# Intersection between two polylines (circles)
# From the "Basics of Drawing and 3D Modeling" tutorial (Python mode, SanPyCAD)

c1=circle(10)
c2=circle(15,[10,10])
p0=s_int1(seg(c1)+seg(c2))
fo(f'''
color("blue") for(p={[c1,c2]}) p_line3d(p,.2);
color("magenta")points({p0},.5);
''')
