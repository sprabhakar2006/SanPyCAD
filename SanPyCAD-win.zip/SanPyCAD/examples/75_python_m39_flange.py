# M39 flange / hub profile
# Real project from the openscad4 examples notebook.
# Builds an outer and inner 2D profile from circles + tangent lines using
# cir_line_tangent(), fillet_intersection_lines(), path_offset() and
# fillet_line_circle(), then trims the two chains together with
# trim_sec_ip() before extruding into a flanged hub with bolt bosses.

c1=circle(10,[-35,0])
c2=circle(10,[35,0])
c3=circle(10,[0,44.06])
l1=rot2d(16.5,[[0,0],[10,0]])
l2=rot2d(-16.5+180,[[0,0],[10,0]])
l1=cir_line_tangent(c1,l1)
l2=cir_line_tangent(c2,l2,1)
f1=fillet_intersection_lines(l1,l2,30)
l3=cir_line_tangent(c2,[[0,0],[0,10]])
p0=[45,35]
p1=p_cir_t(p0,c3)
l4=[p0,p1]
f2=fillet_intersection_lines(l3,l4,10)
p3=[-45,35]
p2=cir_p_t(c3,p3)
l5=[p2,p3]
l6=cir_line_tangent(c1,[[0,0],[0,10]],1)
f3=fillet_intersection_lines(l5,l6,10)
l1o=path_offset(l1,-2.5)
l2o=path_offset(l2,2.5)
l3o=path_offset(l3,-2.5)
l4o=path_offset(l4,-2.5)
l5o=path_offset(l5,-2.5)
l6o=path_offset(l6,2.5)
f4=fillet_line_circle(l1o,c1,2.5)
f5=fillet_intersection_lines(l1o,l2o,32.5)
f6=fillet_line_circle(l2o,c2,2.5,2)
f7=fillet_line_circle(l3o,c2,2.5)
f8=fillet_intersection_lines(l3o,l4o,7.5)
f9=fillet_line_circle(l4o,c3,2.5,3)
f10=fillet_line_circle(l5o,c3,2.5)
f11=fillet_intersection_lines(l5o,l6o,7.5)
f12=fillet_line_circle(l6o,c1,2.5,2)

sec_outer=trim_sec_ip(c1,l6[0],l1[0])+f1+trim_sec_ip(c2,l2[0],l3[0])+f2 \
+trim_sec_ip(c3,l4[-1],l5[0])+f3

sec_inner=flip(f12)+trim_sec_ip(flip(c1),f12[0],f4[0],1)+f4+f5+flip(f6)+ \
trim_sec_ip(flip(c2),f6[0],f7[0],1)+f7+f8+flip(f9)+trim_sec_ip(flip(c3),f9[0],f10[0],1) \
+f10+f11
sec_inner=remove_duplicates(sec_inner)

sol1=linear_extrude(sec_outer,15)
path1=cr2dt([[-1.25,2.5],[1.25,0,1.25],[0,12.5,1.25],[1.25,0],[0,.1]],10)
sol2=f_prism(sec_inner,path1)
e1=end_cap(sol1,1.25)
sol3=linear_extrude(offset(c1,-2.5),15)
sol4=linear_extrude(offset(c2,-2.5),15)
sol5=linear_extrude(offset(c3,-2.5),15)
e2=end_cap_1(sol3,.5,s=2)
e3=end_cap_1(sol4,.5,s=2)
e4=end_cap_1(sol5,.5,s=2)

fo(f'''
difference(){{
{swp(sol1)}
{swp(sol2)}
for(p={e1})swp_c(p);
{swp(sol3)}
{swp(sol4)}
{swp(sol5)}
for(p={e2})swp(p);
for(p={e3})swp(p);
for(p={e4})swp(p);
}}

''')
