@echo off
rem run_sanpycad.bat -- alternate Windows launcher for SanPyCAD.
rem
rem Double-click SanPyCAD.vbs instead for the normal experience (no
rem console window, error alerts instead of a raw traceback). This .bat
rem file is a simpler backup for two cases: (1) some locked-down/
rem corporate Windows machines block .vbs files from running at all
rem (VBScript has a long history of being abused by malware, so this is
rem a common security policy), and (2) you'd rather see the console
rem output live (e.g. while troubleshooting) instead of just a log file.
rem It does the same thing SanPyCAD.vbs does -- just with a visible
rem console window, and without the pre-flight numpy/scipy/sympy/
rem scikit-image check (if a package is missing, Python's own error
rem shows directly in this window).

setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 app.py
  goto :done
)

where python >nul 2>nul
if %errorlevel%==0 (
  python app.py
  goto :done
)

where python3 >nul 2>nul
if %errorlevel%==0 (
  python3 app.py
  goto :done
)

echo Could not find Python 3 on PATH.
echo Install it from https://www.python.org/downloads/
echo (check "Add python.exe to PATH" during setup), then re-run this file.
pause
exit /b 1

:done
if errorlevel 1 (
  echo.
  echo SanPyCAD exited with an error -- see the messages above.
  echo If a package is missing, try: pip install numpy scipy sympy scikit-image pywebview
  pause
)
