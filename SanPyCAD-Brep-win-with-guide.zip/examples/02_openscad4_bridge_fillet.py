# 41_ocad_bridge_fillet.py -- the opt-in `import ocad` escape
# hatch, bridged into loft_fillet() to build a real B-rep fillet SOLID
# on a case with genuinely curved surfaces (a cylinder against an
# angled plane -- not the flat/analytic post-on-a-plate case example
# 40 solves by hand with plain trig).
#
# Pipeline: tessellate both real B-rep solids (to_triangles()), find
# their real intersection curve by triangle-triangle intersection in
# the ocad mesh environment, stitch the raw segments into one
# ordered loop (the spine), then walk that spine OUTWARD along each
# surface's own triangulation by a fixed blend distance (o_3d_tri()) to
# get the other two lines a fillet needs -- all real ocad.py
# calls, not brep.py ports. The 3 lines then go into loft_fillet() to
# build one real, closed, watertight B-rep solid.

import ocad as o4   # opt-in mesh/point-list toolkit -- see
                          # python_eval.py's module docstring

a = cylinder(r=10, h=40)
b = plane([0.4, 0, 1], [50, 50], [0, 0, 15])
show(a)
show(b)

# spine: the real intersection curve between the cylinder and the
# angled plane (an ellipse), found by mesh triangle-triangle
# intersection and stitched into one ordered closed loop.
l1 = o4.contiguous_chains(o4.two_tri_intersection(to_triangles(a), to_triangles(b)))[0]

# line_a/line_b: the spine walked 3 units out across each surface's
# OWN triangulation (surface b one way, surface a the other) -- this
# is the mesh-side equivalent of the offset_face()+intersection()
# recipe from example 40's docstring, done directly on the real
# triangulated surfaces instead of re-deriving another B-rep
# intersection for each blend line.
l2 = o4.o_3d_tri(l1, to_triangles(b), 3)
l3 = o4.o_3d_tri(l1, to_triangles(a), -3)

# loft through all 3 lines to build a real closed solid fillet ring
# (loft_fillet(), not convert_3lines2fillet()+surface_from_points_grid()
# -- that pair builds an open NURBS patch instead; see example 40).
f1 = loft_fillet(l2, l3, l1, closed_loop=1)

show(color(f1, "orange"))
