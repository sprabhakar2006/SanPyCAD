# 07_flanged_bracket_assembly.py -- 3-part bracket: hulled+drilled main
# flange (now built via the opt-in ocad bridge's own
# convex_hull()/equidistant_pathc() point-list pipeline -- hull the 3
# circles' point lists directly, close the resulting outline into a
# wire with cap_wire(), then linear_extrude() that -- rather than the
# old build123d hull() of 3 already-extruded cylinders), a 4-hole end
# cap (radial rot() array of cut cylinders), and a bent arm swept along
# a cr3dt() path between them -- unioned into one part and fillet()'d
# along the edges picked with the app's own Pick tool (captured as the
# e1 "# <- probe ... tool" comment below), rather than the old
# GeomType.CIRCLE/Axis.Z/Axis.X face-filter selectors.

import ocad as o
c1 = o.circle(17.5)
c2 = o.circle(7.5, [14.5, 0])
c3 = o.circle(7.5, [-14.5, 0])
c1 = cap_wire(o.equidistant_pathc( o.convex_hull(c1+c2+c3),pitch=1))
c4 = linear_extrude(cap_wire(o.circle(6.5)), 5.5)
c5 = linear_extrude(cap_wire(o.circle(3, [14.5, 0])), 5.5)
c6 = linear_extrude(cap_wire(o.circle(3, [-14.5, 0])), 5.5)
s1 = linear_extrude(c1,5.5)
s2 = difference(s1, c4, c5, c6)
c7 = linear_extrude(cap_wire(o.circle(19.5)), 4)
c8 = linear_extrude(cap_wire(o.circle(2.5, [15, 0])), 4)
c8 = [rot(f'z{i}', c8) for i in [0, 90, 180, 270]]
c9 = linear_extrude(cap_wire(o.circle(6.5)), 4)
s3 = difference(c7, c8, c9)
s3 = translate([-44 + 4, 0, 29], rot('y-90', s3))
path = cr3dt([[0, 0, -0.01], [0, 0, 29, 17.5], [-44, 0, 0]], 10)
s4 = sweep_sec2path(cap_wire(o.circle(10)), path)
s5 = sweep_sec2path(cap_wire(o.circle(6.5)), path)
s6 = difference(s4, s5)
s7 = union(s2, s3, s6)
e1 = [s7.edges()[i] for i in [2, 157, 158, 159, 161, 160, 149, 188, 186, 187, 7, 8, 6, 17]]  # <- probe list tool: e1
s7 = fillet(s7, e1, 0.5)  # <- probe fillet tool: e1
show(s7)
