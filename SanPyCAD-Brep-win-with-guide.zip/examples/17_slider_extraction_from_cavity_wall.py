# 17_slider_extraction_from_cavity_wall.py -- extracting a mold SLIDER
# tool body from a filleted sphere/cube cavity (the same corner-notch
# part built in 08_filleted_cube_sphere_cut.py): sews the cavity's flat
# wall + surrounding fillet blends into one Shell (shell_from_faces()),
# pulls its own outer rim edges into an ordered point list, projects
# that rim onto a flat reference plane along the slider's pull
# direction, sweeps the projected rim into a two-row ruled "surface"
# (ocad.py's own surface_line_vector() bridge), lofts that into an
# oversized straight block, then trims it back down to the exact
# slider shape with split() against the real cavity wall.
#
# TWO gotchas found getting this to work cleanly, both worth knowing
# for any similar "extract a tool body along a picked boundary" script:
#
# 1. Building each lofted cross-section with cap_wire(mixed_wire(p)) --
#    wrapping the raw sampled points in mixed_wire() first -- looks
#    reasonable but produces visible facet/crease lines across the
#    finished slider. mixed_wire() ALWAYS connects consecutive raw
#    points with straight lines (that's its whole job when fed real
#    Edges, to preserve them exactly); fed a long run of plain sampled
#    points instead, that turns a smooth curve into a many-sided
#    straight-edge polygon, and the faces built from it inherit that
#    faceting. cap_wire() already handles raw points correctly on its
#    own -- given a plain point list (not pre-wrapped in mixed_wire()),
#    it automatically fits ONE smooth periodic interp_spline() through
#    them instead. So: cap_wire(p) directly, NOT cap_wire(mixed_wire(p)),
#    whenever `p` is raw sampled points rather than a deliberate mix of
#    straight runs and real Edges.
#
# 2. split(s1, wall, 'top') came back completely empty (0 solids), and
#    'both' came back as a single un-split solid (len(s1.solids()) ==
#    1) -- wall wasn't dividing s1 at all. Cause: s1's own cross-
#    section (l1p) was built directly from wall's own rim, so the
#    prism's outer boundary sat exactly flush/coincident with wall's
#    edge at the rim instead of having any real clearance -- a cutting
#    surface whose own edge is coincident with the target's boundary,
#    rather than genuinely crossing through its interior, is a
#    degenerate/tangential case split() can't cleanly bisect. Fix:
#    shrink the projected rim slightly (a tiny NEGATIVE/inner
#    offset -- ocad.py's own offset_3d(), -0.01 here) before
#    sweeping it into the prism, so wall ends up with genuine
#    clearance just inside the prism's own boundary and split() gets a
#    real interior crossing instead of a tangent touch.

import ocad as o

a = cube(10)
b = sphere(10)
c = difference(b, a)
e1 = [c.edges()[i] for i in [4, 5, 6]]  # <- probe list tool: e1
c = fillet(c, e1, 1)  # <- probe fillet tool: e1
e2 = [c.edges()[i] for i in [0, 2, 3, 6, 7, 15]]  # <- probe list tool: e2
c = fillet(c, e2, 1)  # <- probe fillet tool: e2
f1 = [c.faces()[i] for i in [11, 12, 9, 8, 10, 13, 14, 2, 3, 5, 7, 6, 1, 4]]  # <- probe list tool: f1
wall = shell_from_faces(f1)
e3 = [wall.edges()[i] for i in [17, 28, 29, 25, 23, 21, 19]]  # <- probe list tool: e3
l1 = sample_curve(mixed_wire(e3), 50)
n1 = o.rot('y-45z45', [20, 0, 0])
pl1 = o.plane(n1, [20, 20], np.array(l1).mean(0))
l1p = o.offset_3d(o.nlos(pl1, l1), -0.01)  # tiny inner offset -- see gotcha 2 above
s1 = o.surface_line_vector(l1p, n1, 1)
s1 = loft([cap_wire(p) for p in s1])  # NOT cap_wire(mixed_wire(p)) -- see gotcha 1 above
s1 = split(s1, wall, 'top')
# show(wall)
show(s1)
export_step(s1, 'extracting_slider.step')
