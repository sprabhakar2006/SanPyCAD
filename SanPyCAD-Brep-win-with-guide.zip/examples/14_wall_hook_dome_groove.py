# 14_wall_hook_dome_groove.py -- a wall hook: a hemisphere (sphere()
# split() 'top' across z=0) with a fillet_line_circle()-shaped
# wall-mount tab (built via the opt-in ocad bridge) extruded and
# subtracted out of it, the resulting rim edge rounded (radius 10,
# edge index captured with the app's own Pick tool), then a groove cut
# across the dome using a profile DERIVED FROM THE ACTUAL CUT BOUNDARY
# rather than an independently-drawn cross-section.
#
# CHANGED FROM THE EARLIER VERSION OF THIS EXAMPLE in two ways:
#
# 1. The tab's own silhouette (the curve later extruded into `s1`) is
#    now built as [interp_spline(...the curve...), corner, corner] via
#    mixed_wire(), instead of resampling the whole boundary (curve +
#    2 straight side points together) with equidistant_pathc() and
#    capping that directly. Same gotcha as 18_flat_rounded_plate.py:
#    feeding a curve's own raw (already fairly dense, but still
#    straight-segmented) points straight into a polygon-style capping
#    call turns the "smooth" curve into a many-sided faceted polygon,
#    which shows up as visible crease lines down the extruded tab.
#    interp_spline()-ing just the curved stretch first, then handing
#    it to mixed_wire() alongside the 2 plain corner points, keeps the
#    curve genuinely smooth while the 2 straight sides of the tab stay
#    genuinely straight.
#
# 2. The groove path is no longer an independent bspline_closed()
#    cross-section lofted between 2 slightly z-offset copies -- it's
#    now traced directly off the dome: e2 (4 edges around the tab-cut
#    opening, picked with the probe list tool) is chained into one
#    Wire and sampled with sample_curve(), then re-anchored to a known
#    start point (closed_loop_st_pnt()), cut down to just the side
#    facing away from the tab (remove_line_beyond_plane()) and
#    re-expressed as a flat XZ profile (xzc()) before being offset
#    inward (path_offset3d()) to give the groove some wall thickness,
#    trimmed to height (remove_line_beyond_plane() again), extended
#    with 2 more points and rounded off at the corners
#    (corner_n_radius_list_3d()), then swept into a cutting surface
#    (surface_line_vector()) and split() out of the dome. Because the
#    groove profile is traced from the real cut boundary instead of a
#    hand-drawn shape, it naturally follows the tab opening's own
#    contour instead of needing to be eyeballed into alignment with
#    it.
#
# NOTE on e2's edge order ([3, 1, 0, 2], not sorted): mixed_wire()
# walks its `pieces` in the exact order given and only bridges gaps
# with straight lines -- it assumes the list is already a genuine walk
# around the loop. Edges picked one at a time with the probe tool come
# out in CLICK order, which has no guaranteed relationship to that, so
# getting mixed_wire(e2) to chain into one closed loop here took
# finding the order (and, implicitly, orientation) that actually
# walks the opening. wire_from_edges() (also in this app) sidesteps
# that entirely by stitching an UNORDERED bag of edges via
# build123d's own Wire.combine() instead -- swap to
# wire_from_edges(e2) here if the edge order ever needs to change
# (e.g. after editing the tab shape) and re-chaining mixed_wire()
# by hand gets tedious.
#
# Finishing: split() 'both' across z=4.2 to fillet a few groove-rim
# edges on the upper half only (radius 1.5, the lower half's own
# groove edges got their radius-1.5 pass earlier in one shot), then
# union() the two halves back together and apply the same non-uniform
# scale() correction as before. Unlike the earlier version, this one
# does export_step() at the end.

import ocad as o
c1 = o.circle(3, [-4, 0])
l1 = [[15, -20], [15, 20]]
a1 = o.fillet_line_circle(l1, c1, 20, 3)
a2 = o.fillet_line_circle(l1, c1, 20, 1)
s1 = o.flip(a1) + o.trim_sec_ip(o.flip(c1), a1[0], a2[0]) + a2
s1 = interp_spline(o.equidistant_path(s1, pitch=2))
s1 = linear_extrude(cap_wire(mixed_wire([s1, [-30, 23], [-30, -23]])), -22)
s1 = translate([0, 0, 4], s1)
s2 = sphere(20)
pl1 = surface_from_points_grid(o.plane_from_equation([0, 0, 1, 0], [50, 50]))
s2 = split(s2, pl1, 'top')
s3 = difference(s2, s1)
e1 = [s3.edges()[i] for i in [4]]  # <- probe list tool: e1
s3 = fillet(s3, e1, 10)  # <- probe fillet tool: e1
e2 = [s3.edges()[i] for i in [3, 1, 0, 2]]  # <- probe list tool: e2
l2 = sample_curve(mixed_wire(e2), 150)
l2 = o.closed_loop_st_pnt(l2, [-20, 0, 4])
l2 = o.xzc(o.remove_line_beyond_plane(l2, [0, -1, 0, 0]))
l3 = o.path_offset3d(l2, -3)
l3 = o.remove_line_beyond_plane(l3, [0, 0, 1, 10])
l4 = [[-30, 0, 4.1], [8, 0, 4.1]]
l4 = l4 + l3
l4 = o.corner_n_radius_list_3d(l4, [0, 5] + np.zeros(len(l3)).tolist()) + [[-30, 0, 16]]
s4 = surface_line_vector(interp_spline(o.equidistant_path(l4, pitch=2)), [0, -20, 0], 1)
# show(p_line3d(l4),'blue')
# show(s4)
s3 = split(s3, s4, 'top')
e3 = [s3.edges()[i] for i in [2, 3, 0, 1]]  # <- probe list tool: e3
s3 = fillet(s3, e3, 1.5)  # <- probe fillet tool: e3
s3a, s3b = split(s3, surface_from_points_grid(o.plane_from_equation([0, 0, 1, 4.2])), 'both')
e4 = [s3a.edges()[i] for i in [20, 17, 19]]  # <- probe list tool: e4
s3a = fillet(s3a, e4, 1.5)  # <- probe fillet tool: e4
s3 = union(s3a, s3b)
s3 = scale([1, 30 / 40, 17 / 20], s3)
show(s3)
export_step(s3, 'wall_hook.step')
