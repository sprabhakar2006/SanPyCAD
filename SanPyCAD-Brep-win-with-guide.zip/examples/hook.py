a=sphere(20)
pl1=plane_from_equation([0,0,1,4],[50,50])
l2=sec1_3d
b=solid_line_vector(l2,[0,0,20])
r1=difference(a,b)
e1 = [r1.edges()[i] for i in [3]]  # <- probe list tool: e1
r1 = fillet(r1, e1, 7)  # <- probe fillet tool: e1
e2 = [r1.edges()[i] for i in [0, 1, 3, 2]]  # <- probe list tool: e2
e2=wire_from_edges(e2)
e2=sample_curve(e2,100)
e2=remove_line_beyond_plane(e2,[0,1,0,0])
pl2=plane_from_equation([0,-1,0,0],[50,50])

c=solid_line_vector(sec2_3d,[0,-30,0],1)
r1=difference(r1,c)
pl3=plane_from_equation([0,0,1,0],[50,50])
r1=split(r1,pl3,'top')
e3 = [r1.edges()[i] for i in [3, 5, 4, 2]]  # <- probe list tool: e3
r1 = fillet(r1, e3, 1.25)  # <- probe fillet tool: e3

e4 = [r1.edges()[i] for i in [20, 19, 18, 15, 23]]  # <- probe list tool: e4
e4=sample_curve( wire_from_edges(e4),50)
x1=o_3dc_tri(e4,to_triangles(r1),1.25)
s1=sec2surface(e4)
x2=o_3d(e4,s1,-1.25,3,0)
f1=convert_3lines2fillet(x2,x1,e4)
f1=solid_from_fillet(f1,-1)
r1=resize_solid (difference(r1,f1),[40,30,15])
show(r1,alpha=1)
# show(f1)

