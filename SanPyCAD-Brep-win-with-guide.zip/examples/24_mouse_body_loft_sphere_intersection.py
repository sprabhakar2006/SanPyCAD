# A computer-mouse-shaped body -- the same model as SanPyCAD's (the
# OpenSCAD-mesh sibling app's) own point-grid version:
#
#   a=cr2dt([[-20,0,15],[40,0,15],[0,40],[5,40,20],[-50,0,20],[5,-40]])
#   b=translate([0,0,-20],sphere(50))
#   s1=prism(a,[[0,0],[15,50]])
#   ... (a sine-wave surface projected onto b via psos(), smoothed)
#   l1=equidistant_pathc(contiguous_chains(two_solids_intersection(b,s1))[0],100)
#   l2=o_3d(l1,b,7,outside=0); l3=o_3d(l1,s1,-3,outside=0)
#   f3=solid_from_fillet_closed(convert_3lines2fillet(l3,l2,l1,closed_loop=1),-3)
#   show(color(difference(intersection(swp(s1),swp(b)),swp_c(f3)),alpha=1))
#
# rebuilt here with genuine B-rep throughout. Two deliberate differences
# from a literal port:
#
#   1. The fillet where the prism meets the sphere is built with a REAL
#      OCCT fillet() call directly on that seam edge, not the offset-
#      curves + convert_3lines2fillet() + solid_from_fillet_closed()
#      bezier-ribbon technique the original needs. That whole technique
#      exists ONLY because ocad/SanPyCAD has no native fillet
#      primitive -- it's a manual workaround (and this session's own
#      debugging of it, on a different model, found real self-
#      intersection issues along exactly that kind of seam). Once the
#      boolean intersection is real B-rep, the seam is a genuine edge on
#      a genuine solid, so one fillet() call rounds it exactly -- no
#      offset curves, no ribbon, none of that technique's failure modes.
#   2. The sine-wave surface sculpted into the sphere (l1/l2/l3/s2/
#      psos() in the original) is rebuilt near the bottom of this file as
#      a real boolean cut -- see the "Groove" section for why that's
#      difference() with a small local tool rather than split() (which
#      is otherwise the more direct B-rep equivalent of a "surface
#      pressed into another surface" -- see split()'s own docstring, its
#      example is exactly this kind of wavy-surface carve).
#
# Other notes:
#   - cr2dt(..., s=None): real Wire, exact circular-arc edges at the
#     rounded corners, not a point-sampled polygon approximation.
#   - s1: loft() between the base profile and the same profile offset
#     outward by 15 and raised to z=50 -- build123d's native 2-section
#     loft is an exact equivalent of ocad.py's prism(sec, path) for
#     this straight 2-station path (see loft()'s own docstring).
#   - seam edge selection: after intersection(s1, b), fillet() needs the
#     loop where s1's flared side meets b's sphere. Found here by
#     keeping only the edges of the result every sampled point of which
#     sits exactly on b's own sphere surface (distance sphere_r from its
#     center) -- s1's own flat base-ring edge stays strictly INSIDE the
#     sphere at that height and gets rejected by the same check -- so
#     this runs standalone instead of needing an edge index probed by
#     hand via the Pick Edges panel (this app's usual workflow, see
#     example 23).

import math

a = [[-20, 0, 15], [40, 0, 15], [0, 40], [5, 40, 20], [-50, 0, 20], [5, -40]]

# Recenter the rounded profile on its own centroid, same as the original
# script's tx=a_(a).mean(0); a=translate_2d(-tx,a).
centroid = cog(cr2dt(a, s=20))
base_wire = translate([-centroid[0], -centroid[1], 0], cr2dt(a, s=None))
base = face_from_wire(base_wire)

top = translate([0, 0, 50], offset(base, 15, kind="arc"))
s1 = loft(base, top)

sphere_center = [0, 0, -20]
sphere_r = 50
b = translate(sphere_center, sphere(sphere_r))

body = intersection(s1, b)


def _on_sphere(edge, tol=0.05):
    for p in sample_curve(edge, 5):
        d = ((p[0] - sphere_center[0]) ** 2 + (p[1] - sphere_center[1]) ** 2 +
             (p[2] - sphere_center[2]) ** 2) ** 0.5
        if abs(d - sphere_r) > tol:
            return False
    return True


seam_edges = [e for e in body.edges() if _on_sphere(e)]
# max_fillet_radius(body, seam_edges) will find the largest radius that
# actually fits this exact seam if 8 turns out to be too big/small for
# your version of the profile.
mouse = fillet(body, seam_edges, 8)

# ---------------------------------------------------------------------
# Groove: a shallow, sine-modulated channel across the top of the mouse
# -- what the original script's l1/l2/l3/s2/psos() pipeline sculpts by
# projecting a swept wavy surface onto the sphere. l1=sinewave(...) IS
# the cross-section there, held constant and swept along path l3 --
# NOT varied station-to-station along the sweep (an earlier version of
# this file got that backwards, tapering a stack of circles' RADIUS
# along the groove's length instead). Rebuilt properly below: one
# sine-wave-bottomed 2D profile, extruded straight (linear_extrude(),
# no twist/taper) so the wavy shape is constant along the groove's
# whole length, same as the original's sweep_sec2path(l1, l3) with a
# fixed cross-section.
#
# split(shape, bisect_by, keep=...) (see its own docstring -- its
# example is literally "carve a wavy notch into a block with
# surface_from_points_grid()") is the more DIRECT B-rep equivalent of
# the original's projection idea: a cutting surface pressed into the
# outer surface. But making that work means building a cutting surface
# that spans the mouse's whole footprint and tracks the DOME's own
# curvature almost exactly everywhere except along the groove -- real
# extra work in its own right, and a surface that drifts even slightly
# off the dome elsewhere would shave off a lot more than a groove.
#
# difference() with a small LOCAL "groove tool" solid sidesteps that
# entirely: the tool only ever needs to be right in its own small
# neighborhood, and the boolean only touches wherever it actually
# overlaps the mouse.
#
# The tool's 2D profile is built flat in the XY plane (X = across the
# groove's width, Y = cut depth -- negative Y dips INTO the mouse,
# tracing the sine wave; the profile then jumps up to a tall flat
# "roof" well above Y=0 on both ends, closing the loop) -- then
# rotate([90,0,0], ...) tips that whole flat shape from the XY plane
# into the XZ plane (Y becomes Z: verified directly -- Rx(90) sends
# (x,y,0) -> (x,0,y)), so the profile's own local "up" (its cut depth)
# lines up with world Z before it's ever extruded. linear_extrude(...,
# dir=[0,1,0]) then sweeps that XZ-plane profile straight along world Y
# -- the groove's length direction -- regardless of the profile's own
# surface normal, so there's no twist/rotation along the sweep, same as
# the original's constant cross-section.
groove_width = 50.0    # X extent, matches sinewave(50, ...)'s own length
wave_cycles = 1.5       # matches sinewave(..., 1.5, ...)'s own cycle count
wave_amp = 3.0          # matches sinewave(..., 3, ...)'s own amplitude
groove_run = 20.0       # Y extent -- how far front-to-back the groove runs
roof = 60.0             # comfortably taller than the deepest cut, so the
                         # tool always fully covers the surface above it

n_pts = 60
bottom_pts = []
for i in range(n_pts + 1):
    xf = i / n_pts
    x = (xf - 0.5) * groove_width
    depth = wave_amp * (1 + math.sin(2 * math.pi * wave_cycles * xf))  # 0..2*wave_amp, never negative
    bottom_pts.append([x, -depth])
profile_pts = bottom_pts + [[groove_width / 2, roof], [-groove_width / 2, roof]]

profile_xz = rotate([90, 0, 0], polygon(profile_pts))
groove_tool = linear_extrude(profile_xz, h=groove_run, dir=[0, 1, 0], center=True)

# Sit its Y=0-in-the-original-profile plane (now world Z) through the
# mouse's own highest point -- read off the ACTUAL finished solid's
# bounding box rather than a guessed z, so this still lands in the
# right place if the profile/offset numbers above ever change.
top_z = mouse.bounding_box().max.Z
groove_tool = translate([0, 0, top_z], groove_tool)

mouse = difference(mouse, groove_tool)

# Round the groove's own new edges too -- isolated with edges_in_box()
# using the groove tool's own bounding box as the probe, so this only
# ever picks up edges the groove cut just introduced, never the outer
# seam fillet() already rounded above.
groove_edges = edges_in_box(mouse.edges(), groove_tool, mode="crossing")
if groove_edges:
    mouse = fillet(mouse, groove_edges, 0.6)

show(mouse, tolerance=0.05, angular_tolerance=0.1)
