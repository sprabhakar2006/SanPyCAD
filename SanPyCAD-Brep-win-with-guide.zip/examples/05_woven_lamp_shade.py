# 05_woven_lamp_shade.py -- twisted woven-strand lamp shade. Each
# strand's centerline/cross-sections are computed with the real
# ocad point-list toolkit (bezier/axis_rot/rot/offset -- the
# opt-in `import ocad` escape hatch), then bridged into real
# B-rep via mixed_polygon() (one Face per cross-section) + loft() (one
# real solid strand), rotationally arrayed n times, mirrored for the
# opposite weave direction, and finally combined with a top/bottom
# ring base -- all exported together as one multi-part STEP assembly
# with group().

import ocad as o4

n = 20  # number of strands in the lamp
t = 5   # thickness of each strand
path = [[42, 0], [62, 50], [25, 100], [25, 180]]
path1 = o4.cytz(o4.bezier(path, 100))
path2 = [o4.axis_rot([0, 0, 1], path1[i], i / (len(path1) - 1) * (180 + 1.8)) for i in range(len(path1) - 1)]
sol = []
for i in range(len(path2)):
    theta = o4.ang(path2[i][0], path2[i][1])
    sol.append(o4.translate(path2[i], o4.rot(f'z{theta}', \
            o4.offset(o4.square(t, center=True), i / len(path2) * -1.5))))
sol = o4.rot('z0', sol)

# bridge into real B-rep: one Face per cross-section, lofted into one solid strand
sol = [mixed_polygon(p) for p in sol]
sol = loft(sol)
# show(sol)

sol1 = [rot(f'z{i}', sol) for i in np.linspace(0, 360, n + 1)[:-1]]
sol2 = [mirror_surface(p, [0, 1, 0], [0, 0, 0]) for p in sol1]
for i in range(len(sol1)):
    show(sol1[i])
    show(sol2[i])

c1 = linear_extrude(circle(45), 2)
c2 = linear_extrude(circle(30), 2)
sol3 = difference(c1, c2)
show(sol3)

export_step(group(sol1, sol2, sol3), "lamp.step")
