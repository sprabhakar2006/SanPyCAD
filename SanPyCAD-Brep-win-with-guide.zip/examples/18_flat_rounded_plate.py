# 18_flat_rounded_plate.py -- a flat plate with one rounded (arc) end
# and one straight end: arc_3p() gives the rounded end as a dense list
# of point-approximated segments, which then gets combined with the 2
# straight corner points of the flat end into one closed boundary
# (mixed_wire()), capped into a flat Face (cap_wire()), extruded into
# a plate (linear_extrude()), and finally has every edge (both ends'
# outlines, top and bottom) rounded in one fillet() pass.
#
# GOTCHA: feeding mixed_wire() the raw arc_3p() points directly --
# mixed_wire(a + [[150, 0], [150, 150]]) -- looks reasonable but
# produces visible VERTICAL CREASE LINES down the extruded side wall
# in the curved area. mixed_wire() always connects consecutive raw
# points with straight lines; arc_3p()'s output is a dense but still
# straight-segmented approximation of the arc, not one real curve, so
# that turns the "round" end into a many-sided straight-edge polygon,
# and each tiny facet becomes its own flat side-wall once extruded --
# each meeting its neighbor at a slightly different angle, which is
# exactly what shows up as those crease lines.
#
# FIX: collapse the arc's own points into ONE real smooth curve with
# interp_spline() BEFORE handing it to mixed_wire(), and pass that
# (plus the 2 plain straight-end corner points) in together --
# mixed_wire() uses a given Edge as-is (this smooth arc, unchanged)
# while still connecting the plain points with straight lines, so the
# flat end stays genuinely sharp/straight and only the arc end
# actually gets smoothed.

import ocad as o

a = o.arc_3p([15, 150], [0, 75], [15, 0])
b = cap_wire(mixed_wire([interp_spline(a), [150, 0], [150, 150]]))
b = linear_extrude(b, -5)
e1 = [b.edges()[i] for i in [3, 2, 1, 6, 5, 4, 9, 8, 7, 11, 10, 0]]  # <- probe list tool: e1
b = fillet(b, e1, 2)  # <- probe fillet tool: e1
show(b)
export_step(b, 'flat_rounded_plate.step')
