# 14_wall_hook_dome_groove.py -- a wall hook: a hemisphere (sphere()
# split() 'top' across z=0) with a fillet_line_circle()-shaped
# silhouette (built via the opt-in openscad4 bridge) extruded and
# subtracted out of it, the resulting rim edges rounded in two passes
# (radii 9 then 1.25, edge indices captured with the app's own Pick
# tool), then a spline-based groove cut across it -- the groove's own
# cross-section is now a genuine closed B-spline (bspline_closed(),
# fit through an equidistant_path()-resampled cr2dt() outline) rather
# than an interp_spline() through the same points, lofted between two
# copies offset slightly off-center in z (translate(..., 0.1) instead
# of sitting exactly on the mid-plane) so the cut isn't perfectly
# symmetric top/bottom. The groove edges are then rounded with a
# single split() 'both' across one horizontal plane (z=10) instead of
# the old two-split/two-plane approach -- each half's own share of the
# groove edges gets its own fillet() pass (radii 1.5 and 2, one per
# half), then the two halves are union()ed back into `hook`, with a
# non-uniform scale() applied at the very end to correct its
# proportions before show(hook). No export_step() this time.

import openscad4 as o
c1= o.circle(20)
l1=[[15,-20],[15,20]]
c2=o.circle(3,[-4,0])
a1=o.fillet_line_circle(l1,c2,20,o=3)
a2=o.fillet_line_circle(l1,c2,20,o=1)
l2=o.flip(a1)+o.trim_sec_ip(o.flip(c2),a1[0],a2[0])+a2+[[-30,23],[-30,-23]]
l3=cap_wire( o.equidistant_pathc(l2,pitch=2))
s1=translate([0,0,4],linear_extrude(l3,-25))
s2=sphere(20)
pl1=o.plane([0,0,1],[50,50])
pl1=surface_from_points_grid(pl1)
s3=split(s2,pl1,'top')
s4=difference(s3,s1)
e1 = [s4.edges()[i] for i in [4]]  # <- probe list tool: e1
s4 = fillet(s4, e1, 9)  # <- probe fillet tool: e1
e2 = [s4.edges()[i] for i in [0, 2, 3, 1]]  # <- probe list tool: e2
s4 = fillet(s4, e2, 1.25)  # <- probe fillet tool: e2
l1=o.rot('x90',o.cr2dt([[-30,4],[37,0],[4,5],[-3,5],[-3,2],[-5,1],[-8,-1.5],[-22,0]]))
l1=o.equidistant_path( l1,pitch=5)
l1=cap_wire( o.bspline_closed(l1,3,50))
s5=loft([translate([0,i,0.1],l1) for i in [-20,20]])
s6=difference(s4,s5)
pl1=surface_from_points_grid( o.plane_from_equation([0,0,1,10],[50,50]))
a,b=split(s6,pl1,'both')
e3 = [a.edges()[i] for i in [19, 17, 18]]  # <- probe list tool: e3
a = fillet(a, e3, 1.5)  # <- probe fillet tool: e3
e4 = [b.edges()[i] for i in [18]]  # <- probe list tool: e4
b = fillet(b, e4, 2)  # <- probe fillet tool: e4
hook=union(a,b)
hook=scale([1,30/40,17/20],hook)
show(hook)
