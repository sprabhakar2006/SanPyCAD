# 07_flanged_bracket_assembly.py -- 3-part bracket: hulled+drilled main
# flange (hull() of 3 cylinders, bolt holes filleted by GeomType.CIRCLE
# edge filter), a 4-hole end cap (radial rot() array of cut cylinders),
# and a bent arm swept along a cr3dt() path between them -- unioned into
# one part and fillet()'d along its Z/X face edges.

import openscad4 as o
from build123d import Axis, GeomType

c1 = linear_extrude(circle(17.5), 5.5)
c2 = linear_extrude(circle(7.5, [14.5, 0]), 5.5)
c3 = linear_extrude(circle(7.5, [-14.5, 0]), 5.5)
c4 = linear_extrude(circle(6.5), 5.5)
c5 = linear_extrude(circle(3, [14.5, 0]), 5.5)
c6 = linear_extrude(circle(3, [-14.5, 0]), 5.5)
s1 = hull(c1, c2, c3)
s2 = difference(s1, c4, c5, c6)
# show(s2, alpha=0.2)
e1 = s2.edges().filter_by(lambda e: e.geom_type == GeomType.CIRCLE)
e2 = [e1[i] for i in [0, 2, 3, 4, 5]]
s2 = fillet(s2, e2, 1)
e3 = s2.faces().filter_by(Axis.Z).edges()
s2 = fillet(s2, e3, 1)
# show(s2)

c7 = linear_extrude(circle(19.5), 4)
c8 = linear_extrude(circle(2.5, [15, 0]), 4)
c8 = [rot(f'z{i}', c8) for i in [0, 90, 180, 270]]
c9 = linear_extrude(circle(6.5), 4)
s3 = difference(c7, c8, c9)
s3 = fillet(s3, s3.faces().filter_by(Axis.Z).edges(), 0.5)
s3 = translate([-44 + 4, 0, 29], rot('y-90', s3))
# show(s3)

path = cr3dt([[0, 0, -0.01], [0, 0, 29, 17.5], [-44, 0, 0]], 10)
s4 = sweep_sec2path(circle(10), path)
s5 = sweep_sec2path(circle(6.5), path)
s6 = difference(s4, s5)
s6 = fillet(s6, s6.faces().filter_by(Axis.Z).edges(), 1)
s6 = fillet(s6, s6.faces().filter_by(Axis.X).edges(), 1)
# show(s6)

s7 = union(s2, s3, s6)
s7 = fillet(s7, s7.faces().filter_by(Axis.Z).edges(), 1)
s7 = fillet(s7, s7.faces().filter_by(Axis.X).edges(), 1)
show(s7)
