# 06_mobile_stand.py -- tilted cradle plate + pedestal, built from the
# real openscad4 point-list toolkit (cr2dt/bezier-style profile, arc/
# guide curves, surface_from_4_lines/slice_sol for the bent wall
# between two copies of the profile), bridged into real B-rep by
# lofting through 3 of the resulting grid's own rows -- rounding the
# grid to 4 decimals first avoids the tiny floating-point wobble that
# otherwise trips build123d's exact planarity check on each row.

import openscad4 as o4
from build123d import Axis

a = o4.cr2dt([[0, 5, 2.4], [0, -5, 2.4], [120, 0, 2.4], [0, 5, 2.4], [7, 0, 2.4]@o4.zrot(120), [5, 0, 2.4]@o4.zrot(210),
        [4.1, 0, .75]@o4.zrot(300), [-15, 0, 5], [50, 0, 2.4]@o4.zrot(120), [5, 0, 2.4]@o4.zrot(210),
        [47.1, 0, 2.4]@o4.zrot(300)], s=10)
a = o4.rot('x90', a)
b = o4.translate([0, 150, 0], a)
l1 = o4.c23(o4.arc_2p([0, 0], [0, 50], 100))
l2 = o4.rot('y60', l1)
l1p = o4.c23(o4.arc_2p([0, 0], [0, 50], 200))
l2p = o4.rot('y60', l1p)
l3 = o4.fit_pline2line(l1, [a[0], b[0]])
l4 = o4.fit_pline2line(l1, [a[21], b[21]])
s1 = o4.surface_from_4_lines(l3, l4, a[0:22], b[0:22])
s2 = o4.cpo(o4.slice_sol([a[22:44], b[22:44]], 20))
l5 = o4.fit_pline2line(l2p, [a[44], b[44]])
l6 = o4.fit_pline2line(l2p, [a[65], b[65]])
s3 = o4.surface_from_4_lines(l5, l6, a[44:66], b[44:66])
s4 = o4.cpo(o4.slice_sol([a[66:88], b[66:88]], 20))
l7 = o4.fit_pline2line(l2, [a[88], b[88]])
l8 = o4.fit_pline2line(l2, [a[109], b[109]])
s5 = o4.surface_from_4_lines(l7, l8, a[88:110], b[88:110])
s6 = o4.cpo(o4.slice_sol([a[110:121], b[110:121]], 20))
surf = o4.flip(o4.cpo(s1+s2+s3+s4+s5+s6))
surf = np.array(surf).round(4).tolist()

# 3 of the grid's own rows (start/mid/end), each turned into a real
# closed Face via mixed_polygon() and lofted through -- much simpler
# than sewing a fitted wall surface to separately-built end caps (see
# the earlier back-and-forth on this in chat: a NURBS-fit boundary and
# an independently-built polygon through the same points are two
# different curves, close but not exactly coincident, which is exactly
# what broke the Shell()-sewing approach).
f1 = [mixed_polygon(surf[i]) for i in [0, 10, 20]]
sol = loft(f1)

e1 = sol.faces().filter_by(Axis.Y)
show(label_faces(e1, 3), 'blue')
sol = fillet(sol, e1.edges(), 0.5)
show(sol)

export_step(sol, "mobile_stand.step")
