# mesh_cap_ribbon() -- caps a shape's own mesh region (its "top" skin,
# as seen along a direction) with a real solid that reaches EXACTLY to
# its true edge, no inward margin needed. Same mouse-body geometry as
# example 26 (copied verbatim) so this is directly comparable.
#
# Why this function exists, in short (see its own docstring for the
# full story -- this is the short version): the obvious way to build
# "the volume between a flat reference plane and a shape's own curved
# top skin" is to flatten the shape's silhouette (shape_outline_
# raster()), fill it with scan lines, and ray-cast each line onto the
# real mesh (surface_cap_solid()/mesh_cap_solid(), or a hand-built
# pipeline the same way). That works, but the flattened silhouette and
# the mesh's TRUE 3D edge are only the same curve where the edge
# happens to sit directly "above" its own flattened shadow -- which an
# organic boundary generally does not do everywhere along its own
# length. Scan points right at the flattened edge can therefore miss
# the real mesh on their way up, which forces the whole fill region to
# be shrunk inward by some safety margin first -- and the result comes
# back a genuine "sub-surface", visibly smaller than the shape's own
# true silhouette.
#
# mesh_cap_ribbon() never flattens anything. It reads the mesh's own
# topology directly to find the TRUE 3D boundary loop of the
# classified "top" triangle set (mesh_boundary_loop()), then builds
# scan lines whose ENDPOINTS are exact interpolations along that real
# edge (not ray-cast at all -- can't miss), and only ray-projects the
# INTERIOR points, which are always safely inside the true footprint
# by construction. No offset, no shrink -- the result reaches exactly
# to the mouse body's own real top edge.

t1 = o.time.time()

a = o.cr2dt([[-20, 0, 15], [40, 0, 15], [0, 40], [5, 40, 20], [-50, 0, 20], [5, -40]])
tx = o.a_(a).mean(0)
a = o.translate_2d(-tx, a)
b = o.translate([0, 0, -20], o.sphere(50))
p1 = [[0, 0], [15, 50]]
s1 = o.prism(a, p1)
l1 = o.translate_2d([-25, 3], o.sinewave(50, 1.5, 3, 50))
l1 = o.mirror_line(l1, [0, 1, 0], [0, 0, 0])
l2 = o.translate_2d([0, -20], o.circle(50))
l3 = o.rot2d(30, [[0, 0], [-10, 0]])
l3 = o.rot('x90z-90', o.flip(o.line2length(o.flip(o.line2length(
    o.cir_line_tangent(l2, l3), 50)), 100)))
s2 = o.sweep_sec2path(l1, l3)
b = o.psos(s2, b, [0, 0, -1] @ o.xrot(-30), 1e7, 1, 3)
b = [o.bspline_closed(p, 3, 50) for p in b]

l1 = o.equidistant_pathc(o.contiguous_chains(o.two_solids_intersection(b, s1))[0], 100)
l2 = o.o_3d(l1, b, 7, outside=0)
l3 = o.o_3d(l1, s1, -3, outside=0)
f3 = o.convert_3lines2fillet(l3, l2, l1, closed_loop=1)
f3 = o.solid_from_fillet_closed(f3, -3)

s1 = loft([cap_wire(mixed_wire(p)) for p in s1])
b = solid_from_closed_rings(b, ruled=True)
sol = intersection(s1, b)

f3 = solid_from_wedge_grid(f3, ruled=True, max_stations=50)
sol = difference(sol, f3)

# The mouse body's own true top-mesh boundary -- one clean loop
# (angle_tol=80's own equatorial-band margin keeps stray near-vertical
# triangles out of the classification in the first place; see
# mesh_boundary_loop()'s own docstring for what happens without it).
loops = mesh_boundary_loop(sol, [0, 0, 1], side="top")
show(*[line3d(l, 0.3) for l in loops], 'blue')

# The exact cap itself: the real volume between z=40 (a height that
# genuinely passes through the body -- see mesh_cap_ribbon()'s own
# docstring for what happens if it doesn't) and the mouse's own real
# curved top skin, reaching all the way to that blue edge above with
# no inward shrink at all.
cap = mesh_cap_ribbon(sol, [0, 0, 1], side="top", plane_point=[0, 0, 40])
show(cap, alpha=0.85)
show(sol, 'blue', alpha=0.3)

t2 = o.time.time()
t2 - t1
