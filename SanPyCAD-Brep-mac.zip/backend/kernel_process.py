"""
kernel_process.py -- the actual "Jupyter kernel" process for SanPyCAD
Brep: every route that touches build123d/OCCT (running a script,
picking edges/faces, computing max-fillet radii, highlighting a
selection) now runs inside a dedicated CHILD PROCESS, not the HTTP
server's own process. kernel_manager.py owns/supervises this process;
server.py never imports python_eval.py or brep.py directly for any of
that -- it goes through kernel_manager.MANAGER.call(...) instead.

WHY: OCCT (via build123d) is a C++ library, and a script can hang it
forever -- an infinite loop in the user's own Python, a fillet()/
max_fillet_radius() binary search that never converges, a boolean on
degenerate geometry that spins, or (per server.py's old _OCCT_LOCK
comment) an outright native segfault. When all of that ran in-process,
a single stuck script wedged the ENTIRE app: the one Python thread
running exec() never returned, so /reset_kernel -- which used to be
just another route behind the same global lock -- could never even
start running, let alone finish. "Reset Memory" doing nothing during a
hang was that design working exactly as built, not a bug in reset
itself.

Moving execution to a child process fixes this the same way Jupyter's
own "Restart Kernel" does: the HTTP server (this app's main process)
only ever talks to the worker over a pair of multiprocessing.Queues,
and never blocks on anything it can't also walk away from. Restarting
the kernel means SIGKILL-ing (TerminateProcess on Windows) this child
outright and spawning a fresh one -- the OS reclaims a killed process
unconditionally, whether it was in an infinite Python loop, blocked
inside a C extension, or already dead from a segfault, so this works
even in every case the old in-process "just clear a dict" reset
couldn't touch. See kernel_manager.py for the supervising side of this
(the part with the timeout/generation bookkeeping that makes a
restart-while-a-request-is-in-flight resolve cleanly instead of
leaving that request hanging on its own end).

Everything below runs INSIDE the worker process once started. It talks
to kernel_manager.py purely via two plain multiprocessing.Queues of
JSON-safe dicts (no live build123d/OCCT objects ever cross the process
boundary -- those only ever live here, in this process's own
python_eval._PERSISTENT_USER_NS); render()/probe_*() already build
JSON-safe result dicts today (server.py sends them straight to the
frontend as-is), so this file's job is purely dispatch, not
reshaping.
"""

import math
import os
import sys
import traceback

import numpy as np

_BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
if _BACKEND_DIR not in sys.path:
    sys.path.insert(0, _BACKEND_DIR)


def _trace_edge_chain(all_edges, seed_i, angle_tol_deg=90.0, tol_rel=1e-4):
    """Walks the connected-edge graph of a real B-rep edge list, starting
    from `seed_i`, and returns every edge that forms ONE continuous,
    SMOOTH-ENOUGH chain or loop through it -- the "select all the
    joining edges instead of picking one at a time" tool behind
    /probe_pick's `loop` flag.

    Two edges are considered TOUCHING when their endpoints coincide
    within a small, fixed, auto-computed tolerance (`tol_rel` scaled to
    the whole edge list's own bounding span -- NOT a user-facing knob;
    real sewn B-rep topology needs barely any slack to detect this, and
    shapes built from point-list-resampled curves at typical model
    scales are already covered by this auto tolerance). Endpoints are
    clustered by real pairwise distance (union-find), not by rounding
    into a fixed grid -- a grid has hard cell boundaries two genuinely
    coincident points can straddle; true-distance clustering doesn't.

    Touching alone doesn't mean the walk continues through, though: at
    every vertex reached, the INTERIOR ANGLE between the edge just
    walked and each candidate next edge is measured -- the angle
    between the two edges' own rays OUT of that shared vertex. 180 deg
    means a perfectly straight continuation, 90 deg a right-angle
    corner, near 0 deg a hairpin doubling back on itself.

    At a vertex where MULTIPLE (unvisited) edges touch -- a real
    junction, e.g. 3+ edges meeting -- the walk doesn't just refuse to
    guess: it picks whichever candidate has the LARGEST interior angle
    (the straightest, most natural continuation) and follows that one,
    same as it would at an ordinary 2-edge join. This resolves the
    exact situation a plain "stop at any branch" rule used to get stuck
    on -- a fine ruled loft's own dense grid of small band edges
    routinely has several edges meeting at one station's own seam
    vertex, and the straightest one is almost always the actually-
    intended continuation. It's only reported as a genuine, unresolvable
    branch if two or more candidates tie for the largest angle (within
    a small epsilon) -- an honest ambiguity, not a guess.

    Either way, the walk only ever continues onto a candidate whose
    angle is >= `angle_tol_deg` -- the default 90 deg means "keep going
    through anything that isn't sharper than a right angle", exactly
    the kind of run a fine ruled loft's own many small band-to-band
    edges naturally forms (each just a few degrees off straight)
    without also spilling across a real, deliberate corner of the
    design. Narrow it (e.g. 150) to only follow very straight runs;
    widen it (e.g. 30) to also sweep through sharper turns. Walking
    runs in two passes from the seed edge's own two ends so an
    asymmetric seed pick (not in the middle of the run) still collects
    the whole thing; if the forward pass alone loops back to the seed's
    start, it's reported closed and the backward pass is skipped.

    Returns (indices, closed, stop_info): `indices` is the walked order
    starting with `seed_i` in the middle-ish. `closed` is True only if
    the chain forms a genuine loop back to its own start. `stop_info`
    is {"forward": {...}, "backward": {...} or None} -- each populated
    direction is one of {"reason": "dead_end"} (nothing touches at
    all), {"reason": "branch", "candidates": [...]} (two or more
    candidates genuinely tied for straightest), or {"reason":
    "sharp_angle", "candidate": j, "angle": deg} (the best candidate
    found still falls under `angle_tol_deg`).
    """
    if not all_edges:
        return [seed_i], False, {"forward": {"reason": "dead_end"}, "backward": None}

    pts = []
    for e in all_edges:
        pts.append(e.position_at(0.0))
        pts.append(e.position_at(1.0))
    xs = [p.X for p in pts]
    ys = [p.Y for p in pts]
    zs = [p.Z for p in pts]
    span = max(max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs), 1e-6)
    tol = max(span * tol_rel, 1e-9)

    flat_pts = [(p.X, p.Y, p.Z) for p in pts]
    n_pts = len(flat_pts)
    parent = list(range(n_pts))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    tol2 = tol * tol
    for i in range(n_pts):
        xi, yi, zi = flat_pts[i]
        for j in range(i + 1, n_pts):
            xj, yj, zj = flat_pts[j]
            d2 = (xi - xj) ** 2 + (yi - yj) ** 2 + (zi - zj) ** 2
            if d2 <= tol2:
                union(i, j)
    clusters = [find(i) for i in range(n_pts)]

    endpoints = [(clusters[2 * i], clusters[2 * i + 1]) for i in range(len(all_edges))]

    touching = {}
    for i, (ka, kb) in enumerate(endpoints):
        touching.setdefault(ka, []).append(i)
        if kb != ka:
            touching.setdefault(kb, []).append(i)

    def _far_point(i, shared_key):
        # the endpoint of edge i that is NOT the shared vertex
        ka, _kb = endpoints[i]
        return flat_pts[2 * i + 1] if ka == shared_key else flat_pts[2 * i]

    def _shared_point(i, shared_key):
        ka, _kb = endpoints[i]
        return flat_pts[2 * i] if ka == shared_key else flat_pts[2 * i + 1]

    def _interior_angle(cur_i, cand_i, shared_key):
        shared_pt = _shared_point(cur_i, shared_key)
        far1 = _far_point(cur_i, shared_key)
        far2 = _far_point(cand_i, shared_key)
        d1 = (far1[0] - shared_pt[0], far1[1] - shared_pt[1], far1[2] - shared_pt[2])
        d2 = (far2[0] - shared_pt[0], far2[1] - shared_pt[1], far2[2] - shared_pt[2])
        n1 = math.sqrt(sum(c * c for c in d1))
        n2 = math.sqrt(sum(c * c for c in d2))
        if n1 < 1e-12 or n2 < 1e-12:
            return None
        dot = sum(a * b for a, b in zip(d1, d2)) / (n1 * n2)
        dot = max(-1.0, min(1.0, dot))
        return math.degrees(math.acos(dot))

    def _step(cur_i, shared_key, visited):
        """Picks the next edge to walk onto from `shared_key`, or
        returns (None, stop_reason) if the walk should stop here."""
        candidates = [j for j in touching.get(shared_key, []) if j not in visited]
        if not candidates:
            return None, {"reason": "dead_end"}
        scored = [(c, _interior_angle(cur_i, c, shared_key)) for c in candidates]
        scored = [(c, a) for c, a in scored if a is not None]
        if not scored:
            return None, {"reason": "dead_end"}
        best_angle = max(a for _c, a in scored)
        tied = [c for c, a in scored if abs(a - best_angle) < 1e-6]
        if len(tied) > 1:
            return None, {"reason": "branch", "candidates": tied}
        if best_angle < angle_tol_deg:
            return None, {"reason": "sharp_angle", "candidate": tied[0], "angle": round(best_angle, 2)}
        return tied[0], None

    stop_info = {"forward": None, "backward": None}

    chain = [seed_i]
    visited = {seed_i}
    cur_far_key = endpoints[seed_i][1]
    while True:
        nxt, stop = _step(chain[-1], cur_far_key, visited)
        if nxt is None:
            stop_info["forward"] = stop
            break
        visited.add(nxt)
        chain.append(nxt)
        ka, kb = endpoints[nxt]
        cur_far_key = kb if ka == cur_far_key else ka
    closed = cur_far_key == endpoints[seed_i][0]
    if closed:
        return chain, True, stop_info

    cur_far_key = endpoints[seed_i][0]
    while True:
        nxt, stop = _step(chain[0], cur_far_key, visited)
        if nxt is None:
            stop_info["backward"] = stop
            break
        visited.add(nxt)
        chain.insert(0, nxt)
        ka, kb = endpoints[nxt]
        cur_far_key = kb if ka == cur_far_key else ka
    return chain, False, stop_info


def _face_edge_key(pt_a, pt_b, ndigits=5):
    """A direction-independent identity for a boundary edge, from its
    own two endpoints -- rounds each to `ndigits` and sorts the pair,
    so the SAME topological edge shared by two adjacent faces lands
    under one shared key regardless of which face's own Edge wrapper
    it came from or which direction that wrapper happens to run in."""
    a = (round(pt_a.X, ndigits), round(pt_a.Y, ndigits), round(pt_a.Z, ndigits))
    b = (round(pt_b.X, ndigits), round(pt_b.Y, ndigits), round(pt_b.Z, ndigits))
    return (a, b) if a <= b else (b, a)


def _trace_face_region(all_faces, seed_i, angle_tol_deg=15.0):
    """The face counterpart to _trace_edge_chain() above: flood-fills
    outward from `seed_i` through every neighboring face reachable by
    crossing a shared edge whose two adjacent faces meet at a shallow
    enough angle -- the "select the whole smoothly-curved surface in
    one click instead of every little facet individually" tool behind
    /probe_pick's `loop` flag in Faces mode.

    WHY THIS IS NEEDED: a `ruled=True` ThruSections loft (or any
    stack-of-many-stations construction -- solid_from_wedge_grid(),
    surface_from_closed_rings(), etc) doesn't come back as one Face per
    visually-smooth surface -- it's genuinely built from many small
    RULED band faces, one strip per pair of adjacent stations. A dome
    lofted through 50 stations is, topologically, ~50 real separate
    Faces that just happen to sit at a near-zero angle to their
    neighbors everywhere. Clicking each one individually to fillet/
    select the whole visible surface is exactly the "cumbersome"
    problem this exists to fix.

    HOW: for every face, every one of its own boundary edges is keyed
    by its two endpoints (_face_edge_key() above) -- an internal edge
    shared by exactly 2 faces (the normal case for a closed, manifold
    solid) becomes the adjacency graph's own edges; an edge owned by
    only 1 face (an open boundary) or 3+ faces (non-manifold) is never
    crossed at all, same "don't guess" principle _trace_edge_chain()
    uses at a branch point. At each internal edge actually considered,
    both faces' Face.normal_at() is sampled at the edge's own midpoint
    and the angle between those two normals is the crossing test:
    <= `angle_tol_deg` (in degrees) counts as "smoothly connected" and
    the walk continues across it; anything sharper is treated as a
    genuine feature edge and stops the region there, the same way a
    real dihedral-angle feature-edge detector would. Real sewn B-rep
    topology (not raw point-list-built curves) coincides at exact
    shared vertices, so simple coordinate rounding for the edge key is
    enough here -- no need for _trace_edge_chain()'s own O(n^2)
    pairwise union-find (built for the harder, opposite case: curves
    independently resampled from point-list data, which can leave a
    real, visible gap even at a logically-shared point).

    `angle_tol_deg` defaults to 15 -- loose enough to walk straight
    through a fine ruled loft's own near-zero band-to-band angles
    without also crossing a real, deliberate corner (most engineering
    features turn considerably sharper than that). Widen it if a
    region is stopping short on a surface you know is meant to be
    treated as continuous; tighten it if it's bleeding across a corner
    that should have stopped the selection.

    Returns (indices, stop_info): `indices` always includes `seed_i`
    (first). `stop_info` is only populated when the region never grew
    past the seed alone -- {"isolated": True} means the seed face has
    no genuinely-shared (exactly-2-owner) edges to cross at all (an
    open boundary or non-manifold face on every side); {"over_tol":
    [(face_index, angle), ...]} means it DOES have shared neighbors,
    but every one of them meets at an angle sharper than
    `angle_tol_deg` -- a real, sharp-cornered face all the way around,
    or a tolerance that needs widening.
    """
    if not all_faces:
        return [seed_i], {"isolated": True}

    edge_owners = {}
    face_edge_cache = []
    for i, f in enumerate(all_faces):
        try:
            edges = list(f.edges())
        except Exception:
            edges = []
        keyed = []
        for e in edges:
            try:
                p0, p1 = e.position_at(0.0), e.position_at(1.0)
                key = _face_edge_key(p0, p1)
            except Exception:
                continue
            keyed.append((key, e))
            edge_owners.setdefault(key, []).append(i)
        face_edge_cache.append(keyed)

    def _angle_between(face_a_i, face_b_i, edge):
        try:
            mid = edge.position_at(0.5)
            pt = (float(mid.X), float(mid.Y), float(mid.Z))
            na = all_faces[face_a_i].normal_at(pt)
            nb = all_faces[face_b_i].normal_at(pt)
            dot = na.X * nb.X + na.Y * nb.Y + na.Z * nb.Z
            dot = max(-1.0, min(1.0, dot))
            return math.degrees(math.acos(dot))
        except Exception:
            return None

    visited = {seed_i}
    region = [seed_i]
    queue = [seed_i]
    seed_neighbors = []
    while queue:
        cur = queue.pop()
        for key, e in face_edge_cache[cur]:
            owners = edge_owners.get(key, [])
            if len(owners) != 2:
                continue
            other = owners[0] if owners[1] == cur else owners[1]
            if other == cur or other in visited:
                continue
            angle = _angle_between(cur, other, e)
            if cur == seed_i:
                seed_neighbors.append((other, angle))
            if angle is None or angle > angle_tol_deg:
                continue
            visited.add(other)
            region.append(other)
            queue.append(other)

    stop_info = {}
    if len(region) == 1:
        if not seed_neighbors:
            stop_info["isolated"] = True
        else:
            stop_info["over_tol"] = [
                (idx, round(a, 2) if a is not None else None) for idx, a in seed_neighbors]
    return region, stop_info


def _probe_pick(PE, brep, cmd):
    """Moved verbatim from server.py's old in-process /probe_pick
    handler -- only the request/response shape changed (a plain dict
    in, a plain dict out, with an extra "_status" key the caller
    pops off to preserve the exact same 400-vs-200 behavior the old
    inline route had; see server.py's do_POST).

    `loop` (default False), edges only: after finding the single
    nearest edge to the click same as always, also walks the connected-
    edge chain through it (see _trace_edge_chain() above) and returns
    every edge in that chain/loop instead of just the one clicked --
    the "select all the joining edges instead of one at a time" mode."""
    var_name = cmd.get("variable", "")
    kind = cmd.get("kind", "edges")
    mode = cmd.get("mode", "inside")
    center = cmd.get("center")
    size = cmd.get("size")
    point = cmd.get("point")
    loop = bool(cmd.get("loop", False))
    loop_tol = cmd.get("loop_tol")

    shape = PE.get_persisted_var(var_name)
    if shape is None:
        return {"_status": 400, "error": (
            f"No variable named '{var_name}' in memory. Render your "
            f"script at least once first (Jupyter-style, its "
            f"variables stay in memory between runs), then try again."
        )}

    if point is not None:
        try:
            px, py, pz = [float(v) for v in point]
            if kind == "faces":
                all_items = list(shape.faces())
                if not all_items:
                    return {"_status": 400, "error": "this shape has no faces"}
                best_i, best_d = None, float("inf")
                for i, f in enumerate(all_items):
                    d = f.distance_to((px, py, pz))
                    if d < best_d:
                        best_d, best_i = d, i
                if loop:
                    angle_tol = 15.0
                    if loop_tol not in (None, ""):
                        try:
                            angle_tol = float(loop_tol)
                        except (TypeError, ValueError):
                            angle_tol = 15.0
                    region, stop_info = _trace_face_region(all_items, best_i, angle_tol_deg=angle_tol)
                    result = {
                        "indices": region, "total": len(all_items),
                        "distance": best_d, "seed": best_i,
                    }
                    if len(region) == 1:
                        if stop_info.get("isolated"):
                            result["isolated"] = True
                        elif stop_info.get("over_tol"):
                            result["over_tol"] = stop_info["over_tol"]
                    return result
                return {"indices": [best_i], "total": len(all_items), "distance": best_d}
            else:
                all_items = list(shape.edges())
                if not all_items:
                    return {"_status": 400, "error": "this shape has no edges"}
                n_samples = 12
                best_i, best_d = None, float("inf")
                for i, e in enumerate(all_items):
                    for k in range(n_samples + 1):
                        t = k / n_samples
                        p = e.position_at(t)
                        d = ((p.X - px) ** 2 + (p.Y - py) ** 2 + (p.Z - pz) ** 2) ** 0.5
                        if d < best_d:
                            best_d, best_i = d, i
                if loop:
                    angle_tol = 90.0
                    if loop_tol not in (None, ""):
                        try:
                            angle_tol = float(loop_tol)
                        except (TypeError, ValueError):
                            angle_tol = 90.0
                    chain, closed, stop_info = _trace_edge_chain(all_items, best_i, angle_tol_deg=angle_tol)
                    result = {
                        "indices": chain, "total": len(all_items),
                        "distance": best_d, "closed": closed, "seed": best_i,
                    }
                    if len(chain) == 1:
                        # Report whichever direction actually stopped with
                        # something to say -- forward/backward usually
                        # agree (same seed, symmetric neighborhood) but
                        # don't have to. Three distinct reasons now
                        # (see _trace_edge_chain()'s own docstring):
                        # dead_end (nothing to report -- no neighbor at
                        # all), branch (a genuine tie for straightest
                        # continuation), sharp_angle (the best candidate
                        # found still turns sharper than Angle tol).
                        info = stop_info.get("forward") or stop_info.get("backward") or {"reason": "dead_end"}
                        reason = info.get("reason")
                        if reason == "branch":
                            result["branch_edges"] = info.get("candidates", [])
                        elif reason == "sharp_angle":
                            result["sharp_angle"] = info.get("angle")
                            result["sharp_angle_candidate"] = info.get("candidate")
                    return result
                return {"indices": [best_i], "total": len(all_items), "distance": best_d}
        except Exception as e:
            return {"_status": 400, "error": str(e)}

    try:
        probe = brep.translate(center, brep.box(size, center=True))
        if kind == "faces":
            all_items = list(shape.faces())
            matched = brep.faces_in_box(all_items, probe, mode=mode)
        else:
            all_items = list(shape.edges())
            matched = brep.edges_in_box(all_items, probe, mode=mode)
        matched_ids = {id(e) for e in matched}
        indices = [i for i, e in enumerate(all_items) if id(e) in matched_ids]
        return {"indices": indices, "total": len(all_items)}
    except Exception as e:
        return {"_status": 400, "error": str(e)}


def _fit_circle_3d(points):
    """Best-fit circle through >= 6 3D points, mirroring the frontend's
    own fitCircleIfClosed()/fitCircle() (index.html) -- a plain
    algebraic (Kasa) circle fit, just done in 3D instead of 2D: PCA
    picks the points' own best-fit plane (the least-variance
    direction), the same Kasa fit then runs on their 2D coordinates
    within that plane, and the result is rejected unless the points
    really do sit close to ONE circle (both within the fitted plane and
    circular within it) -- same spirit as the frontend's own 5%-of-
    radius residual tolerance, plus a sanity check against an
    absurdly-large radius from a near-collinear point set (mirroring
    the frontend's own fitLooksReasonable()).

    This exists because Edge.geom_type doesn't always come back CIRCLE
    for an edge that IS geometrically a circle -- a real, common OCCT
    artifact for a hole rim that survived a union()/fillet(): the
    resulting boundary curve is a face-face (or blend-surface)
    intersection, which OCCT often represents as a BSPLINE_CURVE
    approximation even when it traces a perfect circle, rather than
    reclassifying it back to a native Circle type. That's exactly why
    the Drawing tab already gets these same holes' radius/center-
    distance right (fitCircleIfClosed() fits a circle to SAMPLED
    points, never trusting the curve's own type tag at all) while this
    analytic-geom-type-only search was missing them -- this brings the
    3D Dimension tool's own hole_center search up to the same standard,
    as a fallback for edges that don't self-report as CIRCLE.

    Returns (center: Vector-like w/ .X/.Y/.Z, radius: float,
    normal: [nx,ny,nz]) or None if the points don't trust-worthily fit
    one circle."""
    pts = np.asarray(points, dtype=float)
    if len(pts) < 6:
        return None
    centroid = pts.mean(axis=0)
    centered = pts - centroid
    cov = centered.T @ centered
    try:
        evals, evecs = np.linalg.eigh(cov)
    except np.linalg.LinAlgError:
        return None
    normal = evecs[:, 0]  # smallest-eigenvalue eigenvector -- the points' own least-variance direction
    nrm = np.linalg.norm(normal)
    if nrm < 1e-12:
        return None
    normal = normal / nrm
    arbitrary = np.array([1.0, 0.0, 0.0])
    if abs(float(np.dot(arbitrary, normal))) > 0.9:
        arbitrary = np.array([0.0, 1.0, 0.0])
    u = np.cross(normal, arbitrary)
    u_norm = np.linalg.norm(u)
    if u_norm < 1e-12:
        return None
    u = u / u_norm
    v = np.cross(normal, u)

    xs = centered @ u
    ys = centered @ v
    zs = centered @ normal  # out-of-plane residual -- should be ~0 for a real planar circle

    n = len(pts)
    sum_x, sum_y = xs.sum(), ys.sum()
    sum_xx, sum_yy, sum_xy = (xs * xs).sum(), (ys * ys).sum(), (xs * ys).sum()
    sum_z = (xs * xs + ys * ys).sum()
    sum_xz = (xs * (xs * xs + ys * ys)).sum()
    sum_yz = (ys * (xs * xs + ys * ys)).sum()
    a_mat = np.array([[sum_xx, sum_xy, sum_x], [sum_xy, sum_yy, sum_y], [sum_x, sum_y, float(n)]])
    b_vec = np.array([sum_xz, sum_yz, sum_z])
    try:
        d_val, e_val, f_val = np.linalg.solve(a_mat, b_vec)
    except np.linalg.LinAlgError:
        return None
    cx, cy = d_val / 2, e_val / 2
    r2 = f_val + cx * cx + cy * cy
    if not (r2 > 0):
        return None
    r = r2 ** 0.5

    dev = np.abs(np.hypot(xs - cx, ys - cy) - r)
    if dev.max() > r * 0.05 + 1e-9:
        return None  # not circular enough -- e.g. a straight or free-form edge, not a hole rim
    if np.abs(zs).max() > r * 0.05 + 1e-9:
        return None  # not planar enough -- a real circle's points all sit in ONE plane

    spread = float(np.linalg.norm(centered, axis=1).max())
    if r > spread * 4:
        return None  # nonsensically large radius from a near-collinear point set -- reject, not a real hole

    center = centroid + cx * u + cy * v

    class _FittedCenter:
        pass
    c = _FittedCenter()
    c.X, c.Y, c.Z = float(center[0]), float(center[1]), float(center[2])
    return c, float(r), [float(normal[0]), float(normal[1]), float(normal[2])]


def _probe_dim_pick(PE, brep, cmd):
    """Resolves a 3D click -- a world-space point at or near the
    model's own surface, e.g. a Three.js raycast hit point from the
    frontend's 3D Dimension tool -- to the nearest REAL B-rep
    dimensioning anchor: a topological vertex (an exact corner), a
    "hole_center" (a circular edge's exact fitted center -- a hole,
    boss, or shaft's flat end rim -- OR, for a click on the round SIDE
    wall of a cylindrical/conical face instead of right at an end edge,
    the point on that face's own axis closest to the click, i.e. a
    shaft/bore's center AT THAT HEIGHT, extending "hole center" along
    the whole length of a shaft rather than just its 2 end circles), or
    a fallback edge (for point-to-edge dimensions). Same "vertex ->
    hole-center -> edge" idea as Drawing's own resolveLinearPick() in
    index.html, but resolved here against the REAL live B-rep shape
    (shape.vertices()/shape.edges()/shape.faces()) rather than a
    tessellated/projected approximation -- a hole's center comes back
    mathematically exact, straight from the circle's own OCCT geometry
    (Edge.arc_center) or a cylinder/cone face's own axis
    (Face.axis_of_rotation), never a fit through sampled/tessellated
    points the way a display mesh alone would force.

    By default (`kind` omitted or "auto"), whichever real candidate --
    of vertex/hole-center/edge, pooled together -- is closest to the
    given `point` wins. No separate per-kind pixel/world-unit tolerance
    bands are needed the way the 2D SVG picker uses: `point` here is
    already a real 3D coordinate ON (or very near) the model's own
    surface from a raycast hit, so "closest wins" alone is enough to
    disambiguate which feature was meant -- EXCEPT when a hole's
    boundary vertices (where its arc segments meet) sit closer to the
    click than the hole's own center, which "auto" alone can't tell
    apart from meaning to click that vertex. Pass `kind` as "vertex",
    "hole_center", or "edge" to restrict the search to just that one
    kind -- same escape hatch as Drawing's own #linear-pick-mode
    selector, for exactly that ambiguous case.

    "face" is deliberately NOT part of "auto"'s pool -- a raycast hit
    point is essentially always sitting exactly ON some face already
    (distance ~0), so pooling faces in by distance would make Auto
    resolve to a face almost every single click, burying the vertex/
    hole/edge candidates auto is actually for. Pass `kind="face"`
    explicitly (the frontend's own Pick: Face option) to search faces
    at all.

    Every non-vertex result also carries "highlight_kind" ("edges" or
    "faces") + "highlight_index" (that feature's own index into
    shape.edges()/shape.faces()) -- ready to hand straight to the
    EXISTING /probe_highlight route (same one the Pick Edges/Faces tool
    already uses) to fetch sampled curve(s) for actually drawing the
    picked feature on screen, so the user can SEE the edge/face/hole
    their click resolved to before committing to it, not just a bare
    point. A "hole_center" result also carries "axis_dir" (a unit
    vector) whenever one is well-defined, so the caller can draw the
    hole/shaft's own axis line through the center too.

    Returns one of:
      {"kind": "vertex", "point": [x,y,z], "distance": d}
      {"kind": "hole_center", "point": [x,y,z], "radius": r,
       "axis_dir": [nx,ny,nz], "highlight_kind": "edges"|"faces",
       "highlight_index": i, "distance": d}
      {"kind": "edge", "a": [x,y,z], "b": [x,y,z],
       "highlight_kind": "edges", "highlight_index": i, "distance": d}
      {"kind": "face", "planar": True, "point": [x,y,z], "normal": [nx,ny,nz],
       "highlight_kind": "faces", "highlight_index": i, "distance": d}
      {"kind": "face", "planar": False, "point": [x,y,z],
       "highlight_kind": "faces", "highlight_index": i, "distance": d}
    For a planar face, "point"/"normal" are an exact point-on-plane
    (Face.is_planar's own Plane.origin) and the plane's exact normal
    (Plane.z_dir) -- together they define the WHOLE infinite plane, so
    a caller can compute an exact perpendicular distance from any other
    point to this face without needing the closest point specifically.
    For a non-planar face (cylindrical, etc.), there's no single normal
    to hand back -- "point" is instead just the closest point ON the
    face to the CLICK (via Face.distance_to_with_closest_points()), an
    approximation a caller should flag as such if used for a distance
    to some other, different point.
    (`distance` is how far the winning candidate is from the given
    click point -- purely informational, not used to reject a pick.)
    """
    var_name = cmd.get("variable", "")
    point = cmd.get("point")
    kind_filter = cmd.get("kind", "auto") or "auto"
    if kind_filter not in ("auto", "vertex", "hole_center", "edge", "face"):
        kind_filter = "auto"

    shape = PE.get_persisted_var(var_name)
    if shape is None:
        return {"_status": 400, "error": (
            f"No variable named '{var_name}' in memory. Render your "
            f"script at least once first (Jupyter-style, its "
            f"variables stay in memory between runs), then try again."
        )}
    if point is None:
        return {"_status": 400, "error": "no point given"}
    try:
        px, py, pz = [float(v) for v in point]
    except Exception as e:
        return {"_status": 400, "error": str(e)}

    best = [None, None]  # [distance, result] -- mutable cell, not a
                          # local nonlocal-captured tuple, so consider()
                          # can update it without needing `nonlocal`

    def consider(d, result):
        if d != d or d in (float("inf"), float("-inf")):
            return  # NaN/Inf distance -- e.g. a degenerate curve/surface that can come
            # out of a complex union()/fillet() -- must never be allowed to win. If left
            # unguarded, a single degenerate candidate like this, if it's simply the
            # FIRST one considered, would lock in as `best` (the `best[0] is None`
            # branch below accepts ANY d unconditionally the first time) and then could
            # NEVER be displaced by any later, real candidate -- NaN comparisons are
            # always False in Python, so `d < best[0]` can never succeed again once
            # best[0] itself is NaN. That is exactly the "no matter which hole/shaft I
            # pick it shows the same center" bug: every click, regardless of where it
            # lands, silently resolves to that same first degenerate candidate.
        if best[0] is None or d < best[0]:
            best[0] = d
            best[1] = result

    try:
        if kind_filter in ("auto", "vertex"):
            for v in shape.vertices():
                d = ((v.X - px) ** 2 + (v.Y - py) ** 2 + (v.Z - pz) ** 2) ** 0.5
                consider(d, {"kind": "vertex", "point": [v.X, v.Y, v.Z]})

        if kind_filter in ("auto", "hole_center"):
            # A circular EDGE -- a hole's rim, a boss/shaft's flat end cap,
            # a counterbore's step, etc. -- gives its exact center
            # straight from the circle's own geometry (Edge.arc_center),
            # and its own axis direction via Edge.normal() (defined for
            # CIRCLE/ELLIPSE curves -- the circle's own plane normal,
            # i.e. exactly the hole's axis direction).
            for i, e in enumerate(shape.edges()):
                try:
                    c = None
                    radius_val = None
                    axis_dir_val = None
                    if e.geom_type == brep.bd.GeomType.CIRCLE:
                        try:
                            c0 = e.arc_center
                            if all(v == v and v not in (float("inf"), float("-inf"))
                                   for v in (c0.X, c0.Y, c0.Z)):
                                c = c0
                        except Exception:
                            pass
                        if c is None:
                            # arc_center can throw, or come back NaN/Inf, for a
                            # numerically degenerate/self-intersecting circle --
                            # a real possibility on a hole rim that got a small
                            # fillet() relative to its own radius (e.g. a
                            # 0.5mm fillet on a 3mm-radius hole is exactly the
                            # kind of tight ratio OCCT's own curve-fit can choke
                            # on). Fall back to the edge's own bounding box
                            # center instead: for any FULL (360-degree)
                            # circular edge, that's exactly the true circle
                            # center too, by plain symmetry, and bounding_box()
                            # is a far more numerically robust computation than
                            # solving the curve's own analytic parameters.
                            try:
                                bc = e.bounding_box().center()
                                if all(v == v and v not in (float("inf"), float("-inf"))
                                       for v in (bc.X, bc.Y, bc.Z)):
                                    c = bc
                            except Exception:
                                pass
                        if c is not None:
                            try:
                                r = e.radius
                                if r == r and r not in (float("inf"), float("-inf")):
                                    radius_val = r
                            except Exception:
                                pass
                            try:
                                n = e.normal()
                                axis_dir_val = [n.X, n.Y, n.Z]
                            except Exception:
                                pass  # normal() can fail for a handful of curve edge cases -- axis just omitted then
                    if c is None:
                        # Not (self-reported as) a native circle -- OR one whose
                        # arc_center/bounding-box both failed above -- try a
                        # generic circle fit through SAMPLED points along the
                        # edge instead (see _fit_circle_3d()'s own docstring for
                        # why: a hole rim that survived a union()/fillet() can
                        # come back as a BSPLINE_CURVE approximation even when
                        # it's geometrically still a perfect circle, so
                        # Edge.geom_type == CIRCLE alone isn't a reliable enough
                        # test -- this is exactly why the Drawing tab already
                        # gets these same holes right while this search didn't).
                        try:
                            n_samples = 12
                            pts = [e.position_at(k / (n_samples - 1)) for k in range(n_samples)]
                            pts = [(p.X, p.Y, p.Z) for p in pts]
                            fit = _fit_circle_3d(pts)
                        except Exception:
                            fit = None
                        if fit is not None:
                            c, radius_val, axis_dir_val = fit
                    if c is None:
                        continue
                    d = ((c.X - px) ** 2 + (c.Y - py) ** 2 + (c.Z - pz) ** 2) ** 0.5
                    result = {
                        "kind": "hole_center", "point": [c.X, c.Y, c.Z],
                        "highlight_kind": "edges", "highlight_index": i,
                    }
                    if radius_val is not None:
                        result["radius"] = radius_val
                    if axis_dir_val is not None:
                        result["axis_dir"] = axis_dir_val
                    consider(d, result)
                except Exception:
                    pass  # a handful of edge/curve types raise on arc_center/radius/position_at -- skip, not fatal

            # A cylindrical (or conical) FACE -- the round SIDE wall of a
            # shaft, pin, or straight hole bore, clicked somewhere along
            # its length rather than right at an end edge -- doesn't have
            # a single "center point" the way a circle does, but it does
            # have an axis (Face.axis_of_rotation). The "center" for a
            # click here is the point on that axis closest to the click,
            # i.e. the axis position at the SAME height/depth as the
            # click -- exactly what "hole center" means for a shaft, just
            # extended along its length instead of one fixed point.
            # Ranked the same way as a circular edge's own center above:
            # distance from click to this candidate is ~= the
            # cylinder/cone's radius at that point (since the click sits
            # ON the surface), so it competes fairly against circular-
            # edge candidates using the exact same distance-based "auto"
            # pooling, not a separate tolerance band.
            for i, f in enumerate(shape.faces()):
                try:
                    gt = f.geom_type
                    if gt in (brep.bd.GeomType.CYLINDER, brep.bd.GeomType.CONE):
                        axis = f.axis_of_rotation
                        if axis is None:
                            continue
                        ax, ay, az = axis.position.X, axis.position.Y, axis.position.Z
                        dx, dy, dz = axis.direction.X, axis.direction.Y, axis.direction.Z
                        t = (px - ax) * dx + (py - ay) * dy + (pz - az) * dz
                        cx, cy, cz = ax + t * dx, ay + t * dy, az + t * dz
                        d = ((cx - px) ** 2 + (cy - py) ** 2 + (cz - pz) ** 2) ** 0.5
                        result = {
                            "kind": "hole_center", "point": [cx, cy, cz], "axis_dir": [dx, dy, dz],
                            "highlight_kind": "faces", "highlight_index": i,
                        }
                        try:
                            radius = f.radius  # only meaningful (non-None) for a CYLINDER, not a CONE
                            if radius is not None:
                                result["radius"] = radius
                        except Exception:
                            pass
                        consider(d, result)
                    else:
                        # A TOROIDAL face -- the swept outer wall of a bent tube/
                        # pipe elbow, most commonly -- has no single axis line the
                        # way a cylinder/cone does (the click sits ~majorRadius
                        # away from the revolution axis, not right next to it), so
                        # it needs its own case entirely; without this, a click on
                        # a bend's outer surface fell through to whatever circular
                        # edge/cylindrical face happened to be geometrically
                        # closest (e.g. the tube's own STRAIGHT-section cross-
                        # sectional radius, or a nearby flange bolt hole), silently
                        # giving the wrong "radius" -- or nothing at all if
                        # kind_filter is forced to "hole_center" (the Radius/O
                        # tool always does this) and every other candidate is
                        # farther away than gets returned. Reported directly:
                        # "It is not able to show the bending radius of the
                        # tube" -- and, after this branch was first added gated
                        # on `gt == brep.bd.GeomType.TORUS`, STILL reported
                        # unfixed: "it shows the radius of the section which is
                        # 10 and is correct, but it doesn't show the bend
                        # radius". That follow-up is exactly what this rewrite
                        # addresses: this branch is now an unconditional `else`
                        # (tried for EVERY face that isn't already a CYLINDER/
                        # CONE), deliberately NOT gated on `f.geom_type ==
                        # TORUS` at all -- checking the raw OCCT surface
                        # adaptor's own GeomAbs_Torus type directly below
                        # instead. build123d's `Face.geom_type` and the raw
                        # `BRepAdaptor_Surface(...).GetType()` are two SEPARATE
                        # classification paths, and for a swept/lofted elbow --
                        # a bend built as a general sweep rather than a
                        # canonical torus primitive in the source CAD, an
                        # extremely common way to author one -- it's entirely
                        # possible for the raw OCCT surface to still be a true,
                        # analytic torus (GeomAbs_Torus) even when build123d's
                        # own higher-level property doesn't report it as one.
                        # Gating on `f.geom_type` first (the ORIGINAL version of
                        # this branch) meant that mismatch silently skipped the
                        # face entirely, with every click on it then falling
                        # through to the globally-nearest OTHER candidate
                        # instead -- explaining exactly the reported symptom:
                        # the SAME wrong "section" radius (10) no matter where
                        # on the visibly curved bend you clicked, since the bend
                        # face itself was never even considered. This is the
                        # same "don't trust the type tag alone" lesson already
                        # applied to circular EDGES via _fit_circle_3d() above
                        # (Edge.geom_type != CIRCLE didn't mean "not a circle"
                        # there either) -- same fix, one level up, for FACES.
                        #
                        # A torus's OWN geometry already carries the bend radius
                        # as an exact constant -- gp_Torus.MajorRadius(), the
                        # radius of the circle the TUBE'S CENTERLINE sweeps along
                        # (exactly "bend radius" in the pipe-fabrication sense,
                        # e.g. drawing callouts like "R38 CLR") -- so there's no
                        # need to derive it from the click at all, unlike the
                        # CYLINDER/CONE case above. What DOES depend on the click
                        # is which point on that sweep circle to center the
                        # dimension on: "point" here is deliberately the torus's
                        # own Location -- the fixed pivot point in the plane of
                        # the bend that every cross-section sweeps around (for a
                        # 90-degree elbow, geometrically the corner where the two
                        # straight pipe run's centerlines, extended, would meet)
                        # -- not a point on the tube surface itself, exactly
                        # mirroring how a hole's own center is returned even
                        # though it's not a point ON the hole's rim either.
                        # "axis_dir" is the torus's main (revolution) axis, which
                        # the frontend already knows how to turn into both an
                        # axis line through "point" AND (by stripping the
                        # along-axis component of the click and scaling the rest
                        # out to "radius") the correct "radial spoke" landing
                        # exactly on the bend's centerline circle at the SAME
                        # sweep angle as the click -- the same
                        # resolveDim3dEnd()/createDim3dFeatureHighlight() path
                        # every other hole_center result already goes through, no
                        # frontend change needed for this to just work.
                        try:
                            from OCP.BRepAdaptor import BRepAdaptor_Surface
                            from OCP.GeomAbs import GeomAbs_Torus
                        except Exception:
                            continue  # OCP not available in this environment -- skip, not fatal
                        try:
                            adaptor = BRepAdaptor_Surface(f.wrapped)
                        except Exception:
                            continue  # some face types can't build an adaptor at all -- skip, not fatal
                        if adaptor.GetType() != GeomAbs_Torus:
                            continue  # a real non-toroidal face (planar, BSpline, etc.) -- not this branch's job
                        torus = adaptor.Torus()
                        major_r = torus.MajorRadius()
                        ax3 = torus.Position()
                        loc = ax3.Location()
                        w = ax3.Direction()
                        ox, oy, oz = loc.X(), loc.Y(), loc.Z()
                        wx, wy, wz = w.X(), w.Y(), w.Z()
                        vx, vy, vz = px - ox, py - oy, pz - oz
                        h = vx * wx + vy * wy + vz * wz
                        rx, ry, rz = vx - h * wx, vy - h * wy, vz - h * wz
                        rlen = (rx * rx + ry * ry + rz * rz) ** 0.5
                        if rlen < 1e-9:
                            continue  # click landed essentially on the axis itself -- no well-defined sweep angle
                        # Distance from the click to the bend's own centerline
                        # circle AT the click's sweep angle -- for a click
                        # genuinely on this torus's surface this is exactly the
                        # tube's own cross-section (minor) radius, the same
                        # "surface sits `radius`-away-from-its-own-defining-
                        # curve" convention the CYLINDER case above uses for
                        # ranking, so a small local feature still outranks a
                        # big sweeping bend surface in "auto" mode.
                        ccx = ox + major_r * rx / rlen
                        ccy = oy + major_r * ry / rlen
                        ccz = oz + major_r * rz / rlen
                        d = ((px - ccx) ** 2 + (py - ccy) ** 2 + (pz - ccz) ** 2) ** 0.5
                        result = {
                            "kind": "hole_center", "point": [ox, oy, oz], "axis_dir": [wx, wy, wz],
                            "radius": major_r,
                            "highlight_kind": "faces", "highlight_index": i,
                        }
                        consider(d, result)
                except Exception:
                    pass  # non-rotational/degenerate faces, etc. -- skip, not fatal

        if kind_filter in ("auto", "edge"):
            for i, e in enumerate(shape.edges()):
                try:
                    d = e.distance_to((px, py, pz))
                except Exception:
                    continue
                if best[0] is not None and d >= best[0]:
                    continue  # can't win against the current best -- skip the position_at() calls below
                a = e.position_at(0.0)
                b = e.position_at(1.0)
                consider(d, {
                    "kind": "edge", "a": [a.X, a.Y, a.Z], "b": [b.X, b.Y, b.Z],
                    "highlight_kind": "edges", "highlight_index": i,
                })

        if kind_filter == "face":  # never part of "auto" -- see docstring
            for i, f in enumerate(shape.faces()):
                try:
                    d = f.distance_to((px, py, pz))
                except Exception:
                    continue
                if best[0] is not None and d >= best[0]:
                    continue  # can't win against the current best -- skip the plane/closest-point work below
                plane = None
                try:
                    plane = f.is_planar  # a Plane (origin + z_dir normal) if planar, else None
                except Exception:
                    plane = None
                if plane is not None:
                    consider(d, {
                        "kind": "face", "planar": True,
                        "point": [plane.origin.X, plane.origin.Y, plane.origin.Z],
                        "normal": [plane.z_dir.X, plane.z_dir.Y, plane.z_dir.Z],
                        "highlight_kind": "faces", "highlight_index": i,
                    })
                else:
                    try:
                        _, p_on_face, _ = f.distance_to_with_closest_points((px, py, pz))
                        pt = [p_on_face.X, p_on_face.Y, p_on_face.Z]
                    except Exception:
                        pt = [px, py, pz]  # last-resort fallback, shouldn't normally hit
                    consider(d, {
                        "kind": "face", "planar": False, "point": pt,
                        "highlight_kind": "faces", "highlight_index": i,
                    })
    except Exception as e:
        return {"_status": 400, "error": str(e)}

    if best[1] is None:
        if kind_filter == "vertex":
            msg = "This shape has no vertices to pick."
        elif kind_filter == "hole_center":
            msg = "This shape has no circular edges (holes) to pick a center from -- try Pick: Auto or Edge instead."
        elif kind_filter == "edge":
            msg = "This shape has no edges to pick."
        elif kind_filter == "face":
            msg = "This shape has no faces to pick."
        else:
            msg = "Nothing pickable on this shape."
        return {"_status": 400, "error": msg}
    result = best[1]
    result["distance"] = best[0]
    return result


def _probe_max_fillet(PE, brep, cmd):
    """Moved verbatim from server.py's old /probe_max_fillet handler."""
    var_name = cmd.get("variable", "")
    indices = cmd.get("indices", [])
    shape = PE.get_persisted_var(var_name)
    if shape is None:
        return {"radii": [0] * len(indices), "error": (
            f"No variable named '{var_name}' in memory. Render your "
            f"script at least once first, then try again."
        )}
    all_edges = list(shape.edges())
    radii = []
    for i in indices:
        try:
            e = all_edges[int(i)]
            radii.append(brep.max_fillet_radius(shape, [e], max_iterations=20))
        except Exception:
            radii.append(0)
    return {"radii": radii}


def _probe_highlight(PE, brep, cmd):
    """Moved verbatim from server.py's old /probe_highlight handler."""
    var_name = cmd.get("variable", "")
    indices = cmd.get("indices", [])
    kind = cmd.get("kind", "edges")
    shape = PE.get_persisted_var(var_name)
    if shape is None:
        return {"curves": [], "error": (
            f"No variable named '{var_name}' in memory. Render your "
            f"script at least once first, then try again."
        )}
    try:
        if kind == "faces":
            all_items = list(shape.faces())
            selected = [all_items[int(i)] for i in indices]
            edges_to_sample = [e for f in selected for e in f.edges()]
        else:
            all_items = list(shape.edges())
            edges_to_sample = [all_items[int(i)] for i in indices]
        n_samples = 12
        curves = []
        for e in edges_to_sample:
            pts = [e.position_at(k / n_samples) for k in range(n_samples + 1)]
            curves.append([[p.X, p.Y, p.Z] for p in pts])
        return {"curves": curves}
    except Exception as e:
        return {"curves": [], "error": str(e)}


def _drawing(PE, brep, cmd):
    """Runs `cmd["code"]` fresh (same as a normal render) and, unlike
    the "render" op, actually KEEPS the resulting `scene` list this
    process gets back from PE.run_python_script() (the "render" op
    above discards it into `_scene` -- see that function's own
    docstring: it's only ever thrown away because a render reply just
    needs the already-JSON-safe `result` dict for the 3D viewer).
    Every Mesh in `scene` that came from a real B-rep Shape (i.e. every
    show()n object built with brep.py's own cube()/sphere()/etc, NOT
    the raw openscad4 mesh-bridge escape hatch) carries that Shape on
    its own .brep_shape attribute (see python_eval.py's module
    docstring) -- exactly what's needed here, since real hidden-line-
    removal needs genuine B-rep topology, not the already-tessellated
    triangles server.py's /export/* routes work with.

    This is why "drawing" is its own op rather than reusing "render"'s
    reply: the live Shape objects can only be reached from INSIDE this
    process, during/right after the script that produced them actually
    runs -- by the time a reply dict crosses back over the queue to
    server.py, everything left is plain JSON, same as the module
    docstring at the top of this file promises."""
    result, scene = PE.run_python_script(
        cmd.get("code", ""), cmd.get("csg_resolution", 56),
        persist=cmd.get("persist", True),
    )
    if result.get("error"):
        return {"error": result["error"]}
    shapes = [m.brep_shape for m in (scene or []) if getattr(m, "brep_shape", None) is not None]
    if not shapes:
        return {"error": (
            "nothing to draw -- the shown shape(s) don't have real B-rep "
            "geometry to compute hidden-line-removed views from (e.g. they "
            "came from the raw openscad4 mesh-bridge escape hatch rather "
            "than brep.py's own cube()/sphere()/etc)."
        )}

    # REAL PERFORMANCE FIX (user report: a large imported STEP file's
    # Drawing tab "loading drawing" never finishing, even though the
    # same file's 3D viewer -- one tessellation pass -- renders fast).
    # technical_drawing_views() defaults n_samples=48 (chosen for
    # visual smoothness on typical hand-built parts, see its own
    # docstring), and pays that per EDGE per VIEW (4 independent real
    # HLR passes for the default FRONT/TOP/RIGHT/ISO set, each its own
    # full project_to_viewport() call -- there's no cheaper "reuse the
    # last view's work" shortcut, different views expose different
    # edges). _hlr_polylines() already skips the extra sampling on
    # straight edges (see its own docstring), but a genuinely huge
    # imported assembly can still have thousands of CURVED edges (every
    # fillet, every hole, every thread) where that shortcut doesn't
    # apply. Rather than always paying full smoothness cost regardless
    # of edge count, count edges once up front and scale n_samples down
    # for edge-heavy shapes -- nobody can tell a hole is a 48-gon vs a
    # 16-gon on a drawing sheet already showing a few thousand other
    # edges, but the sampling cost difference is real. Small/typical
    # parts (the common case) are completely unaffected.
    total_edges = 0
    for s in shapes:
        try:
            total_edges += len(s.edges())
        except Exception:
            pass  # best-effort -- if this shape doesn't support edges() for
                   # some reason, just don't let it affect the estimate
    if total_edges > 6000:
        n_samples = 8
    elif total_edges > 2000:
        n_samples = 16
    elif total_edges > 800:
        n_samples = 24
    else:
        n_samples = 48  # technical_drawing_views()'s own default

    try:
        views = brep.technical_drawing_views(
            shapes, views=cmd.get("views"),
            custom_views=cmd.get("custom_views"),
            sections=cmd.get("sections"),
            n_samples=n_samples,
            include_hidden=cmd.get("include_hidden", True),
            # REAL FIX (user report: a 26MB STEP file's Drawing tab still
            # hadn't loaded after 5+ minutes): each of the default 4
            # views is its own completely independent, potentially very
            # expensive OCCT HLR pass (see technical_drawing_views()'s
            # own docstring for exactly why) -- without a shared budget,
            # one unusually slow view (e.g. ISO, which typically has the
            # most overlapping/self-occluding geometry to resolve)
            # silently blocks every view queued after it, even ones that
            # would have finished in seconds. 180s here is generous for
            # anything but a genuinely huge/complex model, and CANNOT
            # help the one specific case this alone doesn't fix -- a
            # single view that's itself slower than the whole budget
            # (nothing can interrupt an already-running native OCCT
            # call) -- see the "views" request param (cmd.get("views")
            # above) for the real mitigation for THAT case: requesting
            # just 1-2 views up front instead of all 4.
            time_budget_s=180.0,
        )
    except Exception as e:
        return {"error": str(e)}
    reply = {"views": views}
    if n_samples < 48:
        reply["warning"] = (
            f"this model has {total_edges} edges -- curve smoothness was "
            f"automatically reduced (n_samples={n_samples}) to keep the "
            "drawing responsive. Call technical_drawing_views()/"
            "export_drawing_svg() directly with your own n_samples if you "
            "need finer curves and can wait longer."
        )
    return reply


def worker_main(cmd_q, result_q):
    """Entry point passed to multiprocessing.Process(target=...) --
    runs forever (until the process is killed by kernel_manager.py, or
    told to stop via the None sentinel) reading one command dict at a
    time off cmd_q and putting exactly one reply dict on result_q for
    each. Deliberately single-threaded/single-request-at-a-time: the
    manager's own call() already serializes callers with a lock before
    a command is ever put here, matching the single-flight guarantee
    server.py's old _OCCT_LOCK used to provide, but scoped to this
    process alone now instead of the whole app.

    python_eval/brep are imported HERE (inside the child), not at
    module level -- this is what gives every fresh kernel (every
    restart) a genuinely clean, from-scratch build123d/OCCT state, the
    same way a real Jupyter kernel restart re-imports everything from
    zero rather than just clearing a namespace inside an already-
    running interpreter."""
    import python_eval as PE
    import brep

    while True:
        try:
            cmd = cmd_q.get()
        except (EOFError, OSError):
            break
        if cmd is None:
            break  # clean-shutdown sentinel (not currently sent anywhere --
                    # restarts kill the process outright -- but harmless to
                    # support for a possible future graceful-stop path)

        op = cmd.get("op")
        try:
            if op == "render":
                result, _scene = PE.run_python_script(
                    cmd.get("code", ""),
                    cmd.get("csg_resolution", 56),
                    persist=cmd.get("persist", True),
                )
                reply = result
            elif op == "kernel_status":
                reply = {"persisted_vars": PE.persisted_variable_names()}
            elif op == "probe_pick":
                reply = _probe_pick(PE, brep, cmd)
            elif op == "probe_dim_pick":
                reply = _probe_dim_pick(PE, brep, cmd)
            elif op == "probe_max_fillet":
                reply = _probe_max_fillet(PE, brep, cmd)
            elif op == "probe_highlight":
                reply = _probe_highlight(PE, brep, cmd)
            elif op == "drawing":
                reply = _drawing(PE, brep, cmd)
            else:
                reply = {"error": f"unknown kernel op: {op!r}"}
        except Exception as e:
            # Belt-and-suspenders: run_python_script() already catches
            # everything a *script* can throw and reports it in
            # result["error"] instead of raising -- this outer catch is
            # only for a bug in this dispatch code itself (or a probe_*
            # helper) misbehaving, so one bad request can't silently
            # starve result_q of its reply and hang the caller forever.
            traceback.print_exc()
            reply = {"error": f"internal kernel error: {e}"}

        try:
            result_q.put(reply)
        except Exception:
            # If the manager already gave up on us (e.g. a restart
            # raced this exact reply), there's nothing useful to do --
            # this process is about to be killed anyway.
            pass
