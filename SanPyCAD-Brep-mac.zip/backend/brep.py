"""
brep.py -- an OpenSCAD-flavored wrapper around build123d: this IS the
geometry engine for SanPyCAD Brep. Every primitive/transform/boolean/
fillet a script calls (see python_eval.py's make_namespace()) is one of
the functions below, producing genuine boundary-representation (B-rep)
solids, not triangle meshes -- exact analytic surfaces (planes,
cylinders, cones, spheres) or exact NURBS surfaces, exact curves for
edges, held together as an exact topological structure (faces bounded
by edge loops, edges bounded by vertices) rather than a pile of flat
triangles. STEP files are built entirely around that model -- that's
why a mesh can only ever be SMUGGLED into a STEP file as "tessellated"
(faceted) geometry, not real B-rep; export_step()/export_brep() below
write the genuine thing.

Writing an actual B-rep kernel (robust NURBS intersection, exact
booleans, fillets, tolerance handling) from scratch is a many-person-
years undertaking -- not something to reproduce here. Instead this
module builds on OpenCASCADE Technology (OCCT), the same open-source
B-rep kernel FreeCAD itself is built on, via build123d -- a Python CAD
library with a code-first style, in an OpenSCAD-like vocabulary
(cube/cylinder/sphere, translate/rotate, union/difference/intersection)
so it reads like the mesh-based SanPyCAD apps' scripts, just backed by
real exact solids instead of triangle soup.

Requires build123d -- the one hard third-party dependency of this whole
app (see requirements.txt / README.md):
    pip install build123d
build123d itself pulls in OCP (the OpenCASCADE Python bindings) as a
pip-installable wheel, no conda/compiling required on a normal
Windows/macOS/Linux install. If it isn't installed, this module still
imports cleanly (so e.g. the doc/reference scanner in server.py can
still load it) -- every function just raises a clear "pip install
build123d" ImportError the moment a script actually calls one (see
_require_build123d()).

IMPORTANT -- this module has been written and structurally checked
against a MOCKED build123d (fake bd.Box/bd.Cylinder/etc recording every
call) but has NOT been run against a real build123d install: this
sandbox has no network access to pip install it. The wiring (which
build123d functions get called, with what arguments, in what order) has
been verified; the actual geometry math (is a Cone's r1/r2/h convention
really what cube()/cylinder()'s docstrings below claim, does
translate() move things the direction you'd expect) has NOT. Please
pip install build123d, run the examples in examples/, or the smoke test
at the bottom of this file (`python3 backend/brep.py`), and report back
what breaks or looks wrong. rotate()/rot() are built entirely out of
single-axis rotations chained together (never a combined multi-axis
call), specifically so they don't depend on build123d's own multi-axis
composition convention, which its docs don't pin down clearly enough to
rely on directly -- so those two should be trustworthy even though the
rest of this is unverified.

Basic usage:
    a = cylinder(r1=20, r2=0, h=20)
    b = box([10, 10, 40], center=True)
    c = difference(a, translate([0, 0, -10], b))
    export_step(c, "cone_notched.step")
    show(c)   # SanPyCAD Brep's own viewer (see python_eval.py's show())
"""

import math
import re
import time

import numpy as np

import drawing_layout

try:
    import build123d as bd
    _HAVE_BUILD123D = True
    _IMPORT_ERROR = None
except Exception as _e:  # pragma: no cover - exercised via test_brep.py mocking
    bd = None
    _HAVE_BUILD123D = False
    _IMPORT_ERROR = _e

# build123d's own Keep enum (TOP/BOTTOM/BOTH), re-exported here so a
# script can write Keep.BOTTOM directly -- see split()'s own docstring
# below for why. None if build123d isn't installed (matches `bd` itself
# -- see _require_build123d()); accessing Keep.BOTTOM in that case just
# raises a plain AttributeError, same as any other brep.py function
# would fail before ever reaching a real geometry error.
Keep = bd.Keep if _HAVE_BUILD123D else None

# build123d's own Polyline class, re-exported the same way as Keep
# above -- a straight-line-segments-only Wire through any 2D or 3D
# point list, open (default) or closed (close=True), e.g.
# Polyline([0,0,0], [10,0,0], [10,5,3]). Unlike polygon() (this app's
# own helper, just below), Polyline() isn't limited to a flat XY
# profile and doesn't force the loop closed -- it's the general
# "any point list -> a real B-rep Wire" building block, meant for
# paths (sweep_sec2path()'s path3d argument) as much as flat profiles.
# Note it hands back a bare Wire, not a filled Face -- pass it through
# face_from_wire() first if you need a profile to extrude/sweep, and
# use line3d(points, d=...) instead if you just want to see it in the
# viewer (show()/to_mesh() can't tessellate a bare Wire directly).
Polyline = bd.Polyline if _HAVE_BUILD123D else None

# build123d's own Wire class, re-exported the same way -- mainly so
# Wire.make_convex_hull(edges) (the exact, real-arcs-not-facets convex
# hull of a set of edges -- see hull()'s own docstring below for how
# that differs from THIS app's own hull()) and Wire.combine(edges) are
# available directly in a script with no import needed.
Wire = bd.Wire if _HAVE_BUILD123D else None


def _require_build123d():
    """
    internal: importing brep.py itself never fails just because
    build123d isn't installed yet (so e.g. a doc/reference scanner can
    still load this file) -- but every function that actually needs it
    calls this first, so you get one clear, actionable error instead of
    a confusing AttributeError on `bd`.
    """
    if not _HAVE_BUILD123D:
        raise ImportError(
            "brep.py needs the 'build123d' package, which isn't installed "
            "in this Python environment. Install it with:\n"
            "    pip install build123d\n"
            f"(original import error: {_IMPORT_ERROR!r})"
        )


def _align(center):
    """
    internal: openscad4.py's cube() uses a plain `center` bool (True =
    centered on the origin, False = one corner sitting at the origin,
    same as real OpenSCAD) -- build123d instead uses an explicit Align
    enum per axis. This is the single place that translates one
    convention into the other for BOX-shaped primitives (a box has an
    actual corner on every axis, so `center` genuinely applies to
    X/Y/Z alike) -- for circular-cross-section primitives (cylinder()/
    cone()) use _align_radial() below instead, NOT this.
    """
    a = bd.Align.CENTER if center else bd.Align.MIN
    return (a, a, a)


def _align_radial(center):
    """
    internal: real OpenSCAD's cylinder(center=...) ONLY ever affects
    Z (False: base circle sits at z=0, spanning up to z=h; True:
    centered on Z too) -- X and Y are ALWAYS centered on the shape's
    own axis regardless of `center`, because a circle has no "corner"
    the way a box does. REAL BUG FIX (found via a real user report --
    a cylinder(center=False) landing with its axis offset to (r,r)
    instead of (0,0)): cylinder() used to reuse _align() above, which
    applies the SAME Align enum to all three axes -- correct for box()
    (whose corner really is at (0,0,0) when center=False), but wrong
    here, since build123d's Align.MIN on a circular Face/Solid shifts
    its BOUNDING BOX's corner to the origin, i.e. shifts the axis
    itself to (radius, radius) -- not the "base circle centered at
    (0,0), sitting at z=0" real OpenSCAD gives you. This function is
    the fix: X/Y are unconditionally CENTER, only Z follows `center`.
    """
    z = bd.Align.CENTER if center else bd.Align.MIN
    return (bd.Align.CENTER, bd.Align.CENTER, z)


def box(size=1, center=False):
    """
    A B-rep rectangular solid -- `size` is either one number (a cube) or
    [x,y,z] (a box), `center` follows real OpenSCAD's meaning (False:
    one corner sits at the origin; True: centered on the origin).
    Builds a build123d Box under the hood.
    """
    _require_build123d()
    if isinstance(size, (int, float)):
        sx = sy = sz = float(size)
    else:
        sx, sy, sz = [float(v) for v in size]
    return bd.Box(sx, sy, sz, align=_align(center))


def cube(size=1, center=False):
    """Alias for box() under OpenSCAD's own name for this primitive."""
    return box(size, center)


def cylinder(r1=None, r2=None, h=1, r=None, center=False, s=None):
    """
    A B-rep cylinder or (truncated) cone -- same r1/r2/h/r/center
    parameters as real OpenSCAD's cylinder(). `s` (segment count /
    $fn) is accepted only for drop-in call compatibility and is
    IGNORED: this is exact geometry, there's no facet count to choose
    -- a cylinder here really is round, not a many-sided prism
    approximating one.

    r1/r2 both given (and different) -> build123d Cone(r1, r2, h).
    Otherwise (r, or matching r1==r2) -> build123d Cylinder(radius, h).
    """
    _require_build123d()
    if r is not None:
        rad1 = rad2 = float(r)
    else:
        rad1 = float(r1) if r1 is not None else 1.0
        rad2 = float(r2) if r2 is not None else rad1
    align = _align_radial(center)
    if rad1 == rad2:
        return bd.Cylinder(rad1, float(h), align=align)
    return bd.Cone(rad1, rad2, float(h), align=align)


def sphere(r=1):
    """A B-rep sphere -- same `r` meaning as openscad4.py's sphere()."""
    _require_build123d()
    return bd.Sphere(float(r))


# ---------------------------------------------------------------------
# 2D profiles -- feed these into linear_extrude()/rotate_extrude() to
# turn them into a solid, the same role openscad4.py's own circle()/
# square()/polygon() play there, just returning a real build123d Sketch
# (a bounded planar Face) instead of a bare [x,y] point list.
# ---------------------------------------------------------------------

def circle(r=1, cp=[0, 0], s=None):
    """
    A B-rep 2D disc, centered at the origin by default -- same as real
    OpenSCAD's circle(r) (which is likewise always centered; real
    OpenSCAD's circle() has no `center` parameter -- use `cp` to shift
    it instead, or translate() the result).

    `s` (segment count -- same name/meaning as openscad4.py's own
    circle(r, cp, s)) controls whether this is exact or faceted:

      s=None (the default) -- an exact round B-rep circle. No facet
      count needed, since the underlying curve is exact -- this is
      different from openscad4.py's circle() (which always faceted,
      defaulting to s=50) and from real OpenSCAD's circle() (which
      always faceted too, at whatever $fn/$fa/$fs resolve to); deviates
      from both on purpose, since "exact" is strictly better than "a
      50-sided polygon" when nothing forces a facet count in the first
      place.

      s=<some integer> -- instead builds an s-sided regular polygon
      approximating a circle (via polygon()), the same way
      openscad4.py's circle() does (this is also how real OpenSCAD's
      own circle($fn=...) behaves at a low $fn/segment count). Useful
      for genuinely wanting flat sides, not just an approximation:
      circle(10, s=6) is a hexagon, circle(10, s=3) a triangle, etc.
    """
    _require_build123d()
    if s is None:
        out = bd.Circle(float(r))
    else:
        n = int(s)
        if n < 3:
            raise ValueError(
                f"circle(): s must be at least 3 (a triangle) to form a polygon, got {s!r}")
        pts = [[r * math.cos(2 * math.pi * i / n), r * math.sin(2 * math.pi * i / n)]
               for i in range(n)]
        out = polygon(pts)
    if cp[0] or cp[1]:
        out = translate([cp[0], cp[1], 0], out)
    return out


def square(size=1, center=False):
    """
    A B-rep 2D rectangle -- same call convention as OpenSCAD's
    square(): `size` is either one number (a square) or [x,y], `center`
    follows OpenSCAD's meaning (False: one corner sits at the origin;
    True: centered on the origin).
    """
    _require_build123d()
    if isinstance(size, (int, float)):
        sx = sy = float(size)
    else:
        sx, sy = [float(v) for v in size]
    a = bd.Align.CENTER if center else bd.Align.MIN
    return bd.Rectangle(sx, sy, align=(a, a))


def _segments_cross(p1, p2, p3, p4):
    """internal: True if 2D segments p1-p2 and p3-p4 PROPERLY cross
    each other (excluding merely touching at a shared point/endpoint,
    which is fine for a polygon loop -- only an actual crossing makes
    it self-intersecting)."""
    def ccw(a, b, c):
        return (c[1] - a[1]) * (b[0] - a[0]) - (b[1] - a[1]) * (c[0] - a[0])
    d1, d2 = ccw(p3, p4, p1), ccw(p3, p4, p2)
    d3, d4 = ccw(p1, p2, p3), ccw(p1, p2, p4)
    return (d1 != 0 and d2 != 0 and (d1 > 0) != (d2 > 0)
            and d3 != 0 and d4 != 0 and (d3 > 0) != (d4 > 0))


def _find_self_intersection(pts):
    """internal: (i, j) indices of the first pair of non-adjacent
    closed-loop edges of `pts` that cross each other, or None if the
    loop is simple (no self-intersections)."""
    n = len(pts)
    edges = [(pts[i], pts[(i + 1) % n]) for i in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            if j == i + 1 or (i == 0 and j == n - 1):
                continue
            if _segments_cross(edges[i][0], edges[i][1], edges[j][0], edges[j][1]):
                return (i, j)
    return None


def polygon(points):
    """
    A B-rep 2D filled polygon through `points` ([[x,y], ...] -- the same
    shape openscad4.py's own circle()/square() return, and what
    OpenSCAD's polygon(points) takes). Unlike those, the winding order
    of `points` controls which way the resulting face's normal points
    (counter-clockwise -> +Z-facing normal, clockwise -> -Z-facing) --
    which matters for linear_extrude()'s default extrude direction.

    The loop is closed automatically (the last point connects straight
    back to the first) -- don't append `points[0]` again to "close" it
    yourself, that creates a zero-length closing edge (invalid
    geometry, since the polygon is then closed twice) rather than
    actually closing anything; if `points` does end with a near-exact
    repeat of its own first point, that repeat is dropped for you.

    That auto-added closing edge has to not cross `points`' own
    outline anywhere, or the result is a self-intersecting (invalid)
    shape -- easy to hit by accident when `points` comes from an open
    curve (bezier()/bspline_open()/etc) whose two ends don't line up
    with its own overall direction. Checked and raised here with a
    clear error pointing at which two points cross, rather than
    silently building invalid geometry that only fails much later,
    cryptically, when the viewer tries to tessellate it.

    Only builds a FLAT profile in the XY plane -- a nonzero z on any
    point RAISES rather than being silently dropped (a real user hit
    this: axis_rot_1_pts()-ing a point list out of the XY plane, then
    handing it to polygon() expecting the bend to carry through --
    it didn't, since a flat Face has no way to represent it, and the
    z values were just discarded with no warning). If `points` is
    already positioned/bent in 3D, use p_line3d(points, ...) to trace
    it directly as a tube instead (no flattening); if you actually
    want a flat profile repositioned in 3D, build it flat here first
    and move/rotate the resulting real Shape afterward with
    translate()/rotate()/axis_rot_1() instead of pre-rotating the raw
    points.
    """
    _require_build123d()
    for i, p in enumerate(points):
        if len(p) > 2 and abs(float(p[2])) > 1e-6:
            raise ValueError(
                f"polygon(): point {i} has a nonzero z ({p[2]!r}) -- polygon() "
                f"only builds a flat profile in the XY plane and would silently "
                f"drop it (see polygon()'s own docstring). Use p_line3d(points, "
                f"...) to trace an already-3D point list directly instead, or "
                f"build the flat profile here and reposition the resulting "
                f"Shape afterward with translate()/rotate()/axis_rot_1().")
    pts = [(float(p[0]), float(p[1])) for p in points]
    if len(pts) > 1 and math.hypot(pts[-1][0] - pts[0][0], pts[-1][1] - pts[0][1]) < 1e-9:
        pts = pts[:-1]
    hit = _find_self_intersection(pts)
    if hit is not None:
        i, j = hit
        raise ValueError(
            f"polygon(): the closed loop through `points` crosses itself, "
            f"between the edge after point {i} and the edge after point {j} "
            f"-- not a valid simple polygon. If `points` came from an open "
            f"curve, check whether its own closing edge (last point back to "
            f"first) crosses the curve -- see polygon()'s own docstring.")
    return bd.Polygon(*pts)


def turtle2d(offsets):
    """
    Converts a list of relative [dx, dy] offsets into absolute [x, y]
    points via a running cumulative sum -- "turtle graphics" style path
    building: each entry means "move this far from wherever you just
    were", not an absolute coordinate. Feed the result into polygon()
    to sketch a closed outline from turtle-style steps instead of
    typing out absolute coordinates by hand:
        sec = turtle2d([[0,0],[10,0],[0,5],[-10,0]])   # a 10x5 rectangle
        show(linear_extrude(polygon(sec), h=3))

    Plain Python -- no build123d involved, just produces the point list
    polygon() then turns into a real B-rep face.
    """
    x, y = 0.0, 0.0
    out = []
    for dx, dy in offsets:
        x += float(dx)
        y += float(dy)
        out.append([x, y])
    return out


def turtle3d(offsets):
    """
    Converts a list of relative [dx, dy, dz] offsets into absolute
    [x, y, z] points via a running cumulative sum -- the 3D counterpart
    of turtle2d() (see its docstring). Each entry means "move this far
    from wherever you just were", not an absolute coordinate:
        path = turtle3d([[0,0,0],[10,0,0],[0,0,10],[0,10,0]])
        # -> [[0,0,0], [10,0,0], [10,0,10], [10,10,10]]

    Plain Python -- no build123d involved. There's no 3D polyline/sweep
    primitive in brep.py yet to feed this straight into, but it's handy
    for building a 3D point path to pass to your own build123d curve
    construction in a script, e.g.:
        from build123d import Polyline
        wire = Polyline(*turtle3d(offsets))
    or for sanity-checking a path's shape with echo()/show_edges()-style
    inspection before using it elsewhere.
    """
    x, y, z = 0.0, 0.0, 0.0
    out = []
    for dx, dy, dz in offsets:
        x += float(dx)
        y += float(dy)
        z += float(dz)
        out.append([x, y, z])
    return out


def _2d_unit(v):
    """internal: unit 2D vector, or raises if `v` is (numerically) zero."""
    n = math.hypot(v[0], v[1])
    if n < 1e-12:
        raise ValueError("cr2dt(): a zero-length edge in the path")
    return (v[0] / n, v[1] / n)


def _3d_unit(v):
    """internal: unit 3D vector, or raises if `v` is (numerically) zero."""
    n = math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
    if n < 1e-12:
        raise ValueError("cr3dt(): a zero-length edge in the path")
    return (v[0] / n, v[1] / n, v[2] / n)


def _3d_cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _3d_dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def cr2dt(sec, s=20):
    """
    Builds a closed 2D outline from turtle-style relative [dx,dy] (or
    [dx,dy,r]) offsets, rounding each vertex with a fillet arc of
    radius r (0 -- the default when a point omits it -- means "leave
    this vertex sharp").

    s (segment count -- same s=None/s=<int> meaning as circle()'s own
    `s`) controls whether the rounded corners are exact or faceted:

      s=<some integer> (the default, 20) -- a plain 2D point list, each
      rounded corner approximated by `s` straight segments, same as
      before this parameter grew the s=None option below. Feed it into
      polygon() for a filled profile:
          sec = cr2dt([[0,0,2],[10,0,2],[0,10,2],[-10,0,2]], 10)
          show(linear_extrude(polygon(sec), h=3))

      s=None -- instead returns a real B-rep Wire, its straight
      stretches exact Line edges and its rounded corners exact circular
      Arc edges (built from the exact same center/radius/tangent-point
      math this function always computes -- s=None just stops
      discretizing that math into sample points and builds the real
      curve from it instead). No facet count needed, same reasoning as
      circle()'s own s=None. Feed the result into face_from_wire() for
      a filled profile instead of polygon() (which takes a point list,
      not a Wire -- see polygon()'s own docstring):
          sec = cr2dt([[0,0,2],[10,0,2],[0,10,2],[-10,0,2]])  # s=None
          show(linear_extrude(face_from_wire(sec), h=3))

    The short name of openscad4.py's corner_radius_with_turtle()
    (cr2dt is that function's own alias there too), reimplemented from
    scratch here -- plain trig (an unsigned "shortest way around" arc
    between the two tangent points at each corner), not a port of the
    original's own ~15-branch case analysis by incoming/outgoing corner
    orientation, since the shortest-way-around trick handles either
    polygon winding direction without needing to tell them apart.

    sec: [[dx,dy], ...] or [[dx,dy,r], ...] -- same turtle convention as
        turtle2d() (each entry moves relative to wherever you just
        were; the first entry is effectively the absolute starting
        point, since the running sum starts at [0,0]), with an optional
        trailing fillet radius per point.
    s: segments per rounded corner when an int (a sharp vertex, r=0, is
        always just 1 point either way); None for an exact Wire instead
        (see above).

    Like corner_radius_with_turtle() itself, this ALWAYS treats `sec`
    as a closed loop -- the corner-rounding at point 0 uses the LAST
    point as its "previous" neighbor, and vice versa -- so if you want
    the first/last points left exactly as given (e.g. building one edge
    of an open profile, not a closed polygon), leave their radius at 0
    (the default when omitted).

    Raises if a requested radius doesn't fit between a vertex and
    either neighboring point (same "radius too large" check the
    original makes, just against each corner's own two edges directly
    here, rather than needing the original's incoming/outgoing-radius
    bookkeeping across the whole loop) -- true whether s is an int or
    None, since both share the same tangent-point math.
    """
    pts = []
    radii = []
    x, y = 0.0, 0.0
    for p in sec:
        x += float(p[0])
        y += float(p[1])
        pts.append((x, y))
        radii.append(float(p[2]) if len(p) > 2 else 0.0)
    n = len(pts)
    if n < 3:
        raise ValueError("cr2dt(): need at least 3 points")

    if s is None:
        _require_build123d()
        entry = [None] * n    # this corner's own entry point (where the
        exitp = [None] * n    # incoming straight edge should stop) and
        arc_edge = [None] * n  # exit point (where the outgoing one resumes)
                               # -- both equal `cur` itself for a sharp
                               # corner (no arc), and the two tangent
                               # points either side of the fillet otherwise.
        for i in range(n):
            cur = pts[i]
            prev_pt = pts[i - 1]
            next_pt = pts[(i + 1) % n]
            r = radii[i]
            if r == 0:
                entry[i] = exitp[i] = cur
                continue
            d1 = (prev_pt[0] - cur[0], prev_pt[1] - cur[1])
            d2 = (next_pt[0] - cur[0], next_pt[1] - cur[1])
            len1 = math.hypot(*d1)
            len2 = math.hypot(*d2)
            u1 = _2d_unit(d1)
            u2 = _2d_unit(d2)
            dot = max(-1.0, min(1.0, u1[0] * u2[0] + u1[1] * u2[1]))
            theta = math.acos(dot)
            if theta < 1e-9 or theta > math.pi - 1e-9:
                entry[i] = exitp[i] = cur
                continue
            tlen = r / math.tan(theta / 2)
            if tlen > len1 or tlen > len2:
                raise ValueError(
                    f"cr2dt(): radius {r} at point {i} is too large for its "
                    f"adjacent edges (needs {tlen:.6g}, edges are "
                    f"{len1:.6g}/{len2:.6g} long)")
            t1 = (cur[0] + u1[0] * tlen, cur[1] + u1[1] * tlen)
            t2 = (cur[0] + u2[0] * tlen, cur[1] + u2[1] * tlen)
            bis_u = _2d_unit((u1[0] + u2[0], u1[1] + u2[1]))
            center_dist = r / math.sin(theta / 2)
            center = (cur[0] + bis_u[0] * center_dist, cur[1] + bis_u[1] * center_dist)
            a1 = math.atan2(t1[1] - center[1], t1[0] - center[0])
            a2 = math.atan2(t2[1] - center[1], t2[0] - center[0])
            d_angle = (a2 - a1 + math.pi) % (2 * math.pi) - math.pi  # shortest way around
            # The arc's own midpoint, evaluated with the exact same
            # parametrization the faceted (s=<int>) branch below samples
            # -- just at k/s=0.5 instead of a whole range of k. Three
            # points (t1, this midpoint, t2) pin down the exact same arc
            # unambiguously, with no start/end-angle-plus-direction sign
            # convention to get right (make_three_point_arc() needs none).
            mid_a = a1 + d_angle / 2.0
            mid_pt = (center[0] + r * math.cos(mid_a), center[1] + r * math.sin(mid_a))
            arc_edge[i] = bd.Edge.make_three_point_arc(
                (t1[0], t1[1], 0.0), (mid_pt[0], mid_pt[1], 0.0), (t2[0], t2[1], 0.0))
            entry[i] = t1
            exitp[i] = t2
        edges = []
        for i in range(n):
            if arc_edge[i] is not None:
                edges.append(arc_edge[i])
            nxt = (i + 1) % n
            a, b = exitp[i], entry[nxt]
            if math.hypot(a[0] - b[0], a[1] - b[1]) > 1e-9:
                edges.append(bd.Edge.make_line((a[0], a[1], 0.0), (b[0], b[1], 0.0)))
        return bd.Wire.combine(edges)[0]

    out = []
    for i in range(n):
        cur = pts[i]
        prev_pt = pts[i - 1]
        next_pt = pts[(i + 1) % n]
        r = radii[i]
        if r == 0:
            out.append([cur[0], cur[1]])
            continue
        d1 = (prev_pt[0] - cur[0], prev_pt[1] - cur[1])
        d2 = (next_pt[0] - cur[0], next_pt[1] - cur[1])
        len1 = math.hypot(*d1)
        len2 = math.hypot(*d2)
        u1 = _2d_unit(d1)
        u2 = _2d_unit(d2)
        dot = max(-1.0, min(1.0, u1[0] * u2[0] + u1[1] * u2[1]))
        theta = math.acos(dot)
        if theta < 1e-9 or theta > math.pi - 1e-9:
            # straight-through or fully-reversed vertex -- no
            # well-defined corner to round; keep the vertex as-is
            out.append([cur[0], cur[1]])
            continue
        tlen = r / math.tan(theta / 2)
        if tlen > len1 or tlen > len2:
            raise ValueError(
                f"cr2dt(): radius {r} at point {i} is too large for its "
                f"adjacent edges (needs {tlen:.6g}, edges are "
                f"{len1:.6g}/{len2:.6g} long)")
        t1 = (cur[0] + u1[0] * tlen, cur[1] + u1[1] * tlen)
        t2 = (cur[0] + u2[0] * tlen, cur[1] + u2[1] * tlen)
        bis_u = _2d_unit((u1[0] + u2[0], u1[1] + u2[1]))
        center_dist = r / math.sin(theta / 2)
        center = (cur[0] + bis_u[0] * center_dist, cur[1] + bis_u[1] * center_dist)
        a1 = math.atan2(t1[1] - center[1], t1[0] - center[0])
        a2 = math.atan2(t2[1] - center[1], t2[0] - center[0])
        d_angle = (a2 - a1 + math.pi) % (2 * math.pi) - math.pi  # shortest way around
        for k in range(s + 1):
            a = a1 + d_angle * k / s
            out.append([center[0] + r * math.cos(a), center[1] + r * math.sin(a)])
    return out


def cr3dt(pnts, s=5):
    """
    3D counterpart of cr2dt() -- builds a closed 3D outline from
    turtle-style relative [dx,dy,dz] (or [dx,dy,dz,r]) offsets,
    rounding each vertex with a fillet arc of radius r. Any two edges
    meeting at a vertex share a plane (two lines through a common point
    always do), so this is the exact same fillet-arc construction
    cr2dt() uses, just built inside that per-corner plane instead of
    always the flat XY one. The short name of openscad4.py's
    corner_radius3d_with_turtle() -- reimplemented from scratch, not a
    port (see cr2dt()'s docstring for why).

    s (same s=None/s=<int> meaning as cr2dt()'s own `s` -- see its
    docstring for the full explanation): an int (default 5) returns a
    plain 3D point list, each rounded corner approximated by `s`
    straight segments -- unchanged from before this parameter grew the
    s=None option. s=None instead returns a real B-rep Wire, exact Line
    edges for the straight stretches and exact circular Arc edges (each
    built in its own corner's actual 3D plane, via
    Edge.make_three_point_arc() through the corner's already-computed
    tangent points and arc midpoint) for the rounded corners -- feed
    THAT straight into sweep_sec2path()'s path3d exactly like the point-
    list form (sweep_sec2path() accepts an already-built Wire directly,
    see its own docstring), just with a genuinely round path instead of
    one approximated by `s` short straight segments.

    pnts: [[dx,dy,dz], ...] or [[dx,dy,dz,r], ...] -- same turtle
        convention as turtle3d(), with an optional trailing fillet
        radius per point.
    s: segments per rounded corner when an int; None for an exact Wire
        instead (see above).

    Same closed-loop wraparound behavior as cr2dt() -- leave the radius
    at 0 (the default) on any point you don't want rounded using a
    wraparound neighbor (e.g. the first/last point of what's
    conceptually an open path -- see cr2dt()'s docstring). Feed the
    result straight into sweep_sec2path()'s path3d for a pre-rounded
    path (an alternative to that function's own transition="round").
    """
    pts = []
    radii = []
    x, y, z = 0.0, 0.0, 0.0
    for p in pnts:
        x += float(p[0])
        y += float(p[1])
        z += float(p[2])
        pts.append((x, y, z))
        radii.append(float(p[3]) if len(p) > 3 else 0.0)
    n = len(pts)
    if n < 3:
        raise ValueError("cr3dt(): need at least 3 points")

    if s is None:
        _require_build123d()
        entry = [None] * n
        exitp = [None] * n
        arc_edge = [None] * n
        for i in range(n):
            cur = pts[i]
            prev_pt = pts[i - 1]
            next_pt = pts[(i + 1) % n]
            r = radii[i]
            if r == 0:
                entry[i] = exitp[i] = cur
                continue
            d1 = (prev_pt[0] - cur[0], prev_pt[1] - cur[1], prev_pt[2] - cur[2])
            d2 = (next_pt[0] - cur[0], next_pt[1] - cur[1], next_pt[2] - cur[2])
            len1 = math.sqrt(d1[0] * d1[0] + d1[1] * d1[1] + d1[2] * d1[2])
            len2 = math.sqrt(d2[0] * d2[0] + d2[1] * d2[1] + d2[2] * d2[2])
            u1 = _3d_unit(d1)
            u2 = _3d_unit(d2)
            dot = max(-1.0, min(1.0, _3d_dot(u1, u2)))
            theta = math.acos(dot)
            if theta < 1e-9 or theta > math.pi - 1e-9:
                entry[i] = exitp[i] = cur
                continue
            tlen = r / math.tan(theta / 2)
            if tlen > len1 or tlen > len2:
                raise ValueError(
                    f"cr3dt(): radius {r} at point {i} is too large for its "
                    f"adjacent edges (needs {tlen:.6g}, edges are "
                    f"{len1:.6g}/{len2:.6g} long)")
            t1 = (cur[0] + u1[0] * tlen, cur[1] + u1[1] * tlen, cur[2] + u1[2] * tlen)
            t2 = (cur[0] + u2[0] * tlen, cur[1] + u2[1] * tlen, cur[2] + u2[2] * tlen)
            bis_u = _3d_unit((u1[0] + u2[0], u1[1] + u2[1], u1[2] + u2[2]))
            center_dist = r / math.sin(theta / 2)
            center = (
                cur[0] + bis_u[0] * center_dist,
                cur[1] + bis_u[1] * center_dist,
                cur[2] + bis_u[2] * center_dist,
            )
            e1 = _3d_unit((t1[0] - center[0], t1[1] - center[1], t1[2] - center[2]))
            normal = _3d_unit(_3d_cross(u1, u2))
            e2 = _3d_cross(normal, e1)  # unit length: normal, e1 are unit & perpendicular
            t2_dir = _3d_unit((t2[0] - center[0], t2[1] - center[1], t2[2] - center[2]))
            span = math.atan2(_3d_dot(t2_dir, e2), _3d_dot(t2_dir, e1))  # shortest way around
            # Same "three points pin down the exact arc, no direction-
            # sign convention needed" trick as cr2dt()'s s=None branch --
            # just evaluated in this corner's own (e1, e2) in-plane basis
            # instead of always the flat XY one.
            mid_a = span / 2.0
            ca, sa = math.cos(mid_a), math.sin(mid_a)
            mid_pt = (
                center[0] + r * (ca * e1[0] + sa * e2[0]),
                center[1] + r * (ca * e1[1] + sa * e2[1]),
                center[2] + r * (ca * e1[2] + sa * e2[2]),
            )
            arc_edge[i] = bd.Edge.make_three_point_arc(t1, mid_pt, t2)
            entry[i] = t1
            exitp[i] = t2
        edges = []
        for i in range(n):
            if arc_edge[i] is not None:
                edges.append(arc_edge[i])
            nxt = (i + 1) % n
            a, b = exitp[i], entry[nxt]
            if math.sqrt((a[0]-b[0])**2 + (a[1]-b[1])**2 + (a[2]-b[2])**2) > 1e-9:
                edges.append(bd.Edge.make_line(a, b))
        return bd.Wire.combine(edges)[0]

    out = []
    for i in range(n):
        cur = pts[i]
        prev_pt = pts[i - 1]
        next_pt = pts[(i + 1) % n]
        r = radii[i]
        if r == 0:
            out.append(list(cur))
            continue
        d1 = (prev_pt[0] - cur[0], prev_pt[1] - cur[1], prev_pt[2] - cur[2])
        d2 = (next_pt[0] - cur[0], next_pt[1] - cur[1], next_pt[2] - cur[2])
        len1 = math.sqrt(d1[0] * d1[0] + d1[1] * d1[1] + d1[2] * d1[2])
        len2 = math.sqrt(d2[0] * d2[0] + d2[1] * d2[1] + d2[2] * d2[2])
        u1 = _3d_unit(d1)
        u2 = _3d_unit(d2)
        dot = max(-1.0, min(1.0, _3d_dot(u1, u2)))
        theta = math.acos(dot)
        if theta < 1e-9 or theta > math.pi - 1e-9:
            out.append(list(cur))
            continue
        tlen = r / math.tan(theta / 2)
        if tlen > len1 or tlen > len2:
            raise ValueError(
                f"cr3dt(): radius {r} at point {i} is too large for its "
                f"adjacent edges (needs {tlen:.6g}, edges are "
                f"{len1:.6g}/{len2:.6g} long)")
        t1 = (cur[0] + u1[0] * tlen, cur[1] + u1[1] * tlen, cur[2] + u1[2] * tlen)
        t2 = (cur[0] + u2[0] * tlen, cur[1] + u2[1] * tlen, cur[2] + u2[2] * tlen)
        bis_u = _3d_unit((u1[0] + u2[0], u1[1] + u2[1], u1[2] + u2[2]))
        center_dist = r / math.sin(theta / 2)
        center = (
            cur[0] + bis_u[0] * center_dist,
            cur[1] + bis_u[1] * center_dist,
            cur[2] + bis_u[2] * center_dist,
        )
        e1 = _3d_unit((t1[0] - center[0], t1[1] - center[1], t1[2] - center[2]))
        normal = _3d_unit(_3d_cross(u1, u2))
        e2 = _3d_cross(normal, e1)  # unit length: normal, e1 are unit & perpendicular
        t2_dir = _3d_unit((t2[0] - center[0], t2[1] - center[1], t2[2] - center[2]))
        span = math.atan2(_3d_dot(t2_dir, e2), _3d_dot(t2_dir, e1))  # shortest way around
        for k in range(s + 1):
            a = span * k / s
            ca, sa = math.cos(a), math.sin(a)
            out.append([
                center[0] + r * (ca * e1[0] + sa * e2[0]),
                center[1] + r * (ca * e1[1] + sa * e2[1]),
                center[2] + r * (ca * e1[2] + sa * e2[2]),
            ])
    return out


def corner_n_radius_list(p0, r_l, n=10):
    """
    Rounds each corner of the ABSOLUTE 2D point list `p0` (a closed
    loop) using the matching radius from the parallel list `r_l` (same
    length as p0; 0 means "leave this vertex sharp") -- cr2dt()'s
    sibling for when you already have a fixed set of absolute corner
    points (e.g. a rectangle's 4 known corners) rather than a chain of
    turtle-style relative offsets: openscad4.py's own
    corner_n_radius_list(), ported. `n` is the number of segments per
    rounded corner (a sharp vertex, r=0, is always just 1 point either
    way -- same convention as cr2dt()'s `s`).

        sec = corner_n_radius_list([[0,0],[10,0],[10,10],[0,10]], [1,2,3,4], 10)
        show(linear_extrude(polygon(sec), h=3))

    Like cr2dt(), always treats `p0` as a CLOSED loop -- corner 0's
    rounding uses the LAST point as its "previous" neighbor, and vice
    versa, so leave a point's radius at 0 if you want it left exactly
    as given (e.g. the end of what's conceptually an open path).
    Raises if a requested radius doesn't fit between a vertex and
    either neighboring edge -- same check as cr2dt().

    openscad4.py also has a corner_n_radius_list_3d() 3D counterpart
    (absolute 3D points, corners rounded in each one's own local
    plane, same idea as cr3dt() vs cr2dt()) -- not ported here, ask if
    you want it too.
    """
    n_pts = len(p0)
    if n_pts < 3:
        raise ValueError("corner_n_radius_list(): need at least 3 points")
    if len(r_l) != n_pts:
        raise ValueError(
            f"corner_n_radius_list(): r_l has {len(r_l)} entries but p0 has "
            f"{n_pts} points -- they need to be the same length (one radius "
            f"per corner, 0 for a sharp one).")
    pts = [(float(p[0]), float(p[1])) for p in p0]

    out = []
    for i in range(n_pts):
        cur = pts[i]
        prev_pt = pts[i - 1]
        next_pt = pts[(i + 1) % n_pts]
        r = float(r_l[i])
        if r == 0:
            out.append([cur[0], cur[1]])
            continue
        d1 = (prev_pt[0] - cur[0], prev_pt[1] - cur[1])
        d2 = (next_pt[0] - cur[0], next_pt[1] - cur[1])
        len1 = math.hypot(*d1)
        len2 = math.hypot(*d2)
        u1 = _2d_unit(d1)
        u2 = _2d_unit(d2)
        dot = max(-1.0, min(1.0, u1[0] * u2[0] + u1[1] * u2[1]))
        theta = math.acos(dot)
        if theta < 1e-9 or theta > math.pi - 1e-9:
            # straight-through or fully-reversed vertex -- no
            # well-defined corner to round; keep the vertex as-is
            out.append([cur[0], cur[1]])
            continue
        tlen = r / math.tan(theta / 2)
        if tlen > len1 or tlen > len2:
            raise ValueError(
                f"corner_n_radius_list(): radius {r} at point {i} is too "
                f"large for its adjacent edges (needs {tlen:.6g}, edges are "
                f"{len1:.6g}/{len2:.6g} long)")
        t1 = (cur[0] + u1[0] * tlen, cur[1] + u1[1] * tlen)
        t2 = (cur[0] + u2[0] * tlen, cur[1] + u2[1] * tlen)
        bis_u = _2d_unit((u1[0] + u2[0], u1[1] + u2[1]))
        center_dist = r / math.sin(theta / 2)
        center = (cur[0] + bis_u[0] * center_dist, cur[1] + bis_u[1] * center_dist)
        a1 = math.atan2(t1[1] - center[1], t1[0] - center[0])
        a2 = math.atan2(t2[1] - center[1], t2[0] - center[0])
        d_angle = (a2 - a1 + math.pi) % (2 * math.pi) - math.pi  # shortest way around
        for k in range(n + 1):
            a = a1 + d_angle * k / n
            out.append([center[0] + r * math.cos(a), center[1] + r * math.sin(a)])
    return out


# ---------------------------------------------------------------------------
# Core point-list/vector-math toolkit, ported from openscad4.py -- pure
# Python (no build123d), same spirit as turtle2d()/turtle3d()/cr2dt()/
# cr3dt() above: build/inspect plain [[x,y],...] or [[x,y,z],...] point
# lists by hand, then feed the result into polygon()/sweep_sec2path()/
# your own script logic. openscad4.py has ~580 top-level functions in
# this vein; this is a first, curated batch of ~36 of the most broadly
# useful ones (arcs/circles, line/vector math, intersections, mirror/
# rotate, sorting/cleanup, convex hull, plane/normal, bezier/b-spline)
# -- reimplemented from scratch against each one's documented behavior
# (openscad4.py's own versions are numpy-vectorized internals not meant
# to be read function-by-function), not ported line-for-line. A few
# related functions (path/polygon offset, line-circle fillets, the more
# exotic derived-curve smoothers) need deeper follow-up work and were
# deliberately left out of this batch -- ask if you want those next.
# ---------------------------------------------------------------------------

def _flatten_points(nested):
    """internal: flattens an arbitrarily-nested list of points (a plain
    point list, a stack of sections, or a mesh vertex list) down to a
    flat list of point tuples."""
    out = []

    def walk(x):
        if isinstance(x, (list, tuple)) and len(x) > 0 and isinstance(x[0], (int, float)):
            out.append(tuple(float(c) for c in x))
        elif isinstance(x, (list, tuple)):
            for y in x:
                walk(y)

    walk(nested)
    return out


def _polar_angle_deg(vx, vy):
    """internal: polar angle of (vx,vy) in degrees, 0-360."""
    a = math.degrees(math.atan2(vy, vx))
    return a + 360 if a < 0 else a


def _cw_2d(pts):
    """internal: 1 if `pts` (>=3 2D points) winds clockwise, -1 if
    counter-clockwise, 0 if collinear/degenerate -- matches arc_2p()/
    cir_2p()'s own cw=1(clockwise)/-1(counter-clockwise) convention."""
    area2 = 0.0
    n = len(pts)
    for i in range(n):
        x0, y0 = pts[i][0], pts[i][1]
        x1, y1 = pts[(i + 1) % n][0], pts[(i + 1) % n][1]
        area2 += x0 * y1 - x1 * y0
    if area2 > 1e-12:
        return -1
    if area2 < -1e-12:
        return 1
    return 0


def _arc_deg(r, a1, a2, cp, s):
    """internal: point list tracing an arc of radius `r` centered at
    2D point `cp`, from angle `a1` to `a2` degrees (0 = +X axis,
    counter-clockwise-positive, same convention math.atan2 uses), as
    `s` segments (s+1 points)."""
    out = []
    for k in range(s + 1):
        a = math.radians(a1 + (a2 - a1) * k / s)
        out.append([cp[0] + r * math.cos(a), cp[1] + r * math.sin(a)])
    return out


def _project_point_on_segment(p, seg_pts):
    """internal: perpendicular foot of `p` on segment seg_pts=[a,b] (2D
    or 3D), the fraction `t` along it (0=a, 1=b, NOT clamped -- caller
    decides what an out-of-[0,1] t means), and the distance from `p` to
    that foot."""
    a, b = seg_pts
    dim = len(a)
    v = [b[i] - a[i] for i in range(dim)]
    vlen2 = sum(c * c for c in v)
    if vlen2 < 1e-18:
        return list(a), 0.0, l_len([p, a])
    w = [p[i] - a[i] for i in range(dim)]
    t = sum(v[i] * w[i] for i in range(dim)) / vlen2
    foot = [a[i] + v[i] * t for i in range(dim)]
    return foot, t, l_len([p, foot])


def seg(sec):
    """
    Consecutive [p_i, p_{i+1}] pairs from `sec`, wrapping the last
    point back to the first -- e.g. seg([[0,0],[10,0],[10,10]]) ->
    [[[0,0],[10,0]], [[10,0],[10,10]], [[10,10],[0,0]]]. Works on plain
    values too: seg([1,2,3]) -> [[1,2],[2,3],[3,1]]. A small building
    block several of the other functions below (and your own scripts)
    are built on.
    """
    n = len(sec)
    return [[sec[i], sec[(i + 1) % n]] for i in range(n)]


def flip(sec):
    """Reverses the order of a list -- e.g. flip([1,2,3]) -> [3,2,1].
    Handy for reversing a point list's winding direction."""
    return list(sec[::-1])


def l_len(line):
    """The length of a 2-point line [p0,p1] -- 2D or 3D. l_len([[0,0],
    [10,0]]) -> 10.0"""
    p0, p1 = line
    return math.sqrt(sum((float(p1[i]) - float(p0[i])) ** 2 for i in range(len(p0))))


def l_lenv(sec):
    """Perimeter of the closed point list `sec` -- the sum of every
    segment length from seg(sec)."""
    return sum(l_len(s) for s in seg(sec))


def mid_point(line):
    """
    The point exactly halfway along `line` by arc length -- for a
    plain 2-point line that's just the average of the endpoints; for a
    longer polyline, the point half its total length along the path
    (not the average of all the points).
    """
    if len(line) == 2:
        p0, p1 = line
        return [(float(p0[i]) + float(p1[i])) / 2.0 for i in range(len(p0))]
    segs = [(line[i], line[i + 1]) for i in range(len(line) - 1)]
    lengths = [l_len(list(s)) for s in segs]
    half = sum(lengths) / 2.0
    walked = 0.0
    for (p0, p1), length in zip(segs, lengths):
        if walked + length >= half or length == 0:
            t = 0.0 if length == 0 else (half - walked) / length
            return [float(p0[i]) + (float(p1[i]) - float(p0[i])) * t for i in range(len(p0))]
        walked += length
    return list(line[-1])


def bb(prism):
    """The 3D bounding-box size [width, height, depth] of a point list
    or nested list of point lists (e.g. to_mesh()'s vertex list, or a
    stack of sections) -- OR of a real B-rep Shape (import_step()'s
    own result, cube()/cylinder()/etc, any split()/fillet()/etc
    result): build123d's own `shape.bounding_box().size`, unwrapped
    into this same plain [w, h, d] list so both kinds of input work
    with one function. Use `shape.bounding_box()` directly instead
    (see its own `.min`/`.max`/`.center()`) if you need more than just
    the overall size -- e.g. import_step()'s own docstring above uses
    `.center()` to center a cutting plane on an imported part."""
    if _HAVE_BUILD123D and isinstance(prism, bd.Shape):
        s = prism.bounding_box().size
        return [float(s.X), float(s.Y), float(s.Z)]
    pts = _flatten_points(prism)
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    zs = [p[2] for p in pts]
    return [max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs)]


def bb2d(sec):
    """2D counterpart of bb() -- [width, height] of a 2D point list."""
    pts = _flatten_points(sec)
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return [max(xs) - min(xs), max(ys) - min(ys)]


def cog(sol):
    """Center of gravity (plain centroid, not area/volume-weighted) of
    a point list or nested list of point lists."""
    pts = _flatten_points(sol)
    n = len(pts)
    dim = len(pts[0])
    return [sum(p[i] for p in pts) / n for i in range(dim)]


def line_as_vector(line):
    """The vector from a 2-point line's start to its end -- e.g.
    line_as_vector([[0,0],[10,0]]) -> [10.0, 0.0]."""
    p0, p1 = line
    return [float(p1[i]) - float(p0[i]) for i in range(len(p0))]


def line_as_unit_vector(line):
    """Unit-length version of line_as_vector()."""
    v = line_as_vector(line)
    n = math.sqrt(sum(c * c for c in v))
    if n < 1e-12:
        raise ValueError("line_as_unit_vector(): a zero-length line")
    return [c / n for c in v]


def _rotate_points_about_axis(pts, axis_dir, axis_point, theta_deg):
    """
    internal: rotates each 3D point in `pts` by `theta_deg` degrees
    around the axis through `axis_point` in direction `axis_dir` --
    plain Rodrigues'-formula point rotation, no build123d needed. The
    point-list counterpart of axis_rot_1() (which rotates a real
    build123d Shape the same way via its own native .rotate()), used
    by functions like fit_pline2line() below that work on raw point
    lists rather than B-rep solids.
    """
    kx, ky, kz = _3d_unit(tuple(float(c) for c in axis_dir))
    ox, oy, oz = (float(c) for c in axis_point)
    theta = math.radians(theta_deg)
    cos_t, sin_t = math.cos(theta), math.sin(theta)
    out = []
    for p in pts:
        vx, vy, vz = float(p[0]) - ox, float(p[1]) - oy, float(p[2]) - oz
        dot = vx * kx + vy * ky + vz * kz
        cx, cy, cz = _3d_cross((kx, ky, kz), (vx, vy, vz))
        rx = vx * cos_t + cx * sin_t + kx * dot * (1 - cos_t)
        ry = vy * cos_t + cy * sin_t + ky * dot * (1 - cos_t)
        rz = vz * cos_t + cz * sin_t + kz * dot * (1 - cos_t)
        out.append([ox + rx, oy + ry, oz + rz])
    return out


def fit_pline2line(polyline, line):
    """
    Fits `polyline` (an open 2D or 3D point list, e.g. sinewave()/
    bezier()/turtle3d() output) onto `line` (a straight 2-point
    line/vector) -- openscad4.py's own fit_pline2line(), ported as
    plain point-list math (no build123d needed, like turtle3d()/
    sinewave()/l_len() above): scales every segment of `polyline` by
    the same factor so its start-to-end chord length matches `line`'s
    length, slides it so its start point lands on `line`'s start
    point, then rotates it about that point so its own chord points
    the same direction as `line` -- the polyline's own shape (bends,
    wiggles, etc) is preserved throughout; only its overall position,
    length, and orientation change. Handy for laying a wavy/curved
    profile down along an arbitrary 3D line before sweeping/lofting
    it (see surface_from_4_lines-style workflows: fit each edge curve
    between the right pair of corner points first).

    Always returns 3D points ([x,y,z]), even if `polyline` was given
    as 2D -- the whole point is usually to lay a flat curve down along
    an arbitrary 3D `line`, which generally means it has to leave the
    XY plane to line up, so flattening the result back to 2D would
    just throw away the fit. `line` can be given as just its 2
    endpoints, or a longer point list (e.g. turtle3d() output) -- only
    its first and last points are used.

        l1 = turtle3d([[0, 10, 0], [0, 0, 20]])
        l2 = sinewave(50, 3, 2, 50)
        l3 = fit_pline2line(l2, l1)
        show(color(p_line3d(l1, 0.1), "blue"))
        show(color(p_line3d(l2, 0.3), "magenta"))
        show(color(p_line3d(l3, 0.3), "cyan"))
    """
    if len(polyline) < 2:
        raise ValueError("fit_pline2line(): polyline needs at least 2 points")
    a = c23(polyline)
    l1 = c23([line[0], line[-1]])
    chord = l_len([a[0], a[-1]])
    if chord < 1e-12:
        raise ValueError("fit_pline2line(): polyline's start and end points coincide (zero chord length)")
    rt = l_len(l1) / chord

    # rescale every segment's vector by the same factor rt (stretches/
    # shrinks the polyline's overall chord length by rt while
    # preserving its shape), rebuilt as a running cumulative sum from
    # the origin.
    b = [[0.0, 0.0, 0.0]]
    x, y, z = 0.0, 0.0, 0.0
    for p0, p1 in seg(a)[:-1]:
        x += (p1[0] - p0[0]) * rt
        y += (p1[1] - p0[1]) * rt
        z += (p1[2] - p0[2]) * rt
        b.append([x, y, z])

    # slide b so its first point lands exactly on line's first point.
    t = [l1[0][i] - b[0][i] for i in range(3)]
    b = [[p[0] + t[0], p[1] + t[1], p[2] + t[2]] for p in b]

    # rotate b about its own (now-placed) first point so its chord
    # direction matches line's direction.
    u1 = line_as_unit_vector(l1)
    u2 = line_as_unit_vector([b[0], b[-1]])
    axis = _3d_cross(u1, u2)
    if all(round(c, 4) == 0 for c in axis):
        return b
    dot = max(-1.0, min(1.0, _3d_dot(u1, u2)))
    theta = -math.degrees(math.acos(dot))
    return _rotate_points_about_axis(b, axis, b[0], theta)


def _chain_segments(seg_list):
    """
    internal helper for contiguous_chains() -- greedily walks `seg_list`
    (a list of disconnected 2-point segments) starting from the first
    one, extending a single chain at either end wherever a matching
    endpoint is found, until no more segments connect. Returns [the
    resulting chain of points, the remaining not-yet-used segments].
    """
    def pt_eq(p0, p1):
        return all(round(float(a), 4) == round(float(b), 4) for a, b in zip(p0, p1))

    remaining = [list(s) for s in seg_list]
    chain = [remaining.pop(0)]
    while remaining:
        added = False
        for i, s in enumerate(remaining):
            if pt_eq(s[0], chain[-1][1]):
                chain.append(s)
            elif pt_eq(s[1], chain[-1][1]):
                chain.append(flip(s))
            elif pt_eq(s[1], chain[0][0]):
                chain.insert(0, s)
            elif pt_eq(s[0], chain[0][0]):
                chain.insert(0, flip(s))
            else:
                continue
            remaining.pop(i)
            added = True
            break
        if not added:
            break
    pts = [s[0] for s in chain] + [chain[-1][1]]
    return pts, remaining


def contiguous_chains(seg_list):
    """
    Stitches a flat, unordered list of 2-point line segments `seg_list`
    into one or more separate continuous chains/loops of points --
    openscad4.py's own contiguous_chains(), ported as plain point-list
    math (no build123d needed). A real build123d boolean's own Wire
    (intersection()'s result, say) already comes back as a proper
    ordered point list, so you won't need this for that -- but
    two_solids_intersection() below (the mesh-based, more robust
    alternative to a real B-rep boolean for genuinely hard cases) DOES
    return raw, disconnected triangle-intersection segments that
    genuinely need stitching -- exactly the pairing this was ported
    for. Also handy for the rare case of feeding in your own
    disconnected segment list from an external data source. It is NOT
    a way to reduce the edge count of an existing B-rep Shape -- for
    that, see arc_3p()'s `s=` parameter or interp_spline().

    Repeatedly pulls out one connected run of segments (matching
    endpoints to 4 decimal places) until every segment has been
    consumed, so the result may contain more than one chain if the
    input isn't all one connected network. A chain whose two ends meet
    back up comes back as a closed loop (first point == last point).

        segs = [[[0,0],[10,0]], [[10,10],[10,0]], [[0,0],[0,10]]]
        contiguous_chains(segs) => [[[10,10],[10,0],[0,0],[0,10]]]
    """
    remaining = [list(s) for s in seg_list]
    chains = []
    while remaining:
        chain, remaining = _chain_segments(remaining)
        chains.append(chain)
    return chains


def slice_mesh_to_rings(V, F, axis=(0, 0, 1), n=20, heights=None, tol=1e-7):
    """
    Slices an arbitrary triangle mesh [V, F] (the SAME [vertex list,
    face-index-triple list] convention to_mesh()/to_triangles() use)
    with a stack of planes perpendicular to `axis`, and returns one
    closed cross-section point-loop ("ring") per plane -- plain numpy
    point math, no B-rep involved yet. This is the first half of
    "contour stacking": turn an arbitrary mesh into a stack of ring
    outlines, then hand those rings to solid_from_mesh_slices() (or
    build your own pipeline with polygon()/loft()/
    surface_from_closed_rings()) to fit a genuine smooth B-rep solid
    through them.

    `axis`: the slicing direction, any vector (not necessarily unit
    length, doesn't need to be X/Y/Z -- an arbitrary tilted axis works
    too, see the third example below).

    `n`: number of evenly-spaced planes spanning the mesh's own extent
    along `axis` (ignored if `heights` is given explicitly). `heights`:
    an explicit list of signed distances along `axis` (measured from
    the origin) to slice at instead.

    `tol`: vertices within `tol` of a given plane are treated as lying
    exactly ON it. This matters more than it looks -- a mesh with any
    real symmetry (e.g. slicing exactly through a model's own
    mirror-plane, or through a flat face that happens to lie in one of
    your slicing planes) can put a whole ring of vertices exactly on a
    plane at once; without this, every triangle touching that ring
    would report "no crossing" on both its edges and the slice would
    come back empty even though the mesh clearly has geometry right
    there.

    Returns a list of (height, ring, extra_loops) tuples, one per
    plane, in the same order as `heights`/the generated `n` planes:
      height: the signed distance along `axis` this plane sits at.
      ring: a list of 3D points with ring[0] == ring[-1] (closed), or
        None if this plane missed the mesh entirely, or the raw
        crossing segments didn't stitch into any closed loop at all
        (e.g. the mesh has a hole/isn't watertight right at this
        height).
      extra_loops: 0 normally. If the plane crossed the mesh at more
        than one separate place (e.g. slicing through two separate
        fingers of a forked shape), only the LARGEST loop (by point
        count) is returned as `ring`, and extra_loops reports how many
        smaller ones were dropped -- loft()/surface_from_closed_rings()
        each need exactly one profile per station; a genuinely
        branching cross-section needs its branches sliced and lofted
        separately, using their own height lists. If the dropped loop
        is substantial (at least 15% as many points as the one kept --
        real geometry, not just a stray mesh sliver), this ALSO prints
        a loud console warning naming the height and both loop sizes --
        confirmed necessary directly: a real union-of-spheres mesh had
        a genuine second lobe silently vanish from the reconstructed
        solid with no indication anything was wrong until the result
        was visually inspected and a chunk of it was missing.

        v, f = to_mesh(some_shape)             # or your own raw mesh
        for h, ring, extra in slice_mesh_to_rings(v, f, n=30):
            if ring is None:
                continue                        # this height missed the mesh
            if extra:
                print(f"height {h}: dropped {extra} smaller loop(s)")
            # ring is ready for polygon()/translate()/loft(), or stack
            # every ring together for surface_from_closed_rings()

    UNVERIFIED against a live install in the sense that solid_from_
    mesh_slices() below (which calls into real OCCT) hasn't been
    exercised on an actual build123d install (see module docstring) --
    but THIS function is pure numpy triangle/plane math with no B-rep
    dependency at all, and has been directly unit-tested standalone
    (axis-aligned box, a subdivided icosphere checked against its own
    analytic r = sqrt(R^2 - h^2) at every height including the exact
    equatorial degenerate case above, two disjoint solids, and a
    tilted non-axis-aligned slicing direction).
    """
    heights, all_loops = _all_loops_per_height(V, F, axis=axis, n=n, heights=heights, tol=tol)
    results = []
    for h, closed in zip(heights, all_loops):
        if not closed:
            results.append((float(h), None, 0))
            continue
        if len(closed) > 1:
            # A second, roughly comparably-sized loop at the same
            # height is genuine branching (e.g. two separate lobes),
            # not mesh noise -- and it's about to be silently thrown
            # away below (see this function's own docstring: only the
            # largest loop is kept). A tiny second loop (a handful of
            # points vs hundreds) is much more likely just a sliver
            # from mesh imperfections and safe to drop quietly, so only
            # the substantial case gets a loud warning -- this is a
            # REAL, confirmed failure mode (a real union-of-spheres
            # mesh sliced through a genuine second lobe near its top,
            # which silently vanished from the reconstructed solid with
            # no indication anything was wrong until the result was
            # visually inspected).
            second_ratio = len(closed[1]) / len(closed[0])
            if second_ratio >= 0.15:
                print(f"slice_mesh_to_rings(): WARNING -- height {h:.4g} has "
                      f"{len(closed)} separate closed loops ({[len(c) for c in closed]} "
                      f"points each), not just one. Only the largest is kept; the "
                      f"other(s) are real geometry being DROPPED, not noise (the "
                      f"second-largest has {second_ratio:.0%} as many points as the "
                      f"one being kept). This mesh likely branches into separate "
                      f"lobes/fingers somewhere near this height -- a single ring "
                      f"per station can't represent that; slice/loft each branch "
                      f"separately over its own height range instead, e.g. using "
                      f"`heights=` to stay within one branch at a time.")
        results.append((float(h), closed[0], len(closed) - 1))
    return results


def _all_loops_per_height(V, F, axis=(0, 0, 1), n=20, heights=None, tol=1e-7):
    """internal, shared by slice_mesh_to_rings() (which keeps only the
    largest loop per height) and the branch-aware solid_from_mesh_slices()
    path (which needs EVERY loop per height, to detect and follow
    genuine branches instead of silently discarding them). Returns
    (heights_array, list-of-lists), one entry per height, each entry
    the height's own closed loops sorted largest-first (empty list if
    the plane missed the mesh or nothing stitched into a closed loop)."""
    V = np.asarray(V, dtype=float)
    F = np.asarray(F, dtype=int)
    ax = np.asarray(axis, dtype=float)
    ax = ax / np.linalg.norm(ax)

    d_all = V @ ax
    if heights is None:
        lo, hi = float(d_all.min()), float(d_all.max())
        pad = (hi - lo) * 1e-4 + 1e-9
        heights = np.linspace(lo + pad, hi - pad, n)
    else:
        heights = np.asarray(heights, dtype=float)

    all_loops = []
    for h in heights:
        dv = d_all - h
        segs = _slice_triangles_at_plane(V, F, dv, tol)
        if not segs:
            all_loops.append([])
            continue
        chains = contiguous_chains(segs)
        closed = [c for c in chains if _ring_pt_eq(c[0], c[-1])]
        closed.sort(key=len, reverse=True)
        all_loops.append(closed)
    return heights, all_loops


def _ring_pt_eq(p0, p1, ndp=4):
    return all(round(float(a), ndp) == round(float(b), ndp) for a, b in zip(p0, p1))


def _slice_triangles_at_plane(V, F, dv, tol):
    """internal, used only by slice_mesh_to_rings(): for every triangle
    in F, finds where the plane (dv==0, dv being every vertex's signed
    distance from that plane) crosses it -- handling both the ordinary
    case (plane crosses two of the triangle's edges) and the degenerate
    case (one or more of the triangle's own vertices sit exactly on the
    plane, within `tol`). Returns a flat list of 2-point segments,
    ready for contiguous_chains()."""
    segs = []
    for tri in F:
        i0, i1, i2 = int(tri[0]), int(tri[1]), int(tri[2])
        idx = (i0, i1, i2)
        d = (float(dv[i0]), float(dv[i1]), float(dv[i2]))
        sign = [0 if abs(x) <= tol else (1 if x > 0 else -1) for x in d]

        if sign[0] == 0 and sign[1] == 0 and sign[2] == 0:
            continue  # whole triangle lies in-plane -- no useful 1D contour here

        pts = []
        for k in range(3):
            if sign[k] == 0:
                pts.append(V[idx[k]])
        edges = ((0, 1), (1, 2), (2, 0))
        for a, b in edges:
            if sign[a] != 0 and sign[b] != 0 and sign[a] != sign[b]:
                pa, pb = d[a], d[b]
                t = pa / (pa - pb)
                pts.append(V[idx[a]] + t * (V[idx[b]] - V[idx[a]]))

        if len(pts) == 2:
            segs.append([pts[0].tolist(), pts[1].tolist()])
        # len(pts) == 1 (plane just touches one vertex, doesn't cross) or
        # 3 (degenerate, shouldn't happen given the all-zero check above)
        # contribute no segment
    return segs


def _resample_closed_ring(ring, n):
    """internal, used only by solid_from_mesh_slices(): arc-length-
    resamples a closed point loop (ring[0] == ring[-1], as returned by
    slice_mesh_to_rings()) to exactly `n` evenly-spaced points, NOT
    repeating the closing point -- same closed-loop convention
    sample_curve() uses. surface_from_closed_rings() requires every row
    to have the SAME point count, but slice_mesh_to_rings() naturally
    returns a different raw point count per height (it depends on how
    many triangle edges that particular plane happened to cross), so
    this is what reconciles the two."""
    pts = np.asarray(ring[:-1], dtype=float)
    m = len(pts)
    if m < 3:
        raise ValueError("solid_from_mesh_slices(): a ring has fewer than 3 "
                          "distinct points, can't resample it")
    nxt = np.roll(pts, -1, axis=0)
    seglen = np.linalg.norm(nxt - pts, axis=1)
    cum = np.concatenate([[0.0], np.cumsum(seglen)])
    total = cum[-1]
    if total < 1e-9:
        raise ValueError("solid_from_mesh_slices(): a ring has ~zero perimeter")
    targets = np.linspace(0.0, total, n, endpoint=False)
    out = []
    for t in targets:
        i = int(np.searchsorted(cum, t, side='right') - 1)
        i = min(max(i, 0), m - 1)
        seg_t = (t - cum[i]) / seglen[i] if seglen[i] > 1e-9 else 0.0
        p = pts[i] + seg_t * (pts[(i + 1) % m] - pts[i])
        out.append(p.tolist())
    return out


def _perp_basis(axis):
    """internal: an arbitrary orthonormal (u, v) basis for the plane
    perpendicular to `axis`, used only to measure ring winding
    direction consistently (any valid basis works for that -- the
    actual u/v directions don't matter, only that the SAME basis is
    used for every ring being compared)."""
    axis = np.asarray(axis, dtype=float)
    axis = axis / np.linalg.norm(axis)
    ref = np.array([1.0, 0.0, 0.0]) if abs(axis[0]) < 0.9 else np.array([0.0, 1.0, 0.0])
    u = np.cross(axis, ref)
    u = u / np.linalg.norm(u)
    v = np.cross(axis, u)
    return u, v


def _ring_signed_area(pts, axis):
    """internal: signed area of `pts` (a closed ring) projected onto
    the plane perpendicular to `axis` -- sign gives winding direction
    (consistent for any two rings measured with the same `axis`,
    regardless of which arbitrary in-plane basis _perp_basis() picks)."""
    pts = np.asarray(pts, dtype=float)
    u, v = _perp_basis(axis)
    x = pts @ u
    y = pts @ v
    return 0.5 * float(np.sum(x * np.roll(y, -1) - np.roll(x, -1) * y))


def _align_ring_stack(rows, axis):
    """internal, used only by solid_from_mesh_slices(): makes an
    ordered stack of same-length rings actually usable as ThruSections
    input.

    slice_mesh_to_rings()/_resample_closed_ring() are each entirely
    independent PER HEIGHT -- contiguous_chains() (which stitches the
    raw crossing segments into a loop) has no notion of "the previous
    ring's winding direction or starting angle," so nothing constrains
    two adjacent rings to start at a similar location or wind the same
    way. Confirmed directly, on as plain a case as a single sphere: two
    adjacent slice heights came back winding OPPOSITE directions, and
    consecutive rings' own point 0 landed over 170 degrees apart in
    angle, with no relationship at all to the previous ring's.

    That matters because surface_from_closed_rings()/ThruSections
    connects "point k of ring i" to "point k of ring i+1" as
    corresponding stations along the lofted surface -- feed it rings
    that wind oppositely or start at unrelated points and the fit
    twists violently trying to connect genuinely unrelated points
    together, producing a self-intersecting, spiky mess instead of a
    smooth surface (a real, confirmed failure mode -- this is what was
    actually happening the first time this function was tried end to
    end, not a performance problem despite how long the resulting
    garbage geometry then took a viewer to tessellate).

    Fixes this in two passes:
      1. Winding: every ring after the first gets reversed if its own
         signed area (measured consistently via `axis`, see
         _ring_signed_area()) doesn't match the first ring's.
      2. Start offset: every ring after the first gets circularly
         rotated (same even point spacing, just a different starting
         index) to whichever rotation offset minimizes total squared
         distance to the PREVIOUS ring's own points, index for index --
         i.e. finds the best angular alignment against its immediate
         neighbor rather than some fixed global reference, so this
         still works even if the stack spirals/drifts gradually from
         one end to the other.

    Every row must already have the same point count (as
    _resample_closed_ring() guarantees)."""
    if len(rows) < 2:
        return rows
    out = [list(rows[0])]
    ref_area = _ring_signed_area(rows[0], axis)
    for row in rows[1:]:
        a = _ring_signed_area(row, axis)
        if (a >= 0) != (ref_area >= 0):
            row = list(reversed(row))
        prev = np.asarray(out[-1], dtype=float)
        cur = np.asarray(row, dtype=float)
        n_pts = len(cur)
        best_off, best_cost = 0, None
        for off in range(n_pts):
            rotated = np.roll(cur, -off, axis=0)
            cost = float(np.sum((rotated - prev) ** 2))
            if best_cost is None or cost < best_cost:
                best_cost, best_off = cost, off
        out.append(np.roll(cur, -best_off, axis=0).tolist())
    return out


def solid_from_mesh_slices(V, F, axis=(0, 0, 1), n=20, heights=None,
                            ring_points=80, cap=True, tol=1e-7, ruled=False,
                            branches=False, significant_ratio=0.15,
                            overlap_stations=2, match_factor=0.6):
    """
    Reconstructs a genuinely smooth B-rep solid from an arbitrary
    triangle mesh [V, F] by contour-stacking: slices the mesh with a
    stack of parallel planes (slice_mesh_to_rings()), resamples every
    resulting ring to the same point count, then fits ONE smooth NURBS
    surface through the whole stack (surface_from_closed_rings()) and
    caps both ends (cap_wire() + solid_from_faces()).

    This is the practical way to turn an arbitrary/unstructured mesh --
    something with no construction history available at all -- back
    into real B-rep, by reducing it to the already-solved "structured
    ring stack -> smooth surface" problem instead of trying to
    reconstruct faces/edges directly from raw triangle soup. In THIS
    app specifically, the mesh doesn't have to come from an external
    file (there's no raw STL/OBJ importer here, only import_step()/
    import_brep() for real B-rep formats) -- the practical use is
    reconstructing/smoothing a mesh you already have from within a
    script, e.g. to_triangles()-tessellating a shape built via
    two_solids_intersection()'s mesh fallback, or an import_step()
    model with coarse faceting, and fitting a smoother native surface
    back through it:

        v, f = to_mesh(rough_shape, tolerance=0.05)
        smooth = solid_from_mesh_slices(v, f, axis=[0,0,1], n=40)
        show(smooth)

    `axis`/`n`/`heights`/`tol`: same as slice_mesh_to_rings().

    `ring_points`: every kept ring is resampled to exactly this many
    evenly-spaced points before fitting (surface_from_closed_rings()
    requires all rows to match). Higher values track sharper in-ring
    detail more closely at the cost of a heavier surface fit.

    Every ring is also automatically re-wound and re-indexed to line up
    with its neighbors (see _align_ring_stack()'s own comment) --
    slice_mesh_to_rings() computes each height's ring completely
    independently, so consecutive rings can come back winding opposite
    directions and starting at unrelated angular positions; feeding
    that straight into a lofted surface fit twists it into a self-
    intersecting mess (confirmed directly, on a plain sphere, the hard
    way).

    `cap`: True (default) closes both ends into a watertight Solid via
    cap_wire()+solid_from_faces(); False returns the open wall Shell
    only (surface_from_closed_rings()'s own raw return), e.g. if you
    plan to cap it some other way yourself, or the two ends should stay
    open (a tube/pipe shape).

    Heights where slice_mesh_to_rings() found no ring at all (a gap, or
    a plane past the mesh's own extent) are skipped with the height
    noted in the raised/printed warning rather than silently producing
    a broken stack; at least 2 valid rings are required.

    `ruled`: passed straight through to surface_from_closed_rings().
    False (default) gives the smooth spline surface -- looks better
    when it works, but CONFIRMED (see below) to be capable of silently
    self-intersecting, no exception raised at all, when adjacent rings
    change shape a lot over relatively few stations. True instead
    connects each ring to the next with straight (faceted, visible
    seam at every station) patches -- more robust, at the cost of
    losing the smooth blend between stations. If the smooth default
    comes out visibly wrong (spiky, tangled, self-intersecting) for
    your mesh, that -- not a bug report -- is the first thing to try:
    call again with `ruled=True`, or increase `n` so consecutive
    stations differ less.

    CONFIRMED against a live build123d install, on two real cases: a
    single sphere (works cleanly either way, ruled=True/False), and a
    real union() of 3 overlapping spheres sliced at only n=10 stations
    -- there, ruled=False (the default) built a technically successful
    Shell with no error raised at all, that was nonetheless visibly
    self-intersecting and took a viewer's tessellation over 6 minutes
    to (fail to) resolve; ruled=True on the exact same rings produced a
    correct, if faceted, watertight solid in well under a second. The
    rings/alignment themselves were confirmed fine in both cases (see
    _align_ring_stack()'s own comment) -- this is specifically
    surface_from_closed_rings()'s smoothed ThruSections mode
    overshooting on sections with real shape change between stations,
    same class of fragility its own docstring already documents.

    The two end caps are built directly from the first/last RESAMPLED
    ring's own points (guaranteed exactly planar by construction, see
    _planar_face_from_ring()'s own comment) rather than from wall's own
    fitted boundary curve -- an earlier version of this function capped
    from wall.edges()[0]/[-1] instead (the pattern
    surface_from_closed_rings()'s own docstring shows) and hit a real,
    confirmed failure: build123d/OCCT rejecting that fitted boundary
    curve as non-planar even though the ring that produced it was
    exactly flat, since a multi-station smoothed surface fit doesn't
    preserve its own end sections' planarity the way a single-ring
    interpolation does. If `cap=True` still fails for some mesh (the
    cap not sewing cleanly against wall's boundary, for instance), call
    with `cap=False` and cap it yourself after inspecting `wall`'s own
    edges via this app's Pick Edges panel.

    `branches`: False (default) is everything described above -- one
    ring per station, fast, but only correct for a mesh whose cross-
    section never splits into more than one loop at a time. Real meshes
    routinely DO branch (fingers on a hand, forked mechanical parts,
    tree-like structures) -- with branches=False, slice_mesh_to_rings()
    silently keeps only the largest loop at any height with more than
    one, which can delete real geometry (see its own docstring; it does
    at least print a loud warning when this happens rather than staying
    silent about it). `branches=True` instead: keeps every loop at every
    height, groups the height range into runs of constant (significant)
    loop count, matches loops across each multi-loop run by nearest-
    centroid assignment, and builds each resulting thread -- one
    trunk/branch/finger, whatever its own shape does along the axis --
    as its own small independent solid, extended slightly into its
    neighboring segments so they share real volume, then union()s all
    of them into one final result. `significant_ratio`/`overlap_stations`/
    `match_factor` tune that process -- see _build_thread_segments()'s
    own comment for exactly what each one guards against; the defaults
    were chosen against a real branching test mesh (see that comment)
    and are a reasonable starting point, not required tuning for every
    mesh. `cap` is ignored when branches=True (every thread is always
    fully capped -- union() needs real closed solids, not open shells,
    to combine).

    CONFIRMED (pure point-math, no B-rep needed to test this part) on a
    real union-of-3-spheres mesh with two genuine branch regions of
    very different width: correctly tells apart a lobe that TERMINATES
    at its own tip from one that CONTINUES past the branch, and drops
    a too-narrow transient branch with a warning rather than trying to
    loft a degenerate 1-station "solid." The final union() of the
    resulting per-thread solids is, like the rest of this file's real
    OCCT calls, UNVERIFIED against a live build123d install.
    """
    _require_build123d()
    if branches:
        threads = _build_thread_segments(V, F, axis, n, heights, tol,
                                          significant_ratio, overlap_stations,
                                          match_factor)
        if not threads:
            raise ValueError(
                "solid_from_mesh_slices(branches=True): no usable thread "
                "segments found -- check that `axis`/`n`/`heights` actually "
                "cross the mesh.")
        if not cap:
            print("solid_from_mesh_slices(): WARNING -- cap=False is ignored "
                  "when branches=True (every branch thread must be a fully "
                  "closed solid for union() to combine them; there's no single "
                  "'open wall' to hand back for a multi-branch result).")
        solids = []
        for t in threads:
            sol = _solid_from_ring_list([ring for _, ring in t], axis,
                                         int(ring_points), bool(ruled), True)
            # .clean() right before the fuse -- union()'s own docstring
            # elsewhere in this file names this as worth trying against
            # exactly the "several near-coincident contacts accumulating"
            # fragility this multi-branch union is prone to
            if hasattr(sol, "clean"):
                sol = sol.clean()
            # ShapeFix_Shape repair pass (the SAME helper import_step()
            # uses to heal a freshly-read file -- see _heal_imported_shape()'s
            # own docstring) run on each thread solid BEFORE it ever
            # reaches the fuse: normalizes small topological
            # inconsistencies (tiny gaps between edges, faces whose
            # normals don't quite agree at a shared boundary) that a
            # boolean union is much less forgiving of than most other
            # operations. Fail-safe -- silently no-ops back to `sol`
            # unchanged if healing itself doesn't work for any reason.
            sol = _heal_imported_shape(sol)
            solids.append(sol)
        # union_multi() (single combined N-ary OCCT boolean pass, see its
        # own docstring) instead of plain union() (pairwise chain) here
        # specifically -- this is the exact spot the real disconnected-
        # fragment symptom at n=200 was reported from. Falls back to
        # union()-equivalent behavior on its own if it doesn't work, so
        # this swap is safe even if it turns out not to fix that symptom.
        result = solids[0] if len(solids) == 1 else union_multi(*solids)
        result = _heal_imported_shape(result)
        _warn_if_invalid(result, "solid_from_mesh_slices(branches=True)")
        return result

    slices = slice_mesh_to_rings(V, F, axis=axis, n=n, heights=heights, tol=tol)
    rings = []
    dropped = []
    for h, ring, extra in slices:
        if ring is None:
            dropped.append(h)
            continue
        rings.append(ring)
    if len(rings) < 2:
        raise ValueError(
            f"solid_from_mesh_slices(): only {len(rings)} usable ring(s) out of "
            f"{len(slices)} planes (missed heights: {dropped}) -- need at least "
            f"2. Check that `axis`/`n`/`heights` actually cross the mesh, and "
            f"that the mesh is watertight at those heights.")
    return _solid_from_ring_list(rings, axis, int(ring_points), bool(ruled), bool(cap))


def _solid_from_ring_list(rings, axis, ring_points, ruled, cap):
    """internal, shared tail end of solid_from_mesh_slices() (both the
    plain single-station-per-height path and the branch-aware path):
    given an ordered list of RAW closed rings (each ring[0] == ring[-1],
    not yet resampled to a common point count), resamples every ring to
    `ring_points` evenly-spaced points, re-winds/re-aligns the whole
    stack (_align_ring_stack()), fits a surface through it
    (surface_from_closed_rings()), and caps both ends
    (_planar_face_from_ring() + solid_from_faces()) unless `cap` is
    False, in which case the open wall Shell is returned instead."""
    rows = [_resample_closed_ring(ring, ring_points) for ring in rings]
    rows = _align_ring_stack(rows, axis)
    wall = surface_from_closed_rings(rows, ruled=ruled)
    if not cap:
        return wall
    cap_a = _planar_face_from_ring(rows[0])
    cap_b = _planar_face_from_ring(rows[-1])
    return solid_from_faces(wall, cap_a, cap_b)


def _planar_face_from_ring(ring):
    """internal, used only by solid_from_mesh_slices(): builds a flat
    cap Face directly from a ring of points that are known to be
    EXACTLY coplanar -- as slice_mesh_to_rings()'s own rings are, by
    construction (every point on a given ring is computed as lying at
    the same signed distance along `axis`, either an on-plane mesh
    vertex or a linear interpolation between two vertices that are both
    constrained to that same plane).

    Deliberately NOT built from wall.edges() (the ThruSections-fitted
    wall surface's own boundary curve, the more obvious-looking
    choice, and cap_wire()'s own docstring example) -- that curve is a
    smoothed multi-station surface fit, not a plain interpolation
    through one ring's points, and in practice does not stay exactly
    planar even when the ring that produced it was, which trips
    build123d/OCCT's planarity check downstream ("non planar face is
    invalid" from Face.make_surface(), a real, confirmed failure mode).

    An INTERPOLATING spline through points that are exactly coplanar
    does not have this problem: every point on such a curve is an
    affine combination of its own control points, which themselves
    solve out to lie in that same plane when the data does -- so the
    curve (and the Face built from it) stays planar up to ordinary
    floating-point roundoff, not the much larger wobble a multi-ring
    surface fit can introduce into its own end boundaries.

    The resulting cap won't sew perfectly edge-for-edge against wall's
    own (very slightly off-plane) boundary curve the way face_from_wire()
    on a shared exact edge would -- solid_from_faces()'s own sewing
    tolerance is relied on to close that small gap, same as it already
    has to for any independently-built cap (see face_from_wire()'s own
    docstring for the general tradeoff)."""
    pts = [(float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0) for p in ring]
    edge = bd.Edge.make_spline(pts, periodic=True)
    wire = bd.Wire([edge])
    return bd.Face(wire)


# --- branch-aware contour stacking -----------------------------------
#
# Everything below handles a mesh whose cross-section genuinely
# BRANCHES somewhere along the slicing axis (splits into two or more
# separate lobes/fingers at some height, or one of several lobes
# terminates at its own tip) -- the case slice_mesh_to_rings() itself
# can only warn about, since a single ring per station fundamentally
# can't represent more than one loop at once. solid_from_mesh_slices()
# dispatches here when called with branches=True: instead of one ring
# per height, every height's FULL set of closed loops is kept, grouped
# into maximal runs of constant loop count, matched loop-to-loop within
# each run (nearest-centroid Hungarian assignment), and stitched across
# run boundaries into independent per-branch "threads" -- each one
# built into its own small solid via the same _solid_from_ring_list()
# tail end the simple path uses, then union()'d together into one
# final result. Real B-rep union is relied on to handle the actual
# merge at each branch point, rather than trying to hand-stitch the
# topology directly.
#
# CONFIRMED directly (pure point-math, no B-rep needed for any of it)
# on a real union-of-3-spheres mesh with two genuine branch regions
# (one substantial, one only a couple of stations wide): correctly
# separates a lobe that TERMINATES at its own tip (a smaller sphere's
# dome ending past its own local max height) from one that CONTINUES
# past the branch region, rather than wrongly stitching both onto
# whatever's nearest (an earlier version of this code did exactly that,
# confirmed and fixed -- see _build_thread_segments()'s own comment).
# The final union() step itself, like the rest of this file's B-rep
# calls, is UNVERIFIED against a live build123d install.

def _loop_centroid(loop, axis):
    """plain (unweighted) centroid of a closed loop's points -- used
    only to judge which loop at one height corresponds to which loop
    at a neighboring height, not as a real geometric center."""
    pts = np.asarray(loop[:-1] if _ring_pt_eq(loop[0], loop[-1]) else loop, dtype=float)
    return pts.mean(axis=0)


def _loop_radius(loop, axis):
    """max distance from a loop's own centroid to any of its points --
    its characteristic size, used to judge whether a nearby loop at a
    neighboring height is close enough to plausibly be the same
    physical feature continuing, or just some other, unrelated loop
    that happens to be nearest."""
    pts = np.asarray(loop[:-1] if _ring_pt_eq(loop[0], loop[-1]) else loop, dtype=float)
    c = _loop_centroid(loop, axis)
    return float(np.max(np.linalg.norm(pts - c, axis=1)))


def _jitter_ring(ring, axis, thread_id, base_scale=0.004):
    """internal, used only by _build_thread_segments(): returns a copy
    of `ring` scaled a tiny, thread_id-specific amount outward from its
    own centroid (in the plane perpendicular to axis).

    Why this exists -- a real, confirmed failure mode: when two SIBLING
    branch threads both borrow overlap rings from the SAME parent run
    (the ordinary case right at a fork), a naive copy hands both
    threads bit-for-bit IDENTICAL boundary data. union()'s own
    docstring elsewhere in this file documents OCCT's fuse as "far more
    fragile on large flush/coplanar contact... than... a small contact
    patch," and specifically that this gets WORSE as several such
    contacts accumulate -- exactly what happened here: at a higher
    station count (more accumulated thread boundaries), a real
    branching reconstruction that worked cleanly at a lower station
    count came back as several small disconnected fragments instead of
    one merged solid.

    Two independently-fit ThruSections surfaces built from literally
    identical input rings are about as close to "large near-coincident
    contact" as this can get. Giving each thread its OWN, uniquely
    (if negligibly) scaled copy of any borrowed ring breaks the exact
    duplication -- the two threads still genuinely overlap the parent
    (and each other) by real volume, just not with bit-identical
    surfaces, which is what a boolean fuse needs to classify inside vs
    outside reliably. `base_scale` is deliberately tiny (0.4% per
    thread id by default) -- enough to separate the surfaces
    numerically, not enough to visibly change the shape."""
    pts = np.asarray(ring[:-1] if _ring_pt_eq(ring[0], ring[-1]) else ring, dtype=float)
    c = _loop_centroid(ring, axis)
    factor = 1.0 + base_scale * (1 + (thread_id % 7))
    out = (c + (pts - c) * factor).tolist()
    out.append(out[0])
    return out


def _warn_if_invalid(shape, where):
    """internal: runs OCCT's own BRepCheck_Analyzer over `shape` (the
    same raw-OCP validity-check pattern offset_shell() uses elsewhere in
    this file) and prints a clear console warning -- naming exactly
    what this app's own Pick Edges/Faces panel can be used to inspect
    further -- if it comes back invalid, rather than silently handing
    back bad geometry with no indication anything is wrong. Never
    raises and never blocks the result from being returned -- an
    invalid-but-mostly-there shape (visible holes/gaps rather than
    being unusable outright) is still often worth looking at, just not
    silently trusted as if union()/the healing pass fully succeeded."""
    try:
        from OCP.BRepCheck import BRepCheck_Analyzer
        is_ok = bool(BRepCheck_Analyzer(shape.wrapped).IsValid())
    except Exception:
        return  # couldn't even run the check -- stay silent rather than
                # raise a confusing secondary error about the CHECK itself
    if not is_ok:
        print(f"{where}: WARNING -- the result did not pass OCCT's own "
              f"validity check (BRepCheck_Analyzer) even after the "
              f".clean()/ShapeFix_Shape repair passes -- likely a real, "
              f"visible defect (a gap/hole where two branch pieces didn't "
              f"quite sew together, or a non-manifold edge from the union), "
              f"not just cosmetic. Use this app's Pick Edges/Faces panel to "
              f"inspect the suspicious area directly; increasing "
              f"`overlap_stations` (deeper genuine 3D overlap between "
              f"neighboring branch pieces) or `n` (more, closer-together "
              f"stations, so neighboring rings differ less) are the most "
              f"likely fixes.")


def _significant_loops(loops, ratio=0.15):
    """keeps a height's largest loop plus any other loop with at least
    `ratio` as many points as it -- same threshold slice_mesh_to_rings()'s
    own console warning uses to tell a real second lobe apart from a
    stray mesh-noise sliver."""
    if not loops:
        return []
    out = [loops[0]]
    for l in loops[1:]:
        if len(l) >= ratio * len(loops[0]):
            out.append(l)
    return out


def _segment_by_significant_count(all_loops, ratio=0.15):
    """groups a list of (height, loops) pairs into maximal runs where
    the SIGNIFICANT loop count (see _significant_loops()) stays
    constant. Returns (filtered_all_loops, runs), `runs` a list of
    (start_index, end_index_inclusive, loop_count) into filtered_all_loops."""
    filtered = [(h, _significant_loops(loops, ratio)) for h, loops in all_loops]
    runs = []
    start = 0
    prev_count = None
    for i, (h, loops) in enumerate(filtered):
        count = len(loops)
        if prev_count is None:
            prev_count = count
            start = i
        elif count != prev_count:
            runs.append((start, i - 1, prev_count))
            start = i
            prev_count = count
    runs.append((start, len(filtered) - 1, prev_count))
    return filtered, runs


def _match_loops_in_run(filtered, run, axis):
    """for a run with a CONSTANT loop count k > 1, matches loop i at
    each height to loop j at the next height by nearest-centroid
    assignment, producing k separate per-height ring lists ("threads")
    for the run. Uses scipy's Hungarian algorithm (optimal assignment)
    when available, falling back to a plain greedy nearest-first match
    if scipy isn't installed -- scipy is already an optional dependency
    of this app (see requirements.txt) so this should normally be the
    Hungarian path, but branch handling shouldn't hard-fail just
    because scipy happens to be missing."""
    s, e, k = run
    try:
        from scipy.optimize import linear_sum_assignment
        have_scipy = True
    except ImportError:
        have_scipy = False

    threads = [[filtered[s][1][j]] for j in range(k)]
    prev_centroids = [_loop_centroid(filtered[s][1][j], axis) for j in range(k)]
    for i in range(s + 1, e + 1):
        loops = filtered[i][1]
        cents = [_loop_centroid(l, axis) for l in loops]
        cost = np.zeros((k, k))
        for a in range(k):
            for b in range(k):
                cost[a, b] = np.linalg.norm(prev_centroids[a] - cents[b])
        if have_scipy:
            row, col = linear_sum_assignment(cost)
            pairs = list(zip(row, col))
        else:
            used_b = set()
            pairs = []
            for a in np.argsort(cost.min(axis=1)):
                b = min((b for b in range(k) if b not in used_b),
                        key=lambda b: cost[a, b])
                used_b.add(b)
                pairs.append((a, b))
        new_centroids = [None] * k
        for a, b in pairs:
            threads[a].append(loops[b])
            new_centroids[a] = cents[b]
        prev_centroids = new_centroids
    return threads


def _build_thread_segments(V, F, axis, n, heights, tol, significant_ratio,
                            overlap_stations, match_factor):
    """internal, used only by solid_from_mesh_slices(branches=True):
    full branch-aware segmentation. Returns a list of independent
    threads, each a list of (height_index, ring) pairs, each ready to
    be lofted into its own solid via _solid_from_ring_list() and then
    union()'d together.

    Every run (see _segment_by_significant_count()) gets extended by
    `overlap_stations` heights borrowed from its immediate neighboring
    run(s), so adjacent thread solids share real 3D volume at the
    boundary rather than just touching along a coincident face -- a
    much more robust starting point for a real CSG union.

    `match_factor` guards each borrow: a thread only extends into a
    neighboring run's loop if that loop's centroid sits within
    `match_factor` * the thread's own last ring's radius -- otherwise
    the thread genuinely ends here rather than being stitched onto
    whatever happens to be nearest. CONFIRMED necessary directly: an
    earlier version without this guard wrongly bridged a lobe that
    should have terminated at its own tip (a smaller sphere's dome,
    past its own local max height) all the way into a distant,
    unrelated single-loop run purely because "nearest available"
    always finds *something* -- fixed by only trusting a genuinely
    close match."""
    heights_arr, all_loops = _all_loops_per_height(V, F, axis=axis, n=n, heights=heights, tol=tol)
    all_loops_pairs = list(zip(heights_arr, all_loops))
    filtered, runs = _segment_by_significant_count(all_loops_pairs, significant_ratio)

    run_threads = []
    for run in runs:
        s, e, k = run
        if k == 0:
            run_threads.append([])
            continue
        if k == 1:
            run_threads.append([[(i, filtered[i][1][0]) for i in range(s, e + 1)]])
            continue
        threads_pts_only = _match_loops_in_run(filtered, run, axis)
        run_threads.append([[(s + off, ring_list[off]) for off in range(len(ring_list))]
                             for ring_list in threads_pts_only])

    final_threads = []
    next_thread_id = 0
    for ri, (run, threads) in enumerate(zip(runs, run_threads)):
        s, e, k = run
        if k == 0:
            continue
        extended = [list(t) for t in threads]
        # a stable, unique id per thread in THIS run -- used below so
        # two sibling threads borrowing from the SAME neighboring ring
        # each get their own distinctly-jittered copy (see _jitter_ring()'s
        # own comment for why that matters)
        ids = list(range(next_thread_id, next_thread_id + len(extended)))
        next_thread_id += len(extended)

        if ri > 0:
            ps, pe, pk = runs[ri - 1]
            prev_threads = run_threads[ri - 1]
            n_borrow = min(overlap_stations, pe - ps + 1)
            for t, tid in zip(extended, ids):
                my_first_ring = t[0][1]
                my_c = _loop_centroid(my_first_ring, axis)
                my_r = _loop_radius(my_first_ring, axis)
                best, best_d = None, None
                for pt in prev_threads:
                    pc = _loop_centroid(pt[-1][1], axis)
                    d = np.linalg.norm(pc - my_c)
                    if best_d is None or d < best_d:
                        best_d, best = d, pt
                if best is not None and best_d <= match_factor * my_r:
                    borrowed = [(idx, _jitter_ring(ring, axis, tid))
                                for idx, ring in best[-n_borrow:]]
                    t[0:0] = borrowed

        if ri < len(runs) - 1:
            ns, ne, nk = runs[ri + 1]
            next_threads = run_threads[ri + 1]
            n_borrow = min(overlap_stations, ne - ns + 1)
            for t, tid in zip(extended, ids):
                my_last_ring = t[-1][1]
                my_c = _loop_centroid(my_last_ring, axis)
                my_r = _loop_radius(my_last_ring, axis)
                best, best_d = None, None
                for nt in next_threads:
                    nc = _loop_centroid(nt[0][1], axis)
                    d = np.linalg.norm(nc - my_c)
                    if best_d is None or d < best_d:
                        best_d, best = d, nt
                if best is not None and best_d <= match_factor * my_r:
                    borrowed = [(idx, _jitter_ring(ring, axis, tid))
                                for idx, ring in best[:n_borrow]]
                    t.extend(borrowed)

        final_threads.extend(extended)

    kept = []
    for t in final_threads:
        if len(t) >= 2:
            kept.append(t)
        else:
            h = filtered[t[0][0]][0]
            print(f"solid_from_mesh_slices(branches=True): WARNING -- a transient "
                  f"branch near height {h:.4g} ({len(t[0][1])} points) only spans a "
                  f"single sampled station even after borrowing overlap -- too short "
                  f"to loft into its own solid, so it's being skipped. Raise `n` "
                  f"(denser slicing) if this feature matters and needs to be captured.")
    return kept


def _sub3(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _add3(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def _scale3(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def _dot3(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _cross3(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _triangle_line_intersection(triangle, line):
    """internal: openscad4.py's own triangle_line_intersection(),
    ported -- the point where segment `line` ([p, q]) pierces
    `triangle` ([a, b, c]), or None if it doesn't (parametric
    triangle/segment intersection, same Cramer's-rule-style solve as
    the original, just plain-tuple 3D vector math instead of numpy)."""
    a, b, c = triangle
    p, q = line
    ab, ac, pq = _sub3(b, a), _sub3(c, a), _sub3(q, p)
    x = _cross3(ab, ac)
    denom = -_dot3(pq, x)
    if abs(denom) < 1e-12:
        return None
    pa = _sub3(p, a)
    t = _dot3(x, pa) / denom
    neg_pq = _scale3(pq, -1)
    u = _dot3(_cross3(ac, neg_pq), pa) / denom
    v = _dot3(_cross3(neg_pq, ab), pa) / denom
    if 0 <= t <= 1 and 0 <= u <= 1 and 0 <= v <= 1 and (u + v) <= 1:
        return list(_add3(p, _scale3(pq, t)))
    return None


def _triangle_triangle_intersection(triangle1, triangle2):
    """internal: openscad4.py's own triangle_triangle_intersection(),
    ported -- the intersection segment (2 points) between two
    triangles, or None if they don't intersect: tests each triangle's
    3 edges against the OTHER triangle, same as the original."""
    a, b, c = triangle1
    d, e, f = triangle2
    edges1 = [(a, b), (b, c), (c, a)]
    edges2 = [(d, e), (e, f), (f, d)]
    p1 = [pt for pt in (_triangle_line_intersection(triangle2, edge) for edge in edges1) if pt is not None]
    p2 = [pt for pt in (_triangle_line_intersection(triangle1, edge) for edge in edges2) if pt is not None]
    if len(p1) == 2:
        return p1
    if len(p2) == 2:
        return p2
    if len(p1) == 1 and len(p2) == 1:
        return [p1[0], p2[0]]
    return None


def two_solids_intersection(a, b, tolerance=0.1, angular_tolerance=0.3):
    """
    The raw intersection LINE SEGMENTS between two real B-rep shapes
    `a`/`b` -- openscad4.py's own two_solids_intersection(), ported:
    tessellates each into a triangle mesh (to_mesh(), same tolerance/
    angular_tolerance meaning as there) and tests every pair of
    nearby triangles (after a bounding-sphere prefilter) for a genuine
    triangle-triangle crossing. Returns the raw, DISCONNECTED list of
    2-point segments -- feed it through contiguous_chains() to stitch
    them into one or more ordered curves:

        segs = two_solids_intersection(a, b)
        spine = contiguous_chains(segs)[0]   # the first (often only) chain

    WHY REACH FOR THIS instead of intersection() (the real B-rep
    boolean, exact and usually the right first choice): OCCT's exact
    boolean intersection can be numerically fragile on genuinely hard
    curved cases (see fillet()'s own docstring for the same class of
    real failure mode) -- a mesh-vs-mesh triangle intersection test
    doesn't care about exact analytic surfaces at all, just triangle
    soup, so it tends to be far more forgiving when intersection()
    itself struggles or errors. The tradeoff: the result is a faceted
    APPROXIMATION of the true curve (as accurate as `tolerance`/
    `angular_tolerance` make the underlying tessellation), not an
    exact analytic curve.

    The full manual-fillet recipe this exists for (see
    convert_3lines2fillet()'s own docstring for the rest of the
    pipeline once you have `spine`):

        spine = contiguous_chains(two_solids_intersection(a, b))[0]
        line_b = sample_curve(intersection(offset_face(a, blend), b), len(spine))
        line_a = sample_curve(intersection(a, offset_face(b, blend)), len(spine))
        grid = convert_3lines2fillet(line_a, line_b, spine, s=15)
        patch = surface_from_points_grid(grid)

    (mixing a mesh-derived `spine` with real-B-rep-derived `line_a`/
    `line_b` like this is fine -- they're just point lists by the time
    convert_3lines2fillet() sees them.)

    REAL PERFORMANCE NOTE: this is a plain O(len(mesh_a) * len(mesh_b))
    pair of nested loops (with a cheap bounding-sphere distance check
    to skip clearly-far pairs) -- brep.py deliberately has no numpy
    dependency (see xrot()'s own docstring), so this doesn't get
    openscad4.py's fully vectorized einsum version. Fine for the
    moderate mesh sizes to_mesh() produces at normal tolerances; if
    it's slow, tessellate coarser first (a bigger `tolerance` here) --
    fewer, larger triangles means far fewer pairs to test.
    """
    _require_build123d()
    va, fa = to_mesh(a, tolerance, angular_tolerance)
    vb, fb = to_mesh(b, tolerance, angular_tolerance)
    tris_a = [[tuple(va[i]) for i in f] for f in fa]
    tris_b = [[tuple(vb[i]) for i in f] for f in fb]

    def centroid(tri):
        return (sum(p[0] for p in tri) / 3.0, sum(p[1] for p in tri) / 3.0, sum(p[2] for p in tri) / 3.0)

    def bounding_radius_sq(tri, cen):
        return max(_dot3(_sub3(p, cen), _sub3(p, cen)) for p in tri)

    cens_a = [centroid(t) for t in tris_a]
    rad2_a = [bounding_radius_sq(t, c) for t, c in zip(tris_a, cens_a)]
    cens_b = [centroid(t) for t in tris_b]
    rad2_b = [bounding_radius_sq(t, c) for t, c in zip(tris_b, cens_b)]

    segments = []
    for i, tri_a in enumerate(tris_a):
        ca, ra2 = cens_a[i], rad2_a[i]
        for j, tri_b in enumerate(tris_b):
            cb, rb2 = cens_b[j], rad2_b[j]
            d = _sub3(ca, cb)
            if _dot3(d, d) > ra2 + rb2:
                continue
            seg = _triangle_triangle_intersection(tri_a, tri_b)
            if seg is not None:
                segments.append(seg)
    return segments


def ang(x, y):
    """
    The polar angle (degrees, 0-360) of the 2D vector (x, y) measured
    from the origin -- openscad4.py's own ang(), ported. Same
    computation as math.degrees(math.atan2(y, x)), just wrapped into
    0-360 instead of -180..180 (and the exact same math already used
    internally throughout this file, e.g. by arc_3p()/ang_2lineccw()/
    etc, via the internal _polar_angle_deg() helper -- ang() just
    exposes that under its original name for direct use in your own
    scripts):

        p1, p2 = [3, 4], [-3, 2]
        v = [p2[0] - p1[0], p2[1] - p1[1]]
        a = ang(v[0], v[1])
    """
    return _polar_angle_deg(x, y)


def ang_2lineccw(p0, p1, p2):
    """
    The counter-clockwise angle (degrees, 0-360) of the ray p0->p2
    measured from the ray p0->p1 -- "how far ccw do you turn from
    pointing at p1 to pointing at p2, both from p0". 2D.
    """
    v1 = (p1[0] - p0[0], p1[1] - p0[1])
    v2 = (p2[0] - p0[0], p2[1] - p0[1])
    a1 = _polar_angle_deg(*v1)
    a2 = _polar_angle_deg(*v2)
    if a1 == a2:
        return 360.0
    return (360 - (a1 - a2)) if a2 < a1 else (a2 - a1)


def ang_2linecw(p0, p1, p2):
    """Clockwise counterpart of ang_2lineccw()."""
    v1 = (p1[0] - p0[0], p1[1] - p0[1])
    v2 = (p2[0] - p0[0], p2[1] - p0[1])
    a = _polar_angle_deg(*v1)
    b = _polar_angle_deg(*v2)
    return abs(a - b) if b <= a else (360 - b) + a


def ang3points(p0, p1, p2):
    """
    The interior angle (degrees, 0-360 -- not clamped to 0-180, so it
    tells you which way the path bends) at the middle point of the
    3-point path p0-p1-p2. 2D.
    """
    orientation = _cw_2d([p0, p1, p2])
    if orientation == 1:
        return ang_2lineccw(p1, p0, p2)
    if orientation == -1:
        return ang_2linecw(p1, p0, p2)
    raise ValueError("ang3points(): p0, p1, p2 are collinear")


def i_p2d(l1, l2):
    """
    The intersection point of two 2D lines l1=[p0,p1], l2=[p2,p3],
    extended infinitely (not clipped to the segments) -- e.g.
    i_p2d([[0,0],[1,4]], [[10,0],[7,2]]) -> [1.4286, 5.7143]. Raises if
    the lines are parallel.
    """
    (x1, y1), (x2, y2) = l1[0], l1[1]
    (x3, y3), (x4, y4) = l2[0], l2[1]
    denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if abs(denom) < 1e-12:
        raise ValueError("i_p2d(): the two lines are parallel (no unique intersection)")
    a = x1 * y2 - y1 * x2
    b = x3 * y4 - y3 * x4
    return [(a * (x3 - x4) - (x1 - x2) * b) / denom, (a * (y3 - y4) - (y1 - y2) * b) / denom]


def perpendicularProjectionOfPointOnLine(p0, l1):
    """
    The perpendicular projection of `p0` onto polyline `l1` -- the
    closest point that actually lies ON one of `l1`'s segments (foot
    strictly between that segment's endpoints); [] if no segment has a
    valid perpendicular foot.
    """
    candidates = []
    for a, b in zip(l1[:-1], l1[1:]):
        foot, t, dist = _project_point_on_segment(p0, [a, b])
        if 0 <= t <= 1:
            candidates.append((dist, foot))
    if not candidates:
        return []
    candidates.sort(key=lambda c: c[0])
    return candidates[0][1]


def distanceOfPointFromLine(p0, l1):
    """Perpendicular distance of `p0` from polyline `l1` -- [] if
    perpendicularProjectionOfPointOnLine() finds no valid foot."""
    foot = perpendicularProjectionOfPointOnLine(p0, l1)
    return l_len([foot, p0]) if foot != [] else []


def mirror_line(pts, n1, loc):
    """
    Mirrors every point in `pts` across the plane through `loc` with
    normal `n1` -- e.g. mirror_line(circle_pts, [1,1,0], [0,0,0])
    reflects a 2D point list across the plane x+y=0. 2D points are
    treated as z=0 while mirroring; the result comes back 2D too
    unless mirroring genuinely moves a point off the z=0 plane.
    """
    n = _3d_unit((float(n1[0]), float(n1[1]), float(n1[2])))
    loc3 = (float(loc[0]), float(loc[1]), float(loc[2]))
    was_2d = all(len(p) <= 2 for p in pts)
    out = []
    for p in pts:
        p3 = (float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0)
        d = _3d_dot((p3[0] - loc3[0], p3[1] - loc3[1], p3[2] - loc3[2]), n)
        out.append((p3[0] - 2 * d * n[0], p3[1] - 2 * d * n[1], p3[2] - 2 * d * n[2]))
    if was_2d and all(abs(p[2]) < 1e-9 for p in out):
        return [[p[0], p[1]] for p in out]
    return [list(p) for p in out]


def mirror_point(pnt, n1, loc):
    """Mirrors a single point `pnt` -- see mirror_line()."""
    return mirror_line([pnt], n1, loc)[0]


def rot2d(a, sec):
    """Rotates 2D point list `sec` by `a` degrees counter-clockwise
    around the origin (any extra coordinates beyond x,y pass through
    unchanged)."""
    rad = math.radians(a)
    c, s = math.cos(rad), math.sin(rad)
    out = []
    for p in sec:
        x, y = float(p[0]), float(p[1])
        nx, ny = x * c - y * s, x * s + y * c
        out.append([nx, ny] + list(p[2:]) if len(p) > 2 else [nx, ny])
    return out


def xrot(theta):
    """
    The 3x3 rotation matrix for rotating a point around the X axis by
    `theta` degrees (right-hand rule) -- openscad4.py's own xrot(),
    ported as a plain nested Python list (3 rows of 3 numbers)
    instead of a numpy array, matching brep.py's other point-list
    math (no numpy dependency needed inside brep.py itself). Apply it
    to a point as a row vector times this matrix, same convention the
    original used (see xrot4d() below for a ready-made point-rotation
    helper that does exactly that, or write your own with numpy if
    you already have `np`/`numpy` imported in your script:
    `array(v) @ array(xrot(theta))`).
    """
    c, s = math.cos(math.radians(theta)), math.sin(math.radians(theta))
    return [
        [1.0, 0.0, 0.0],
        [0.0, c, s],
        [0.0, -s, c],
    ]


def yrot(theta):
    """Same as xrot(), but the rotation matrix for the Y axis."""
    c, s = math.cos(math.radians(theta)), math.sin(math.radians(theta))
    return [
        [c, 0.0, -s],
        [0.0, 1.0, 0.0],
        [s, 0.0, c],
    ]


def zrot(theta):
    """Same as xrot(), but the rotation matrix for the Z axis."""
    c, s = math.cos(math.radians(theta)), math.sin(math.radians(theta))
    return [
        [c, s, 0.0],
        [-s, c, 0.0],
        [0.0, 0.0, 1.0],
    ]


def _mat3_vec_mul(v3, m):
    """internal: v3 @ m -- v3 as a row vector times the 3x3 matrix m,
    matching xrot()/yrot()/zrot()'s own row-vector convention."""
    return [sum(v3[i] * m[i][j] for i in range(3)) for j in range(3)]


def xrot4d(theta, v):
    """
    Rotates a point `v` (a [x,y,z] point, or a longer one like
    [x,y,z,extra,...] -- e.g. pts3()/corner_radius3d()-style points
    with a trailing corner-radius value) around the X axis by `theta`
    degrees, using xrot() -- openscad4.py's own xrot4d(), ported. Any
    elements beyond the first 3 (x,y,z) pass through unchanged.
    """
    return _mat3_vec_mul([float(c) for c in v[:3]], xrot(theta)) + list(v[3:])


def yrot4d(theta, v):
    """Same as xrot4d(), but rotates around the Y axis (via yrot())."""
    return _mat3_vec_mul([float(c) for c in v[:3]], yrot(theta)) + list(v[3:])


def zrot4d(theta, v):
    """Same as xrot4d(), but rotates around the Z axis (via zrot())."""
    return _mat3_vec_mul([float(c) for c in v[:3]], zrot(theta)) + list(v[3:])


def c23(pts):
    """
    Converts a 2D point list to 3D by padding each point with z=0 --
    openscad4.py's own c23()/c2t3(), ported. Points that are already
    3D pass through unchanged. Handy right before feeding a plain 2D
    point list (turtle2d()/cr2dt()'s output, etc) to a function that
    expects real 3D points:

        c23([[0, 0], [10, 0]])   # -> [[0, 0, 0], [10, 0, 0]]
    """
    return [[float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0] for p in pts]


def c32(pts):
    """
    Converts a 3D point list to 2D by dropping z -- openscad4.py's own
    c32()/c3t2(), ported (the inverse of c23()). Points that are
    already 2D pass through unchanged.

        c32([[1, 2, 3], [4, 5, 6]])   # -> [[1, 2], [4, 5]]
    """
    return [[float(p[0]), float(p[1])] for p in pts]


def rot_p(a, points):
    """
    Rotates a point list `points` (2D or 3D -- sinewave()/cosinewave()
    output, cr2dt()'s output, etc) by axis letters and angles packed
    into a single string `a` -- the point-list sibling of rot()/
    rotate(), which only work on real Shapes. Same string convention
    as openscad4.py's own rot()/brep.py's own rot(): each axis is
    applied in the ORDER it appears in the string.

        rot_p('x90', [[0, 0], [10, 0]])
        # rotates around X by 90 deg

        rot_p('z30x70y-90', points)
        # rotates z by 30, then x by 70, then y by -90, in that order

    2D points are padded to z=0 first (via c23()); extra trailing
    values on a point (e.g. a corner-radius column) pass through
    unchanged, same as xrot4d()/yrot4d()/zrot4d() (which this is built
    from). This is the tool for the sinewave/cosinewave-into-a-plane
    trick used throughout the surface_from_2_waves() examples --
    instead of building each wave directly in its target plane
    (`[[x, 0, y] for x, y in sinewave(...)]`), you can now do:

        l1 = rot_p('x90', sinewave(60, 3, 8, 60))
        l2 = rot_p('x90z90', cosinewave(60, 3, 8, 60))
    """
    axis_idx = [i for i, ch in enumerate(a) if ch in "xyz"] + [len(a)]
    segments = list(zip(axis_idx[:-1], axis_idx[1:]))
    if not segments:
        raise ValueError(f"rot_p(): couldn't find any x/y/z axis letters in {a!r}")
    rotors = {"x": xrot4d, "y": yrot4d, "z": zrot4d}
    pts = c23(points)
    for i, j in segments:
        axis = a[i]
        theta = float(a[i + 1:j])
        pts = [rotors[axis](theta, p) for p in pts]
    return pts


def xyc(pnts):
    """
    Zeroes the z-coordinate of every point in a 3D point list --
    openscad4.py's own xyc(), ported: projects onto the XY plane while
    keeping the points 3D (unlike c32(), which drops z entirely and
    returns 2D points).

        xyc([[1, 2, 3], [4, 5, 6]])   # -> [[1, 2, 0], [4, 5, 0]]
    """
    return [[float(p[0]), float(p[1]), 0.0] for p in pnts]


def xzc(pnts):
    """
    Zeroes the y-coordinate of every point in a 3D point list --
    openscad4.py's own xzc(), ported: projects onto the XZ plane.

        xzc([[1, 2, 3], [4, 5, 6]])   # -> [[1, 0, 3], [4, 0, 6]]
    """
    return [[float(p[0]), 0.0, float(p[2])] for p in pnts]


def yzc(pnts):
    """
    Zeroes the x-coordinate of every point in a 3D point list --
    openscad4.py's own yzc(), ported: projects onto the YZ plane.

        yzc([[1, 2, 3], [4, 5, 6]])   # -> [[0, 2, 3], [0, 5, 6]]
    """
    return [[0.0, float(p[1]), float(p[2])] for p in pnts]


def _arc_2p_center(p1, p2, r, cw):
    """internal: the center of a radius-`r` circle through `p1`,`p2`,
    on the side `cw` picks (see arc_2p()'s docstring)."""
    mid = [(p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2]
    d = l_len([mid, p1])
    if abs(r) < d - 1e-9:
        raise ValueError(f"radius {r} is too small to span the two points (need at least {d:.6g})")
    h = math.sqrt(max(0.0, r * r - d * d))
    vx, vy = p1[0] - mid[0], p1[1] - mid[1]
    vlen = math.hypot(vx, vy)
    if vlen < 1e-12:
        raise ValueError("the two points coincide")
    ux, uy = vx / vlen, vy / vlen
    perpx, perpy = (-uy, ux) if cw == 1 else (uy, -ux)
    return [mid[0] + perpx * h, mid[1] + perpy * h]


def arc(radius=0, start_angle=0, end_angle=0, cp=(0, 0), s=20):
    """
    The most basic arc primitive: a point list tracing a circle of
    `radius` around center `cp`, sweeping from `start_angle` to
    `end_angle` degrees (0 = +X axis, counter-clockwise-positive), as
    `s` segments (s+1 points) -- openscad4.py's own arc(), ported
    directly (angles/center/radius given explicitly, unlike
    arc_2p()/arc_3p() below, which instead *fit* an arc to given
    points). Handy for a simple pie-slice/fillet-by-hand/dial-gauge
    curve where you already know the center and sweep you want:

        a1 = arc(radius=10, start_angle=180, end_angle=270, cp=[10, 10], s=20)
        show(p_line3d(a1, .3))
    """
    return _arc_deg(float(radius), float(start_angle), float(end_angle), [float(cp[0]), float(cp[1])], int(s))


def arc_edge(radius, start_angle=0, end_angle=360, cp=(0, 0)):
    """
    The exact, real-B-rep counterpart of arc(): a genuine analytic
    circular-arc Edge (build123d's own Edge.make_circle(), a true
    curved curve, not a faceted point list), same
    radius/start_angle/end_angle/cp meaning as arc(). No `s` -- there's
    no facet count to choose, same reasoning as circle(s=None).

    Use this (not arc()) anywhere a *real curve* is wanted, especially
    as sweep_sec2path()'s `path3d`: feeding arc()'s point list straight
    in (even via c23()) turns it into a 20-straight-segment Polyline,
    and with the default transition="round" that means OCCT has to
    build a rounded joint at every one of those ~19 corners -- slow,
    and pointless when the path is really just a circular arc. arc_edge()
    sweeps as one smooth analytic curve instead, same as circle()
    already does for a *full* circle:

        path = arc_edge(20, -90, 90)
        a = sweep_sec2path(circle(5), path)   # fast, exact
        show(a)

    arc() itself is still the right choice for turtle-path point-list
    math (feeding into p_line3d(), s_int1(), offset() trimming, etc) --
    this is only for when you specifically want a real curved Edge.
    """
    _require_build123d()
    p = bd.Plane(origin=(float(cp[0]), float(cp[1]), 0.0), z_dir=(0, 0, 1))
    return bd.Edge.make_circle(float(radius), plane=p, start_angle=float(start_angle), end_angle=float(end_angle))


def arc_2p(p1, p2, r, cw=1, s=20):
    """
    An arc between 2 points `p1`,`p2` with radius `r`, as an
    `s`-segment point list. There are always two circles of radius `r`
    through 2 points (centers on either side of the chord); `cw`=1
    (default) traces the clockwise arc between them (the one on that
    circle), `cw`=-1 the counter-clockwise one (the other circle).
    """
    p1 = [float(c) for c in p1]
    p2 = [float(c) for c in p2]
    cp = _arc_2p_center(p1, p2, r, cw)
    a1 = _polar_angle_deg(p1[0] - cp[0], p1[1] - cp[1])
    a2 = _polar_angle_deg(p2[0] - cp[0], p2[1] - cp[1])
    a2f = (a2 + 360 if a2 < a1 else a2) if cw == -1 else (a2 if a2 < a1 else a2 - 360)
    return _arc_deg(r, a1, a2f, cp, s)


def cir_2p(p1, p2, r, cw=1, s=20):
    """A full circle of radius `r` through both `p1` and `p2`, as an
    `s`-segment point list -- `cw` picks which of the two possible
    circles (see arc_2p()'s docstring)."""
    p1 = [float(c) for c in p1]
    p2 = [float(c) for c in p2]
    cp = _arc_2p_center(p1, p2, r, cw)
    a1 = _polar_angle_deg(p1[0] - cp[0], p1[1] - cp[1])
    return _arc_deg(r, a1, a1 + 360, cp, s)


def cp_3p(p1, p2, p3):
    """The center (circumcenter) of the circle through 3 points `p1`,
    `p2`, `p3` -- 2D or 3D (3 points always share a plane)."""
    a = l_len([p2, p3])
    b = l_len([p1, p3])
    c = l_len([p1, p2])
    a2, b2, c2 = a * a, b * b, c * c
    wa = a2 * (b2 + c2 - a2)
    wb = b2 * (a2 + c2 - b2)
    wc = c2 * (a2 + b2 - c2)
    wsum = wa + wb + wc
    if abs(wsum) < 1e-9:
        raise ValueError("cp_3p(): the 3 points are (nearly) collinear")
    dim = len(p1)
    return [(wa * p1[i] + wb * p2[i] + wc * p3[i]) / wsum for i in range(dim)]


def arc_3p(p1, p2, p3, s=30):
    """An arc through 3 2D points `p1`,`p2`,`p3` (their circumcircle's
    arc from p1 through p2 to p3), as an `s`-segment point list."""
    cp = cp_3p(p1, p2, p3)
    r = l_len([p1, cp])
    a1 = _polar_angle_deg(p1[0] - cp[0], p1[1] - cp[1])
    a3 = _polar_angle_deg(p3[0] - cp[0], p3[1] - cp[1])
    orientation = _cw_2d([p1, p2, p3])
    a3f = (a3 + 360 if a3 < a1 else a3) if orientation == -1 else (a3 if a3 < a1 else a3 - 360)
    return _arc_deg(r, a1, a3f, cp, s)


def cir_3p(p1, p2, p3, s=50):
    """A full circle through 3 2D points, as an `s`-segment point
    list -- same circumcenter/radius as arc_3p()/cp_3p()."""
    cp = cp_3p(p1, p2, p3)
    r = l_len([p1, cp])
    return _arc_deg(r, 0, 360, cp, s)


def arc_2p_3d(n1, p0, p1, r, cw=1, s=20):
    """
    3D counterpart of arc_2p() -- an arc between two 3D points `p0`,
    `p1`, lying in the plane with normal `n1` through `p0`.
    """
    n = _3d_unit((float(n1[0]), float(n1[1]), float(n1[2])))
    p0 = [float(c) for c in p0]
    p1 = [float(c) for c in p1]
    origin = p0
    raw = (p1[0] - origin[0], p1[1] - origin[1], p1[2] - origin[2])
    if math.sqrt(sum(c * c for c in raw)) < 1e-9:
        raise ValueError("arc_2p_3d(): p0 and p1 coincide")
    d = _3d_dot(raw, n)
    e1_raw = (raw[0] - d * n[0], raw[1] - d * n[1], raw[2] - d * n[2])
    e1len = math.sqrt(sum(c * c for c in e1_raw))
    if e1len < 1e-9:
        raise ValueError("arc_2p_3d(): p0->p1 is parallel to n1 -- they can't both lie in that plane")
    e1 = (e1_raw[0] / e1len, e1_raw[1] / e1len, e1_raw[2] / e1len)
    e2 = _3d_cross(n, e1)

    def to_2d(p):
        v = (p[0] - origin[0], p[1] - origin[1], p[2] - origin[2])
        return [_3d_dot(v, e1), _3d_dot(v, e2)]

    def to_3d(p2):
        return [origin[0] + p2[0] * e1[0] + p2[1] * e2[0],
                origin[1] + p2[0] * e1[1] + p2[1] * e2[1],
                origin[2] + p2[0] * e1[2] + p2[1] * e2[2]]

    arc2d = arc_2p(to_2d(p0), to_2d(p1), r, cw, s)
    return [to_3d(p) for p in arc2d]


def tcct(r1, r2, cp1, cp2, cw=1):
    """
    The internal (crossing) tangent line between two circles -- radius
    `r1` centered at `cp1`, radius `r2` centered at `cp2` -- as
    [touch_point_on_circle1, touch_point_on_circle2]. Only exists when
    the circles don't overlap (center distance >= r1+r2); raises
    otherwise. There are always two internal tangent lines (mirrored
    across the line joining the centers); `cw`=1 (default) picks one,
    `cw`=-1 the other.
    """
    cp1 = [float(c) for c in cp1]
    cp2 = [float(c) for c in cp2]
    d_vec = (cp2[0] - cp1[0], cp2[1] - cp1[1])
    d = math.hypot(*d_vec)
    if d < 1e-9:
        raise ValueError("tcct(): the two circles have coincident centers")
    if d < r1 + r2 - 1e-9:
        raise ValueError(
            f"tcct(): circles overlap (center distance {d:.6g} < r1+r2 "
            f"{r1 + r2:.6g}) -- no internal tangent exists")
    d_hat = (d_vec[0] / d, d_vec[1] / d)
    d_perp = (-d_hat[1], d_hat[0])
    cos_t = max(-1.0, min(1.0, -(r1 + r2) / d))
    theta = math.acos(cos_t)
    sin_t = math.sin(theta) if cw == 1 else -math.sin(theta)
    n = (cos_t * d_hat[0] + sin_t * d_perp[0], cos_t * d_hat[1] + sin_t * d_perp[1])
    p0 = [cp1[0] - r1 * n[0], cp1[1] - r1 * n[1]]
    p1 = [cp2[0] + r2 * n[0], cp2[1] + r2 * n[1]]
    return [p0, p1]


def remove_extra_points(points_list):
    """Removes duplicate entries from `points_list`, keeping each
    one's FIRST occurrence and original order -- works on plain values
    or point lists alike."""
    seen = []
    out = []
    for p in points_list:
        key = tuple(p) if isinstance(p, (list, tuple)) else p
        if key not in seen:
            seen.append(key)
            out.append(p)
    return out


def min_d_points(sec, min_d=0.1):
    """Thins `sec` so consecutive KEPT points are always at least
    `min_d` apart (measured from the last point actually kept, not
    just each point's immediate predecessor in `sec`)."""
    if not sec:
        return []
    out = [sec[0]]
    last = sec[0]
    for p in sec[1:]:
        if l_len([last, p]) >= min_d:
            out.append(p)
            last = p
    return out


def sort_points(sec, list1):
    """
    For every point in `sec`, finds its nearest point in `list1` --
    returns a list the same length as `sec`. Brute-force nearest-
    neighbor search (fine for hand-built profile/path point counts).
    """
    out = []
    for p in sec:
        nearest = min(list1, key=lambda q: l_len([p, q]))
        out.append(nearest)
    return out


def convex_hull(pnts):
    """
    The convex hull of 2D point list `pnts`, as an ordered point list
    of just the hull's own vertices (the outline you'd get wrapping a
    rubber band around every point). Andrew's monotone chain
    algorithm.
    """
    pts = sorted(set(tuple(p) for p in pnts))
    if len(pts) <= 2:
        return [list(p) for p in pts]

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    lower = []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    upper = []
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return [list(p) for p in lower[:-1] + upper[:-1]]


def normal_vector(sec):
    """
    The unit normal vector of a planar point list `sec` (3+ points) --
    exactly 3 points uses a plain cross product; more uses Newell's
    method (robust for any planar polygon, convex or not, as long as
    the points are genuinely coplanar).
    """
    n = len(sec)
    if n < 3:
        raise ValueError("normal_vector(): need at least 3 points")
    pts = [[float(c) for c in p] + ([0.0] if len(p) == 2 else []) for p in sec]
    if n == 3:
        v1 = [pts[1][i] - pts[0][i] for i in range(3)]
        v2 = [pts[2][i] - pts[0][i] for i in range(3)]
        nrm = _3d_cross(v1, v2)
    else:
        nx = ny = nz = 0.0
        for i in range(n):
            x0, y0, z0 = pts[i]
            x1, y1, z1 = pts[(i + 1) % n]
            nx += (y0 - y1) * (z0 + z1)
            ny += (z0 - z1) * (x0 + x1)
            nz += (x0 - x1) * (y0 + y1)
        nrm = (nx, ny, nz)
    return list(_3d_unit(nrm))


def equation_of_plane(pts):
    """The equation of the plane through `pts` (3+ coplanar points),
    as [a,b,c,d] where ax+by+cz=d -- built on normal_vector()."""
    n = normal_vector(pts)
    p0 = pts[0]
    p0_3 = [float(p0[0]), float(p0[1]), float(p0[2]) if len(p0) > 2 else 0.0]
    d = sum(n[i] * p0_3[i] for i in range(3))
    return list(n) + [d]


def fillet3points(sec, r=1, s=20):
    """
    The fillet arc rounding the corner at the middle point of the
    3-point path `sec`=[p0,p1,p2], radius `r`, as an `s`-segment point
    list -- the single-corner building block cr2dt() applies at every
    vertex of a whole profile at once (see its docstring for the
    underlying math).
    """
    p0, p1, p2 = sec
    u1 = _2d_unit((p0[0] - p1[0], p0[1] - p1[1]))
    u2 = _2d_unit((p2[0] - p1[0], p2[1] - p1[1]))
    len1 = l_len([p1, p0])
    len2 = l_len([p1, p2])
    dot = max(-1.0, min(1.0, u1[0] * u2[0] + u1[1] * u2[1]))
    theta = math.acos(dot)
    if theta < 1e-9 or theta > math.pi - 1e-9:
        raise ValueError("fillet3points(): p0, p1, p2 are (nearly) collinear -- no corner to fillet")
    tlen = r / math.tan(theta / 2)
    if tlen > len1 or tlen > len2:
        raise ValueError(
            f"fillet3points(): radius {r} is too large for the given points "
            f"(needs {tlen:.6g}, edges are {len1:.6g}/{len2:.6g} long)")
    t1 = (p1[0] + u1[0] * tlen, p1[1] + u1[1] * tlen)
    t2 = (p1[0] + u2[0] * tlen, p1[1] + u2[1] * tlen)
    bis_u = _2d_unit((u1[0] + u2[0], u1[1] + u2[1]))
    center_dist = r / math.sin(theta / 2)
    center = (p1[0] + bis_u[0] * center_dist, p1[1] + bis_u[1] * center_dist)
    a1 = math.degrees(math.atan2(t1[1] - center[1], t1[0] - center[0]))
    a2 = math.degrees(math.atan2(t2[1] - center[1], t2[0] - center[0]))
    d_angle = (a2 - a1 + 180) % 360 - 180
    return _arc_deg(r, a1, a1 + d_angle, center, s)


def bezier(pl, s=20):
    """A Bezier curve through control points `pl` (passes through the
    first/last point only, pulled toward the others), as an `s`-point
    list -- standard Bernstein-polynomial construction. 2D or 3D."""
    n = len(pl) - 1
    dim = len(pl[0])
    out = []
    for k in range(s):
        t = k / (s - 1) if s > 1 else 0.0
        pt = [0.0] * dim
        for i, p in enumerate(pl):
            b = math.comb(n, i) * (t ** i) * ((1 - t) ** (n - i))
            for d in range(dim):
                pt[d] += float(p[d]) * b
        out.append(pt)
    return out


def bspline_open(pl, deg=3, s=100):
    """
    An open (clamped) B-spline curve through control points `pl`,
    degree `deg` (0 <= deg < len(pl)), as an `s`-point list -- passes
    through the first and last control points; `deg`=1 gives a plain
    polyline through every point, higher degrees smooth it out more.
    Standard Cox-de Boor recursive basis functions. 2D or 3D.
    """
    n = len(pl) - 1
    k = deg
    if not (0 <= k < len(pl)):
        raise ValueError(f"bspline_open(): deg must be 0 <= deg < {len(pl)}, got {deg}")
    dim = len(pl[0])

    def knot(i):
        if i <= k:
            return 0
        if i <= n:
            return i - k
        return n - k + 1

    def basis(i, kk, u):
        if kk == 0:
            return 1.0 if knot(i) < u <= knot(i + 1) else 0.0
        t_i, t_ik, t_i1, t_ik1 = knot(i), knot(i + kk), knot(i + 1), knot(i + kk + 1)
        a = 0.0 if t_ik == t_i else (u - t_i) / (t_ik - t_i)
        b = 0.0 if t_ik1 == t_i1 else (t_ik1 - u) / (t_ik1 - t_i1)
        return a * basis(i, kk - 1, u) + b * basis(i + 1, kk - 1, u)

    us = [(n - k + 1) * j / (s - 1) for j in range(s)] if s > 1 else [0.0]
    out = []
    for u in us:
        pt = [0.0] * dim
        for i, p in enumerate(pl):
            b = basis(i, k, u)
            for d in range(dim):
                pt[d] += float(p[d]) * b
        out.append(pt)
    out[0] = [float(c) for c in pl[0]]  # the clamped basis is degenerate exactly at u=0
    return out


def bspline_closed(pl, deg=3, s=100):
    """
    Closed-loop counterpart of bspline_open() -- a periodic B-spline
    curve through control points `pl` (wraps back to its own start),
    degree `deg`, as an `s`-point list. 2D or 3D.
    """
    k = deg
    pl2 = pl + pl[:k]
    n = len(pl2) - 1
    if not (0 <= k < len(pl)):
        raise ValueError(f"bspline_closed(): deg must be 0 <= deg < {len(pl)}, got {deg}")
    dim = len(pl[0])

    def knot(i):
        return i - k

    def basis(i, kk, u):
        if kk == 0:
            return 1.0 if knot(i) < u <= knot(i + 1) else 0.0
        t_i, t_ik, t_i1, t_ik1 = knot(i), knot(i + kk), knot(i + 1), knot(i + kk + 1)
        a = 0.0 if t_ik == t_i else (u - t_i) / (t_ik - t_i)
        b = 0.0 if t_ik1 == t_i1 else (t_ik1 - u) / (t_ik1 - t_i1)
        return a * basis(i, kk - 1, u) + b * basis(i + 1, kk - 1, u)

    us = [(n - k + 1) * j / (s - 1) for j in range(s)] if s > 1 else [0.0]
    out = []
    for u in us:
        pt = [0.0] * dim
        for i, p in enumerate(pl2):
            b = basis(i, k, u)
            for d in range(dim):
                pt[d] += float(p[d]) * b
        out.append(pt)
    return out[:-1]


def linear_extrude(profile, h=1, center=False, twist=0, scale=1, dir=None):
    """
    Extrudes a 2D profile (from circle()/square()/polygon(), or any
    build123d Sketch/Face) into a real solid by height `h` -- same
    call convention as openscad4.py's own linear_extrude(sec, h, a,
    steps), just real B-rep in and out. `center` follows OpenSCAD's
    linear_extrude(..., center=...) meaning (False: extrudes from the
    profile's own plane up to h; True: centered on that plane instead).

    Extrudes along +Z by default -- but that's really "the profile's
    own local normal", which only happens to be +Z because circle()/
    square()/polygon() build flat in the XY plane by default. If
    you've since rot()/translate()d the profile (or its winding order
    makes its normal point the "wrong" way), the actual extrusion
    direction moves with it -- pass `dir` ([x,y,z], only its direction
    matters, `h` still controls the distance) to pin the extrusion to
    a specific direction regardless of the profile's own orientation,
    e.g. to match a surface_line_vector() sweep vector exactly:

        a = rot('x90', polygon(cr2dt([...], s=10)))
        wall = surface_line_vector(a, [0, 100, 0])   # side surface only
        solid = linear_extrude(a, h=100, dir=[0, 1, 0])  # the real solid

    twist/scale (OpenSCAD's linear_extrude(twist=, scale=) -- a helical/
    tapered extrusion) are NOT implemented yet: build123d's own
    extrude() has no direct equivalent for either (that shape needs a
    loft between rotated/scaled copies of the profile, or a genuine
    helical sweep, neither wired up here yet) -- passing a non-default
    value raises rather than silently extruding straight with no
    explanation.
    """
    _require_build123d()
    if twist:
        raise NotImplementedError(
            "linear_extrude(twist=...) isn't implemented in brep.py yet "
            "(no direct build123d equivalent -- would need a loft between "
            "rotated copies of the profile). Use h/center only for now.")
    if scale != 1:
        raise NotImplementedError(
            "linear_extrude(scale=...) isn't implemented in brep.py yet "
            "(no direct build123d equivalent -- would need a loft between "
            "differently-scaled copies of the profile). Use h/center only for now.")
    dvec = None
    unit_dir = (0.0, 0.0, 1.0)
    if dir is not None:
        dvec = tuple(float(c) for c in dir)
        n = math.sqrt(sum(c * c for c in dvec))
        if n < 1e-12:
            raise ValueError("linear_extrude(): dir must be nonzero")
        unit_dir = tuple(c / n for c in dvec)
    out = bd.extrude(profile, amount=float(h), dir=dvec)
    if center:
        out = translate([-float(h) / 2.0 * c for c in unit_dir], out)
    return out


def rotate_extrude(profile, angle=360):
    """
    Revolves a 2D profile around the Z axis into a solid -- same idea as
    OpenSCAD's rotate_extrude(angle=...): `profile`'s local X becomes
    the resulting solid's radius, local Y becomes its height, same
    convention real OpenSCAD's rotate_extrude has. `profile` should lie
    on the +X side of the Z axis (a profile straddling or crossing the
    axis produces self-intersecting/invalid geometry).

    REAL BUG FIX (found via a real user report -- "rotate_extrude did
    not work"): circle()/square()/polygon()/cr2dt()+polygon() all build
    `profile` flat on the XY plane (z=0 everywhere), same as they need
    to be for linear_extrude(). But build123d's own revolve() sweeps a
    Face rigidly around the literal 3D axis given -- per its own
    docs, "the most common use case is when the axis is in the same
    plane as the face to be revolved". Axis.Z is PERPENDICULAR to the
    XY plane, not in it, so hand build123d's revolve() a profile
    straight off circle()/polygon()/etc and every point just spins in
    place within its own z=0 plane -- a degenerate, zero-height
    "solid" (or an outright OCCT error), not the swept solid OpenSCAD's
    rotate_extrude() produces. The fix: rotate the profile 90 degrees
    about X first, carrying it from the XY plane onto the XZ plane
    (local (x,y) -> world (x,0,y)) -- NOW Axis.Z lies IN the profile's
    plane, exactly the case revolve() is built for, and local X/Y map
    onto radius/height exactly like real OpenSCAD.
    """
    _require_build123d()
    reoriented = _rotate_single_axis('x', 90.0, profile)
    return bd.revolve(reoriented, axis=bd.Axis.Z, revolution_arc=float(angle))


_SWEEP_TRANSITIONS = {"round": "ROUND", "transformed": "TRANSFORMED", "right_corner": "RIGHT"}


def _as_path_wire(shape, fn_name):
    """
    internal: turns a real Shape into a sweep/trace-able Wire/Edge,
    pulling a filled 2D shape's (circle()/square()/polygon()/cr2dt()+
    polygon()/etc) boundary wire out automatically -- a filled Face
    isn't itself a valid path (that needs an actual curve, a Wire/
    Edge), so this does the same "grab its outline instead" step
    sweep_sec2path() always did for a Shape path3d, now shared with
    p_line3d() too so a real Shape works the same way as an argument
    to either.
    """
    path_wire = shape
    faces = path_wire.faces() if hasattr(path_wire, "faces") else []
    if faces:
        wires = path_wire.wires() if hasattr(path_wire, "wires") else []
        if not wires:
            raise ValueError(
                f"{fn_name}(): path is a filled 2D shape with no boundary wire to trace")
        path_wire = wires[0]
    return path_wire


def sweep_sec2path(section2d, path3d, mirror=0, orientation=0, closed_loop=0,
                    is_frenet=False, transition="round"):
    """
    Sweeps a 2D cross-section along a 3D path to build a solid -- the
    B-rep counterpart of openscad4.py's sweep_sec2path(). Calls
    build123d's own native sweep() (OCCT's pipe-shell sweep) directly --
    this went through two home-rolled reimplementations first (manually
    extruding+unioning each straight path segment, to work around
    sweep() apparently choking on sharp path corners) before landing
    back here, because the actual problem was a single missing
    argument, not sweep() itself: `transition=`.

    `transition` controls how OCCT joins two straight (or curved)
    stretches of `path3d` at a corner:
      "round" (default here -- see below): inserts a rounded fillet-like
        surface at the joint. The one that reliably produces valid
        geometry through a sharp corner, which is why it's the default
        here -- build123d's own default (used if you pass
        transition="transformed" instead) is the "transformed" one
        below, which is fine for gentle bends but is a well-known way to
        get an invalid/self-intersecting solid through a genuinely sharp
        corner (a mitered/extended-face joint whose faces cross each
        other), which is almost certainly what a couple of earlier real
        bug reports against this function actually were.
      "transformed": each cross-section is rigidly carried along the
        path and the resulting faces are extended/trimmed to meet at a
        flat mitered joint. Sharper-looking corners on GENTLE bends;
        prone to invalid geometry on sharp ones (see above).
      "right_corner": a hard-edged corner join, no rounding.
    If your path has any tight turns and the default doesn't look
    right, this is the first thing to try changing.

    section2d: the cross-section to sweep -- either a [[x,y], ...] point
        list (same shape circle()/square()/turtle2d() produce; turned
        into a polygon() automatically) or an already-built 2D shape
        (circle(), square(), polygon(), ...). Defined once in the XY
        plane; this function moves/orients a copy of it to the start of
        `path3d` for you -- you don't need to position it there
        yourself.
    path3d: the path to sweep along -- either a [[x,y,z], ...] point
        list (same shape turtle3d() produces; turned into a straight-
        line-segment Wire automatically, i.e. build123d's Polyline --
        2D [[x,y], ...] points, like arc()'s or sinewave()'s output,
        are accepted too and padded to z=0 automatically, so a path
        built entirely in the XY plane doesn't need c23()'d by hand
        first), an already-built build123d Edge/Wire (e.g. from your
        own build123d Spline/Helix/ThreePointArc, for a smoothly
        curved path instead of straight segments), or a filled 2D
        shape like circle()/
        square()/polygon() -- its boundary is used as the path
        automatically (e.g. sweep_sec2path(circle(2), circle(20)) sweeps
        a small circle around a big one, a torus -- circle()/etc return
        a filled face, not just its outline, but a face isn't itself a
        valid sweep path, so the outline is pulled out for you here).
        Only reliable for a simple outline with a single boundary (like
        circle()/square()/a plain polygon()) -- for anything with holes
        or multiple boundaries, build your own explicit Wire/Edge and
        pass that instead.
    mirror: 0 (default) or 1 -- flips the section across its own local
        X axis before sweeping (same as openscad4.py's mirror= flag).
    orientation: 0/1/2/3 -- rotates the section 0/90/180/270 degrees
        about the path's own tangent direction before sweeping. A 2D
        cross-section has no inherent "up" once it's swept along an
        arbitrary 3D path -- there's no single correct answer for which
        way it should face, only a family of 4 that differ by which
        edge points which way -- so, same as openscad4.py's own
        orientation= flag, this is a "try 0, look at it, bump to
        1/2/3 if it's facing the wrong way" knob, not something
        computed automatically.
    closed_loop: 0 (default, open path) or 1 -- set 1 if `path3d`'s
        last point should connect back to its first (a closed-loop
        path, e.g. swept around a ring) rather than stopping there.
        Only meaningful when `path3d` is a point list; if you pass your
        own Edge/Wire, close it yourself before calling this.
    is_frenet: passed straight through to build123d's own
        sweep(is_frenet=...) -- False (default) uses OCCT's twist-
        minimizing "corrected" frame as the section travels the path;
        True uses a strict Frenet frame instead, which can flip
        abruptly at inflection points on some paths. Leave this False
        unless you have a specific reason to want strict Frenet
        behavior -- ONE such reason: cutting a helical thread/groove
        with an off-axis profile (e.g. a V-shaped point meant to face
        radially inward). The default frame has no guaranteed
        relationship to "radially inward" -- it just avoids twisting,
        so the profile's point can end up facing sideways or outward
        instead, making a difference() with it barely touch the solid
        (see examples/14_loft_and_helix.py's thread-cutting example).
        is_frenet=True fixes this FOR A HELIX SPECIFICALLY, since a
        helix's own principal normal always points straight at its
        central axis. If the cut still comes out inverted (cutting
        outward instead of in), try mirror=1 or orientation=2 on top.

    IMPORTANT -- this has been through several rounds of real bug fixes
    against a real build123d install (invalid geometry and a crash with
    orientation != 0; then, after switching to a hand-rolled
    segment-union approach, visibly disjointed segments; then switching
    to native sweep() plus transition="round"; then a filled 2D shape
    like circle() passed as path3d raising AttributeError, since a Face
    isn't itself a valid sweep path -- fixed by extracting its boundary
    wire automatically) but this exact version has NOT itself been
    re-verified against that real install (no network access in this
    environment to pip install build123d) -- only wiring-checked with a
    mock. Please report back what you see -- if "round" still doesn't
    look right for your geometry, try transition="right_corner" or
    "transformed" before assuming something else is wrong.

    CONFIRMED real failure mode (real user report): a many-segment,
    NON-PLANAR path3d (e.g. one bent out of flat via axis_rot_1_pts()
    or similar) with the default transition="round" can raise
    `AttributeError: 'NoneType' object has no attribute 'NbNodes'` --
    a real OCCT/OCP error deep in the "round" transition's per-corner
    fillet-surface construction, not a bug in this wrapper. Switching
    to transition="right_corner" (no fillet surfaces at all) fixed it.
    Same fragility class documented in p_line3d()'s own docstring
    (and examples/20_3d_knots.py's story) -- many segments + sharp/
    varying turns + "round" is the pattern to watch for; try
    "right_corner" or "transformed" first before digging further.
    """
    _require_build123d()

    if isinstance(path3d, bd.Shape):
        path_wire = _as_path_wire(path3d, "sweep_sec2path")
        start_pt = path_wire.position_at(0)
        start_tangent = path_wire.tangent_at(0)
    else:
        pts = [(float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0) for p in path3d]
        if len(pts) < 2:
            raise ValueError("sweep_sec2path(): path3d needs at least 2 points")
        if closed_loop and pts[0] != pts[-1]:
            pts = pts + [pts[0]]
        path_wire = bd.Polyline(*pts)
        # REAL BUG FIX (found via a real user report -- a many-point,
        # non-planar path, an axis_rot_1_pts()-bent profile fed
        # straight to p_line3d()): calling path_wire.position_at(0)/
        # .tangent_at(0) on a JUST-BUILT multi-segment Polyline can hit
        # a real OCCT/OCP rough edge in some build123d versions --
        # "'NoneType' object has no attribute 'NbNodes'" -- deep in
        # OCCT's own curve-adaptor code, unrelated to anything wrong
        # with the geometry itself. But there's no reason to ask OCCT
        # for this Wire's own start point/tangent at all here -- we
        # just built it FROM these exact points, so pts[0] IS the
        # start point, and the direction to the next point that isn't
        # a duplicate of it IS the start tangent, both known directly
        # with no Wire query (and no chance of hitting that bug).
        start_pt = pts[0]
        j = 1
        while j < len(pts) and pts[j] == pts[0]:
            j += 1
        if j >= len(pts):
            raise ValueError("sweep_sec2path(): path3d's points are all the same point")
        dx, dy, dz = pts[j][0] - pts[0][0], pts[j][1] - pts[0][1], pts[j][2] - pts[0][2]
        n = math.sqrt(dx * dx + dy * dy + dz * dz)
        start_tangent = (dx / n, dy / n, dz / n)

    section = section2d if isinstance(section2d, bd.Shape) else polygon(section2d)

    if mirror:
        section = bd.mirror(section, about=bd.Plane(origin=(0, 0, 0), z_dir=(1, 0, 0)))
    if orientation:
        section = rotate([0, 0, 90 * (int(orientation) % 4)], section)

    section = bd.Plane(origin=start_pt, z_dir=start_tangent) * section

    key = str(transition).lower()
    if key not in _SWEEP_TRANSITIONS:
        raise ValueError(
            f"sweep_sec2path(): transition must be one of "
            f"{sorted(_SWEEP_TRANSITIONS)}, got {transition!r}")
    transition_enum = getattr(bd.Transition, _SWEEP_TRANSITIONS[key])

    return bd.sweep(section, path=path_wire, is_frenet=bool(is_frenet), transition=transition_enum)


def translate(v, shape):
    """
    Moves `shape` by [x,y,z] -- same convention as openscad4.py's own
    translate(p, sec), just with build123d's B-rep Shape instead of a
    prism/section point list. Returns a new shape; doesn't mutate the
    original (build123d shapes are immutable under these operators).
    """
    _require_build123d()
    x, y, z = [float(c) for c in v]
    return bd.Pos(x, y, z) * shape


def _rotate_single_axis(axis_letter, angle, shape):
    """
    internal: rotate `shape` by `angle` degrees about ONE axis only.
    Unlike a combined bd.Rotation(x,y,z) call (which depends on
    whichever multi-axis composition convention build123d uses
    internally -- extrinsic vs intrinsic, XYZ vs ZYX, etc., not
    something worth guessing at), a single nonzero component has no
    such ambiguity: "rotate 37 degrees around X" means exactly one
    thing regardless of convention. rotate()/rot() below both build on
    this rather than ever calling bd.Rotation with more than one
    nonzero component at once, so neither depends on knowing
    build123d's internal convention.
    """
    x, y, z = (angle, 0.0, 0.0) if axis_letter == 'x' else (0.0, angle, 0.0) if axis_letter == 'y' else (0.0, 0.0, angle)
    return bd.Rotation(x, y, z) * shape


def rotate(angles, shape):
    """
    Rotates `shape` by [x, y, z] degrees -- same convention as real
    OpenSCAD's rotate([x,y,z], ...): applied as three separate single-
    axis rotations in sequence, first x degrees about X, then y about
    Y, then z about Z (OpenSCAD's own documented order for the vector
    form). Implemented as three chained single-axis rotations (see
    _rotate_single_axis()) specifically so this doesn't depend on
    build123d's own internal convention for a combined multi-axis
    Rotation(x,y,z) call, which isn't pinned down clearly enough in its
    docs to rely on directly.
    """
    _require_build123d()
    x, y, z = [float(a) for a in angles]
    out = shape
    if x:
        out = _rotate_single_axis('x', x, out)
    if y:
        out = _rotate_single_axis('y', y, out)
    if z:
        out = _rotate_single_axis('z', z, out)
    return out


def rot(a, shape):
    """
    A string-based axis+angle rotation DSL -- e.g. rot('z30x70y-90',
    shape) rotates first about Z by 30 degrees, then X by 70, then Y by
    -90, strictly in the order the axis letters appear in the string
    (not always x-then-y-then-z like rotate() above -- whatever order
    you write it in).

    Like rotate() above, each individual step here is a pure single-
    axis rotation (see _rotate_single_axis()), so there's no dependence
    on build123d's own multi-axis composition convention.
    """
    _require_build123d()
    tokens = re.findall(r'([xyz])(-?\d+\.?\d*)', a)
    if not tokens:
        raise ValueError(f"rot(): couldn't parse any x<angle>/y<angle>/z<angle> tokens out of {a!r}")
    out = shape
    for axis_letter, angle_str in tokens:
        out = _rotate_single_axis(axis_letter, float(angle_str), out)
    return out


def axis_rot_1(sol, ax1, loc1, theta):
    """
    Rotates `sol` by `theta` degrees about an ARBITRARY axis -- the
    axis passes through point `loc1` with direction `ax1`, unlike
    rotate()/rot() above, which only ever rotate about an axis through
    the origin. openscad4.py's own axis_rot_1(), ported: the original
    built this out of a translate-to-the-solid's-own-centroid/apply-a-
    rotation-matrix/translate-back dance; here it's just build123d's
    own native Shape.rotate(axis, angle), which already IS "rotate
    about an arbitrary axis" directly -- no centroid math needed.

        c1 = cylinder(r=5, h=20)
        c2 = axis_rot_1(c1, [1, 1, 0], [0, 0, 20], -90)
        show(c1)
        show(color(c2, "blue", alpha=0.5))
    """
    _require_build123d()
    axis = bd.Axis(tuple(float(c) for c in loc1), tuple(float(c) for c in ax1))
    return sol.rotate(axis, float(theta))


def axis_rot_1_pts(pts, ax1, loc1, theta):
    """
    Rotates a raw point list `pts` ([x,y] or [x,y,z] points -- 2D
    points are padded to z=0 first) by `theta` degrees about an
    ARBITRARY axis (direction `ax1` through point `loc1`) -- the
    point-list counterpart of axis_rot_1() (which rotates a real
    build123d Shape the same way, via its own native .rotate()), for
    when you have a plain point list rather than a Shape (no
    build123d needed, same spirit as fit_pline2line()/xrot4d() above).

    Always returns 3D points, even for 2D input (see fit_pline2line()'s
    own note on why -- rotating about an arbitrary axis generally
    needs to leave whatever plane the input started in, so flattening
    back to 2D would just throw the rotation away).

    Handy for rotating a profile's points BEFORE building a real
    shape from them -- e.g. `polygon(axis_rot_1_pts(pts, ax, loc,
    theta))` -- instead of building the shape first and rotating it
    afterward with axis_rot_1(); this also sidesteps a real build123d/
    OCCT rough edge some rotated Face boundary wires can hit later
    (position_at() raising "'NoneType' object has no attribute
    'NbNodes'" when passed to p_line3d()/sweep_sec2path()).

        pts = arc_3p([10, 0], [0, 50], [10, 100]) + [[-10, 100], [-10, 0]]
        pts = axis_rot_1_pts(pts, [0, 1, 0], [10, 0, 0], 60)
        d = polygon(pts)
        show(p_line3d(d, 0.1))
    """
    pts3 = c23(pts)
    return _rotate_points_about_axis(pts3, ax1, loc1, theta)


def mirror(v, shape):
    """
    Mirrors `shape` across the plane through the origin whose normal is
    `v` -- same convention as OpenSCAD's mirror(v, ...), e.g. mirror([1,
    0, 0], shape) flips it across the YZ plane.
    """
    _require_build123d()
    x, y, z = [float(c) for c in v]
    plane = bd.Plane(origin=(0, 0, 0), z_dir=(x, y, z))
    return bd.mirror(shape, about=plane)


def surface_line_vector(line, vector, both_sides=False):
    """
    Builds a real ruled Face by sweeping `line` (a point list, e.g.
    sinewave()/turtle3d()/fit_pline2line() output) straight along
    `vector` -- openscad4.py's own surface_line_vector(), ported as a
    real B-rep ruled surface (build123d's own native
    Face.make_surface_from_curves(), an exact ruled surface between
    two curves computed by OCCT) instead of a 2-row point-list
    "surface" meant for swp_surf()'s later mesh triangulation -- like
    the rest of the mesh-native surface family, that intermediate
    representation is dropped here in favor of returning a real,
    already-usable Face directly (union/loft/extrude/export-ready, no
    separate meshing step needed).

    `both_sides=False` (default) sweeps from `line` itself out to
    `line` translated by `vector` (a one-sided sweep -- `line` runs
    along one edge of the resulting Face). `both_sides=True` sweeps
    from `line` shifted by `-vector` to `line` shifted by `+vector`
    instead (a symmetric sweep -- `line` runs through the middle of
    the resulting Face, not along either edge).

    `line` can also be a real Shape instead of a raw point list -- a
    Wire/Edge (e.g. arc_edge(), interp_spline()'s output), or a filled
    2D shape like polygon()/circle()'s output (its boundary is used
    automatically, same _as_path_wire() step p_line3d()/
    sweep_sec2path() use for a Shape argument). Translating a real
    Shape by `vector` uses translate()'s own real B-rep move (exact,
    no faceting), rather than shifting individual points.

        # rotate()/translate() only work on real Shapes, not raw point
        # lists (see fit_pline2line()'s own note) -- for a point list
        # like sinewave()'s output, build it straight into the plane
        # you want instead (here XZ: local (x,y) -> world (x,0,y)).
        l1 = [[x, 0, y] for x, y in sinewave(50, 3, 2, 50)]
        s1 = surface_line_vector(l1, [0, 20, 0], both_sides=True)
        show(color(p_line3d(l1, 0.3), "blue"))
        show(color(s1, "cyan", alpha=0.5))
    """
    _require_build123d()
    vx, vy, vz = [float(c) for c in vector]

    if isinstance(line, bd.Shape):
        path_wire = _as_path_wire(line, "surface_line_vector")
        if both_sides:
            w0 = bd.Pos(-vx, -vy, -vz) * path_wire
            w1 = bd.Pos(vx, vy, vz) * path_wire
        else:
            w0 = path_wire
            w1 = bd.Pos(vx, vy, vz) * path_wire
        return bd.Face.make_surface_from_curves(w0, w1)

    pts = _flatten_points(line)
    if len(pts) < 2:
        raise ValueError("surface_line_vector(): line needs at least 2 points")
    pts3 = [(p[0], p[1], p[2] if len(p) > 2 else 0.0) for p in pts]
    if both_sides:
        row0 = [(x - vx, y - vy, z - vz) for x, y, z in pts3]
        row1 = [(x + vx, y + vy, z + vz) for x, y, z in pts3]
    else:
        row0 = pts3
        row1 = [(x + vx, y + vy, z + vz) for x, y, z in pts3]
    w0 = bd.Polyline(*row0)
    w1 = bd.Polyline(*row1)
    return bd.Face.make_surface_from_curves(w0, w1)


def convert_3lines2fillet(line_a, line_b, spine, s=20, closed_loop=0):
    """
    Builds a fillet surface (as a 2D point grid) by blending 3
    matching-length point lists station-by-station -- openscad4.py's
    own convert_3lines2fillet(), ported: openscad4.py called these
    positional args l2, l3, l1 respectively (matching that exact
    positional order if you're porting an old script), describing the
    order as "starting line, ending line, anchor line" -- `spine` here
    is that 3rd "anchor" argument.

    The manual, explicit-geometry way to build a fillet when
    fillet()/max_fillet_radius() genuinely can't find one -- a deep or
    sharp cut, a seam edge, edges too close together (see fillet()'s
    own docstring for the real failure modes this is the fallback
    for).

    `spine` is the actual sharp edge you're rounding off -- e.g. a
    real intersection curve between two surfaces `a`/`b`, sampled into
    a point list. `line_a`/`line_b` are two curves tracing where the
    fillet should blend INTO each of the two original surfaces --
    pulled a little way off `spine`, onto each surface respectively.
    All 3 lists must be the SAME length, in the SAME station order --
    station i on `spine` must correspond to station i on `line_a`/
    `line_b`.

    The general recipe for getting all 3 from two real surfaces `a`/
    `b`, using ONLY real B-rep booleans (no surface-projection math
    needed): nudge one surface off its own plane with offset_face(),
    then intersect it with the OTHER (un-nudged) surface -- the
    resulting curve lies exactly on the un-nudged surface, shifted
    away from the true spine by roughly the nudge amount:

        blend = 2                                       # how far the fillet reaches
        n = 40                                           # station count
        spine  = sample_curve(intersection(a, b), n)
        line_b = sample_curve(intersection(offset_face(a, blend), b), n)
        line_a = sample_curve(intersection(a, offset_face(b, blend)), n)
        grid = convert_3lines2fillet(line_a, line_b, spine, s=15)
        patch = surface_from_points_grid(grid)
        show(patch)

    (project_curve_on_face()/psos() are the other real B-rep tools for
    getting a curve to lie on a specific surface, if you already have
    one from elsewhere instead of deriving it via offset_face()+
    intersection() above.)

    At every station, builds a small bezier() arc through
    `[line_a[i], spine[i], line_b[i]]` (`s` points, pulled toward the
    spine point in the middle, same as any bezier() control point).
    The result is a 2D point grid (one row per station) -- feed it
    straight into surface_from_points_grid() for the real B-rep fillet
    Face:

        grid = convert_3lines2fillet(line_a, line_b, spine, s=15)
        patch = surface_from_points_grid(grid)
        show(patch)

    DIFFERS from openscad4.py's own version in one deliberate way: the
    original appended the spine point again at the end of every
    station (`+[p1]`), closing each cross-section into a wedge shape
    for its own mesh-based swp_c() (a closed-section sweep -- see
    swp_c()'s own real behavior: it auto-closes the LAST point of
    every row back to the FIRST, so appending the spine point again at
    the end there actually built a closed, pinched-at-the-spine wedge
    profile per station, not just a cosmetic extra point). This
    function returns the OPEN row instead (no reclosing point) since
    it's meant for surface_from_points_grid() below, which fits one
    smooth surface through the whole grid directly and doesn't need
    (or want) a closed per-row loop. If you want the actual closed-
    wedge-per-station behavior for a REAL solid via loft() -- the
    build123d equivalent of swp_c() -- see loft_fillet() right below
    instead, which reconstructs that exact reclosing.

    `closed_loop=1` also repeats the FIRST station as one more row at
    the end -- for a fillet that wraps all the way around a closed
    spine (a full loop, not two open ends), same closed_loop
    convention as turtle3d()/p_line3d()/sweep_sec2path().
    """
    n = len(spine)
    if len(line_a) != n or len(line_b) != n:
        raise ValueError(
            f"convert_3lines2fillet(): line_a/line_b/spine must all have "
            f"the same number of points (got line_a={len(line_a)}, "
            f"line_b={len(line_b)}, spine={n})")
    if n < 1:
        raise ValueError("convert_3lines2fillet(): need at least 1 station")
    grid = [bezier([line_a[i], spine[i], line_b[i]], s) for i in range(n)]
    return grid if not closed_loop else grid + [grid[0]]


def loft_fillet(line_a, line_b, spine, s=20, closed_loop=0, ruled=False):
    """
    Builds a real B-rep SOLID filling the corner between two surfaces,
    by lofting through MANY small closed cross-section wedges (one per
    station) instead of fitting a single open surface patch
    (convert_3lines2fillet()+surface_from_points_grid() above) -- the
    real B-rep equivalent of openscad4.py's own swp_c()-based closed-
    section sweep. Same 3-line input (spine/line_a/line_b -- see
    convert_3lines2fillet()'s own docstring for the full recipe for
    deriving all 3, including the mesh-based two_solids_intersection()
    route for genuinely hard cases where a real B-rep boolean
    struggles).

    At every station, builds a small CLOSED wedge profile: the bezier
    arc from line_a[i] through spine[i] (pulled toward it) out to
    line_b[i], then back to spine[i], closed back to line_a[i]
    (mixed_polygon() does the explicit closing build123d has no auto-
    close for, matching swp_c()'s own real auto-close-last-to-first
    behavior). Lofting through the whole stack of these wedges fills
    exactly the corner between the two original surfaces, pinched down
    to the sharp spine at every cross-section.

        blend = 2
        n = 40
        spine  = sample_curve(intersection(a, b), n)
        line_b = sample_curve(intersection(offset_face(a, blend), b), n)
        line_a = sample_curve(intersection(a, offset_face(b, blend)), n)
        solid = loft_fillet(line_a, line_b, spine, s=10)
        show(solid)

    Each station's wedge needs to be at least CLOSE to planar for
    mixed_polygon()'s underlying Face(Wire) construction to succeed --
    true for most reasonable blend widths relative to how sharply the
    spine curves, but a spine that twists tightly relative to `blend`
    can produce a station too warped to build (mixed_polygon() or
    loft() itself will raise). If you hit that,
    surface_from_points_grid(convert_3lines2fillet(...)) is the more
    robust fallback -- fits one smooth surface through the whole grid
    at once instead of building/lofting individual station Faces,
    trading the solid result for an open patch you'd thicken()
    yourself.

    `closed_loop`/`ruled` mean the same as convert_3lines2fillet()'s/
    loft()'s own (see their docstrings) -- `ruled=True` if you want a
    piecewise-straight fillet between stations instead of the smooth
    default.

    Builds the wedge grid then hands it straight to
    solid_from_wedge_grid() to actually loft it -- so every fix that
    applies there applies here too, automatically: each station is
    planarize_ring()-projected onto its own best-fit plane first (a
    spine that twists tightly relative to `blend` producing a station
    that's only SLIGHTLY off-plane no longer needs to hit the
    surface_from_points_grid() fallback below -- it just gets planarized
    like any other borderline station), and closed_loop=True gets the
    sliver-free tube+overlapping-closer construction instead of a
    single loft() through a station repeated at both ends.
    """
    _require_build123d()
    n = len(spine)
    if len(line_a) != n or len(line_b) != n:
        raise ValueError(
            f"loft_fillet(): line_a/line_b/spine must all have the same "
            f"number of points (got line_a={len(line_a)}, line_b={len(line_b)}, spine={n})")
    if n < 2:
        raise ValueError("loft_fillet(): need at least 2 stations to loft through")
    stations = [bezier([line_a[i], spine[i], line_b[i]], s) + [spine[i]] for i in range(n)]
    if closed_loop:
        stations = stations + [stations[0]]
    return solid_from_wedge_grid(stations, ruled=ruled)


def _ring_best_fit_normal(ring):
    """
    Newell's method: a robust normal for a closed point loop even when
    the points don't lie exactly in one plane (noise, projection error,
    a sculpted/non-spherical seam, etc). Works directly off the raw
    point loop -- no SVD/eigendecomposition needed -- by accumulating a
    cross-product-like sum over each consecutive edge pair; for an
    EXACTLY planar ring this reduces to the same normal a cross product
    of any two edges would give, and for a slightly non-planar ring it
    gives the least-bad single normal for the loop as a whole (the
    standard technique used in mesh processing for exactly this
    "polygon normal from a not-quite-planar boundary" problem).
    """
    nx = ny = nz = 0.0
    n = len(ring)
    for i in range(n):
        x1, y1, z1 = ring[i]
        x2, y2, z2 = ring[(i + 1) % n]
        nx += (y1 - y2) * (z1 + z2)
        ny += (z1 - z2) * (x1 + x2)
        nz += (x1 - x2) * (y1 + y2)
    length = (nx * nx + ny * ny + nz * nz) ** 0.5
    if length < 1e-12:
        return (0.0, 0.0, 1.0)
    return (nx / length, ny / length, nz / length)


def planarize_ring(ring):
    """
    Projects every point of a closed point loop onto the single best-fit
    plane through it (centroid + _ring_best_fit_normal()'s normal),
    returning a NEW ring that is exactly planar by construction --
    each point is nudged only along the normal direction, so its
    position WITHIN the plane (and hence the ring's overall shape) is
    otherwise preserved.

    Exists so mixed_polygon() (needs an exactly planar input) can
    succeed on every station of a wedge grid, including ones a raw
    B-rep/mesh pipeline left slightly non-planar (e.g. per-station
    points independently computed via offset-along-surface, which can
    drift a fraction of a unit out of plane station to station) --
    replacing solid_from_wedge_grid()'s old per-row fallback to
    cap_wire() (a filling-surface approximation that can bulge slightly
    and doesn't align as predictably with its neighbors) with an exact
    flat wedge on every row instead. A row that's already planar is
    unaffected (projection distance ~0), so this is safe to apply
    unconditionally to a whole grid, not just the rows that would
    otherwise fail.
    """
    n = len(ring)
    cx = sum(p[0] for p in ring) / n
    cy = sum(p[1] for p in ring) / n
    cz = sum(p[2] for p in ring) / n
    nx, ny, nz = _ring_best_fit_normal(ring)
    out = []
    for p in ring:
        dx, dy, dz = p[0] - cx, p[1] - cy, p[2] - cz
        d = dx * nx + dy * ny + dz * nz
        out.append([p[0] - d * nx, p[1] - d * ny, p[2] - d * nz])
    return out


def solid_from_wedge_grid(rows, ruled=False, planarize=True, closed_loop=None, max_stations=None):
    """
    Builds a real B-rep SOLID by lofting through an ALREADY-BUILT grid
    of closed per-station wedge/profile rows -- the same last two lines
    loft_fillet() does internally (mixed_polygon() each row into a
    closed profile, then loft() through the whole stack), for when you
    already have the grid itself rather than a fresh line_a/line_b/
    spine triple for loft_fillet() to build it from.

    The direct match for openscad4.py's own mesh-based
    convert_3lines2fillet()+swp_c() combo's OUTPUT specifically: each
    row already closed into a wedge (the spine point repeated at both
    ends of every station -- swp_c()'s own auto-close-last-to-first
    convention, see loft_fillet()'s own docstring), and -- if
    closed_loop=1 was used there -- the first row already repeated
    again at the very end for a fillet that wraps all the way around a
    closed spine. Both of those are exactly what this function expects
    as-is; it does no reclosing or repeating of its own, unlike
    loft_fillet() (which builds that structure itself from raw
    line_a/line_b/spine curves). Skips straight to the loft, so there's
    no separate "cap the two ends" step needed the way there is after
    surface_from_closed_rings() -- each station being a CLOSED wedge
    (not an open ring) is what lets loft() close the result into a
    solid directly.

    CLOSED-LOOP SEAM (rows[0] == rows[-1], e.g. a fillet that wraps
    all the way around a closed spine): a single loft() call through
    the WHOLE stack does NOT reliably close this seamlessly, even when
    the repeated first/last row is bit-for-bit identical.
    BRepOffsetAPI_ThruSections (loft()'s own underlying OCCT engine)
    treats its section list as a plain start-to-end sequence, not a
    periodic ring -- it has no notion that the last section is meant
    to BE the first one again, so it still builds a distinct (if
    razor-thin) closing segment between them, which shows up as a
    visible sliver/kink right at that join once the result is
    subtracted from something. This is the exact same failure
    openscad4.py's own swp() has at the MESH level -- swp_c() exists
    specifically to dodge it there, and this function dodges it the
    same way here: when closed_loop is True (auto-detected from
    rows[0]==rows[-1] if left as None), the duplicate final row is
    dropped and ONE loft() runs through only the distinct stations
    (still a single efficient ThruSections call, fast regardless of
    station count), leaving exactly one gap unclosed between the last
    station and the first. A second, small loft() bridges that gap --
    but deliberately OVERLAPS the main loft by one extra station
    (station[-1] -> station[0] -> station[1], not just station[-1] ->
    station[0]) rather than merely touching it at a single coincident
    end face. Two solids that only share a bare face with zero
    volumetric overlap are exactly the fragile, tolerance-sensitive
    case for BRepAlgoAPI_Fuse that tends to leave slivers; a real
    shared VOLUME (even a thin sliver of one) gives the fuse solid
    material to work with and is numerically robust. union_fuzzy()
    then merges the two into one seamless closed solid. No single
    loft() call ever sees the same station twice, and only ONE boolean
    op happens regardless of how many stations the grid has, unlike an
    earlier version of this function that lofted every consecutive
    pair separately and fused the whole ring with union_multi(), which
    was correct but far too slow on a 100+ station grid (an N-way
    BOPAlgo_Builder fuse over that many small solids, plus N-1 separate
    loft() calls, versus 2 loft() calls and 1 fuse here).

        f3 = o.convert_3lines2fillet(l3, l2, l1, closed_loop=1)  # still
                                                    # fine to reuse for
                                                    # the point math --
                                                    # this is a plain
                                                    # point grid either
                                                    # way, nothing here
                                                    # cares which
                                                    # pipeline built it
        fillet_solid = solid_from_wedge_grid(f3)  # rows[0]==rows[-1] ->
                                                    # closed_loop auto-
                                                    # detected, pairwise-
                                                    # loft-and-fuse path
                                                    # used automatically
        sol = difference(sol, fillet_solid)

    `ruled` means the same as loft()'s own -- piecewise-straight
    between stations (True) vs a smooth blended loft (False, default),
    same tradeoff/diagnostic use as everywhere else in this file (try
    ruled=True first if a smoothed loft struggles, to check whether the
    rows themselves are the problem or just the smoothing).

    EACH ROW'S FACE: with planarize=True (the default), every row is
    first passed through planarize_ring() -- projected onto its own
    best-fit plane (see that function's docstring) -- BEFORE
    mixed_polygon(row) is tried, so a row that started out a fraction
    of a unit out of plane (independently-computed offset points
    drifting station to station, a sculpted/non-spherical seam, etc)
    still gets an exact flat wedge face instead of failing planarity.
    This keeps the genuinely SHARP pinch corner at the repeated spine
    point and a consistent flat-faceted look across the WHOLE grid, not
    just the rows that happened to already be planar. mixed_polygon(row)
    still has a final fallback to cap_wire(row) (a non-planar-capable
    interpolating-spline boundary) for the rare row where even the
    planarized points fail to form a valid simple polygon (e.g. a
    genuinely self-intersecting projection). Pass planarize=False to
    restore the old behavior (only fall back to cap_wire() on rows that
    fail mixed_polygon() as-is, un-projected) if you want to compare.

    Raises whatever loft() itself raises if the grid is too irregular
    for a single loft to follow even after that per-row fallback --
    same real failure mode as loft_fillet() (see its own docstring): a
    spine/seam that twists tightly relative to the fillet's own width
    is the usual cause. Thin a very fine-stationed grid down with
    pick_key_stations() first if that happens.

    max_stations: the direct lever for SPEED, not just correctness. A
    fine-stationed grid (100+ rows, each row built from a fairly
    resolved wedge -- e.g. loft_fillet()'s own bezier(..., s) arcs)
    genuinely costs real time here: ThruSections has to weave together
    every one of those sections, and the resulting solid -- easily
    thousands of faces for a 100-station x 20-edge grid -- then still
    has to be fused against the closer piece. That cost is proportional
    to grid density, not wasted work (this function is already down to
    2 loft() calls and 1 fuse total, regardless of station count -- see
    the closed_loop branch below). If max_stations is set and there are
    more rows than that, pick_key_stations() (see its own docstring)
    thins the grid down first -- clustering the kept stations where the
    wedge's own shape is actually changing fastest, rather than
    blindly every Nth row, so a long near-straight stretch of the seam
    gets thinned hard while a sharp turn keeps most of its resolution.
    Always keeps the first and last row, so a closed_loop grid's own
    rows[0]==rows[-1] convention survives thinning intact. None
    (default) leaves the grid exactly as given -- opt in explicitly if
    a render is taking too long.
    """
    _require_build123d()
    if len(rows) < 2:
        raise ValueError("solid_from_wedge_grid(): need at least 2 stations to loft through")
    if max_stations is not None and len(rows) > max_stations:
        keep = pick_key_stations(rows, n_keep=max_stations)
        rows = [rows[i] for i in keep]
    if closed_loop is None:
        closed_loop = rows[0] == rows[-1]
    sections = []
    for row in rows:
        row_in = planarize_ring(row) if planarize else row
        try:
            sections.append(mixed_polygon(row_in))
        except Exception:
            sections.append(cap_wire(row_in))
    if closed_loop:
        # rows[0]==rows[-1] is just the caller's "closed" marker -- drop
        # the duplicate before lofting, so no single loft() call ever
        # sees the same station twice (that duplicate-final-section
        # ambiguity is exactly what caused the sliver in the first
        # place). One loft() through all the DISTINCT stations handles
        # almost the entire loop in a single, efficient ThruSections
        # call (the same primitive surface_from_closed_rings() already
        # leans on for 50-100+ rings elsewhere in this file -- fast by
        # design, not something to be avoided at scale). That leaves
        # exactly one gap unclosed -- station N-1 back to station 0 --
        # bridged by one more small loft, then a single union_fuzzy()
        # fuses the two pieces together. The closer is built to OVERLAP
        # the tube by one full extra station (distinct[-1] -> distinct[0]
        # -> distinct[1]), not just touch it at a single coincident end
        # face -- a real shared VOLUME is a numerically robust case for
        # BRepAlgoAPI_Fuse, where two solids that only share a bare face
        # (exact coincidence, no volumetric overlap at all) is exactly
        # the fragile/tolerance-sensitive case that tends to leave slivers.
        # Two loft() calls and one 2-shape fuse, regardless of station
        # count -- no N-way union_multi() over dozens of tiny segments,
        # which is what was making this slow.
        distinct = sections[:-1]
        if len(distinct) < 3:
            raise ValueError("solid_from_wedge_grid(): need at least 3 distinct stations for a closed loop")
        tube = loft(*distinct, ruled=bool(ruled))
        closer = loft(distinct[-1], distinct[0], distinct[1], ruled=bool(ruled))
        return union_fuzzy(tube, closer)
    return loft(*sections, ruled=bool(ruled))


def surface_from_points_grid(points, tol=0.01, min_deg=1, max_deg=3):
    """
    Fits a real B-rep surface (a Face, generally non-planar) through a
    2D grid of 3D points -- build123d's own native
    Face.make_surface_from_array_of_points() (GeomAPI_PointsToBSplineSurface
    under the hood: a genuine NURBS surface approximation through the
    whole grid), instead of a triangle mesh. `points` is a list of
    rows, each row a same-length list of [x,y,z] (or [x,y], z=0)
    points -- a rectangular V x U grid.

    The general-purpose building block behind surface_from_2_waves()
    below -- reach for this one directly whenever you already have
    your own 2D point grid (your own height-field/parametric math, a
    grid sampled off some other surface, etc) and just want it as one
    real curved Face rather than assembling it from wave curves.

    `tol`/`min_deg`/`max_deg` control the fitting accuracy/degree --
    same meaning as build123d's own parameters, defaults are fine for
    most cases. Raises ValueError ("B-spline approximation failed") if
    the grid is too irregular/self-overlapping for a single surface to
    fit through at the given tolerance -- try loosening `tol` first.
    """
    _require_build123d()
    grid = [[(float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0)
             for p in row] for row in points]
    return bd.Face.make_surface_from_array_of_points(
        grid, tol=float(tol), min_deg=int(min_deg), max_deg=int(max_deg))


def surface_from_points_grid_closed(points):
    """
    Like surface_from_points_grid() above, but for a point grid that
    should wrap into ONE continuous, seamless loop along its ROW
    direction (the direction openscad4.py's path_extrude_open()/
    path_extrude_closed() sweep along) instead of stopping at an open
    start/end -- e.g. a ribbon swept all the way around a closed path
    (o.arc(10, 0, 360, s=49), a full circle) that should genuinely meet
    itself with no seam, not just end up visually touching.

    WHY surface_from_points_grid() ITSELF CAN'T DO THIS: it's a thin
    wrapper around build123d's Face.make_surface_from_array_of_points()
    (OCCT's GeomAPI_PointsToBSplineSurface), which only ever fits an
    OPEN (non-periodic) B-spline surface -- there's no "closed" mode to
    ask for. The usual-looking workaround -- appending a duplicate of
    the first row onto the end of `points`, which is exactly what
    o.path_extrude_closed() does differently from o.path_extrude_open()
    -- LOOKS closed once rendered, but isn't: you get two separate,
    exactly-coincident rows of geometry sitting flush against each
    other at the seam instead of one shared boundary. That's precisely
    the "flush/coincident contact" case OCCT's booleans and fillets are
    documented elsewhere in this file to be fragile on (see union()'s
    own docstring) -- which is why fillet() can behave differently, or
    fail outright, right at that seam even once edge indices are
    re-probed for the new topology.

    THE FIX: don't fit one big surface through a duplicated grid at
    all. Treat each COLUMN of `points` (station 0 across every row,
    station 1 across every row, ...) as its own rail curve running
    along the path, close EACH rail into a genuine single closed Wire
    (looping back to its own first point -- ONE piece of geometry, not
    two coincident ones sitting on top of each other), then rule a real
    B-rep surface directly between each pair of ADJACENT rails
    (build123d's own native Face.make_surface_from_curves() -- the same
    call surface_line_vector() above already uses successfully) and sew
    the resulting strips into one Shell via the same OCCT-level sewing
    shell_from_faces()/solid_from_faces() use. For the common case of a
    flat 2-point cross-section (a ribbon -- o.path_extrude_open(d, c)
    with d=[[-2,0],[2,0]]) that's just ONE ruled strip between the 2
    rails, genuinely periodic with no seam artifact anywhere, and this
    returns that single Face directly rather than a 1-face Shell.

    Each rail tries a smooth periodic interpolating spline first
    (build123d's Edge.make_spline(pts, periodic=True) -- matches
    surface_from_points_grid()'s own NURBS-fit smoothness along this
    direction), falling back automatically to a plain closed Polyline
    (straight facets between path samples -- still one single
    continuous Wire, never two coincident ones) if this build123d
    version's make_spline() doesn't accept periodic=True, or the fit
    fails for some other reason (e.g. a self-tangent or too-short
    column). Either way the loop closure itself is real, not visual.

    `points`: same shape/convention as surface_from_points_grid() takes
    -- rows of same-length [x,y] or [x,y,z] points -- and the SAME
    convention o.path_extrude_open() returns. Feed it o.path_extrude_
    open()'s output directly, NOT o.path_extrude_closed()'s (and don't
    duplicate the first row onto the end yourself either) -- this
    function closes the loop on its own, from an ordinary open grid:

        a = o.rot('x90', o.sinewave(50, 3, 2, 50))
        b = o.c23(o.arc(10, 0, 360, s=49))
        c = o.extrude_wave2path(a, b)
        d = [[-2, 0], [2, 0]]
        sr1 = o.path_extrude_open(d, c)         # NOT path_extrude_closed
        wall = surface_from_points_grid_closed(sr1)
        sr1 = thicken(wall, -1)
        show(sr1)

    Returns a real Face (2-column grid) or Shell (3+ columns) -- feed
    it straight to thicken() same as a plain surface_from_points_grid()
    Face; thicken() already accepts either (see shell_from_faces()'s
    own docstring/example). Since the loop is now genuinely closed all
    the way around, thicken() has no start/end cap edges left to wall
    off at all -- the only boundary left is the rail curves at each end
    of the grid's own COLUMN range (e.g. the first and last rail, for a
    grid wider than 2 columns), which thicken() walls same as always.

    Raises ValueError if `points` has fewer than 2 rows, fewer than 2
    columns, or rows of inconsistent length (need a genuine rectangular
    grid, same as surface_from_points_grid()), or whatever build123d/
    OCCT itself raises if a rail is too irregular for either the spline
    or the polyline fallback to rule a valid surface from.
    """
    _require_build123d()
    rows = [[(float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0)
             for p in row] for row in points]
    if len(rows) < 2:
        raise ValueError("surface_from_points_grid_closed(): need at least 2 rows")
    n_cols = len(rows[0])
    if n_cols < 2:
        raise ValueError("surface_from_points_grid_closed(): need at least 2 columns")
    if any(len(row) != n_cols for row in rows):
        raise ValueError(
            "surface_from_points_grid_closed(): every row must have the same number of points")

    def _closed_rail(col_pts):
        try:
            return bd.Wire([bd.Edge.make_spline(col_pts, periodic=True)])
        except Exception:
            return bd.Polyline(*col_pts, *col_pts[:1])

    rails = [_closed_rail([rows[r][c] for r in range(len(rows))]) for c in range(n_cols)]
    strips = [bd.Face.make_surface_from_curves(rails[c], rails[c + 1]) for c in range(n_cols - 1)]
    if len(strips) == 1:
        return strips[0]
    return _sew_faces_to_shell(strips, _caller="surface_from_points_grid_closed")


def surface_from_closed_rings(rows, ruled=False, tol=1e-6):
    """
    A genuinely SMOOTH, minimal-patch closed-loop B-rep surface, built
    from an ORDERED list of closed cross-section rings -- e.g. exactly
    the ring-per-sweep-station data a manual point-grid pipeline
    naturally produces (o.solid_from_2surfaces()'s own output, or
    anything shaped like it), in its ORIGINAL [station][ring point]
    layout -- no o.cpo() transpose needed, unlike
    surface_from_points_grid_closed() (see below for why).

    WHY THIS EXISTS ALONGSIDE surface_from_points_grid_closed(): that
    function is a real, working closed-loop surface, but it's built
    from N-1 separate RULED strip Faces (one per pair of adjacent rail
    curves) sewn into a Shell -- correct, watertight topology, but
    genuinely a multi-facet Shell, not one smooth surface, and its
    facet/edge COUNT scales directly with however many stations you
    feed it (a few hundred stations really does mean a few hundred
    real B-rep edges -- not a display artifact; see fillet()/
    thicken()'s own performance notes elsewhere in this file, and
    reducing the input resolution only ever reduces the facet count,
    never removes the faceting itself).

    This function instead calls build123d's own loft engine directly
    on periodic section wires -- OCCT's BRepOffsetAPI_ThruSections,
    `ruled=False` == its "smoothed" mode, the exact same engine
    FreeCAD's own Part Design Loft feature uses with "Ruled" unchecked.
    Given ordered PERIODIC closed wires, it blends them into ONE
    genuinely smooth, typically SINGLE-Face surface (a real multi-span
    NURBS surface -- C2-continuous across every station internally,
    but one topological Face, not N sewn ones), with no per-station
    facet edges left behind at all.

    `rows`: ordered list of R closed rings (station 0 first, station
    R-1 last), each ring a same-length list of [x,y,z] (or [x,y],
    z=0) points -- same point-grid convention as
    surface_from_points_grid()/surface_from_points_grid_closed(), just
    NOT transposed: every row here already IS one ring, so this closes
    the ring axis directly rather than needing the column-becomes-row
    trick surface_from_points_grid_closed() relies on.

    `ruled=False` (default) is the smoothed/single-surface mode this
    function exists for. `ruled=True` instead facets straight between
    adjacent rings (visually similar to
    surface_from_points_grid_closed(), just built via ThruSections
    instead of manual rail-ruling) -- mostly useful as a diagnostic: if
    a smoothed fit fails but `ruled=True` succeeds, the rings
    themselves are fine and it's specifically the smoothing that's
    struggling (e.g. two adjacent rings differing wildly in shape).

    Returns a Shell open at its two ends (the first/last ring's own
    boundary edge, same as surface_from_points_grid_closed()) --
    cap_wire() + solid_from_faces() close it into a solid exactly the
    same way:

        wall = surface_from_closed_rings(rows)
        e_start, e_end = wall.edges()[0], wall.edges()[-1]  # probe-pick
                                                              # for real
        cap_a, cap_b = cap_wire([e_start]), cap_wire([e_end])
        solid = solid_from_faces(wall, cap_a, cap_b)

    Raises RuntimeError if OCCT's ThruSections can't build a valid
    surface through the given rings at all (self-intersecting rings,
    fewer than 2 rings, or rings that vary too wildly station to
    station for any single smooth fit to follow) -- try `ruled=True`
    first as a diagnostic (see above), or loosen `tol`.
    """
    _require_build123d()
    if len(rows) < 2:
        raise ValueError("surface_from_closed_rings(): need at least 2 rings")
    n_pts = len(rows[0])
    if any(len(row) != n_pts for row in rows):
        raise ValueError(
            "surface_from_closed_rings(): every ring must have the same number of points")

    from OCP.BRepOffsetAPI import BRepOffsetAPI_ThruSections
    import OCP.TopAbs as _ta
    from OCP.TopoDS import TopoDS as _TopoDS

    def _closed_wire(pts, ruled):
        pts3 = [(float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0) for p in pts]
        # ruled=True facets straight between stations regardless of how
        # smooth any one ring's own curve is -- fitting a periodic
        # B-spline through every ring's points is real, avoidable OCCT
        # cost that buys nothing visually in this mode (confirmed
        # directly in this app: this was measurably slower than the
        # plain-polyline cap_wire(mixed_wire(...)) + loft() pattern it
        # replaces). Use a plain closed polyline here instead, and
        # reserve the spline fit for ruled=False, where the ring's own
        # smoothness actually feeds into the final surface.
        if ruled:
            return bd.Polyline(*pts3, *pts3[:1]).wrapped
        try:
            return bd.Wire([bd.Edge.make_spline(pts3, periodic=True)]).wrapped
        except Exception:
            return bd.Polyline(*pts3, *pts3[:1]).wrapped

    gen = BRepOffsetAPI_ThruSections(False, bool(ruled), float(tol))
    for row in rows:
        gen.AddWire(_closed_wire(row, ruled))
    gen.Build()
    if not gen.IsDone():
        raise RuntimeError(
            "surface_from_closed_rings(): OCCT ThruSections could not build a "
            "valid surface through these rings -- try ruled=True as a "
            "diagnostic (see this function's own docstring), or check the "
            "rings for self-intersection")
    result = gen.Shape()
    shape_type = result.ShapeType()
    if shape_type == _ta.TopAbs_SHELL:
        return bd.Shell(_TopoDS.Shell(result))
    elif shape_type == _ta.TopAbs_FACE:
        return bd.Face(_TopoDS.Face(result))
    else:
        return bd.Shell(list(bd.Compound(_TopoDS.Compound(result)).faces()))


def solid_from_closed_rings(rows, ruled=False, tol=1e-6):
    """
    A real closed B-rep SOLID, built directly from an ordered list of
    closed cross-section rings -- the one-line version of the standard
    3-step combination:

        b_1 = surface_from_closed_rings(b, ruled=True)
        c = cap_wire(b[0])
        d = cap_wire(b[-1])
        b_2 = solid_from_faces(b_1, c, d)

        b_2 = solid_from_closed_rings(b, ruled=True)   # same result

    surface_from_closed_rings() (see its own docstring) builds the
    curved wall, open at both ends -- this caps it into a solid the
    same way that function's own docstring shows by hand: cap_wire()
    on the FIRST/LAST ROW'S OWN RAW POINT DATA, not on
    wall.edges()/wall.wires() pulled back off the already-built wall
    Shell. That distinction matters: a `ruled=True` wall built from
    many stations can produce far more than the 2 boundary wires
    you'd expect (internal per-band seams aren't always recognized as
    shared/interior edges once sewn), so picking the end boundary back
    off the wall itself is unreliable at real station counts. Capping
    straight from the ORIGINAL row data -- which is exactly the real
    boundary curve either way -- sidesteps that failure mode entirely.

    `ruled`/`tol` are passed straight through to
    surface_from_closed_rings() unchanged -- see its own docstring:
    `ruled=False` (default, matching that function's own default) is
    the smoothed single-surface mode; `ruled=True` facets straight
    between stations instead, useful when a sculpted/high-curvature
    ring stack makes the smoothed fit struggle, fail outright, or (a
    real case hit in practice) fail to TESSELLATE for on-screen preview
    even though the underlying B-rep may technically still be valid --
    `ruled=True` is the safer default to reach for on a genuinely
    organic/non-primitive ring stack; try `ruled=False` afterward if
    you want fewer surface seams in an exported STEP and the shape
    isn't too extreme.

    Raises whatever surface_from_closed_rings()/cap_wire()/
    solid_from_faces() themselves raise -- same failure modes as
    calling them by hand.
    """
    _require_build123d()
    wall = surface_from_closed_rings(rows, ruled=ruled, tol=tol)
    if ruled:
        # surface_from_closed_rings(ruled=True) builds each ring's own
        # wall boundary as a plain closed POLYLINE through the exact
        # points (see that function's own performance note) -- the cap
        # here has to be built from that SAME curve type, not
        # cap_wire()'s default periodic-spline fit, or the two edges
        # only coincide at the vertices and solid_from_faces()'s sewing
        # fails (confirmed directly in this app). Passing an explicit
        # Polyline Wire in makes cap_wire() use it as-is instead of
        # spline-fitting raw points -- exact edge match, and cheaper
        # too.
        def _poly_wire(pts):
            pts3 = [(float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0) for p in pts]
            return bd.Polyline(*pts3, *pts3[:1])
        cap_a = cap_wire(_poly_wire(rows[0]))
        cap_b = cap_wire(_poly_wire(rows[-1]))
    else:
        cap_a = cap_wire(rows[0])
        cap_b = cap_wire(rows[-1])
    return solid_from_faces(wall, cap_a, cap_b)


def pick_key_stations(rows, n_keep=10):
    """
    Thins an ordered list of `rows` (same-length point-list rings, one
    per sweep station -- exactly surface_from_closed_rings()'s own
    input shape) down to `n_keep` stations, chosen where the
    cross-section is changing SHAPE fastest, not evenly spaced by
    station index.

    WHY: surface_from_closed_rings() fits one global, genuinely
    INTERPOLATING surface through every station you hand it (see its
    own docstring) -- feed it many uniformly-resampled stations off an
    organic, freely-varying shape and that interpolation is prone to
    rippling between them, the same Runge's-phenomenon-style
    overshoot a high-degree global Bezier curve shows through many
    control points (see solid_line_vector()/bezier()'s own notes
    elsewhere in this project). Cutting the STATION COUNT helps, but
    picking evenly-spaced stations wastes several of them re-covering
    a stretch that barely changes (e.g. a long flat back panel) while
    starving the one place the shape actually turns a corner (e.g. a
    headrest-to-neck transition) -- exactly where the interpolation
    most needs a nearby constraint to stay on track.

    This instead measures how much each ring differs from the one
    before it (summed point-to-point distance -- rows are already
    same-length and consistently ordered/oriented by construction, so
    corresponding indices already line up, no re-alignment needed),
    then picks stations evenly spaced along that CUMULATIVE CHANGE
    curve instead of evenly spaced by index -- clusters more stations
    where the shape moves fast, fewer where consecutive rings are
    nearly identical. The first and last stations are always kept (the
    two ends surface_from_closed_rings()'s own open boundary needs).

        sol2 = [ o.equidistant_pathc(o.bspline_closed(o.homogenise(p, 30), 3, 30), 30)
                 for p in sol1]                          # smooth each ring only
        keep = pick_key_stations(sol2, n_keep=10)         # <- pick stations here
        sol2 = [sol2[i] for i in keep]                    # instead of a uniform
                                                            #    bspline_open/
                                                            #    equidistant_path
                                                            #    resample pass
        sol2 = surface_from_closed_rings(sol2, tol=.1)

    Deliberately does NOT also smooth/resample the station (rail)
    direction itself the way an o.bspline_open()+o.equidistant_path()
    pass would -- surface_from_closed_rings()'s own smoothed mode
    already interpolates smoothly BETWEEN whichever real stations you
    hand it, so pre-smoothing the rail first just means feeding it a
    denser, already-interpolated input to re-interpolate, which is
    both slower and does nothing to reduce ripple. Feed it the real
    (ring-smoothed only) station data directly.

    Returns a plain sorted list of indices into `rows` (not the rows
    themselves), so you can also use it to select from a DIFFERENT
    but same-length/same-order list if needed (e.g. picking the same
    stations out of an unsmoothed variant for comparison).
    """
    if n_keep < 2:
        raise ValueError("pick_key_stations(): n_keep must be at least 2")
    n_rows = len(rows)
    if n_keep >= n_rows:
        return list(range(n_rows))

    pts = [np.array(row, dtype=float) for row in rows]
    delta = [0.0]
    for i in range(1, n_rows):
        d = pts[i] - pts[i - 1]
        delta.append(float(np.sqrt((d ** 2).sum(axis=1)).sum()))
    cum = np.cumsum(delta)
    total = cum[-1]

    if total <= 0:
        idx = np.linspace(0, n_rows - 1, n_keep)
    else:
        targets = np.linspace(0, total, n_keep)
        idx = np.searchsorted(cum, targets)
        idx = np.clip(idx, 0, n_rows - 1)

    picked = sorted(set(int(i) for i in idx))
    picked[0] = 0
    picked[-1] = n_rows - 1
    return sorted(set(picked))


def surface_from_2_waves(p0, p1, amplitude=1):
    """
    A wavy real B-rep surface combining two wave-like point lists
    `p0`/`p1` (each meant to run along its OWN axis, perpendicular to
    the other -- see the example below) -- openscad4.py's own
    surface_from_2_waves(), ported as a real fitted NURBS Face
    (surface_from_points_grid() above) instead of a triangle-mesh grid.

    For every combination of a point `i` from `p0` (the grid's "row"
    direction) and a point `j` from `p1` (the "column" direction),
    builds a grid point at [i.x, j.y, i . j] (i and j's own 3D dot
    product -- so the two waves' heights multiply together, the
    classic combined-wave "basket weave"/ripple look), then rescales
    the whole grid's height so its max is exactly `amplitude`.

    `p0`/`p1` are typically sinewave()/cosinewave() output laid out
    directly in their own plane (NOT rotated afterward with rot() --
    that only works on real Shapes, not point lists -- build the wave
    straight into the plane you want instead, same trick
    surface_line_vector()'s own docstring uses):

        l1 = [[x, 0, y] for x, y in sinewave(50, 3, 2, 50)]      # XZ plane
        l2 = [[0, x, y] for x, y in cosinewave(50, 3, 2, 50)]    # YZ plane
        s1 = surface_from_2_waves(l1, l2, 2)
        show(s1)

    A ripple with a small `amplitude` relative to `p0`/`p1`'s own
    length (e.g. amplitude=2 over a length=100 wave -- only a ~2%
    grade) will genuinely look almost flat at normal zoom, in any
    renderer -- that's not a bug, just perspective. Use a bigger
    amplitude:length ratio to see it clearly, or check
    `s1.bounding_box().size.Z` (should be close to 2*amplitude, since
    the surface genuinely swings +amplitude to -amplitude) to confirm
    the ripple is really there before assuming something's wrong.
    """
    _require_build123d()
    pts0 = [(float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0) for p in p0]
    pts1 = [(float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0) for p in p1]
    grid = [[(i[0], j[1], i[0] * j[0] + i[1] * j[1] + i[2] * j[2]) for j in pts1] for i in pts0]
    max_z = max(pt[2] for row in grid for pt in row)
    if max_z == 0:
        raise ValueError(
            "surface_from_2_waves(): the combined grid height is all zero "
            "-- can't rescale to `amplitude` (check p0/p1 aren't both flat).")
    grid = [[(pt[0], pt[1], pt[2] / max_z * float(amplitude)) for pt in row] for row in grid]
    return surface_from_points_grid(grid)


def thicken(shape, amount, both=False):
    """
    Thickens a Face (e.g. surface_line_vector()'s own output, or any
    Face at all -- planar or not) into a real solid, offset along its
    own surface normal at every point -- build123d's own native
    thicken(). Unlike linear_extrude(), which needs the extrusion
    direction spelled out yourself, this follows whatever direction
    the surface itself curves in point by point, which matters for a
    non-planar surface (surface_line_vector()'s ruled Face, most of
    the time) that has no single straight-line extrusion direction to
    begin with.

    `amount`'s SIGN picks which side gets the material: positive
    thickens along the surface's own normal ("outside", from however
    it was built/wound), negative thickens against it ("inside") -- a
    Face's normal direction isn't always obvious up front, so if it
    comes out on the wrong side, just flip the sign and try again.

    `both=True` thickens in BOTH directions at once and fuses the
    result into one solid centered on the original surface -- note
    this means `amount` on EACH side (2*`amount` total thickness
    across the surface), not `amount` split between the two.

        a = rot('x90', polygon(cr2dt([...], s=10)))
        wall = surface_line_vector(a, [0, 100, 0])
        solid = thicken(wall, 2)             # 2 units thick, one side only
        shell = thicken(wall, 1, both=True)  # 2 units thick total, centered
    """
    _require_build123d()
    return bd.thicken(shape, amount=float(amount), both=bool(both))


def offset_shell(shell, amount, both=False, validate=True):
    """
    A safer thicken() for exactly the failure mode that motivated it:
    thicken() (bd.thicken() above -- OCCT's BRepOffsetAPI_MakeThickSolid
    under the hood) doesn't reliably RAISE when the requested `amount`
    can't actually exist as a valid, non-self-intersecting solid
    everywhere on `shell` -- by far the most common real cause is a
    concave fillet somewhere on the shell with a radius SMALLER than
    abs(amount): a uniform wall that thick would need to fold back
    through itself right at that fillet (its own offset radius would
    have to go negative there, which isn't geometrically possible).
    OCCT is just as likely to hand back a technically-non-null but
    topologically INVALID or self-intersecting solid as it is to
    raise a clean exception for this -- which is exactly what "the
    result looks wrong" (a spiky/self-crossing/garbled shape, not a
    crash) usually means in practice, and is easy to not notice until
    much later (export, a boolean against it, a slicer).

    Calls the exact same bd.thicken() thicken() does, then (unless
    validate=False) runs the real result through OCCT's own
    BRepCheck_Analyzer -- the standard validity checker some build123d
    versions expose as Shape.is_valid(), called directly via raw OCP
    here instead since this app has no confirmed real build123d
    install to check whether every version wraps it the same way (see
    this module's own header docstring; import_brep()'s own
    _heal_imported_shape() above uses this exact same raw-OCP-access
    pattern for the same reason) -- and raises a clear, actionable
    error instead of silently handing back bad geometry if it comes
    back invalid.

    `amount`/`both` mean exactly what they do for thicken() -- see its
    own docstring first for the basics; this only adds the validity
    check and a more specific error message on top.

        f2 = shell_from_faces(f1)
        f3 = offset_shell(f2, -30)   # raises a clear error naming the
                                      # likely cause instead of silently
                                      # handing back a bad solid if some
                                      # fillet on f2 is tighter than 30

    If it raises: the two real fixes are increasing whichever fillet(s)
    on the ORIGINAL solid (before shell_from_faces()) are smaller than
    abs(amount) so they can actually accommodate a wall that thick, or
    reducing abs(amount) to fit the tightest fillet that's actually on
    `shell`. There's no way to make an offset that thick valid AT that
    fillet without changing one of those two numbers -- it's a real
    geometric conflict, not a bug to work around.

    Pass validate=False to skip the check and get thicken()'s raw
    result straight back, e.g. if you already know it's fine and just
    want to avoid the extra check's cost on a very large shape.
    """
    _require_build123d()
    try:
        result = bd.thicken(shell, amount=float(amount), both=bool(both))
    except Exception as exc:
        # A HARDER failure than the invalid-but-present-solid case below
        # -- OCCT couldn't build ANY candidate shape at all for this
        # amount (a real, reported failure: "Null TopoDS_Shape object"),
        # rather than handing back something invalid to inspect. Same
        # underlying cause as the check further down, just a step
        # earlier -- give the same actionable explanation instead of
        # letting the raw OCCT error stand unexplained.
        raise RuntimeError(
            f"offset_shell(): thicken() couldn't build ANY solid for "
            f"amount={amount} ({exc}) -- by far the most common cause "
            f"is a concave fillet somewhere on this shell with a radius "
            f"SMALLER than abs(amount)={abs(float(amount))}: a uniform "
            f"wall that thick can't physically exist there without "
            f"folding back through itself, and OCCT can fail outright "
            f"on that instead of handing back something to inspect. "
            f"Check every fillet radius you applied to the solid THIS "
            f"shell's faces came from against {abs(float(amount))} -- "
            f"the fix is either increasing whichever fillet(s) are "
            f"smaller than that, or reducing abs(amount) to fit the "
            f"tightest one.") from exc
    if not validate:
        return result

    try:
        from OCP.BRepCheck import BRepCheck_Analyzer
        is_ok = bool(BRepCheck_Analyzer(result.wrapped).IsValid())
    except Exception:
        # Couldn't run the check at all (OCP import failed, or this
        # build123d version wraps the underlying shape differently) --
        # fail OPEN, same as _heal_imported_shape()'s own raw-OCP
        # access below: better to hand back thicken()'s own result
        # unchecked than to turn an unrelated environment quirk into a
        # NEW failure here.
        return result

    if is_ok:
        return result

    raise RuntimeError(
        f"offset_shell(): thicken() ran without raising, but the "
        f"resulting solid failed OCCT's own validity check (self-"
        f"intersecting or otherwise topologically broken) -- by far "
        f"the most common cause is a concave fillet somewhere on this "
        f"shell with a radius SMALLER than abs(amount)={abs(float(amount))}: "
        f"a uniform wall that thick can't physically exist there "
        f"without folding back through itself. Check every fillet "
        f"radius you applied to the solid THIS shell's faces came from "
        f"against {abs(float(amount))} -- the fix is either increasing "
        f"whichever fillet(s) are smaller than that, or reducing "
        f"abs(amount) to fit the tightest one. Pass validate=False to "
        f"get thicken()'s raw (invalid) result back anyway if you want "
        f"to inspect it directly first.")


def mirror_surface(shape, n1, loc=(0, 0, 0)):
    """
    Mirrors a real `shape` (solid/face/wire/edge) across the plane
    through `loc` with normal `n1` -- openscad4.py's own
    mirror_surface(), ported. The original mirrored a mesh "surface"
    (a grid of point-list rows) row-by-row via mirror_line(); here
    it's just build123d's own native mirror() applied straight to a
    real shape, with an arbitrary `loc` offset -- the general form of
    this app's own mirror(v, shape) above, which always mirrors
    through the origin. For mirroring a raw 2D/3D point list instead
    of a real shape, see mirror_line()/mirror_point().

        s1 = translate([0, -30, 0], sphere(10))
        s2 = mirror_surface(s1, [1, 1, 0], [0, -30, 0])
        show(s1)
        show(color(s2, "cyan"))
    """
    _require_build123d()
    n = tuple(float(c) for c in n1)
    p = bd.Plane(origin=tuple(float(c) for c in loc), z_dir=n)
    return bd.mirror(shape, about=p)


def scale(v, shape):
    """
    Scales `shape` about the origin -- same convention as OpenSCAD's
    scale(v, ...): `v` is either one number (uniform scale) or [x,y,z]
    (independent per-axis scale).
    """
    _require_build123d()
    if isinstance(v, (int, float)):
        factor = float(v)
    else:
        factor = tuple(float(c) for c in v)
    return bd.scale(shape, by=factor)


_OFFSET_KINDS = {"arc": "ARC", "intersection": "INTERSECTION", "tangent": "TANGENT"}


def offset(shape, amount, kind="arc", openings=None):
    """
    Grows (amount > 0) or shrinks (amount < 0) `shape` by `amount` --
    same idea as OpenSCAD's offset(), just calling build123d's own
    native offset() directly rather than a hand-rolled polygon-offset
    algorithm (2D polygon offsetting -- correctly handling corners,
    self-intersections after a large inward offset, holes, etc -- is
    a genuinely hard problem in its own right, exactly the kind of
    thing this app leans on the real OCCT kernel for rather than
    reimplementing; see sweep_sec2path()'s own docstring for a case
    where a hand-rolled attempt at something similar didn't go well).

    `shape` can be:
      - a 2D shape (circle()/square()/polygon()/etc): grows/shrinks its
        outline -- e.g. offset(square(10, center=True), 2) is a 14x14
        square; offset(..., -2) a 6x6 one. A shape with holes has its
        holes offset the opposite direction automatically (so growing
        the outer boundary shrinks the holes, like OpenSCAD's own
        offset()), so e.g. offsetting a ring outward makes it a wider
        ring, not a filled disc.
      - a 3D solid: SHELLS it -- hollows it out to a uniform wall
        thickness `amount`, sealed on every face by default (a closed
        hollow shell) unless you open some of them via `openings=`
        (e.g. openings=box.faces().sort_by(Axis.Z)[-1] leaves the top
        face open, like a hollow box with no lid -- same edges()/
        faces() selector API fillet()/chamfer() use; see the README's
        "Manually selecting edges" section).

        A FULLY SEALED shell (openings=None) of a solid that's
        entirely curved with no flat face to anchor on -- a sphere or
        a capped cylinder are the classic cases -- is a known-fragile
        operation in OCCT itself: the thicken algorithm can fail
        outright there (an "offset Error"), and unlike a mitered-vs-
        rounded-corner problem, trying a different `kind` often does
        NOT fix it (it's not a corner-handling issue at all -- it's
        that a fully closed offset of a shape with no flat "seam" to
        start stitching from is a genuinely hard case for the
        algorithm). If you hit that, don't bother cycling through
        `kind` values -- either open at least one face via `openings=`
        (even a small one), or, most robust of all, skip offset()
        entirely and build the hollow shape directly out of two nested
        copies with difference() instead -- e.g.
        difference(sphere(10), sphere(8)) for a hollow sphere with a
        2-unit wall. That's a plain boolean, not dependent on the
        thicken algorithm at all, so it always works.

    kind picks how corners are handled where the offset outline can't
    stay parallel to a sharp original corner:
      "arc" (default): rounds the corner.
      "intersection": a sharp, mitered corner (extends both offset
        edges until they meet -- can fail on a corner sharp/tight
        enough for that extension to self-intersect, same class of
        issue as sweep_sec2path()'s "transformed" transition).
      "tangent": a straight-line transition between the two edges.
    """
    _require_build123d()
    key = str(kind).lower()
    if key not in _OFFSET_KINDS:
        raise ValueError(f"offset(): kind must be one of {sorted(_OFFSET_KINDS)}, got {kind!r}")
    kind_enum = getattr(bd.Kind, _OFFSET_KINDS[key])
    kwargs = {} if openings is None else {"openings": openings}
    try:
        return bd.offset(shape, amount=float(amount), kind=kind_enum, **kwargs)
    except Exception as exc:
        raise RuntimeError(
            f"offset(): OCCT couldn't compute this offset with kind={kind!r} "
            f"({exc}). Note this is often NOT a `kind` problem -- a fully "
            f"sealed shell (openings=None) of a solid that's entirely "
            f"curved with no flat face (a sphere, a capped cylinder) is a "
            f"known-fragile case in OCCT regardless of `kind`. Two more "
            f"reliable fixes: open at least one face via `openings=`, or "
            f"skip offset() and build the hollow shape directly with "
            f"difference() of two nested copies instead -- e.g. "
            f"difference(sphere(10), sphere(8)) for a hollow sphere."
        ) from exc


def erode(shape, depth, kind="arc", openings=None):
    """
    Uniformly shrinks a SOLID inward by `depth` from every face,
    returning a smaller SOLID -- not a hollow shell. offset() alone
    can't do this directly (for a solid it always SHELLS, producing
    the hollow material near the boundary, not a smaller solid on its
    own); erode() gets there by shelling and then subtracting that
    shell back out of the original shape.

    Reach for this to approximate which region of a casting
    solidifies/cools LAST: the material with the most surrounding mass
    (farthest from every outer surface) survives the deepest erosion,
    so progressively eroding a part and watching what core remains is
    a rough geometric proxy for where shrinkage porosity risk
    concentrates -- see erosion_series() for the stepwise version of
    exactly that.

    `depth` should be POSITIVE (how far to erode inward) -- unlike
    offset()'s own `amount` (where negative means inward, positive
    outward), this only ever erodes, so it reads naturally without
    needing to remember a sign convention.

    `kind`/`openings`: passed straight through to offset() -- see its
    own docstring for what they mean.

    IMPORTANT, confirmed on this app's own test shape (the filleted
    sphere/cube cavity from 08_filleted_cube_sphere_cut.py): a sharp
    CONCAVE corner (where several faces meet cupping inward -- this
    shape's own 3-flat-wall cavity is exactly that) combined with
    small fillets right at that corner is a genuinely hard case for
    OCCT's offset algorithm and can fail outright (offset()'s own
    RuntimeError), even with one face opened and a small depth. Two
    fixes, in order of how likely they are to help:
      1. Pass `openings=` with SEVERAL of the concave region's own
         faces, not just one -- e.g. the same face list you'd hand
         shell_from_faces() for that cavity -- giving OCCT more room
         to resolve the shell around the tight corner.
      2. Erode the shape BEFORE any small fillets are applied at that
         corner, not after -- fillets sitting right at an already-
         tight concave junction are what tends to destabilize this,
         and for a hot-spot/rough solidification check, doing it on
         the simplified unfilleted geometry is usually accurate enough
         anyway (fillets are a small local detail that rarely changes
         which broad region solidifies last).

        raw = difference(b, a)                        # before fillet()
        concave_faces = [raw.faces()[i] for i in [...]]  # pick with the Pick tool
        core = erode(raw, 2, openings=concave_faces)
        show(core)
    """
    _require_build123d()
    shell = offset(shape, -float(depth), kind=kind, openings=openings)
    return difference(shape, shell)


def erosion_series(shape, depths, kind="arc", openings=None):
    """
    erode() at every depth in `depths`, each computed independently
    from the SAME original `shape` (not compounded from the previous
    step's result, so there's no accumulated error and you can jump
    straight to any single depth) -- the stepwise "which region
    survives the deepest peel" scan, ready to color/show in one loop:

        raw = difference(b, a)
        concave_faces = [raw.faces()[i] for i in [...]]
        cores = erosion_series(raw, [1, 2, 3, 4], openings=concave_faces)
        palette = ["red", "orange", "yellow", "green"]
        for core, col in zip(cores, palette):
            show(color(core, col))

    Returns a list of solids, same order/length as `depths`. If one
    depth fails (too deep for this shape's own tightest feature -- see
    erode()'s own docstring), that RuntimeError propagates immediately
    rather than being silently skipped -- knowing exactly which depth
    stopped working is itself useful here, since it marks how deep
    material extends before hitting this shape's own geometric pinch
    point.
    """
    _require_build123d()
    return [erode(shape, d, kind=kind, openings=openings) for d in depths]


def offset_face(face, amount):
    """
    Moves a Face (or Shell) `amount` along its own surface normal --
    build123d's own native Face.offset()/Shell.offset() INSTANCE
    method. This is deliberately a DIFFERENT function from offset()
    above, because they do genuinely different things for a Face:
    offset() (the top-level function above) offsets the face's OUTER
    WIRE sideways, WITHIN its own plane (bigger/smaller outline, same
    plane) -- offset_face() instead pushes the whole face OFF its own
    plane, along its normal (a plain flat plate pushed straight up).

    EXACT for a planar Face (plane()'s own output, say): every point
    genuinely moves `amount` along the same constant normal, so this
    is a true parallel copy of the plane.

    APPROXIMATE for a curved Face (a cylinder's lateral surface, a
    fitted NURBS patch): build123d implements this as one RIGID
    TRANSLATION by (the face's own reference-point normal) * amount,
    not a true "every point grows along ITS OWN local normal" offset
    surface (that operation isn't exposed as a simple one-line call in
    build123d). Good enough as a nearby stand-in surface for finding a
    shifted intersection curve (see convert_3lines2fillet()'s own
    docstring for the full recipe this is built for) -- not a
    substitute for a real, precise offset surface.

        line_b = sample_curve(intersection(offset_face(a, 1), b), 40)
        line_a = sample_curve(intersection(a, offset_face(b, 1)), 40)
    """
    _require_build123d()
    return face.offset(float(amount))


_SPLIT_KEEP = {"top": "TOP", "bottom": "BOTTOM", "both": "BOTH"}


def split(shape, bisect_by, keep="top"):
    """
    Bisects `shape` with a plane (or a Face) and keeps one side, the
    other, or both -- build123d's own split(), exposed directly here so
    `split(...)` and `Keep.X` both just work in your script without
    `from build123d import split, Keep` first (build123d's own docs/
    examples always show it written that way, since build123d itself
    doesn't auto-expose its own names into scripts the way this app's
    whole function library does).

    `bisect_by` is the cutting surface -- typically a real Plane (see
    plane()/plane_from_equation()) for a flat cut, or a Face for a
    curved one, e.g. carving the top off a block along an arbitrary
    wavy surface instead of a flat plane:

        import openscad4 as o
        block = cube([30, 30, 10])
        wavy = surface_from_points_grid(o.plane_from_equation([1, 1, 0, 7], [50, 50]))
        bottom_half = split(block, bisect_by=wavy, keep="bottom")

    `keep` selects which side survives -- accepts either a plain string
    ("top"/"bottom"/"both", case-insensitive -- same convention as this
    app's own offset()'s `kind` argument) or build123d's own Keep enum
    directly (Keep.TOP/Keep.BOTTOM/Keep.BOTH, already in scope, no
    import needed -- matches how build123d's own examples write it):
      "top" (the default): the half on `bisect_by`'s positive-normal
        side.
      "bottom": the other half.
      "both": BOTH halves at once, combined into a single returned
        shape -- same convention as this app's other multi-piece
        results (e.g. offset()'s hollowed shell); pull the two halves
        back apart with e.g. `.solids()` on the result if you need them
        separately.
    """
    _require_build123d()
    if isinstance(keep, str):
        key = keep.strip().lower()
        if key not in _SPLIT_KEEP:
            raise ValueError(
                f"split(): keep must be one of {sorted(_SPLIT_KEEP)} or a "
                f"Keep enum value (Keep.TOP/Keep.BOTTOM/Keep.BOTH), got {keep!r}"
            )
        keep_enum = getattr(bd.Keep, _SPLIT_KEEP[key])
    else:
        keep_enum = keep
    return bd.split(shape, bisect_by=bisect_by, keep=keep_enum)


def union(*shapes):
    """
    CSG union of two or more B-rep shapes (the `+` operator).

    CONFIRMED real failure mode (real user report): fusing several
    already-unioned shapes against one more shape that meets them
    across a large EXACTLY COPLANAR shared area (e.g. a flat base
    plate whose top face sits flush with several standing panels'
    bottom edges, all resting at the same z) can raise `AttributeError:
    'NoneType' object has no attribute 'NbNodes'` deep inside OCCT --
    same fragility class already documented in sweep_sec2path()'s/
    p_line3d()'s own docstrings, here triggered inside the boolean
    fuse itself rather than a sweep. It reliably showed up only once
    SEVERAL pieces' coincident contact area had accumulated (each
    piece unioned individually against the base worked fine) -- OCCT's
    fuse is well known to be far more fragile on large flush/coplanar
    contact than on a genuine volumetric overlap or a small contact
    patch.

    FIX: don't let two pieces meet across an exactly flush shared
    plane -- give the piece real volumetric overlap into the others
    instead (a thicker base shifted to poke slightly INTO whatever
    sits on top of it, say), e.g.:

        base = translate([0, 0, -0.5], linear_extrude(square(70), 2))
        # instead of: linear_extrude(square(70), 1)  # flush at z=0

    `.clean()`-ing operands right before a fuse that's struggling is
    also worth trying, but didn't fix this particular case on its own
    -- the real fix was removing the flush/coincident contact.
    """
    _require_build123d()
    shapes = _flatten(shapes)
    if len(shapes) == 0:
        raise ValueError("union(): need at least one shape")
    out = shapes[0]
    for s in shapes[1:]:
        out = out + s
    return out


def union_fuzzy(*shapes, fuzzy_value=1e-3):
    """
    Same job as union() -- CSG union of two or more B-rep shapes -- but
    drops past build123d's `+` operator to call OCCT's
    BRepAlgoAPI_Fuse directly so a "fuzzy value" can be set explicitly.
    Reach for this INSTEAD of union() specifically when you hit the
    large-flush/coplanar-contact fragility union()'s own docstring
    documents (`AttributeError: 'NoneType' object has no attribute
    'NbNodes'` or similar deep-OCCT failures on pieces that meet across
    an exactly-shared flat area) and giving the pieces real volumetric
    overlap isn't practical.

    WHAT FUZZY VALUE ACTUALLY DOES: OCCT's boolean engine normally
    treats two vertices/edges as "the same" only within its ordinary
    geometric tolerance (tiny, near machine precision). A large flush
    contact multiplies how many near-coincident vertex/edge pairs the
    algorithm has to disambiguate at once, and it's exactly that
    disambiguation step that goes fragile. SetFuzzyValue(fuzzy_value)
    widens the distance within which OCCT is willing to merge
    near-coincident vertices/edges BEFORE doing the boolean -- the
    same knob FreeCAD's own Part Boolean feature exposes as "Fuzzy
    value" for this identical class of problem. Too large a value can
    weld together geometry that was only meant to be close, not
    coincident, so start small (the 1e-3 default is in the same units
    as the model, i.e. 0.001 mm for a millimeter-scale part) and raise
    it only as far as actually needed.

    `shapes` accepts the same union(a,b,c) / union([a,b,c]) calling
    conventions as union() (via the same _flatten() helper).

    UNVERIFIED against a real build123d/OCP install (see this module's
    own header docstring) -- BRepAlgoAPI_Fuse's constructor/argument
    shapes and SetFuzzyValue()/Build()/IsDone()/Shape() are documented
    OCCT API (unchanged across recent OCCT versions), and
    `shape.wrapped` / reconstructing `type(shape)(topods)` are the same
    established build123d patterns already used elsewhere in this file
    (see _heal_imported_shape()), but this exact call sequence hasn't
    been run against a real install. Falls back to plain union() (and
    therefore to whatever union() itself would have done, fuzzy value
    or not) if anything about the raw OCP path fails, so this is safe
    to try -- worst case it behaves exactly like calling union().
    """
    _require_build123d()
    shapes = _flatten(shapes)
    if len(shapes) == 0:
        raise ValueError("union_fuzzy(): need at least one shape")
    if len(shapes) == 1:
        return shapes[0]
    try:
        from OCP.BRepAlgoAPI import BRepAlgoAPI_Fuse
        from OCP.TopTools import TopTools_ListOfShape

        out = shapes[0]
        for s in shapes[1:]:
            args = TopTools_ListOfShape()
            args.Append(out.wrapped)
            tools = TopTools_ListOfShape()
            tools.Append(s.wrapped)
            op = BRepAlgoAPI_Fuse()
            op.SetArguments(args)
            op.SetTools(tools)
            op.SetFuzzyValue(float(fuzzy_value))
            op.Build()
            if not op.IsDone():
                raise RuntimeError("BRepAlgoAPI_Fuse did not complete")
            out = type(out)(op.Shape())
        return out
    except Exception:
        # Fail-safe: identical fallback pattern to _heal_imported_shape()
        # elsewhere in this file -- if the raw OCP path doesn't work in
        # this build123d/OCCT version for any reason, silently behave
        # exactly like union() instead of raising something new.
        return union(*shapes)


def union_multi(*shapes, fuzzy_value=1e-3):
    """
    Fuses THREE OR MORE shapes in a single combined OCCT boolean pass
    (BOPAlgo_Builder) instead of union()'s/union_fuzzy()'s pairwise
    chain (a+b, then (a+b)+c, then ((a+b)+c)+d, ...). Falls back to
    union_fuzzy() for 1-2 shapes, where there's no "chain" to avoid.

    WHY THIS EXISTS -- CONFIRMED real failure mode (real user report,
    solid_from_mesh_slices(branches=True) below): fusing many
    similarly-shaped solids that each share a near-coincident boundary
    with a common neighbor (adjacent branch "threads" built from
    overlapping/jittered copies of the same borrowed rings -- see
    _jitter_ring()'s own docstring) came back as multiple disconnected
    solids/faces instead of one watertight result once enough pieces
    accumulated (n=200 station count), even after per-piece .clean()
    and ShapeFix_Shape healing. That symptom -- OCCT reporting several
    separate pieces after what should be one continuous fuse -- is a
    known weak spot of chaining BRepAlgoAPI_Fuse pairwise: each step
    only ever compares TWO already-fused results against each other,
    so any tolerance/rounding slop from an early step compounds into
    the next one, and a piece that only barely (near-coincidentally)
    touches its neighbor can end up on the wrong side of that slop by
    the time it's chained through several prior fuses.

    BOPAlgo_Builder is OCCT's own lower-level, general N-ary boolean
    framework -- the thing BRepAlgoAPI_Fuse itself is built on for the
    2-argument case -- run here directly across ALL the shapes AT ONCE
    in one combined pass instead of pairwise. OCCT's own documentation
    recommends exactly this (BOPAlgo_Builder over chained
    BRepAlgoAPI_Fuse) for fusing many shapes together for this same
    accumulated-tolerance reason. Whether it actually resolves the
    n=200 branching case specifically hasn't been confirmed (no live
    build123d/OCP install here to test against -- see this module's own
    header docstring) -- please try this in place of the plain
    union(*solids) call in solid_from_mesh_slices(branches=True) and
    report back whether the disconnected-fragment symptom is gone, and
    at what station count (n) it starts up again, if at all.

    UNVERIFIED against a real build123d/OCP install, same caveat as
    union_fuzzy() above. Falls back to union_fuzzy() (chained pairwise)
    if the BOPAlgo_Builder path fails for any reason, so this is safe
    to try -- worst case it behaves exactly like union_fuzzy().
    """
    _require_build123d()
    shapes = _flatten(shapes)
    if len(shapes) == 0:
        raise ValueError("union_multi(): need at least one shape")
    if len(shapes) <= 2:
        return union_fuzzy(*shapes, fuzzy_value=fuzzy_value)
    try:
        from OCP.BOPAlgo import BOPAlgo_Builder
        from OCP.TopTools import TopTools_ListOfShape

        builder = BOPAlgo_Builder()
        for s in shapes:
            builder.AddArgument(s.wrapped)
        if hasattr(builder, "SetFuzzyValue"):
            builder.SetFuzzyValue(float(fuzzy_value))
        builder.Perform()
        if builder.HasErrors():
            raise RuntimeError("BOPAlgo_Builder reported errors")
        return type(shapes[0])(builder.Shape())
    except Exception:
        return union_fuzzy(*shapes, fuzzy_value=fuzzy_value)


def difference(base, *shapes):
    """
    CSG difference: `base` minus every shape in `shapes` (the `-`
    operator) -- same argument order as openscad4.py's usual
    difference(first_child, remaining_children...) convention.
    """
    _require_build123d()
    shapes = _flatten(shapes)
    out = base
    for s in shapes:
        out = out - s
    return out


def face_from_wire(wire):
    """
    Wraps an EXISTING closed Wire directly into a Face -- build123d's
    own native Face(wire) constructor. The point of this over
    mixed_polygon()/polygon() (which both build a brand new Wire from a
    plain point list) is EXACT edge matching: when you need a cap Face
    whose boundary is guaranteed to coincide exactly with another real
    shape's own boundary edges (e.g. one end of a
    surface_from_points_grid() surface), rebuilding that boundary
    independently from raw points (even the SAME points) traces a
    close-but-not-identical curve -- a fitted NURBS boundary and a
    fresh straight-line polygon through the same points are two
    genuinely different curves, and OCCT's exact-topology sewing
    (solid_from_faces()) needs edges to coincide, not just look close,
    or it fails to zip them into one watertight shell.

        wall = surface_from_points_grid(surf)      # a curved wall Face
        w = wall.wires()                            # its own boundary wire(s)
        cap_a = face_from_wire(w[0])                 # exact match to wall's own edge
        cap_b = face_from_wire(w[1])
        solid = solid_from_faces(wall, cap_a, cap_b)

    Raises whatever build123d itself raises if `wire` isn't planar (a
    Face can only be built from a wire that lies in one flat plane --
    same restriction polygon()/mixed_polygon() have).
    """
    _require_build123d()
    return bd.Face(wire)


def cap_wire(boundary, surface_points=None):
    """
    Caps a closed boundary with a real, potentially NON-planar Face --
    build123d's own native Face.make_surface() (OCCT's
    BRepOffsetAPI_MakeFilling under the hood: a genuine curvature-
    aware surface fill through the given boundary, not a flat cap).
    The non-planar counterpart to face_from_wire() above -- reach for
    this one instead whenever the ring you need to cap does NOT lie in
    one flat plane (face_from_wire()/polygon()/mixed_polygon() all
    require planarity; this doesn't).

    `boundary` is either a closed loop of raw [x,y,z] points (built
    into one periodic interpolating spline Edge via interp_spline()
    first) or an existing Wire/Edge/list of Edges to use directly --
    e.g. one of a Shape's own wall.wires(), for the closest possible
    edge match when sewing with solid_from_faces() (an independently
    built spline through the same points is still a genuinely
    different curve, so it won't sew edge-exact the way face_from_wire()
    does for a planar cap).

    `surface_points`, if given, are extra raw [x,y,z] points the fill
    is pulled through in addition to the boundary -- use this to keep
    a bulging/non-planar cap closer to the true shape in the middle
    instead of just bridging flat-ish between the boundary points.

        wall = surface_from_points_grid(grid)   # a tube, open at both ends
        cap_a = cap_wire(grid[0])                # first ring, however curved
        cap_b = cap_wire(grid[-1])               # last ring
        solid = solid_from_faces(wall, cap_a, cap_b)
    """
    _require_build123d()
    if isinstance(boundary, bd.Wire):
        exterior = boundary
    elif isinstance(boundary, bd.Edge):
        exterior = [boundary]
    elif isinstance(boundary, (list, tuple)) and boundary and isinstance(boundary[0], bd.Edge):
        exterior = list(boundary)
    else:
        exterior = [interp_spline(boundary, closed=True)]
    pts = None
    if surface_points:
        flat = _flatten_points(surface_points)
        pts = [(p[0], p[1], p[2] if len(p) > 2 else 0.0) for p in flat]
    return bd.Face.make_surface(exterior, surface_points=pts)


def intersection(*shapes):
    """CSG intersection of two or more B-rep shapes (the `&` operator)."""
    _require_build123d()
    shapes = _flatten(shapes)
    if len(shapes) == 0:
        raise ValueError("intersection(): need at least one shape")
    out = shapes[0]
    for s in shapes[1:]:
        out = out & s
    return out


def sample_curve(shape, n):
    """
    `n` evenly-parametrized points along a Wire/Edge (or a filled
    Face's own boundary wire, pulled out automatically -- same "grab
    the outline" step sweep_sec2path()/p_line3d() use internally) --
    the general-purpose way to turn a real curve into a plain point
    list, for when to_points() isn't enough: to_points() only grabs
    each EDGE's own START point, so a Wire made of few but long/curved
    edges (an intersection() result, most commonly -- often just ONE
    single curved edge) comes back as far too few points from
    to_points() to be useful as a station list. sample_curve() instead
    walks the WHOLE wire's own combined parametrization evenly,
    regardless of how many edges it's actually built from.

    Reach for this whenever you need a real curve (an intersection()
    result, an arc_edge(), any Wire/Edge) as a point list for one of
    brep.py's point-list functions -- convert_3lines2fillet()'s own
    spine/line_a/line_b, most commonly:

        curve = intersection(a, b)
        pts = sample_curve(curve, 40)

    On a CLOSED wire (a full loop, e.g. mixed_wire()'s own output, or
    one of a solid's own wires()), `n` distinct points are spread
    evenly around the WHOLE loop without ever repeating the start
    point -- unlike an open curve, where t=0 and t=1 are genuinely
    different endpoints worth keeping both of, t=0 and t=1 on a closed
    one are the exact same physical point, so including both would
    silently duplicate it. That matters downstream: feeding a
    duplicated closing point into interp_spline(..., closed=True) (cap_
    wire()'s own fallback for a raw point list) gives OCCT's periodic
    interpolator a zero-length final span, which fails with a
    low-level "BSplCLib::Interpolate" error rather than a clean
    Python one.

    UNVERIFIED against a real build123d install (see module
    docstring) -- Wire.position_at(t) is expected to parametrize
    evenly by ARC LENGTH across the whole wire (t=0.5 landing on the
    true geometric midpoint) rather than by the wire's raw underlying
    parameter space (which could bunch points unevenly if the wire's
    edges have very different natural parameter ranges); if station
    spacing looks uneven in practice, that assumption is what to
    revisit here.
    """
    _require_build123d()
    wire = _as_path_wire(shape, "sample_curve")
    n = int(n)
    if n < 2:
        raise ValueError("sample_curve(): need at least 2 points")
    # On a CLOSED wire, position_at(0) and position_at(1) are the exact
    # same physical point (t=1 wraps back to the start) -- sampling the
    # full inclusive range i/(n-1) there would silently duplicate the
    # first point as the last one. That's not just a harmless repeat:
    # feeding it straight into interp_spline(..., closed=True) (as
    # cap_wire() does for a raw point list -- see its own docstring)
    # gives OCCT's periodic interpolator a zero-length final span to
    # fit through, which fails outright with a low-level
    # "BSplCLib::Interpolate" error, not a clean Python exception. So:
    # n DISTINCT evenly-spaced points around the whole loop (t = i/n,
    # never revisiting t=0) for a closed wire, and the original
    # both-endpoints-inclusive spacing (t = i/(n-1)) for an open one,
    # where the start and end genuinely are two different points worth
    # keeping.
    closed = bool(getattr(wire, "is_closed", False))
    pts = []
    for i in range(n):
        t = i / n if closed else i / (n - 1)
        p = wire.position_at(t)
        pts.append([float(p.X), float(p.Y), float(p.Z)])
    return pts


def hull(*shapes):
    """
    The convex hull enclosing all the given shapes -- real B-rep, built
    from build123d's own ConvexPolyhedron (which computes the hull of a
    point cloud itself; there's no need to compute hull faces here).

    Every shape is tessellated first (to_mesh(), default tolerance) and
    every triangle vertex from all of them is fed into the hull
    together. For a shape made only of flat faces (box(), a union() of
    boxes, etc), tessellating doesn't add or move any true corner --
    triangulating a flat face just adds a diagonal across it -- so the
    result is exact. For a shape with curved faces (cylinder(),
    sphere(), a fillet()ed edge), it's only an approximation, accurate
    to roughly that default tessellation tolerance -- tessellate the
    shape yourself first with a tighter to_mesh(shape, tolerance=...)
    and pass the resulting points through bd.ConvexPolyhedron directly
    if you need closer than that.
    """
    _require_build123d()
    shapes = _flatten(shapes)
    if len(shapes) == 0:
        raise ValueError("hull(): need at least one shape")
    all_points = []
    for s in shapes:
        v, _f = to_mesh(s)
        all_points.extend(tuple(p) for p in v)
    if not all_points:
        raise ValueError("hull(): no points found on any given shape")
    return bd.ConvexPolyhedron(all_points)


def fillet(shape, edges, radius):
    """
    Rounds `edges` of `shape` with the given radius -- a real, exact
    B-rep fillet (a genuine curved/cylindrical blend surface computed by
    OCCT), not a faceted approximation built out of extra geometry the
    way OpenSCAD scripts usually fake a fillet (e.g. unioning in a
    rotate_extrude()'d quarter-circle profile, or minkowski() with a
    sphere).

    `edges` is a selection of edges FROM `shape` itself -- most simply
    `shape.edges()` for every edge (real build123d Shape objects, which
    is what box()/cylinder()/union()/etc all return here, have this
    method directly), or narrowed down first, e.g.
    `shape.edges().filter_by(Axis.Z)` for only the vertical ones (needs
    `from build123d import Axis`), or `shape.edges().sort_by(Axis.Z)[-4:]`
    for just the top 4. See build123d's own docs for the full edge-
    selector API -- brep.py doesn't wrap that part, `shape` is a real
    build123d object so its own methods are already there to use
    directly.

    `edges` can also be a single bare Edge (not wrapped in a list) --
    e.g. `fillet(a, a.edges()[3], 2)` works the same as
    `fillet(a, [a.edges()[3]], 2)` -- same convenience as
    show_edges()/label_edges().

    Example:
        a = cube([20,20,20])
        rounded = fillet(a, a.edges(), 3)

    If `radius` is too big for the local geometry at one of `edges`
    (blend surfaces from adjacent edges would collide/overlap), OCCT
    raises "Failed creating a fillet with radius of X" -- a real
    geometric limit, not a bug: some edges in your selection just can't
    take that big a rounding given how close they are to other
    features. Try a smaller radius, fillet a smaller edge subset at a
    time, or call max_fillet_radius(shape, edges) first to get the
    largest radius that actually works for that exact selection.

    UNVERIFIED against a real build123d install, same caveat as the
    rest of this file (see module docstring) -- fillet()/chamfer() are
    thin passthroughs to build123d's own top-level fillet()/chamfer()
    functions, so if something's wrong here it's most likely just the
    argument order/names, not the underlying operation.
    """
    _require_build123d()
    try:
        edge_list = list(edges)
    except TypeError:
        edge_list = [edges]
    try:
        return bd.fillet(edge_list, radius)
    except Exception as exc:
        raise ValueError(
            f"fillet(): radius {radius} doesn't fit at (at least) one of the "
            f"selected edges ({exc}). This is a real geometric limit -- the "
            f"blend surface at that radius would collide with a neighboring "
            f"face/edge -- not a bug. Try a smaller radius, split `edges` into "
            f"smaller groups to isolate which one is the problem, or call "
            f"max_fillet_radius(shape, edges) to get the largest radius that "
            f"actually works for this exact selection."
        ) from exc


def max_fillet_radius(shape, edges, tolerance=0.1, max_iterations=10):
    """
    The largest radius that fillet(shape, edges, radius) will actually
    succeed with, for this exact `shape`/`edges` selection -- a thin
    wrapper around build123d's own Shape.max_fillet() (a binary search
    over candidate radii, each checked by actually attempting the
    fillet). Directly answers the question fillet()'s own error message
    points you at ("...try a smaller value or use max_fillet() to find
    the largest valid fillet radius") without you having to guess-and-
    check radii by hand:

        edges = [c.edges()[i] for i in [-4,-8,-9,-10,-11,-12]]
        r = max_fillet_radius(c, edges)
        show(fillet(c, edges, r))

    `tolerance`/`max_iterations` control the binary search's precision
    and effort, same meaning as build123d's own parameters -- the
    defaults are usually fine, but see the important caveat below for
    models with small features relative to their overall size.

    IMPORTANT (verified against build123d's own max_fillet() source):
    the binary search's STARTING window is always (0, 2 * shape's own
    overall bounding_box().diagonal) -- the whole model's size, not
    anything related to the specific edges/feature you're testing. On
    a model where the actual achievable radius is small relative to
    the whole shape (a thin wall on a much bigger part, e.g. a 2mm
    wall on an 80mm-tall tube), the search can spend most/all of its
    max_iterations budget just narrowing that huge starting window
    down into the right neighborhood, and run out before ever
    converging -- reporting "couldn't find ANY radius" even though a
    real small radius likely DOES exist, it just wasn't found in time.
    This is a genuine false negative, not proof of unfilletability --
    raising max_iterations well above the default (e.g. 30-40) CAN and
    often does fix this, and is the first thing to try before
    concluding an edge is really unfilletable:

        max_fillet_radius(shape, edges, max_iterations=40)

    If THAT still raises "Failed to find the max value within
    <tolerance> in <max_iterations>", NOW it's more likely a genuinely
    different, more fundamental problem: at least one edge in your
    selection can't be filleted no matter how small the radius is --
    not "1 was too big", but "this particular edge is unfilletable" (a
    seam edge on a periodic/cylindrical surface, or an edge at a vertex
    where too many filleted faces would need to meet, are the two most
    common real causes). The fix at that point is to find out WHICH
    edge in the group is the problem by testing them one at a time
    (still with a generous max_iterations):

        edges = [c.edges()[i] for i in [-4,-8,-9,-10,-11,-12]]
        for i, e in enumerate(edges):
            try:
                print(i, max_fillet_radius(c, [e]))
            except Exception as exc:
                print(i, "UNFILLETABLE:", exc)

    then drop whichever index(es) print UNFILLETABLE from the group (or
    fillet them separately with chamfer() or a different radius/edge
    choice instead).

    `edges` can also be a single bare Edge (not wrapped in a list) --
    e.g. `max_fillet_radius(shape, e)` works the same as
    `max_fillet_radius(shape, [e])`, so a per-edge testing loop like the
    one above doesn't need to wrap each `e` itself -- same convenience
    as fillet()/show_edges()/label_edges(). (Forgetting this wrapping
    used to surface as a confusing "'Edge' object is not iterable"
    buried inside the generic "couldn't find ANY radius" message below
    -- a plain Python usage error masquerading as a geometric one; now
    it just works instead.)
    """
    _require_build123d()
    try:
        edge_list = list(edges)
    except TypeError:
        edge_list = [edges]
    try:
        return shape.max_fillet(edge_list, tolerance=float(tolerance), max_iterations=int(max_iterations))
    except Exception as exc:
        raise RuntimeError(
            f"max_fillet_radius(): couldn't find ANY radius that works for this "
            f"edge group within {max_iterations} iterations ({exc}). The search "
            f"always starts from a window sized off the WHOLE shape's own "
            f"bounding_box().diagonal, not the local feature -- so on a small "
            f"feature (a thin wall, a small fillet) on a much bigger overall "
            f"shape, it can genuinely run out of iterations before converging, "
            f"even though a real small radius exists. TRY A BIGGER "
            f"max_iterations FIRST (e.g. max_fillet_radius(shape, edges, "
            f"max_iterations=40)) before concluding the edge is really "
            f"unfilletable. If a generous max_iterations STILL fails, then it's "
            f"more likely a genuine geometric dead end -- at least one edge in "
            f"the selection can't be filleted at all (a seam edge, or a vertex "
            f"where too many fillets would need to meet). Test the edges one at "
            f"a time (still with a generous max_iterations) with "
            f"max_fillet_radius(shape, e, max_iterations=40) for each e to find "
            f"out which one is the problem -- see this function's own docstring "
            f"for the exact snippet."
        ) from exc


def chamfer(shape, edges, length):
    """
    Bevels `edges` of `shape` by `length` -- a real, exact B-rep
    chamfer, same idea as fillet() above but a flat angled cut instead
    of a rounded one. See fillet()'s docstring for how to select
    `edges` (e.g. `shape.edges()` for all of them) -- `edges` can also
    be a single bare Edge, same convenience as fillet().
    """
    _require_build123d()
    try:
        edge_list = list(edges)
    except TypeError:
        edge_list = [edges]
    return bd.chamfer(edge_list, length)


def show_edges(edges, radius=0.3, samples=12):
    """
    Turns an edge selection into a visible "beaded string" of small
    spheres following each edge's own curve (straight or curved -- e.g.
    a cylinder's round rim comes out as a curved string of beads, not a
    straight line between its endpoints) -- a debug/visualization aid
    for confirming EXACTLY which edges a selector expression picked out
    (see fillet()'s docstring for selector examples) before actually
    handing them to fillet()/chamfer(). The viewer has no click-to-
    identify-a-B-rep-edge tool yet (its picking tool works on the
    tessellated display mesh, not the exact underlying topology), so
    this is the practical way to check a selection visually in the
    meantime: show it alongside your real model in a different color.

        edges = a.edges().filter_by(Axis.Z)
        show(a, alpha=0.3)                    # the model, faded
        show(show_edges(edges), c="red")      # just the selected edges, highlighted
        # once the highlighted edges look right:
        r = fillet(a, edges, 3)

    `edges` is exactly what you'd pass to fillet()/chamfer() -- e.g.
    a.edges(), or a filtered/sorted/sliced selection of it.

    `radius` controls how thick the beads are -- there's no automatic
    scaling to your model's size, so adjust it by hand for a very large
    or very small model (the default (0.3) is a reasonable starting
    point for a model with dimensions in the tens, not hundreds or
    fractions of a unit). `samples` is how many points are sampled
    along each edge's own curve (more = a smoother-looking curve for a
    rounded edge, at the cost of more spheres -- doesn't affect a
    straight edge's appearance either way).
    """
    _require_build123d()
    try:
        edge_list = list(edges)
    except TypeError:
        # a single bare Edge (e.g. edges[3], not a slice) isn't
        # iterable itself -- treat it as a one-edge selection instead
        # of erroring, so show_edges(edges[3]) works same as
        # show_edges(edges[3:4]) or show_edges([edges[3]]).
        edge_list = [edges]
    if not edge_list:
        raise ValueError("show_edges(): no edges given (empty selection)")
    n = max(2, int(samples))
    beads = []
    for e in edge_list:
        for i in range(n + 1):
            t = i / n
            p = e.position_at(t)
            beads.append(bd.Pos(float(p.X), float(p.Y), float(p.Z)) * bd.Sphere(radius))
    out = beads[0]
    for b in beads[1:]:
        out = out + b
    return out


def label_edges(edges, text_size=1, h=0.1):
    """
    Labels each edge in `edges` with its own index (0, 1, 2, ...) as
    small flat text at that edge's midpoint -- the edge-selection
    counterpart of track_points() (same idea, indices instead of point
    numbers), for exactly the workflow fillet()'s/max_fillet_radius()'s
    own docstrings point at: figuring out which index(es) into
    shape.edges() are the ones you actually want, before calling
    fillet(shape, [shape.edges()[i] for i in [...]], radius) -- no more
    guessing indices blind or filleting the whole shape to see what
    happens.

    Pass the SAME list you'd index into for fillet()/chamfer() --
    almost always shape.edges() itself, unfiltered, so the numbers
    shown line up with shape.edges()[i]:

        a = cube([20, 20, 20])
        show(a, alpha=0.2)
        show(label_edges(a.edges()), 'red')
        # read the indices you want off the viewer, then:
        show(fillet(a, [a.edges()[i] for i in [3, 7, 11]], 2))

    If you pass an already-filtered/sorted/sliced selection instead
    (e.g. a.edges().filter_by(Axis.Z)), the numbers are just that
    selection's own 0-based position in the order given -- NOT the
    original shape.edges() index -- so that's only useful once you've
    already narrowed a group down and want to double check which ones
    ended up in it, not for picking indices back out of the full
    shape.edges() list.

    `text_size`/`h` control the label size/thickness, same meaning as
    track_points()'s own parameters -- there's no automatic scaling to
    your model's size, adjust by hand. Combine with show_edges(edges)
    to see the actual edge curves highlighted alongside the numbers:

        show(show_edges(a.edges()), 'blue')
        show(label_edges(a.edges()), 'red')
    """
    _require_build123d()
    try:
        edge_list = list(edges)
    except TypeError:
        # a single bare Edge isn't iterable itself -- same convenience
        # as show_edges() above.
        edge_list = [edges]
    if not edge_list:
        raise ValueError("label_edges(): no edges given (empty selection)")
    labels = []
    for i, e in enumerate(edge_list):
        p = e.position_at(0.5)
        labels.append(bd.Pos(float(p.X), float(p.Y), float(p.Z))
                       * text(str(i), size=text_size, h=h, center=True))
    return bd.Compound(labels)


def label_faces(faces, text_size=1, h=0.1):
    """
    Labels each face in `faces` with its own index (0, 1, 2, ...) as
    small flat text at that face's own center -- label_edges()'s
    counterpart for face selectors, for the exact same workflow: figure
    out which index(es) into shape.faces() are the ones you want before
    handing them to something that takes a face selection (e.g. an
    offset()'s `openings=` argument, or picking a face to build a
    workplane/sketch on) instead of guessing blind.

    Pass the SAME list you'd index into afterward -- almost always
    shape.faces() itself, unfiltered, so the numbers shown line up with
    shape.faces()[i]:

        a = cube([20, 20, 20])
        show(a, alpha=0.2)
        show(label_faces(a.faces()), 'red')
        # read the index you want off the viewer, then e.g.:
        hollow = offset(a, -2, openings=[a.faces()[i] for i in [4]])

    If you pass an already-filtered/sorted/sliced selection instead
    (e.g. a.faces().sort_by(Axis.Z)[-1:]), the numbers are just that
    selection's own 0-based position in the order given -- NOT the
    original shape.faces() index -- same caveat as label_edges().

    `text_size`/`h` control the label size/thickness, same meaning as
    label_edges()'s/track_points()'s own parameters -- no automatic
    scaling to your model's size, adjust by hand.
    """
    _require_build123d()
    try:
        face_list = list(faces)
    except TypeError:
        # a single bare Face isn't iterable itself -- same convenience
        # as label_edges()/show_edges() above.
        face_list = [faces]
    if not face_list:
        raise ValueError("label_faces(): no faces given (empty selection)")
    labels = []
    for i, f in enumerate(face_list):
        p = f.center()
        labels.append(bd.Pos(float(p.X), float(p.Y), float(p.Z))
                       * text(str(i), size=text_size, h=h, center=True))
    return bd.Compound(labels)


def edges_in_box(edges, box, mode="inside", tolerance=1e-6):
    """
    Picks edges by drawing a probe box around/through them, instead of
    reading indices off label_edges()'s numbers -- build, position, and
    size any shape (almost always just box([dx, dy, dz]), translate()'d/
    rotate()'d into place) around the region you want, pass it in as
    `box`, and get back exactly the edges that fall inside or cross it.
    Only `box`'s own bounding_box() is used -- its actual geometry never
    matters, so a plain axis-aligned box() is normally enough even to
    isolate edges on a tilted/curved shape.

    `mode`:
      "inside"   -- (default) only edges FULLY CONTAINED in the probe
                    box's extent -- draw a box that ENCLOSES just the
                    edges you want and nothing else.
      "crossing" -- edges whose own bounding box overlaps the probe box
                    AT ALL, including ones only partly inside it -- draw
                    a (usually thin) box that CUTS THROUGH the edges you
                    want, even if it doesn't fully contain them.

        a = cube([20, 20, 20])
        show(a, alpha=0.2)
        probe = translate([-10, -10, 8], box([20, 20, 4]))
        show(probe, alpha=0.15, color='red')  # eyeball/adjust probe first
        picked = edges_in_box(a.edges(), probe)
        show(sol := fillet(a, picked, 1))

    Pass the SAME list you'd index into for fillet()/chamfer() --
    almost always shape.edges() itself, unfiltered -- and the returned
    list is already the plain list of Edge objects fillet()/chamfer()
    expect, no further indexing needed. Combine with the other
    filter_by()/sort_by()/label_edges() techniques as needed -- e.g.
    `edges_in_box(a.edges(), probe, mode="crossing")` still returns a
    real ShapeList-friendly list, so
    `[e for e in edges_in_box(...) if e.length > 5]` works fine on top.
    """
    _require_build123d()
    try:
        edge_list = list(edges)
    except TypeError:
        edge_list = [edges]
    ref = box.bounding_box() if hasattr(box, "bounding_box") else box
    if mode == "inside":
        def _keep(e):
            eb = e.bounding_box()
            return (
                eb.min.X >= ref.min.X - tolerance and eb.max.X <= ref.max.X + tolerance
                and eb.min.Y >= ref.min.Y - tolerance and eb.max.Y <= ref.max.Y + tolerance
                and eb.min.Z >= ref.min.Z - tolerance and eb.max.Z <= ref.max.Z + tolerance
            )
    elif mode == "crossing":
        def _keep(e):
            return ref.overlaps(e.bounding_box(), tolerance=tolerance)
    else:
        raise ValueError(
            f"edges_in_box(): mode must be 'inside' or 'crossing', got {mode!r}")
    return [e for e in edge_list if _keep(e)]


def faces_in_box(faces, box, mode="inside", tolerance=1e-6):
    """
    faces_in_box()'s own counterpart for face selectors -- the exact
    same probe-box picking workflow as edges_in_box(), but for
    shape.faces() instead of shape.edges(). Useful for things like
    offset()'s `openings=` argument or picking which faces to fillet()/
    chamfer() by drawing a box around/through them instead of reading
    label_faces()'s numbers.

    `box`: any B-rep shape (usually box([dx, dy, dz]), translate()'d/
    rotate()'d into place) -- only its own bounding_box() is used, its
    actual geometry never matters.

    `mode`:
      "inside"   -- (default) only faces FULLY CONTAINED in the probe
                    box's extent -- draw a box that ENCLOSES just the
                    faces you want and nothing else.
      "crossing" -- faces whose own bounding box overlaps the probe box
                    AT ALL, including ones only partly inside it -- draw
                    a (usually thin) box that CUTS THROUGH the faces you
                    want, even if it doesn't fully contain them.

        a = cube([20, 20, 20])
        show(a, alpha=0.2)
        probe = translate([-10, -10, 18], box([20, 20, 4]))
        show(probe, 'red', alpha=0.15)  # eyeball/adjust probe first
        top_face = faces_in_box(a.faces(), probe)
        hollow = offset(a, -2, openings=top_face)

    Pass the SAME list you'd index into for offset()/fillet()/chamfer()
    -- almost always shape.faces() itself, unfiltered -- and the
    returned list is already the plain list of Face objects those
    functions expect, no further indexing needed. Combine with the
    other filter_by()/sort_by()/label_faces() techniques as needed --
    e.g. `[f for f in faces_in_box(...) if f.area > 50]` works fine on
    top of this.
    """
    _require_build123d()
    try:
        face_list = list(faces)
    except TypeError:
        face_list = [faces]
    ref = box.bounding_box() if hasattr(box, "bounding_box") else box
    if mode == "inside":
        def _keep(f):
            fb = f.bounding_box()
            return (
                fb.min.X >= ref.min.X - tolerance and fb.max.X <= ref.max.X + tolerance
                and fb.min.Y >= ref.min.Y - tolerance and fb.max.Y <= ref.max.Y + tolerance
                and fb.min.Z >= ref.min.Z - tolerance and fb.max.Z <= ref.max.Z + tolerance
            )
    elif mode == "crossing":
        def _keep(f):
            return ref.overlaps(f.bounding_box(), tolerance=tolerance)
    else:
        raise ValueError(
            f"faces_in_box(): mode must be 'inside' or 'crossing', got {mode!r}")
    return [f for f in face_list if _keep(f)]


def _edge_endpoint_key(edge, ndigits=5):
    """A direction-independent identity for a real Edge, from its own
    two endpoints -- rounds each to `ndigits` and sorts the pair, so
    the SAME topological edge shared by two adjacent faces (or handed
    in separately as a "wall" boundary edge) lands under one shared key
    regardless of which Edge wrapper it came from or which direction
    it runs in. Shared with faces_within_boundary() below."""
    p0, p1 = edge.position_at(0.0), edge.position_at(1.0)
    a = (round(p0.X, ndigits), round(p0.Y, ndigits), round(p0.Z, ndigits))
    b = (round(p1.X, ndigits), round(p1.Y, ndigits), round(p1.Z, ndigits))
    return (a, b) if a <= b else (b, a)


def faces_within_boundary(faces, boundary_edges, seed_point=None):
    """
    Selects every face reachable from a starting face WITHOUT crossing
    any of `boundary_edges` -- "select the region enclosed by this edge
    loop" as a real function, the face counterpart to seam_edges()'s
    own "find the boundary" direction: once you already have a
    boundary (seam_edges(), a fillet()'s own edge list, edges picked by
    hand through this app's Pick Edges panel, or any other list of real
    Edges), this fills in everything INSIDE it.

        seam = seam_edges(sol, s1, b_2)
        patch = faces_within_boundary(sol.faces(), seam, seed_point=[0, 0, 40])
        show(*patch, 'red')

    `boundary_edges` doesn't need to be one single closed loop -- works
    just as well with several separate closed loops at once (e.g. an
    inner + outer ring bounding an annular band -- pass both loops'
    edges together in one list), or an OPEN chain that doesn't fully
    close on its own. Every face's own boundary edge is either (a) one
    of `boundary_edges` (never crossed), (b) shared with exactly one
    other face and NOT in `boundary_edges` (crossed freely -- this is
    how the flood fill spreads), or (c) owned by only that one face at
    all (a genuinely free/open edge -- e.g. a Shell's own outer rim --
    with no "other side" to flood into regardless). An open boundary
    chain still works as long as it, together with the shape's own
    real free edges, fully encloses the region you want -- the flood
    fill simply has nowhere else to go once it reaches either kind.

    `seed_point`: [x, y, z] on any ONE face inside the region you want
    -- resolves which side of the boundary is "inside" without
    guessing (the boundary generally splits `faces` into two pieces,
    same as a closed curve splits a plane). If omitted, returns
    whichever resulting piece has FEWER faces -- a reasonable default
    (the enclosed patch is usually the minority of the shape), but
    pass seed_point explicitly whenever that guess might be wrong,
    e.g. picking a large region bounded by a small hole.

    Returns a list of Faces (a subset of `faces`).
    """
    _require_build123d()
    all_faces = list(faces.faces()) if hasattr(faces, "faces") and not isinstance(faces, (list, tuple)) else list(faces)
    if not all_faces:
        raise ValueError("faces_within_boundary(): no faces given")

    wall_keys = set()
    for e in boundary_edges:
        try:
            wall_keys.add(_edge_endpoint_key(e))
        except Exception:
            continue

    edge_owners = {}
    face_edge_cache = []
    for i, f in enumerate(all_faces):
        try:
            edges = list(f.edges())
        except Exception:
            edges = []
        keyed = []
        for e in edges:
            try:
                key = _edge_endpoint_key(e)
            except Exception:
                continue
            keyed.append(key)
            edge_owners.setdefault(key, []).append(i)
        face_edge_cache.append(keyed)

    n = len(all_faces)
    visited = [False] * n
    components = []
    for start in range(n):
        if visited[start]:
            continue
        comp = []
        stack = [start]
        visited[start] = True
        while stack:
            cur = stack.pop()
            comp.append(cur)
            for key in face_edge_cache[cur]:
                if key in wall_keys:
                    continue
                owners = edge_owners.get(key, [])
                if len(owners) != 2:
                    continue
                other = owners[0] if owners[1] == cur else owners[1]
                if not visited[other]:
                    visited[other] = True
                    stack.append(other)
        components.append(comp)

    if seed_point is not None:
        px = float(seed_point[0])
        py = float(seed_point[1])
        pz = float(seed_point[2]) if len(seed_point) > 2 else 0.0
        best_i, best_d = None, float("inf")
        for i, f in enumerate(all_faces):
            d = f.distance_to((px, py, pz))
            if d < best_d:
                best_d, best_i = d, i
        target = next(c for c in components if best_i in c)
    else:
        target = min(components, key=len)

    return [all_faces[i] for i in target]


def face_islands(faces):
    """
    Splits `faces` into its separate topologically-CONNECTED groups --
    "how many disjoint pieces is this face list actually made of"
    as a real function. Two faces are in the same group if you can walk
    from one to the other over a chain of shared edges (exactly the
    same shared-edge adjacency faces_within_boundary() floods over, but
    with no boundary walls here -- this just reports the natural
    islands the faces already fall into on their own).

    Directly answers "why won't shell_from_faces()/solid_from_faces()
    stitch these together": both require ONE single connected Shell,
    and a normal-direction/region selection like faces_facing() has NO
    guarantee of returning one connected patch -- on a curved or
    organic shape, faces sharing a similar normal direction can easily
    fall into several separate islands (e.g. a shape's main dome PLUS
    a few disconnected slivers elsewhere that happen to face the same
    way). If shell_from_faces() is failing, run this first:

        groups = face_islands(f1)
        [len(g) for g in groups]        # sizes of each disconnected piece
        show(*groups[0], 'red')          # just the largest connected piece

        f1_clean = groups[0]             # keep only the largest island
        shell = shell_from_faces(f1_clean)

    Returns a list of lists of Faces, largest group first -- a single
    connected input comes back as one group containing everything.
    """
    _require_build123d()
    all_faces = list(faces.faces()) if hasattr(faces, "faces") and not isinstance(faces, (list, tuple)) else list(faces)
    if not all_faces:
        raise ValueError("face_islands(): no faces given")

    edge_owners = {}
    face_edge_cache = []
    for i, f in enumerate(all_faces):
        try:
            edges = list(f.edges())
        except Exception:
            edges = []
        keyed = []
        for e in edges:
            try:
                key = _edge_endpoint_key(e)
            except Exception:
                continue
            keyed.append(key)
            edge_owners.setdefault(key, []).append(i)
        face_edge_cache.append(keyed)

    n = len(all_faces)
    visited = [False] * n
    components = []
    for start in range(n):
        if visited[start]:
            continue
        comp = []
        stack = [start]
        visited[start] = True
        while stack:
            cur = stack.pop()
            comp.append(cur)
            for key in face_edge_cache[cur]:
                owners = edge_owners.get(key, [])
                if len(owners) != 2:
                    continue
                other = owners[0] if owners[1] == cur else owners[1]
                if not visited[other]:
                    visited[other] = True
                    stack.append(other)
        components.append(comp)

    components.sort(key=len, reverse=True)
    return [[all_faces[i] for i in comp] for comp in components]


def faces_facing(faces, direction, angle_tol=90.0):
    """
    Selects every face whose own outward normal points TOWARD
    `direction` -- "select all faces visible from this direction" as a
    real function:

        top_faces = faces_facing(sol.faces(), [0, 0, 1])
        show(*top_faces, 'red')

    Tests each face's normal_at() (sampled at its own center()) against
    `direction`: a face qualifies if the angle between its own normal
    and `direction` is <= `angle_tol` degrees. The default (90) keeps
    anything that faces at least partly TOWARD the direction rather
    than strictly away from it -- narrow it (e.g. 30-45) for only faces
    pointing MORE directly toward it, e.g. a genuinely flat "top" versus
    a steeply-angled side that technically still has a sliver of upward
    component.

    This is a NORMAL-DIRECTION test, not a true occlusion-aware
    visibility test -- it doesn't ray-cast to check whether some OTHER
    part of the same shape sits in front and actually blocks a given
    face from that viewpoint (a real concave pocket can have a face
    that technically points toward `direction` but is still hidden
    behind a wall). Fine for convex-ish or mildly concave shapes (this
    project's own mouse-body dome included); for a shape with deep
    pockets/cavities where that distinction actually matters, filter
    the result further by hand. Real ray-cast visibility is genuinely
    expensive PER-FACE work -- same performance class as seam_edges()'s
    own .distance_to() cost this session -- deliberately not attempted
    here.

    `direction` doesn't need to be a unit vector -- only its own
    direction matters, not its length.

    Returns a list of Faces (a subset of `faces`).
    """
    _require_build123d()
    dx = float(direction[0])
    dy = float(direction[1])
    dz = float(direction[2]) if len(direction) > 2 else 0.0
    dn = math.sqrt(dx * dx + dy * dy + dz * dz)
    if dn < 1e-12:
        raise ValueError("faces_facing(): direction must be non-zero")
    dx, dy, dz = dx / dn, dy / dn, dz / dn
    out = []
    for f in faces:
        try:
            c = f.center()
            n = f.normal_at((float(c.X), float(c.Y), float(c.Z)))
        except Exception:
            continue
        dot = n.X * dx + n.Y * dy + n.Z * dz
        dot = max(-1.0, min(1.0, dot))
        angle = math.degrees(math.acos(dot))
        if angle <= angle_tol:
            out.append(f)
    return out


def fill_face_holes(faces, all_faces, max_size=None):
    """
    Adds back any small "hole" in a face selection -- a connected group
    of faces that got EXCLUDED from `faces` but is completely enclosed
    by faces that ARE in `faces` (never touching `all_faces`' own real
    outer/free edge), so it's really just an island punched straight
    through an otherwise simply-connected patch.

    Directly fixes the failure mode close_faces_to_plane() (and
    anything else expecting one clean boundary loop) hits on a face-
    NORMAL selection like faces_facing()'s own output, confirmed
    directly in this app: on a fine, many-facet mesh, individual flat
    facets can flip in and out of a normal-angle cutoff right at the
    threshold -- especially along a carved groove/fillet, where the
    true surface's normal keeps crossing back and forth near the cutoff
    as it winds around -- punching dozens of tiny single-facet holes
    through an otherwise-connected patch. face_islands() still reports
    the patch as ONE connected piece (every face IS reachable from
    every other), but each of those tiny holes is its OWN separate
    boundary loop, and wire_from_edges() can't (and shouldn't) silently
    guess how to chain several genuinely separate closed loops into
    one.

        f1 = faces_facing(sol.faces(), [0, 0, 1])   # riddled with holes
        f1_filled = fill_face_holes(f1, sol.faces())
        f1_clean = face_islands(f1_filled)[0]
        shell = shell_from_faces(f1_clean)
        slider = close_faces_to_plane(shell, [0, 0, 80], [0, 0, 1])

    This does NOT loosen `faces_facing()`'s own `angle_tol` -- it keeps
    the selection criterion exactly as given and only patches over the
    facet-level noise that criterion leaves behind, so this is the
    right fix when the selection angle itself is correct/required and
    just needs cleaning up, not widening.

    `all_faces`: the full pool `faces` was drawn from (e.g. `sol.faces()`
    -- same shape `faces`' own items came from). Needed to tell a
    genuinely enclosed hole apart from an excluded region that's simply
    part of the real outside (e.g. faces_facing()'s own excluded
    "pointing away" hemisphere) -- an island only gets filled if NONE of
    its own edges are free (single-owner) across the WHOLE `all_faces`
    pool, meaning it never actually reaches the outside at all.

    `max_size`, if given, only fills a hole with AT MOST that many
    faces -- leaves a bigger enclosed region alone (more likely a real,
    intentional window/cavity through the patch than facet noise).
    Default (None) fills every enclosed hole regardless of size.

    `faces`/`all_faces` each accept either a plain list of Faces or a
    single Shape (Shell/Solid/Compound) with its own `.faces()`.

    Returns a new list of Faces: everything in `faces`, plus every
    enclosed hole's own faces added back in.
    """
    _require_build123d()
    all_list = list(all_faces.faces()) if hasattr(all_faces, "faces") and not isinstance(all_faces, (list, tuple)) else list(all_faces)
    sel_list = list(faces.faces()) if hasattr(faces, "faces") and not isinstance(faces, (list, tuple)) else list(faces)
    if not all_list:
        raise ValueError("fill_face_holes(): no faces given for `all_faces`")
    if not sel_list:
        raise ValueError("fill_face_holes(): no faces given for `faces`")

    # Real OCCT topology, not coordinate matching -- same reasoning (and
    # the same earlier failure mode, confirmed directly in this app) as
    # close_faces_to_plane()'s own free-edge detection: on a dense,
    # many-face selection this is the difference between correct results
    # and a coordinate-rounding key occasionally matching (or missing)
    # the wrong edge, which for THIS function doesn't just fragment a
    # boundary -- it can misjudge which islands are actually enclosed,
    # making the result WORSE, not better (confirmed directly in this
    # app: 49 boundary fragments before fill_face_holes(), 58 after, on
    # the coordinate-key version).
    global_free_keys = set()
    face_edge_keys = []
    try:
        from OCP.TopAbs import TopAbs_EDGE, TopAbs_FACE
        from OCP.TopExp import TopExp
        from OCP.TopTools import TopTools_IndexedDataMapOfShapeListOfShape

        compound = bd.Compound(all_list)
        edge_face_map = TopTools_IndexedDataMapOfShapeListOfShape()
        TopExp.MapShapesAndAncestors_s(compound.wrapped, TopAbs_EDGE, TopAbs_FACE, edge_face_map)

        for f in all_list:
            try:
                edges = list(f.edges())
            except Exception:
                edges = []
            keys = []
            for e in edges:
                idx = edge_face_map.FindIndex(e.wrapped)
                if idx != 0:
                    keys.append(idx)
            face_edge_keys.append(keys)

        for i in range(1, edge_face_map.Extent() + 1):
            if edge_face_map.FindFromIndex(i).Extent() == 1:
                global_free_keys.add(i)
    except Exception as _topo_err:
        # DIAGNOSTIC (temporary): surface the real error instead of
        # silently falling back to coordinate-key adjacency -- the
        # fallback was masking whatever's actually wrong with the OCP
        # route above (confirmed directly in this app: results were
        # byte-for-byte identical with and without this route, meaning
        # it silently wasn't running at all).
        raise RuntimeError(
            f"fill_face_holes(): the OCP topology route itself failed "
            f"({_topo_err!r}) -- this is temporarily NOT falling back "
            f"silently so the real cause is visible."
        ) from _topo_err

    included_ids = set(id(f) for f in sel_list)
    excluded_idx = [i for i, f in enumerate(all_list) if id(f) not in included_ids]
    if not excluded_idx:
        return list(sel_list)

    excl_owner = {}
    for i in excluded_idx:
        for k in face_edge_keys[i]:
            excl_owner.setdefault(k, []).append(i)

    visited = set()
    fill_idx = set()
    for i in excluded_idx:
        if i in visited:
            continue
        comp = []
        stack = [i]
        visited.add(i)
        touches_outer = False
        while stack:
            cur = stack.pop()
            comp.append(cur)
            for k in face_edge_keys[cur]:
                if k in global_free_keys:
                    touches_outer = True
                for other in excl_owner.get(k, []):
                    if other not in visited:
                        visited.add(other)
                        stack.append(other)
        if not touches_outer and (max_size is None or len(comp) <= max_size):
            fill_idx.update(comp)

    return list(sel_list) + [all_list[i] for i in fill_idx]


def close_faces_to_plane(faces, plane_point, direction=(0, 0, 1), tol=None):
    """
    Closes an open patch of Faces into a real solid by extending its
    own free boundary along `direction` until it hits a flat plane
    through `plane_point`, and capping it there -- "project this
    surface up onto a plane to make a solid" as a real function, the
    standard way to turn a picked cavity/core surface (e.g.
    faces_facing()'s own output) into a real mold slider/core block:

        f1 = faces_facing(sol.faces(), [0, 0, 1])
        f1_clean = face_islands(f1)[0]        # drop any disconnected slivers
        slider = close_faces_to_plane(f1_clean, [0, 0, 60])  # cap at z=60
        show(slider)

    `direction` is NOT limited to straight up -- a real slider can pull
    in any direction, so the CAP PLANE ITSELF is always built
    perpendicular to `direction` (its normal IS `direction`), passing
    through `plane_point`, whatever that direction happens to be:

        # a slider pulling sideways instead of vertically
        slider = close_faces_to_plane(f1_clean, [80, 0, 0], direction=[1, 0, 0])

    `plane_point` is any single point that lies on the flat plane you
    want the cap to sit on -- it does NOT need to be near `faces`
    itself; the reference plane built internally is automatically
    sized and re-centered on `faces`' own boundary before use, only
    `plane_point`'s position ALONG `direction` (which plane, out of the
    infinite family of parallel planes through that normal) actually
    matters.

    How it works: finds `faces`' own free boundary edges (every edge
    owned by exactly ONE of `faces` -- same shared-edge adjacency
    face_islands()/faces_within_boundary() use, so any interior seam
    between two of `faces` is correctly skipped and only the true outer
    rim is used), chains them into one closed Wire (wire_from_edges()
    -- pass `tol` through to it if that boundary doesn't chain cleanly
    on the first try), projects that boundary wire onto the flat target
    plane along `direction` (project_curve_on_face(), exact B-rep
    projection, no sampling), builds the "skirt" wall as a ruled Face
    between the original and projected boundary
    (Face.make_surface_from_curves(), the same engine surface_line_vector()
    uses), and caps the far end with a flat Face bounded by the
    projected (and therefore genuinely planar) wire -- then sews
    `faces` + skirt + cap into one solid with solid_from_faces().

    Raises whatever wire_from_edges()/project_curve_on_face()/
    solid_from_faces() themselves raise -- most commonly from
    wire_from_edges() if `faces`' free edges don't chain into exactly
    one closed loop (a real gap in the selection, or `faces` covering
    more than one disconnected patch -- run face_islands() first and
    feed it just one group, as in the example above).
    """
    _require_build123d()
    all_faces = list(faces.faces()) if hasattr(faces, "faces") and not isinstance(faces, (list, tuple)) else list(faces)
    if not all_faces:
        raise ValueError("close_faces_to_plane(): no faces given")

    # Real OCCT topology, not coordinate matching: TopExp::MapShapesAndAncestors
    # against a Compound of `all_faces` finds each edge's TRUE owning-face
    # count via shared TopoDS identity (the same identity a prior
    # shell_from_faces() sewing pass -- or simply pulling these faces off
    # one already-connected solid, e.g. sol.faces() -- already established),
    # not by re-deriving adjacency from rounded endpoint coordinates.
    # That distinction matters a lot here: this app's own earlier
    # coordinate-key approach (still used as a fallback below) can both
    # MISS a true match (two genuinely-shared endpoints that happen to
    # round differently) and, just as bad, INVENT a false one (two
    # unrelated edges that happen to round to the same key on a dense,
    # regular mesh) -- either mistake creates a gap in the real boundary
    # chain and fragments it into many separate wires, which is exactly
    # the failure mode this replaced (confirmed directly in this app on a
    # 2181-face faces_facing() selection: the coordinate-key version kept
    # fragmenting the same clean, already-sewn Shell no matter how loose
    # `tol` was pushed, because the actual bug wasn't tolerance at all).
    free_edges = None
    try:
        from OCP.TopAbs import TopAbs_EDGE, TopAbs_FACE
        from OCP.TopExp import TopExp
        from OCP.TopTools import TopTools_IndexedDataMapOfShapeListOfShape
        from OCP.TopoDS import TopoDS as _TopoDS

        compound = bd.Compound(all_faces)
        edge_face_map = TopTools_IndexedDataMapOfShapeListOfShape()
        TopExp.MapShapesAndAncestors_s(compound.wrapped, TopAbs_EDGE, TopAbs_FACE, edge_face_map)
        free_edges = []
        for i in range(1, edge_face_map.Extent() + 1):
            owners = edge_face_map.FindFromIndex(i)
            if owners.Extent() == 1:
                free_edges.append(bd.Edge(_TopoDS.Edge(edge_face_map.FindKey(i))))
    except Exception as _topo_err:
        # DIAGNOSTIC (temporary): surface the real error instead of
        # silently falling back to coordinate-key adjacency -- see
        # fill_face_holes()'s own identical note for why.
        raise RuntimeError(
            f"close_faces_to_plane(): the OCP topology route itself "
            f"failed ({_topo_err!r}) -- this is temporarily NOT falling "
            f"back silently so the real cause is visible."
        ) from _topo_err

    if not free_edges:
        raise ValueError(
            "close_faces_to_plane(): no free boundary edges found on "
            "`faces` -- this patch is already a closed shell, with no "
            "open rim left to extend to a plane")

    boundary = wire_from_edges(free_edges, tol=tol) if len(free_edges) > 1 else bd.Wire([free_edges[0]])

    dx, dy, dz = [float(c) for c in direction]
    dn = math.sqrt(dx * dx + dy * dy + dz * dz)
    if dn < 1e-12:
        raise ValueError("close_faces_to_plane(): direction must be non-zero")
    d = (dx / dn, dy / dn, dz / dn)
    pp = tuple(float(c) for c in plane_point)

    # Size/center the reference plane on `faces`' own boundary (NOT on
    # `plane_point`, which only needs to lie somewhere on the infinite
    # target plane) -- project the boundary's own centroid onto that
    # plane along `direction` for the center, and use the boundary's
    # own farthest-point spread for the size, so this works the same
    # regardless of how far away or how `direction` is oriented.
    pts = sample_curve(boundary, 200)
    n = len(pts)
    centroid = tuple(sum(p[i] for p in pts) / n for i in range(3))
    t = sum((pp[i] - centroid[i]) * d[i] for i in range(3))
    center = tuple(centroid[i] + t * d[i] for i in range(3))
    radius = max(
        math.sqrt(sum((p[i] - centroid[i]) ** 2 for i in range(3))) for p in pts
    )
    span = max(radius * 4.0, 1.0)
    target = plane(d, size=(span, span), intercept=center)

    projected = project_curve_on_face(boundary, target, d, closest=True)
    if isinstance(projected, (list, tuple)):
        projected = projected[0]

    skirt = bd.Face.make_surface_from_curves(boundary, projected)
    cap = bd.Face(projected)
    return solid_from_faces(*all_faces, skirt, cap)


def _rasterize_uv_triangles(pts_uv, tris, res, pad=2):
    """
    Rasterizes 2D triangles (`pts_uv`: (N,2) float array, `tris`: (M,3)
    int array of vertex indices into `pts_uv`) onto a boolean occupancy
    grid of cell size `res` -- every pixel whose CENTER falls inside a
    triangle is marked True. Pure numpy, no OCCT/build123d call
    involved at all: used to compute a real 2D areal union FAST,
    without paying OCCT's own real per-call boolean-op overhead
    thousands of times over -- see slider_from_faces()'s default path
    for why that matters (the same per-call-overhead cost shape that
    made seam_edges()'s original per-edge distance_to() loop take 638+
    seconds earlier this session).

    Verified directly (square / concave L-shape / two-disjoint-blobs /
    donut-with-a-hole test cases, all producing correct areas and
    simple, non-self-intersecting traced outlines; plus a ~2000-
    triangle organic-shape-with-a-groove timing test: rasterized in
    ~0.1s on a 374x374 grid) before use in slider_from_faces() below.

    Returns `(occ, u0, v0)`: `occ` is the (nx, ny) bool grid, `(u0, v0)`
    the real UV coordinate of grid CORNER (0, 0) -- grid corner (i, j)
    sits at real UV point `(u0 + i*res, v0 + j*res)`.
    """
    P = np.asarray(pts_uv, dtype=float)
    umin, vmin = P[:, 0].min(), P[:, 1].min()
    umax, vmax = P[:, 0].max(), P[:, 1].max()
    u0 = umin - pad * res
    v0 = vmin - pad * res
    nx = int(math.ceil((umax - u0) / res)) + pad
    ny = int(math.ceil((vmax - v0) / res)) + pad
    occ = np.zeros((nx, ny), dtype=bool)
    T = np.asarray(tris, dtype=int)
    for tri in T:
        a, b, c = P[tri[0]], P[tri[1]], P[tri[2]]
        tumin = min(a[0], b[0], c[0]); tumax = max(a[0], b[0], c[0])
        tvmin = min(a[1], b[1], c[1]); tvmax = max(a[1], b[1], c[1])
        i0 = max(int((tumin - u0) / res) - 1, 0)
        i1 = min(int((tumax - u0) / res) + 2, nx)
        j0 = max(int((tvmin - v0) / res) - 1, 0)
        j1 = min(int((tvmax - v0) / res) + 2, ny)
        if i1 <= i0 or j1 <= j0:
            continue
        us = u0 + (np.arange(i0, i1) + 0.5) * res
        vs = v0 + (np.arange(j0, j1) + 0.5) * res
        UU, VV = np.meshgrid(us, vs, indexing="ij")
        d00 = b - a
        d01 = c - a
        denom = d00[0] * d01[1] - d01[0] * d00[1]
        if abs(denom) < 1e-15:
            continue
        px = UU - a[0]
        py = VV - a[1]
        w1 = (px * d01[1] - py * d01[0]) / denom
        w2 = (d00[0] * py - d00[1] * px) / denom
        w0 = 1 - w1 - w2
        mask = (w0 >= -1e-9) & (w1 >= -1e-9) & (w2 >= -1e-9)
        occ[i0:i1, j0:j1] |= mask
    return occ, u0, v0


def _trace_grid_boundary_loops(occ):
    """
    Traces every boundary loop of boolean grid `occ` (True = inside) as
    a list of closed loops, each a list of (i, j) GRID CORNER integer
    coordinates -- exact integer chaining, no floating-point matching-
    tolerance issues at all (unlike wire_from_edges()'s real-edge
    chaining, which is exactly the kind of tolerance problem that broke
    close_faces_to_plane() earlier this session). One loop comes back
    per outer silhouette AND one per hole (a donut traces to two loops:
    one around its outer rim, one around the hole) -- verified against
    all four test cases described in _rasterize_uv_triangles()'s own
    docstring.
    """
    nx, ny = occ.shape
    padded = np.zeros((nx + 2, ny + 2), dtype=bool)
    padded[1:-1, 1:-1] = occ

    def cell(i, j):
        return padded[i + 1, j + 1]

    segs = {}

    def add_seg(p, q):
        segs.setdefault(p, []).append(q)
        segs.setdefault(q, []).append(p)

    for i in range(nx + 1):
        for j in range(ny):
            if cell(i - 1, j) != cell(i, j):
                add_seg((i, j), (i, j + 1))
    for i in range(nx):
        for j in range(ny + 1):
            if cell(i, j - 1) != cell(i, j):
                add_seg((i, j), (i + 1, j))

    loops = []
    visited = set()
    for start in list(segs.keys()):
        for first_next in list(segs[start]):
            e0 = (start, first_next) if start < first_next else (first_next, start)
            if e0 in visited:
                continue
            loop = [start]
            prev, cur = start, first_next
            visited.add(e0)
            guard = 0
            max_steps = 4 * (nx + 1) * (ny + 1) + 1000
            while cur != start:
                loop.append(cur)
                nxt = None
                for p in segs[cur]:
                    e = (cur, p) if cur < p else (p, cur)
                    if e not in visited:
                        nxt = p
                        break
                if nxt is None:
                    break
                e2 = (cur, nxt) if cur < nxt else (nxt, cur)
                visited.add(e2)
                prev, cur = cur, nxt
                guard += 1
                if guard > max_steps:
                    raise RuntimeError(
                        "_trace_grid_boundary_loops(): a loop failed to "
                        "close -- this is a bug, please report it")
            loops.append(loop)
    return loops


def _loop_area_2d(loop):
    """Signed shoelace area of a closed 2D point loop (positive = CCW)."""
    a = 0.0
    n = len(loop)
    for k in range(n):
        x1, y1 = loop[k]
        x2, y2 = loop[(k + 1) % n]
        a += x1 * y2 - x2 * y1
    return a / 2.0


def _simplify_collinear_loop(loop, tol=1e-9):
    """
    Drops points from a closed loop that sit exactly on the straight
    line between their neighbors -- collapses a grid-boundary trace's
    long straight runs (one point per grid cell along every straight
    edge) down to just its real corners, without changing its shape at
    all. Keeps `loop` unchanged if that would leave fewer than 3 points.
    """
    n = len(loop)
    if n < 3:
        return list(loop)
    out = []
    for k in range(n):
        ax, ay = loop[(k - 1) % n]
        bx, by = loop[k]
        cx, cy = loop[(k + 1) % n]
        cross = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)
        if abs(cross) > tol:
            out.append(loop[k])
    return out if len(out) >= 3 else list(loop)


def _dp_simplify_open(pts, tol):
    """
    Iterative (stack-based, not recursive -- safe on a large point list,
    e.g. a fine-grid staircase trace with thousands of points, without
    risking Python's recursion-depth limit) Douglas-Peucker simplification
    of an OPEN polyline `pts`, dropping any point within `tol` of the
    straight line its neighbors would already imply.
    """
    n = len(pts)
    if n < 3:
        return list(pts)

    def perp_dist(p, a, b):
        ax, ay = a
        bx, by = b
        px, py = p
        dx, dy = bx - ax, by - ay
        L2 = dx * dx + dy * dy
        if L2 < 1e-15:
            return math.hypot(px - ax, py - ay)
        t = ((px - ax) * dx + (py - ay) * dy) / L2
        t = max(0.0, min(1.0, t))
        cx, cy = ax + t * dx, ay + t * dy
        return math.hypot(px - cx, py - cy)

    keep = [False] * n
    keep[0] = True
    keep[-1] = True
    stack = [(0, n - 1)]
    while stack:
        i0, i1 = stack.pop()
        if i1 - i0 < 2:
            continue
        a, b = pts[i0], pts[i1]
        dmax, idx = -1.0, -1
        for i in range(i0 + 1, i1):
            d = perp_dist(pts[i], a, b)
            if d > dmax:
                dmax, idx = d, i
        if dmax > tol:
            keep[idx] = True
            stack.append((i0, idx))
            stack.append((idx, i1))
    return [pts[i] for i in range(n) if keep[i]]


def _dp_simplify_closed_loop(loop, tol):
    """
    Douglas-Peucker simplification of a CLOSED loop -- this is what
    actually removes a rasterization staircase's jaggedness (see
    slider_from_faces()'s default path): a diagonal/curved boundary
    rasterized onto a grid comes back as a real right-angle staircase
    (_simplify_collinear_loop() above only removes perfectly straight
    grid-aligned runs, NOT a zigzagging staircase -- consecutive
    staircase points are never collinear), so left unsimplified that
    staircase becomes real cut geometry in the final tool. Splits the
    loop into two open chains at its two most-distant points, simplifies
    each with _dp_simplify_open(), and rejoins them.

    Verified directly: a 20-unit square rotated 27 degrees (the classic
    worst case for grid rasterization -- no edge grid-aligned at all),
    rasterized at a 0.2 grid resolution, traces to 536 raw staircase
    points; simplified here with tol=1.5x the grid resolution, it comes
    back as the correct 4-point rotated square, 0.31% area error,
    confirmed still a simple (non-self-intersecting) polygon.
    """
    n = len(loop)
    if n < 4:
        return list(loop)

    def d2(p, q):
        return (p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2

    i1 = max(range(n), key=lambda k: d2(loop[0], loop[k]))
    i2 = max(range(n), key=lambda k: d2(loop[i1], loop[k]))
    a, b = sorted([i1, i2])
    chain1 = loop[a:b + 1]
    chain2 = loop[b:] + loop[:a + 1]
    s1 = _dp_simplify_open(chain1, tol)
    s2 = _dp_simplify_open(chain2, tol)
    result = s1[:-1] + s2[:-1]
    return result if len(result) >= 3 else list(loop)


def slider_from_faces(sol, faces, direction=(0, 0, 1), inset=0.1, length=None, hull=False, exact=False, grid_res=None):
    """
    Builds a mold slider/core INSERT with the NEGATIVE (opposite,
    complementary) contour of `sol`'s own surface -- a genuine SOLID
    PRISM built from the flattened, slightly-shrunk FOOTPRINT of `faces`,
    extruded `length` units along `direction`, with `sol`'s own material
    then carved OUT of it (difference(tool, sol)): the prism's own
    material everywhere EXCEPT where `sol` occupies that same space.
    That's deliberately NOT the same as a slice of `sol`'s own material
    (intersection(sol, tool), which just looks like a chunk of `sol`
    itself, confirmed directly in this app to be the wrong shape for an
    actual tooling insert) -- a real mold slider/core is a separate
    piece of tool steel with a cavity/relief cut into it matching the
    INVERSE of the part surface it forms, not a copy of the part's own
    material.

    Instead of stitching `faces`' exact BOUNDARY into a closed solid by
    hand (close_faces_to_plane()'s approach -- needs every free edge to
    chain into exactly one loop, and fails outright on a boundary
    riddled with small holes from facet-level noise, e.g. faces_facing()
    right at its own angle cutoff on a fine mesh), this computes the
    real AREA covered by `faces` once flattened: by default, it
    tessellates `faces` (to_mesh(), one fast call), flattens every mesh
    vertex into the footprint plane's own (u, v) coordinates, and
    RASTERIZES every triangle onto a fine boolean occupancy grid (pure
    numpy -- see _rasterize_uv_triangles()) -- the union of many
    triangles' areas, computed as a raster fill instead of thousands of
    individual OCCT boolean calls. The grid's own boundary is then
    traced back into a real 2D polygon (_trace_grid_boundary_loops()),
    and that traced outline -- a real right-angle STAIRCASE wherever the
    true boundary isn't grid-aligned -- is smoothed back down with
    Douglas-Peucker simplification (_dp_simplify_closed_loop()) so the
    stairstep pattern doesn't itself become visible cut geometry in the
    final tool. It's a real areal union either way, so genuine
    concavities come through correctly (an L-shaped cavity stays
    L-shaped, not ballooned out to its own
    convex hull), same as projecting/fusing real B-rep faces would, but
    without paying OCCT's fixed per-call overhead over however many
    thousand faces `faces` has (confirmed directly in this app: that
    per-call overhead is exactly what made the real-projection route --
    still available as `exact=True`, see below -- too slow on a
    ~2000-face selection). Only the SINGLE LARGEST traced loop is kept
    as the footprint -- any smaller loops (real small holes from facet-
    level noise, e.g. faces_facing() right at its own angle cutoff) are
    dropped rather than carried through as holes in the tool, since a
    slider/core is usually meant to be solid material anyway. If you
    need holes preserved exactly, or fully exact (non-rasterized)
    geometry, use `exact=True`.

    That footprint is shrunk inward by `inset` (so the cutting tool
    never touches `sol`'s own real surface exactly -- a small deliberate
    gap, not a precision boundary) and extruded into a real, CLOSED
    solid prism -- a plain intersection()/difference() against that
    solid tool is a much better-posed operation than split() against an
    open/unbounded surface: no ambiguity about which "side" is which,
    and `sol`'s own already-valid geometry (not the exact patch
    boundary) is what actually determines the result either way.

        f1 = faces_facing(sol.faces(), [0, 0, 1])
        slider, rest = slider_from_faces(sol, f1, [0, 0, 1])
        show(slider)

    `hull=True` uses the FASTEST, always-simple CONVEX HULL of `faces`'
    own vertices instead -- a deliberate trade of precision (a slider
    with a convex outline, not hugging any real concavity) for the
    cheapest possible geometry (no rasterization or mesh work at all).

    `exact=True` uses the ORIGINAL real-B-rep-projection route (every
    one of `faces`' own Faces projected via OCCT's own
    Face.project_to_shape(), fused with union_multi()) instead of the
    rasterized default -- exact analytic geometry and real hole
    preservation, at real per-face OCCT cost; reach for this only on a
    small/moderate face selection, or when you need the holes kept.

    `grid_res`: the rasterization grid's cell size (model units), only
    used by the default (non-hull, non-exact) path. Defaults (None) to
    an automatic size scaled to `faces`' own bounding-box diagonal,
    capped so the grid never exceeds ~1.5M cells regardless -- the
    traced outline is then simplified (Douglas-Peucker, tolerance tied
    to this same resolution) to remove the grid's own stairstep error,
    so the final outline comes out clean regardless of `inset`. Pass a
    smaller number for a more precise outline on a very large/flat
    selection, or a larger one to speed up an extremely fine/dense mesh
    further.

    `length`: how far the prism extends along `direction`, split evenly
    on both sides of the footprint's own flat plane (so the tool is
    guaranteed to fully clear through `faces`' own local relief on
    whichever side `sol`'s material actually sits, without needing to
    know that up front). Defaults (None) to 4x `faces`' own bounding-box
    extent SPECIFICALLY ALONG `direction` -- not `sol`'s whole bounding
    box, and not `faces`' full 3D diagonal either (a wide, shallow patch
    has a diagonal dominated by its own XY footprint, not its actual
    depth along the pull direction, and using that instead produced a
    needlessly long prism too) -- so the returned insert's length stays
    proportionate to how deep the local feature actually is, not how
    wide its footprint is or how big `sol` itself is. Give it an
    explicit number instead whenever you need a specific real backing
    thickness for the physical insert.

    `inset` (default 0.1): how far to shrink the flattened footprint
    inward before extruding it into the prism -- start small (0.05-0.5
    depending on your model's scale) and only increase if the result
    still catches exactly on `sol`'s own real boundary somewhere.

    `faces` accepts either a plain list of Faces or a single Shape
    (Shell/Solid/Compound) with its own `.faces()`.

    UNVERIFIED against a real build123d/OCP install (see this module's
    own header docstring) for the parts that call build123d/OCCT
    (to_mesh(), polygon(), offset(), linear_extrude(), intersection(),
    difference(), and the `hull=True`/`exact=True` paths). The
    rasterization/grid-tracing math itself (_rasterize_uv_triangles(),
    _trace_grid_boundary_loops(), _loop_area_2d(),
    _simplify_collinear_loop()) IS independently verified -- pure
    numpy/Python, tested directly against known geometric cases before
    being wired in here.

    Returns `(slider, rest)`.
    """
    _require_build123d()
    all_faces = list(faces.faces()) if hasattr(faces, "faces") and not isinstance(faces, (list, tuple)) else list(faces)
    if not all_faces:
        raise ValueError("slider_from_faces(): no faces given")

    dx, dy, dz = [float(c) for c in direction]
    dn = math.sqrt(dx * dx + dy * dy + dz * dz)
    if dn < 1e-12:
        raise ValueError("slider_from_faces(): direction must be non-zero")
    d = (dx / dn, dy / dn, dz / dn)

    faces_compound = bd.Compound(all_faces)
    bbox = faces_compound.bounding_box()
    center_v = bbox.center()
    centroid = (center_v.X, center_v.Y, center_v.Z)
    diag = math.sqrt(bbox.size.X ** 2 + bbox.size.Y ** 2 + bbox.size.Z ** 2)
    span = max(diag * 2.0, 1.0)
    # How far `faces`' own bounding box actually spans ALONG `direction`
    # specifically (the exact projection range of an axis-aligned box
    # onto a unit direction: 2x the sum of each axis's half-extent times
    # that axis's component of `d`) -- NOT `diag` (the box's full 3D
    # diagonal, dominated by whichever axis is BIGGEST, which for a
    # selection like faces_facing() picking a wide, shallow patch off a
    # curved surface is almost always its own XY FOOTPRINT, not its
    # depth along the pull direction). Using `diag` for the prism's
    # length confirmed directly in this app: a wide, shallow local patch
    # came back as a needlessly long cylinder/prism, most of it just
    # raw uncut material far beyond where `sol` actually reaches, because
    # the footprint span (large) got used as a stand-in for the relief
    # depth (small) they're unrelated quantities.
    relief = 2.0 * (
        bbox.size.X / 2.0 * abs(d[0])
        + bbox.size.Y / 2.0 * abs(d[1])
        + bbox.size.Z / 2.0 * abs(d[2])
    )

    pl = bd.Plane(origin=centroid, z_dir=d)
    xdir = (pl.x_dir.X, pl.x_dir.Y, pl.x_dir.Z)
    ydir = (pl.y_dir.X, pl.y_dir.Y, pl.y_dir.Z)

    def _to_uv(p3):
        rel = [p3[i] - centroid[i] for i in range(3)]
        u = sum(rel[i] * xdir[i] for i in range(3))
        v = sum(rel[i] * ydir[i] for i in range(3))
        return (u, v)

    if hull:
        # Point-cloud CONVEX HULL fallback -- always valid/simple, but
        # forces a convex outline (see this function's own docstring for
        # when to reach for this instead of the default).
        pts3 = []
        for f in all_faces:
            try:
                pts3.extend((v.X, v.Y, v.Z) for v in f.vertices())
            except Exception:
                continue
        if not pts3:
            raise ValueError("slider_from_faces(): couldn't collect any vertices from `faces`")

        hull_uv = convex_hull([_to_uv(p) for p in pts3])
        if len(hull_uv) < 3:
            raise ValueError(
                "slider_from_faces(): `faces` collapsed to a degenerate "
                "(near-zero-area) outline when flattened along `direction` "
                "-- try a different `direction`")
        flat_face = bd.Plane(origin=centroid, z_dir=d) * polygon(hull_uv)

    elif exact:
        # Original real-B-rep-projection route -- exact analytic
        # geometry and real hole preservation, at real per-face OCCT
        # cost (see this function's own docstring for when to reach
        # for this over the rasterized default).
        target = plane(d, size=(span, span), intercept=centroid)
        try:
            projected = faces_compound.project_to_shape(target, d)
        except Exception:
            projected = None

        if not projected:
            projected = []
            for f in all_faces:
                try:
                    projected.extend(f.project_to_shape(target, d))
                except Exception:
                    continue

        if not projected:
            raise ValueError(
                "slider_from_faces(): projecting `faces` onto the flattening "
                "plane along `direction` produced nothing -- try `hull=True`, "
                "or a different `direction`")
        flat_face = union_multi(*projected) if len(projected) > 1 else projected[0]

    else:
        # DEFAULT: mesh rasterization + grid-boundary trace. Fast --
        # pure numpy, no per-face/per-piece OCCT calls at all until the
        # very final polygon()/offset()/linear_extrude() (a handful of
        # OCCT calls total, regardless of how many thousands of faces
        # `faces` has) -- and still correctly non-convex (a real areal
        # union via rasterization, not a point-cloud hull heuristic).
        # See this function's own docstring for the full explanation.
        mtol = max(min(diag / 2000.0, 0.1), 1e-4)
        verts, tris = to_mesh(faces_compound, tolerance=mtol)
        if not verts or not tris:
            raise ValueError(
                "slider_from_faces(): tessellating `faces` produced no "
                "mesh at all -- try `exact=True` or `hull=True`")
        V = np.asarray(verts, dtype=float)
        T = np.asarray(tris, dtype=int)
        rel = V - np.asarray(centroid, dtype=float)
        pts_uv = np.column_stack([rel @ np.asarray(xdir), rel @ np.asarray(ydir)])

        if grid_res is None:
            res = max(diag / 600.0, 1e-6)
            uspan = float(pts_uv[:, 0].max() - pts_uv[:, 0].min())
            vspan = float(pts_uv[:, 1].max() - pts_uv[:, 1].min())
            max_cells = 1_500_000
            est_cells = (uspan / res + 4) * (vspan / res + 4)
            if est_cells > max_cells:
                res *= math.sqrt(est_cells / max_cells)
        else:
            res = float(grid_res)
            if res <= 0:
                raise ValueError("slider_from_faces(): grid_res must be positive")

        occ, u0, v0 = _rasterize_uv_triangles(pts_uv, T, res)
        loops = _trace_grid_boundary_loops(occ)
        if not loops:
            raise ValueError(
                "slider_from_faces(): the flattened footprint came back "
                "empty -- try a different `direction`, or `hull=True`/`exact=True`")

        real_loops = [[(u0 + i * res, v0 + j * res) for (i, j) in loop] for loop in loops]
        areas = [abs(_loop_area_2d(l)) for l in real_loops]
        outer_idx = max(range(len(real_loops)), key=lambda k: areas[k])
        if len(real_loops[outer_idx]) < 3 or areas[outer_idx] < (res * res) * 2:
            raise ValueError(
                "slider_from_faces(): `faces` collapsed to a degenerate "
                "(near-zero-area) outline when flattened along `direction` "
                "-- try a different `direction`")
        # A rasterized grid boundary is a real right-angle STAIRCASE for
        # any edge that isn't grid-aligned (i.e. basically every edge, on
        # an organic/curved face selection) -- left as-is, that staircase
        # becomes actual cut geometry in the final tool (confirmed
        # directly in this app: a smooth selection came back with a
        # visibly serrated/toothed edge on the final slider). Douglas-
        # Peucker with a tolerance tied to the grid resolution collapses
        # that staircase back down to a clean outline within about one
        # grid cell of the true boundary -- see _dp_simplify_closed_loop()
        # for the verified test case (rotated square: 536 raw staircase
        # points -> 4 correct corners, 0.31% area error).
        outer = _dp_simplify_closed_loop(real_loops[outer_idx], tol=res * 1.5)
        flat_face = bd.Plane(origin=centroid, z_dir=d) * polygon(outer)

    # offset() only shrinks a single Face/Sketch -- union_multi()'s own
    # BOPAlgo_Builder result can come back as a Compound (of several
    # touching-but-not-fully-merged faces) even when it computed the
    # right UNION geometrically (confirmed directly in this app: "F:
    # TopoDS_Face -> TopoDS_Wire, Invoked with: TopoDS_Compound" out of
    # offset() otherwise). Offset every constituent face individually
    # instead, then hand the whole set to linear_extrude() at once
    # (extrude() is far more tolerant of a multi-face Compound/Sketch
    # than offset() is).
    flat_faces = list(flat_face.faces()) if hasattr(flat_face, "faces") else [flat_face]
    if not flat_faces:
        raise ValueError("slider_from_faces(): the flattened footprint has no faces at all")
    shrunk_faces = []
    for f in flat_faces:
        try:
            shrunk_faces.append(offset(f, -abs(float(inset))))
        except Exception:
            continue
    if not shrunk_faces:
        raise ValueError(
            "slider_from_faces(): every piece of the flattened footprint "
            "was too small to shrink by `inset` -- try a smaller inset")
    shrunk_face = bd.Compound(shrunk_faces) if len(shrunk_faces) > 1 else shrunk_faces[0]

    if length is None:
        # Scaled to `relief` -- `faces`' own bounding-box extent
        # SPECIFICALLY ALONG `direction` (computed above) -- not `diag`
        # (the box's full 3D diagonal) and not `sol`'s whole bounding
        # box. `sol` can easily be a much bigger part than the one local
        # feature `faces` picks out (a small notch/groove/dome on a
        # large body), so sizing off `sol`'s full extent made the
        # returned slider balloon out to the size of the WHOLE part.
        # `diag` has the same problem in a subtler way: a wide, shallow
        # patch (large XY footprint, small depth along the actual pull
        # direction) has a `diag` dominated by that footprint, not its
        # depth -- using it for the prism's LENGTH (which only extrudes
        # along `direction`) again produced a needlessly long prism, most
        # of it raw uncut material (confirmed directly in this app,
        # twice: once with `sol`'s bbox, once with `diag`). `relief` is
        # the one quantity that actually measures "how far does this
        # patch extend along the pull direction" -- relief*4 (so
        # length/2 = relief*2 on each side of the footprint plane)
        # comfortably clears through the patch's own real depth there,
        # with a floor (a small fraction of the footprint's own span) for
        # the degenerate case of an almost perfectly flat patch, where
        # relief alone would collapse to ~0.
        length = max(relief * 4.0, diag * 0.1, 1.0)

    tool = linear_extrude(shrunk_face, h=float(length), dir=d, center=True)

    # `slider` is the TOOL block with `sol`'s own material carved OUT of
    # it -- a real mold-slider/core insert has the NEGATIVE (opposite,
    # complementary) contour of the part it forms, not a chunk of the
    # part's own material (that was this function's original behavior --
    # intersection(sol, tool) -- confirmed directly in this app to look
    # just like a slice of `sol` itself, which isn't what an actual
    # tooling insert is). difference(tool, sol) instead keeps the tool
    # block's own material everywhere EXCEPT where `sol` occupies that
    # same space -- so wherever `sol`'s surface passes through `tool`,
    # `slider` comes back with a cavity/relief exactly matching (the
    # inverse of) that surface, and solid material everywhere else in
    # the block.
    slider = difference(tool, sol)
    rest = difference(sol, tool)
    return slider, rest


def text(txt, size=10, h=1, font="Arial", center=False):
    """
    A real, extruded 3D text solid -- build123d's own native Text()
    (real glyph outlines rendered from an installed system font, not
    a flat placeholder), pre-extruded by `h` in one call, the same
    convenience real OpenSCAD's own text()+linear_extrude() two-step
    idiom gives you. openscad4.py never had a real text() of its own
    (its own text()/fo() only ever emitted raw OpenSCAD source, for
    OpenSCAD itself to render later) -- this is a genuine new
    primitive here, not a line-for-line port.

    `size` is the font size (roughly the cap height, in model units).
    `center=False` (default) leaves the text's own baseline-left
    origin at [0,0,0] (matches real OpenSCAD's text() default
    halign="left"/valign="baseline"); `center=True` centers the text
    on the origin on both axes instead -- handy for labels you're
    about to position by their own middle (see track_points() below).

    Needs a font actually installed wherever this runs -- `font`
    defaults to "Arial", which may not exist on every system
    (especially Linux); pass a font name that IS installed there
    instead if you hit a missing-font error.

    `h<=0` skips the extrude step entirely and returns the flat 2D
    text sketch instead (a real Face per glyph, not a solid) -- the
    real per-label cost here is rendering the font glyphs themselves
    (bd.Text()), not the extrude on top, but skipping the extrude
    still saves a real operation per call, which matters if you're
    calling text() many times (see track_points()'s own perf note).
    Still union()/translate()/etc-able like any other Shape either way.

        show(translate([0, 0, 0], text("Hello", size=10, h=2)))
    """
    _require_build123d()
    align = (bd.Align.CENTER, bd.Align.CENTER) if center else None
    sketch = bd.Text(str(txt), float(size), font=str(font), align=align)
    if h <= 0:
        return sketch
    return linear_extrude(sketch, h=float(h))


def points(pts, d=0.5, shape="cube"):
    """
    Marker geometry at each point in `pts` (a flat list of 2D or 3D
    points) -- openscad4.py's own points() module, ported: a small
    cube (or sphere) of size `d` at every point, unioned into one
    shape, so you can show() a raw point list (turtle2d()/turtle3d()'s
    output, a bezier()/bspline_closed() control polygon, anything) to
    see exactly where its points land -- the same debugging role
    show_edges() plays for a real B-rep edge selection, but for plain
    point lists that never became a shape at all.

        ctrl = [[0, 0], [5, 15], [15, 15], [20, 0]]
        show(points(ctrl, 1), c="red")   # where are the control points?
        show(linear_extrude(polygon(bezier(ctrl, 30)), h=2))

    `shape` is `"cube"` (default, matches openscad4.py's own points()
    exactly) or `"sphere"`. 2D points are placed at z=0.

    REAL PERFORMANCE NOTE: markers are grouped with a lightweight
    Compound() rather than union()'d together -- for a big point list
    (a densely-sampled cr2dt()/bezier()/etc curve, say), union()ing
    every marker one at a time is the same real O(N) chained-boolean
    cost documented in p_line3d()'s own docstring, and completely
    unnecessary here: these markers are disjoint, disposable debug
    dots that never need to be a single watertight solid, so a real
    boolean fuse between them is pure wasted CSG work. Compound()
    just groups them for display/export with no solving at all.
    """
    _require_build123d()
    pt_list = _flatten_points(pts)
    if not pt_list:
        raise ValueError("points(): need at least one point")
    key = str(shape).lower()
    if key not in ("cube", "sphere"):
        raise ValueError(f"points(): shape must be 'cube' or 'sphere', got {shape!r}")
    markers = []
    for p in pt_list:
        x, y, z = p[0], p[1], (p[2] if len(p) > 2 else 0.0)
        marker = cube(d, center=True) if key == "cube" else sphere(d / 2)
        markers.append(bd.Pos(x, y, z) * marker)
    return bd.Compound(markers)


def line3d(points, d=0.5, closed=False):
    """
    A polyline made of small real cylinder segments (diameter `d`)
    connecting each consecutive point in `points` -- a lightweight,
    genuinely different construction from p_line3d()/sweep_sec2path()
    (no sweep() call at all, and no rounded end caps): one plain
    bd.Cylinder primitive per segment, oriented with a real build123d
    Plane (the same origin/z_dir trick sweep_sec2path()/
    surface_line_vector() use internally to orient a cross-section
    along a direction), grouped with bd.Compound() -- the same "don't
    union disjoint debug geometry" trick points()/show_edges() already
    use (a real boolean fuse between segments would be pure wasted CSG
    work for something that's just meant to be looked at).

    The point-list sibling of show_edges() (which does the same job
    for a real Shape's edge selection, not a raw point list) -- handy
    for a quick, cheap look at ANY point list (sinewave()/cosinewave()/
    rot_p()'s output, cr3dt()'s output, a bezier() control path, l1/l2
    before combining them with surface_from_2_waves(), etc) without
    the tessellate()-only-works-on-Faces limitation a bare
    Edge/Wire (e.g. bd.Polyline(*points) on its own) would hit trying
    to show() it directly:

        l1 = rot_p('x90', sinewave(60, 3, 8, 60))
        l2 = rot_p('x90z90', cosinewave(60, 3, 8, 60))
        show(line3d(l1, 0.3), 'blue')
        show(line3d(l2, 0.3), 'magenta')

    `closed=True` also connects the last point back to the first (same
    closed_loop convention as turtle3d()/p_line3d()/sweep_sec2path()).
    2D points are placed at z=0.
    """
    _require_build123d()
    pts = _flatten_points(points)
    if len(pts) < 2:
        raise ValueError("line3d(): need at least 2 points")
    pts3 = [(p[0], p[1], p[2] if len(p) > 2 else 0.0) for p in pts]
    pairs = list(zip(pts3, pts3[1:]))
    if closed:
        pairs.append((pts3[-1], pts3[0]))
    align = _align_radial(False)
    segs = []
    for p0, p1 in pairs:
        v = tuple(b - a for a, b in zip(p0, p1))
        length = math.sqrt(sum(c * c for c in v))
        if length < 1e-9:
            continue
        segs.append(bd.Plane(origin=p0, z_dir=v) * bd.Cylinder(d / 2, length, align=align))
    if not segs:
        raise ValueError("line3d(): all consecutive points coincide")
    return bd.Compound(segs)


def track_points(line, text_size=1, h=0.1, step=1):
    """
    Labels each point in `line` with its own index number (0, 1, 2,
    ...) as small real 3D text -- openscad4.py's own track_points(),
    ported: the original generated raw OpenSCAD source text() calls,
    only usable through fo(); this returns one real, already-
    positioned Shape (every digit label grouped together) you
    show()/color() directly, no text-code step needed. Handy for
    figuring out which index in a point list corresponds to which
    point when debugging a curve/path/profile -- the numeric sibling
    of points() above (which just marks each point, without saying
    which is which).

        pts = bezier([[0, 0], [5, 15], [15, 15], [20, 0]], 8)
        show(color(polygon(pts), "lightgray", alpha=0.3))
        show(track_points(pts, text_size=1.5), "blue")

    `text_size`/`h` are passed straight through to text() (font size,
    extrusion height). No text_color parameter here (unlike the
    original) -- same convention as points() above: pass a color to
    show()/color() yourself when you actually display the result.

    REAL PERFORMANCE NOTE: rendering N real text labels is N real
    font-render-and-extrude operations no matter how the results get
    grouped afterward -- Compound() (used here instead of union(),
    see below) only removes an EXTRA, unnecessary cost on top of
    that, not this one. For a path with many points (a densely-
    sampled cr2dt() outline, say), the label count itself is usually
    the real bottleneck, so two direct levers:
      `step` (default 1, every point) -- e.g. step=5 labels only
        every 5th point, cutting the label count (and cost) by 5x.
        Each label still shows its point's TRUE index in `line`, not
        a renumbered 0,1,2,... count, so it stays meaningful even
        skipped.
      `h=0` -- skips the extrude step per label (see text()'s own
        note), rendering flat labels instead of solids -- meaningful
        savings if you don't need solid/printable labels, just
        something to look at.
    Labels are grouped with a lightweight Compound() rather than
    union()'d together regardless -- these are disjoint, disposable
    debug labels that never need to be one watertight solid, so a
    real boolean fuse between them (the O(N) chained-boolean cost
    documented in p_line3d()'s own docstring) was pure wasted CSG
    work on top of whatever building each label itself costs.
    """
    _require_build123d()
    pts = _flatten_points(line)
    if not pts:
        raise ValueError("track_points(): need at least one point")
    stride = max(1, int(step))
    labels = []
    for i in range(0, len(pts), stride):
        p = pts[i]
        x, y, z = p[0], p[1], (p[2] if len(p) > 2 else 0.0)
        labels.append(bd.Pos(x, y, z) * text(str(i), size=text_size, h=h, center=True))
    return bd.Compound(labels)


def p_line3d(path, d=1, closed=0, transition="round"):
    """
    A tube/rope of diameter `d` following `path`, real B-rep --
    openscad4.py's own p_line3d()/p_line3dc() modules, ported. Handy
    for turning a bare 3D point list (turtle3d()'s output, cr3dt()'s
    output, any hand-built polyline) straight into a real solid you
    can show() directly, without setting up sweep_sec2path()'s 2D-
    section-and-path call yourself -- e.g. a quick tube/wireframe-
    style rendering of a 3D path, or an actual rope/cable model.
    `closed=1` also connects the last point back to the first
    (openscad4.py's separate p_line3dc()) -- same closed_loop
    convention as turtle3d()/sweep_sec2path().

    `path` can also be a real Shape instead of a raw point list -- a
    Wire/Edge (e.g. arc_edge(), or a Face's own `.wires()[0]`), or a
    filled 2D shape like polygon()/circle()/cr2dt()+polygon()'s output
    (its boundary outline is traced automatically, same "pull the
    outline out of a filled Face" step sweep_sec2path() already does
    for a Shape path3d -- see _as_path_wire()). A genuinely closed
    Shape (a closed Wire, or a filled Face's boundary -- polygon()'s
    output, say) skips the end caps automatically, the same as
    `closed=1` does for a raw point list, since there's no open end to
    round off either way.

    REAL PERFORMANCE FIX: this used to build a capsule (hull() of two
    spheres, or two cubes with rec=1 -- that parameter's gone now, see
    below) for EVERY consecutive pair of points, then union() them all
    together -- one hull() plus one boolean per segment, chained. That
    was a real user-reported slowdown: unioning N solids one at a time
    is O(N) booleans, each re-solving against the whole accumulated
    result so far, and a path with even a few dozen points made this
    genuinely slow. Now it's ONE sweep_sec2path() call along the whole
    path plus 2 small sphere() caps unioned on at the very ends --
    same rounded-tube-with-rounded-ends look, a handful of real B-rep
    operations total instead of one per segment (the exact fix applied
    by hand in examples/21_drill_bit.py before it was folded back into
    this function directly).

    No more `rec` (square vs round caps) -- a round tube with round
    end-caps is what this function is actually for now; if you
    specifically want flat/square caps instead, call
    sweep_sec2path(square(d, center=True), path) yourself.

    `transition` is passed straight through to sweep_sec2path() (see
    its own docstring for what it does) -- "round" (the default) is
    fine for most paths, but a path with many points and/or tight,
    sharp turns relative to `d` can hit the same fragility any long
    multi-segment sweep can (see examples/20_3d_knots.py for the full
    story on that failure mode) -- try "right_corner" or "transformed"
    if you hit it here too. CONFIRMED via a real user report: a
    many-point, non-planar path (e.g. axis_rot_1_pts()-bent) with the
    default "round" raised `AttributeError: 'NoneType' object has no
    attribute 'NbNodes'` -- a real OCCT/OCP error in "round"'s per-
    corner fillet construction -- and transition="right_corner" fixed
    it. If you see that exact error, this is almost certainly why.

    `closed=1` skips the end caps entirely (there's no exposed end
    left to round off once the loop connects back to itself) -- just
    the one sweep, closed all the way around.
    """
    _require_build123d()
    r = float(d) / 2

    if isinstance(path, bd.Shape):
        path_wire = _as_path_wire(path, "p_line3d")
        tube = sweep_sec2path(circle(r), path_wire, transition=transition)
        if closed or getattr(path_wire, "is_closed", False):
            return tube
        start, end = path_wire.position_at(0), path_wire.position_at(1)
        caps = union(bd.Pos(start.X, start.Y, start.Z) * sphere(r),
                     bd.Pos(end.X, end.Y, end.Z) * sphere(r))
        return union(tube, caps)

    pts = _flatten_points(path)
    if len(pts) < 2:
        raise ValueError("p_line3d(): path needs at least 2 points")
    pts = [(p[0], p[1], p[2] if len(p) > 2 else 0.0) for p in pts]
    if closed:
        return sweep_sec2path(circle(r), pts + [pts[0]], transition=transition)
    tube = sweep_sec2path(circle(r), pts, transition=transition)
    caps = union(bd.Pos(*pts[0]) * sphere(r), bd.Pos(*pts[-1]) * sphere(r))
    return union(tube, caps)


# ---------------------------------------------------------------------------
# A second batch of openscad4.py ports: plane(), sinewave()/cosinewave(),
# loft(), helix(), interp_spline(), s_int1(), project_curve_on_face(),
# tangent_arc(). Same spirit as the core toolkit above -- reimplemented
# against documented behavior, preferring a real build123d native
# operation wherever one exists (loft/Helix/Spline/ConstrainedArcs/
# project all replace what was hand-rolled point-list math in the mesh
# version) rather than a line-for-line port. concave_hull() was
# attempted and DROPPED -- a naive nearest-neighbor nearest-angle walk
# turned out to be genuinely unreliable at correctly tracing a concave
# boundary (verified wrong on a simple L-shaped test case), and getting
# it right needs more careful work than this batch had room for. A few
# other openscad4.py mesh-only helpers in this same family
# (wrap_around(), prism(), o_solid(), swp_prism_h(), h_lines_sec(),
# surround(), honeycomb()) were also deliberately left out to focus on
# the functions that map onto genuinely new B-rep capability -- ask if
# you want those next.
# ---------------------------------------------------------------------------

def plane(normal, size=(100, 100), intercept=(0, 0, 0)):
    """
    A flat rectangular Face of the given `size` ([width, height]), lying
    in the plane through `intercept` with the given `normal` -- e.g.
    plane([1,0,0]) is a rectangle in the YZ plane; plane([0,0,1]) is a
    rectangle in the XY plane. openscad4.py's own plane(), ported --
    real B-rep, build123d's own Plane+Rectangle rather than the
    hand-built surface-from-2-vectors construction the mesh version
    needed. Mostly useful as a visual reference plane, or as the
    `target` for project_curve_on_face()/a cutting tool for split()-
    style operations you build yourself with build123d's own Shape
    methods.

    Returns a genuine bare Face, not the Sketch that `Plane(...) *
    Rectangle(...)` actually produces -- build123d's own Rectangle()
    returns a Sketch (and Sketch IS-A Compound, per build123d's own
    source: `class Sketch(Compound)`), so multiplying it onto a Plane
    still comes back as a Compound-wrapping-one-Face, not a bare Face.
    That distinction matters a lot for split(): passing that Compound
    straight through as `bisect_by` reaches OCCT's own cut internals,
    which expect a real TopoDS_Face and fail there with a confusing
    "UVBounds_s(): incompatible function arguments ... invoked with
    TopoDS_Compound" -- unwrapping it with .faces()[0] here avoids that
    for every caller, not just split()'s own callers.
    """
    _require_build123d()
    if isinstance(size, (int, float)):
        w = h = float(size)
    else:
        w, h = float(size[0]), float(size[1])
    n = tuple(float(c) for c in normal)
    p = bd.Plane(origin=tuple(float(c) for c in intercept), z_dir=n)
    return (p * bd.Rectangle(w, h)).faces()[0]


def sinewave(length, cycles, amplitude, n):
    """
    A 2D point list tracing a sine wave: x runs 0 to `length`, y =
    `amplitude` * sin(2*pi*`cycles`*x/`length`), sampled at `n` points.
    openscad4.py's own sinewave(), ported. Feed it to polygon()/
    linear_extrude(), or wrap it into 3D yourself (translate/rotate)
    for a rippled profile.
    """
    l, n_cyc, a, p = float(length), float(cycles), float(amplitude), int(n)
    return [
        [x, a * math.sin(2 * math.pi * n_cyc * x / l)]
        for x in [l * i / (p - 1) for i in range(p)]
    ]


def cosinewave(length, cycles, amplitude, n):
    """Same as sinewave() but starting at the wave's peak (cosine phase)
    instead of zero -- openscad4.py's own cosinewave(), ported."""
    l, n_cyc, a, p = float(length), float(cycles), float(amplitude), int(n)
    return [
        [x, a * math.cos(2 * math.pi * n_cyc * x / l)]
        for x in [l * i / (p - 1) for i in range(p)]
    ]


def honeycomb(r, n1, n2):
    """
    A hex grid of `n1` x `n2` regular hexagons of "radius" `r` (center
    to vertex) -- openscad4.py's own honeycomb(), reimplemented as
    plain hex-grid math: returns a list of hexagons, each a closed
    6-point 2D loop, ready for `[polygon(h) for h in honeycomb(...)]`
    or filtering with point_in_polygon().
    """
    r, n1, n2 = float(r), int(n1), int(n2)
    dx = 1.5 * r
    dy = r * math.sqrt(3)
    hexes = []
    for col in range(n1):
        cx = col * dx
        cy0 = (dy / 2) if col % 2 else 0.0
        for row in range(n2):
            cy = cy0 + row * dy
            hexes.append([
                [cx + r * math.cos(math.radians(60 * i)), cy + r * math.sin(math.radians(60 * i))]
                for i in range(6)
            ])
    return hexes


def point_in_polygon(point, poly):
    """
    True if `point` ([x,y]) lies inside the closed 2D polygon `poly`
    ([[x,y], ...]) -- standard ray-casting test. Handy for filtering a
    point set (or, per-vertex, a shape like honeycomb()'s hexagons)
    down to whatever's actually inside an arbitrary boundary:

        cells = honeycomb(3, 8, 8)
        boundary = cr2dt([[3,2,1],[8,3,3],[5,7,1],[-8,0,2],[-5,20,1]])
        inside = [h for h in cells if all(point_in_polygon(v, boundary) for v in h)]
    """
    x, y = float(point[0]), float(point[1])
    inside = False
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i][0], poly[i][1]
        x2, y2 = poly[(i + 1) % n][0], poly[(i + 1) % n][1]
        if (y1 > y) != (y2 > y):
            x_cross = (x2 - x1) * (y - y1) / (y2 - y1) + x1
            if x < x_cross:
                inside = not inside
    return inside


def pies1(section, pnts):
    """
    Filters a list of 2D points down to just the ones that lie inside
    the closed polygon `section` -- openscad4.py's own pies1(), ported
    as a thin wrapper around point_in_polygon() rather than its
    original numpy line-intersection formulation (same result, much
    simpler): returns the subset of `pnts` for which
    point_in_polygon(p, section) is True.

        pts = [[random.uniform(-5,20), random.uniform(-2,25)] for _ in range(10000)]
        sec = cr2dt([[2,1,.1],[7,5,2],[5,7,3],[-5,7,2],[-7,5,3]])
        inside = pies1(sec, pts)
        show(p_line3d(sec, .05, 0, 1))
        show(color(points(inside, .2), "magenta"))
    """
    poly = _flatten_points(section)
    return [p for p in pnts if point_in_polygon(p, poly)]


def vertex(point):
    """
    A single real B-rep Vertex at `point` ([x,y] or [x,y,z]) --
    build123d's own native Vertex. Mainly useful as a loft() section:
    passing a Vertex as the FIRST and/or LAST section (instead of
    another Face) tells loft() to taper smoothly to a single point
    there instead of blending into another ring -- the standard,
    numerically robust way to cap a lofted stack of rings with a
    genuine rounded/pointed tip, instead of feeding loft() a nearly-
    degenerate near-zero-size ring (real curve/surface fitting --
    interp_spline()/cap_wire()/Face-building in general -- can easily
    choke on a ring that's collapsed down to a tiny cluster of
    near-coincident points; "BRep_API: command not done" is a typical
    symptom of exactly that).

        rings = [translate([0, 0, h], circle(r)) for h, r in
                 [(2, 8), (8, 8)]]
        show(loft([vertex([0, 0, 0]), *rings, vertex([0, 0, 10])]))
    """
    _require_build123d()
    p = (point[0], point[1], point[2] if len(point) > 2 else 0.0)
    return bd.Vertex(*[float(c) for c in p])


def _point_to_mesh_min_dist(p, verts, tris):
    """Vectorized true point-to-TRIANGLE minimum distance from `p` to a
    triangle mesh (`verts`: (N,3) float array, `tris`: (M,3) int array
    of vertex indices) -- the standard closest-point-on-triangle
    construction (Ericson's region test, done for every triangle at
    once via numpy), not a nearest-VERTEX shortcut. Verified directly
    against known geometric cases (point over a triangle's interior,
    over each vertex/edge region, and across a multi-triangle mesh)
    before use in seam_edges() below -- see that function's own
    docstring for why nearest-vertex specifically isn't good enough
    here."""
    p = np.asarray(p, dtype=float)
    A = verts[tris[:, 0]]
    B = verts[tris[:, 1]]
    C = verts[tris[:, 2]]
    ab = B - A
    ac = C - A
    ap = p - A

    d1 = np.einsum('ij,ij->i', ab, ap)
    d2 = np.einsum('ij,ij->i', ac, ap)
    mask_A = (d1 <= 0) & (d2 <= 0)

    bp = p - B
    d3 = np.einsum('ij,ij->i', ab, bp)
    d4 = np.einsum('ij,ij->i', ac, bp)
    mask_B = (d3 >= 0) & (d4 <= d3) & (~mask_A)

    cp = p - C
    d5 = np.einsum('ij,ij->i', ab, cp)
    d6 = np.einsum('ij,ij->i', ac, cp)
    mask_C = (d6 >= 0) & (d5 <= d6) & (~mask_A) & (~mask_B)

    vc = d1 * d4 - d3 * d2
    mask_AB = (vc <= 0) & (d1 >= 0) & (d3 <= 0) & (~mask_A) & (~mask_B) & (~mask_C)
    v_ab = np.zeros_like(d1)
    nz = (d1 - d3) != 0
    v_ab[nz] = d1[nz] / (d1[nz] - d3[nz])

    vb = d5 * d2 - d1 * d6
    mask_AC = (vb <= 0) & (d2 >= 0) & (d6 <= 0) & (~mask_A) & (~mask_B) & (~mask_C) & (~mask_AB)
    w_ac = np.zeros_like(d1)
    nz = (d2 - d6) != 0
    w_ac[nz] = d2[nz] / (d2[nz] - d6[nz])

    va = d3 * d6 - d5 * d4
    mask_BC = (va <= 0) & ((d4 - d3) >= 0) & ((d5 - d6) >= 0) & (~mask_A) & (~mask_B) & (~mask_C) & (~mask_AB) & (~mask_AC)
    w_bc = np.zeros_like(d1)
    denom = (d4 - d3) + (d5 - d6)
    nz = denom != 0
    w_bc[nz] = (d4[nz] - d3[nz]) / denom[nz]

    mask_face = ~(mask_A | mask_B | mask_C | mask_AB | mask_AC | mask_BC)
    denom_f = va + vb + vc
    v_f = np.zeros_like(d1)
    w_f = np.zeros_like(d1)
    nzf = denom_f != 0
    v_f[nzf] = vb[nzf] / denom_f[nzf]
    w_f[nzf] = vc[nzf] / denom_f[nzf]

    closest = np.empty_like(A)
    closest[mask_A] = A[mask_A]
    closest[mask_B] = B[mask_B]
    closest[mask_C] = C[mask_C]
    closest[mask_AB] = A[mask_AB] + ab[mask_AB] * v_ab[mask_AB, None]
    closest[mask_AC] = A[mask_AC] + ac[mask_AC] * w_ac[mask_AC, None]
    closest[mask_BC] = B[mask_BC] + (C[mask_BC] - B[mask_BC]) * w_bc[mask_BC, None]
    closest[mask_face] = A[mask_face] + ab[mask_face] * v_f[mask_face, None] + ac[mask_face] * w_f[mask_face, None]

    d = closest - p
    dist2 = np.einsum('ij,ij->i', d, d)
    return float(np.sqrt(dist2.min()))


def seam_edges(solid, a, b, tol=0.1, samples=3, mesh_tol=None):
    """
    Finds the edges of `solid` that lie on BOTH `a`'s and `b`'s own
    surfaces within `tol` -- the genuine seam where two solids'
    surfaces crossed to produce `solid` (typically
    solid = intersection(a, b), but works for union()/difference()
    results too). Generalizes 24_mouse_body_loft_sphere_intersection.py
    's own _on_sphere() trick -- which only worked because its second
    solid was a perfect analytic sphere() and could use a closed-form
    distance-from-center formula -- to ANY pair of solids, sculpted/
    non-primitive ones included, by testing real surface distance
    instead of a formula.

    Every edge of `solid` is, by construction, either (1) leftover
    boundary from `a` alone (trimmed by `b`), (2) leftover boundary
    from `b` alone (trimmed by `a`), or (3) a genuinely NEW edge that
    only exists because `a`'s surface crossed `b`'s. Category (3) is
    the real seam, and is exactly the edges that sit close to BOTH
    surfaces at once -- edges from (1)/(2) only ever sit close to one.

    PERFORMANCE, and why this ISN'T built on Shape.distance_to():
    `solid.edges()` can easily run into the thousands for anything
    built from many-station ruled lofts, and each call to
    .distance_to() against a real, complex solid re-pays that solid's
    OWN internal setup cost from scratch (build123d/OCCT don't cache
    anything between calls) -- confirmed directly in this app: even
    with a cheap single-point pre-filter added first, checking a few
    thousand edges against two complex multi-hundred-face solids still
    took over 10 minutes. Tessellating `a` and `b` into a triangle mesh
    ONCE instead (to_mesh(), the same tessellation this app's own
    viewer already relies on) and doing every distance check as a
    vectorized numpy POINT-TO-TRIANGLE distance against that fixed mesh
    is a completely different cost shape: one bounded tessellation pass
    per solid, then every subsequent query is microseconds instead of
    the 100ms+ a single real OCCT distance_to() call was costing here.

    This measures distance to the nearest point on the tessellated
    surface (true point-to-triangle distance, not just nearest mesh
    VERTEX -- an earlier version of this function used nearest-vertex,
    which is a much worse approximation than it sounds: to_mesh() only
    adds vertices where curvature actually demands them, so a genuinely
    FLAT stretch of a shape (a swept prism's own flat side panel, for
    instance) can tessellate into just one or two large triangles with
    vertices far apart -- a point sitting exactly ON that flat face,
    dead center of a triangle, could easily be much farther than `tol`
    from the NEAREST VERTEX even though its true distance to the
    surface is zero. Confirmed directly in this app: nearest-vertex
    caused seam_edges() to come back completely empty on exactly this
    kind of shape. Real point-to-triangle distance doesn't have that
    failure mode -- it's accurate to the tessellation's own chordal
    tolerance everywhere, flat or curved, matching what `mesh_tol`
    below actually promises.

    Samples `samples` points along each edge; an edge only qualifies if
    EVERY sampled point is within `tol` of both `a`'s and `b`'s mesh
    (each edge's own midpoint is checked FIRST, alone, as a cheap
    reject before the full `samples`-point pass). `tol` needs to be
    loose enough to absorb whatever construction tolerance `a`, `b`, or
    `solid` itself carries if any of them were built from discretized
    data (ring lofts, offset surfaces, etc) rather than pure analytic
    primitives -- start around 0.1-1.0 and widen if this comes back
    empty; narrow it if it's pulling in edges that clearly aren't the
    seam.

    `mesh_tol`: the tessellation tolerance to_mesh() uses for `a`/`b` --
    defaults to `tol / 2` (fine enough that the nearest-mesh-vertex
    approximation stays well inside `tol` of the true surface almost
    everywhere) if left as None. Pass a coarser number explicitly for
    extra speed on a very large solid if `tol` is already generous.

    Two direct uses:

        seam = seam_edges(sol, s1, b_2)
        mouse = fillet(sol, seam, 8)                    # real fillet(),
                                                          # if the seam
                                                          # chains into
                                                          # clean loops

        spine = sample_curve(seam[0], 100)               # or feed ONE
        f3 = convert_3lines2fillet(line_a, line_b, spine, closed_loop=1)
                                                          # offset-curve
                                                          # ribbon
                                                          # technique,
                                                          # when the
                                                          # seam is too
                                                          # fragmented
                                                          # for fillet()
                                                          # to walk as
                                                          # one loop

    UNVERIFIED against a real build123d/OCP install -- to_mesh()/
    shape.tessellate() is documented, standard build123d Shape API, but
    this exact function hasn't been run here. The point-to-triangle
    distance math itself (_point_to_mesh_min_dist(), above) IS verified
    directly -- tested standalone against known cases (point over a
    triangle's face/edge/vertex regions, across a multi-triangle mesh)
    with exact expected distances back in every case.
    """
    _require_build123d()
    mtol = mesh_tol if mesh_tol is not None else max(tol / 2.0, 0.001)
    va, fa = to_mesh(a, tolerance=mtol)
    vb, fb = to_mesh(b, tolerance=mtol)
    verts_a = np.asarray(va, dtype=float)
    tris_a = np.asarray(fa, dtype=int)
    verts_b = np.asarray(vb, dtype=float)
    tris_b = np.asarray(fb, dtype=int)
    if verts_a.size == 0 or tris_a.size == 0 or verts_b.size == 0 or tris_b.size == 0:
        return []

    out = []
    for e in solid.edges():
        try:
            mid = e.position_at(0.5)
            pm = (float(mid.X), float(mid.Y), float(mid.Z))
        except Exception:
            continue
        if (_point_to_mesh_min_dist(pm, verts_a, tris_a) > tol
                or _point_to_mesh_min_dist(pm, verts_b, tris_b) > tol):
            continue
        ok = True
        for p in sample_curve(e, samples):
            if (_point_to_mesh_min_dist(p, verts_a, tris_a) > tol
                    or _point_to_mesh_min_dist(p, verts_b, tris_b) > tol):
                ok = False
                break
        if ok:
            out.append(e)
    return out


def loft(*sections, ruled=False):
    """
    A solid lofted through a sequence of 2D cross-sections -- e.g.
    `loft(square(20, center=True), translate([0,0,20], circle(8)))`
    smoothly blends a square base into a round top 20 units up.
    Real B-rep, build123d's own native loft() (an exact ruled/smooth
    surface between the section boundaries, not a stack of thin mesh
    slices) -- accepts 2 or more sections, each already positioned
    where you want it (translate()/rotate() them into place first,
    same as sweep_sec2path()'s section). This is what openscad4.py's
    prism()/swp_prism_h() and the various "stitch two rail curves
    together" part-building tricks are standing in for by hand --
    build123d's loft() does the same underlying job natively and more
    robustly, so those weren't ported as separate point-list functions.

    `ruled` controls how the surface behaves AT each intermediate
    section, which matters a lot as soon as there are 3+ sections:
      False (default): a smooth spline surface threading through every
        section with continuous tangency -- if section 2's radius
        jumps up and section 3's jumps back down, the surface eases
        into and out of that bulge rather than kinking, so you will
        NOT see a sharp corner exactly at an intermediate section's
        height even though its radius is a local max/min. This is
        almost certainly why a profile built from rings of varying
        radius (e.g. a stack of circles at different heights/radii)
        comes out looking rounded/blobby instead of angular.
      True: straight-line ("ruled") surface between each consecutive
        pair of sections instead -- ends up as a stack of conical
        frustums, with a visible sharp corner exactly at every
        intermediate section's height. This is what you want if the
        rings/sections were meant to define a piecewise-straight
        profile (a vase with angular shoulders, a stepped cone, etc).

        rings = [translate([0,0,h], circle(r)) for h, r in
                 [(0,10),(10,14),(20,9),(30,15),(40,8)]]
        show(loft(*rings, ruled=True))   # sharp corner at each ring
    """
    _require_build123d()
    secs = _flatten(sections)
    if len(secs) < 2:
        raise ValueError("loft(): need at least 2 sections")
    return bd.loft(list(secs), ruled=bool(ruled))


def helix(radius=10, pitch=10, turns=1, center=(0, 0, 0), direction=(0, 0, 1), lefthand=False):
    """
    A helical Wire (a coil/spring/thread path) -- real B-rep, build123d's
    own native Helix curve (exact, not a polyline approximation), of
    the given `radius` and `pitch` (rise per full turn), `turns` long,
    starting at `center` and winding along `direction`. openscad4.py's
    own helix(), ported (its `number_of_coils`/`step_angle` become
    `turns`/build123d's own exact curve -- no facet-angle step needed).
    Feed it straight to sweep_sec2path() as path3d for a coil spring or
    a screw thread:

        show(sweep_sec2path(circle(1), helix(radius=10, pitch=5, turns=4)))
    """
    _require_build123d()
    return bd.Helix(float(pitch), float(pitch) * float(turns), float(radius),
                     center=tuple(float(c) for c in center),
                     direction=tuple(float(c) for c in direction),
                     lefthand=bool(lefthand))


def interp_spline(points, closed=False):
    """
    A smooth curve that passes EXACTLY through every point in `points`
    (2D or 3D) -- unlike bezier()/bspline_open()/bspline_closed() above
    (which only approximate through their control points), this is a
    true interpolating spline: openscad4.py's own
    interpolation_bspline_open()/interpolation_bspline_closed(),
    ported, as a thin wrapper around build123d's native
    Edge.make_spline() (GeomAPI_Interpolate under the hood -- exact,
    not fitted). `closed=True` makes a periodic (closed-loop) spline
    through the points instead of an open curve -- same idea as
    bspline_closed()'s closed_loop convention. Returns a real B-rep
    Edge, feed it to polygon()-style usage yourself if you need a
    filled face (Face(Wire([...]))-equivalent isn't wrapped here since
    the point-list functions above already cover the common polygon()
    case for approximating curves).
    """
    _require_build123d()
    pts = _flatten_points(points)
    if len(pts) < 2:
        raise ValueError("interp_spline(): need at least 2 points")
    pts3d = [(p[0], p[1], p[2] if len(p) > 2 else 0.0) for p in pts]
    return bd.Spline(*pts3d, periodic=bool(closed))


def mixed_wire(pieces):
    """
    Chains `pieces` into ONE closed Wire -- the exact-points half of
    mixed_polygon() below, pulled out on its own so you can cap the
    result with something OTHER than mixed_polygon()'s planar-only
    bd.Face(wire). Each item in `pieces` can be EITHER a plain 2D/3D
    point ([x,y] -- a straight-line vertex) OR a real build123d Edge
    (interp_spline(), arc_edge(), tangent_arc() output, etc) used
    as-is for that stretch of the boundary instead of a straight line.
    Walks `pieces` in order, connecting consecutive plain points with
    straight lines and dropping in each given Edge directly (adding a
    straight line from the previous point to the Edge's own start if
    there's a gap), then closes the loop from the last item back to
    the first the same way -- combines the whole chain into one Wire
    (bd.Wire.combine()) and returns it (NOT a Face -- see below).

    WHY THIS EXISTS, separately from mixed_polygon(): mixed_polygon()
    caps its wire with bd.Face(wire), which -- like face_from_wire()/
    polygon() -- requires the wire to be exactly PLANAR (flat, no
    matter how slightly it bows out of one plane). Feed it a boundary
    that isn't quite flat (an easy thing to end up with by the time
    points have been through several rot()/translate()/curve-fitting
    steps in a real pipeline) and the result is NOT a clean error --
    it's a silently wrong/degenerate Face, which shows up downstream
    as loft()/linear_extrude() only picking up a small sliver of the
    boundary instead of the whole thing you fed in, with no obvious
    cause at the mixed_polygon() call site itself.

    cap_wire() doesn't have that restriction -- it fills a boundary
    with a genuine curvature-aware surface (build123d's
    Face.make_surface(), the same one a non-planar boundary from raw
    points already goes through there) and, unlike mixed_polygon(),
    accepts an existing Wire directly. So for the exact-points-AND-
    real-Edges input mixed_polygon() takes, but with cap_wire()'s
    non-planar-safe result instead of mixed_polygon()'s planar-only
    one:

        w = mixed_wire([curve, [-10, 100], [-10, 0]])
        sec = cap_wire(w)          # instead of mixed_polygon(...)
        show(linear_extrude(sec, 10))

    mixed_polygon() itself is unchanged (still bd.Face(mixed_wire(...)),
    still planar-only) -- reach for mixed_wire()+cap_wire() instead the
    moment mixed_polygon() gives you a suspiciously small/wrong result,
    without needing to first prove the boundary really is non-planar.

    Raises if `pieces` doesn't chain up into exactly one closed loop
    (e.g. a given Edge points the wrong way, or there's a real gap) --
    same check, same message, as mixed_polygon().
    """
    _require_build123d()
    if len(pieces) < 2:
        raise ValueError("mixed_wire(): need at least 2 pieces")

    def as_pt3(p):
        return (float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0)

    def dist(p0, p1):
        return math.sqrt(sum((p1[i] - p0[i]) ** 2 for i in range(3)))

    edges = []
    first_pt = None
    cursor = None
    for item in pieces:
        if isinstance(item, bd.Shape):
            start_v, end_v = item.position_at(0), item.position_at(1)
            start_pt = (start_v.X, start_v.Y, start_v.Z)
            end_pt = (end_v.X, end_v.Y, end_v.Z)
            if cursor is not None and dist(cursor, start_pt) > 1e-6:
                edges.append(bd.Edge.make_line(cursor, start_pt))
            edges.append(item)
            if first_pt is None:
                first_pt = start_pt
            cursor = end_pt
        else:
            pt = as_pt3(item)
            if cursor is not None and dist(cursor, pt) > 1e-6:
                edges.append(bd.Edge.make_line(cursor, pt))
            if first_pt is None:
                first_pt = pt
            cursor = pt
    if dist(cursor, first_pt) > 1e-6:
        edges.append(bd.Edge.make_line(cursor, first_pt))

    wires = bd.Wire.combine(edges)
    if len(wires) != 1:
        raise ValueError(
            f"mixed_wire(): pieces didn't chain into a single closed "
            f"loop ({len(wires)} separate wires came out) -- check for a "
            f"real gap, or an Edge whose start/end is reversed from the "
            f"direction you're walking `pieces` in.")
    return wires[0]


def wire_from_edges(edges, tol=None):
    """
    Stitches an UNORDERED, mixed-direction bag of real build123d Edges
    into ONE closed Wire -- e.g. a handful of edges picked one at a
    time with the probe list tool, in whatever order they happened to
    be clicked, not necessarily the order they connect in around the
    loop.

    THIS IS NOT mixed_wire(): mixed_wire() walks `pieces` in the EXACT
    order given, connecting each item's end to the next item's start
    with a straight line if there's a gap -- correct for a hand-built
    profile ([curve, corner_pt, corner_pt, ...]) where you already
    know the walking order, but wrong for a set of Edges picked off an
    existing shape by clicking, where nothing guarantees the click
    order matches the geometric order, or that each Edge's own
    start/end (position_at(0)/(1)) points the way you happened to walk
    it. Feeding an out-of-order/mixed-direction Edge list to
    mixed_wire() doesn't fail cleanly -- it silently inserts a spurious
    straight "bridge" line between mismatched endpoints for every
    out-of-sequence Edge, which is exactly what breaks the result into
    multiple separate wires instead of raising something more
    informative at the actual problem.

    wire_from_edges() skips that cursor-walking step entirely and
    hands `edges` straight to build123d's own Wire.combine(), which
    stitches by matching COORDINATES at shared endpoints regardless of
    input order or individual edge direction -- the same underlying
    call mixed_wire() itself ends with, just without the point-based
    bridging in front of it. Only takes real Edges (no plain [x, y]
    points mixed in, unlike mixed_wire()/mixed_polygon()) -- if you
    need to mix in straight corner points too, reorder `edges` into a
    genuine walk and use mixed_wire() instead.

        e2 = [s3.edges()[i] for i in [3, 2, 0, 1]]  # <- probe list tool: e2
        w = wire_from_edges(e2)
        pts = sample_curve(w, 50)

    Raises the same way mixed_wire() does if `edges` doesn't chain
    into exactly one closed loop -- here that means a REAL gap (the
    edges given don't actually share endpoints all the way around),
    since ordering is no longer a factor. UNLESS `tol` is given (see
    below), that's still true: Wire.combine()'s own coordinate matching
    uses a very tight built-in tolerance, tight enough that edges from
    genuinely different construction paths (e.g. one edge sampled off a
    NURBS surface fit, another a real edge off a solid that's been
    through split()/union()/mirror()) can be visibly touching in the
    viewer and still fail to combine, off by some small but real amount
    from floating-point drift accumulated along two different paths to
    "the same" point.

    `tol`, if given, is a SECOND ATTEMPT that runs only after the exact-
    match attempt above has already failed -- it does NOT loosen or
    replace that first attempt (so a script that already worked keeps
    working identically, byte-for-byte, whether or not you pass `tol`).

    With `tol` set, every possible (edge end) <-> (edge end) pairing
    across the WHOLE selection is considered up front and accepted
    shortest-distance-first (a standard "greedy edge" cycle-building
    heuristic) -- NOT a single-direction walk that only ever compares
    candidates against wherever it currently happens to be. That
    distinction matters on exactly the case `tol` exists for: several
    edges clustered close together (e.g. picking edges off a solid
    that's been union()ed with a near-duplicate mirror copy of itself
    only a fraction of a unit away almost everywhere) can make a single
    cursor's own nearest candidate the WRONG one, even though a
    different, unambiguous, genuinely-shortest pairing exists elsewhere
    in the same selection -- processing shortest-first instead locks in
    every unambiguous short match before a longer, more ambiguous one
    is ever even considered, regardless of which edge got looked at
    first. Once every edge has a matched partner at each end, a short
    straight bridge line is added at every matched pair that isn't
    ALREADY touching at build123d's own tight exact-match precision,
    and the ORIGINAL edges (never copied, reversed, or reordered) plus
    those bridges are handed to build123d's own Wire.combine() one more
    time -- letting real topology (not this function's own guess at
    direction) resolve the final connectivity, the same as the plain
    exact-match attempt at the very top of this function already does.

    Pick `tol` a little larger than the actual gaps you're seeing
    (start small -- e.g. 0.01-1 depending on your model's own scale --
    and increase only if it still fails) rather than something huge:
    too large a `tol` still risks matching an edge to the wrong
    neighbor when several candidates are ALL within `tol`, even with
    the shortest-first ordering above (it reduces, but can't fully
    eliminate, the risk when the true gap and a wrong-neighbor distance
    are close to each other) -- silently building a wrong loop instead
    of raising a clear error.

        e3 = [s6.edges()[i] for i in [2]] + [sol2.edges()[i] for i in [11, 15, 19, 20]]  # <- probe list tool: e3
        s7 = wire_from_edges(e3, tol=0.5)   # small real gaps between s6's and sol2's edges

    Raises ValueError if, even with `tol` given, the edges still don't
    all chain into one connected sequence (a gap bigger than `tol`
    somewhere, or a genuinely missing/extra edge in the selection).
    """
    _require_build123d()
    edges = list(edges)
    if len(edges) < 2:
        raise ValueError("wire_from_edges(): need at least 2 edges")
    wires = bd.Wire.combine(edges)
    if len(wires) == 1:
        return wires[0]
    if tol is None:
        raise ValueError(
            f"wire_from_edges(): edges didn't chain into a single closed "
            f"loop ({len(wires)} separate wires came out) -- these edges "
            f"don't actually share endpoints all the way around; check for "
            f"a real gap or a missing edge in the list, or pass tol= (e.g. "
            f"wire_from_edges(edges, tol=0.5)) if the gaps are real but "
            f"small enough to bridge.")

    tol = float(tol)
    n = len(edges)

    def pt(v):
        return (v.X, v.Y, v.Z)

    def dist(p0, p1):
        return math.sqrt(sum((p1[i] - p0[i]) ** 2 for i in range(3)))

    # GLOBAL greedy edge-matching (a standard "shortest edge first" cycle-
    # building heuristic), not a single-direction walk -- an earlier
    # version of this fallback grew a chain by always extending from ONE
    # cursor to whichever remaining edge was nearest IT specifically.
    # That's fragile exactly where this feature matters most: several
    # edges clustered near each other (e.g. a mirrored-and-union()ed
    # solid, where the mirror copy sits only a fraction of a unit from
    # the original almost everywhere) can make the cursor's single
    # nearest candidate the WRONG one, even though a different pairing
    # elsewhere is unambiguous -- a real, reported failure mode (the
    # walk consumed every edge into SOME order, so it never even
    # reached this function's own "couldn't chain" error, but the
    # resulting order still wasn't a real loop, and mixed_wire()'s own
    # combine() check at the very end caught it instead, several steps
    # too late to say anything useful about which pairing was wrong).
    #
    # This version instead looks at EVERY possible (edge, end) <->
    # (edge, end) pairing across the whole set up front, and accepts
    # them shortest-distance-first -- so an unambiguous, very-short
    # match elsewhere always gets locked in before a longer, more
    # ambiguous one is even considered, regardless of which edge
    # happened to be looked at first.
    def vertex_ends(e, p0_hint, p1_hint):
        # The REAL topological Vertex coordinates for `e`'s start/end,
        # matched to whichever hint (from position_at()) each is
        # closer to -- NOT just position_at(0)/(1) themselves. Those
        # re-evaluate the edge's underlying curve at its own parametric
        # 0/1, which is usually right at the vertex but, after an edge
        # has been through a surface fit / trim / copy (exactly what
        # e.g. surface_from_points_grid()'s boundary edges or a solid's
        # own edges after split()/union()/mirror() have been through),
        # can drift from the ACTUAL stored vertex position by a small
        # but real amount -- a real, reported failure mode: every
        # computed gap was a few hundredths of a micron (~1e-5), an
        # order of magnitude too small to be a genuine modeling gap but
        # still bigger than build123d's own internal stitching
        # tolerance, so a bridge line built between two position_at()
        # points can miss the actual vertex Wire.combine() checks
        # against by just enough to keep failing. Falls back to the
        # position_at() hints themselves if `e` doesn't expose exactly
        # 2 distinct vertices (e.g. a closed/periodic curve with only
        # one), so this is purely additive precision, never a behavior
        # change when it can't apply.
        try:
            vs = [(float(v.X), float(v.Y), float(v.Z)) for v in e.vertices()]
        except Exception:
            return p0_hint, p1_hint
        if len(vs) != 2:
            return p0_hint, p1_hint
        if dist(vs[0], p0_hint) <= dist(vs[1], p0_hint):
            return vs[0], vs[1]
        return vs[1], vs[0]

    ends = [(pt(e.position_at(0)), pt(e.position_at(1))) for e in edges]
    # Precise, vertex-based versions of `ends` above, used ONLY for
    # building bridge segments and the final diagnostic (see
    # vertex_ends() docstring above) -- kept separate from `ends` so
    # the actual shortest-distance MATCHING (which pair of edges should
    # connect at all) still runs on position_at(), which is more than
    # precise enough for that decision and doesn't depend on every
    # build123d version exposing .vertices() the same way.
    vends = [vertex_ends(e, ends[k][0], ends[k][1]) for k, e in enumerate(edges)]
    candidates = []
    for i in range(n):
        for j in range(i + 1, n):
            for wi in (0, 1):
                for wj in (0, 1):
                    d = dist(ends[i][wi], ends[j][wj])
                    if d <= tol:
                        candidates.append((d, i, wi, j, wj))
    candidates.sort(key=lambda c: c[0])

    parent = list(range(n))
    # comp_size[root] = how many EDGES (not connections) are currently
    # chained together in that fragment -- this, not the global
    # `connections` count, is what tells us whether joining two ports
    # already in the same fragment is a premature sub-loop closure or
    # the genuine final edge completing the one big loop. Several
    # fragments can be growing in parallel (e.g. edges naturally
    # cluster into a few separate local groups, like this function's
    # own tol= docstring example mixing edges from two different
    # shapes) -- a small fragment can legitimately finish (all of ITS
    # edges chained) long before the global connection count is
    # anywhere near n-1, and comparing against the global count instead
    # of that fragment's own size let exactly this kind of small
    # fragment close itself into its own separate mini-loop early
    # (a real, reported failure: the edges did all get consumed into
    # SOME set of connections, so this function's own "couldn't match"
    # error below never fired, but the result was multiple disjoint
    # wires, caught only later and less informatively by mixed_wire()'s
    # own combine() check at the very end).
    comp_size = [1] * n

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    used_port = set()  # {(edge_idx, which_end)}
    degree = [0] * n
    connections = []  # (i, wi, j, wj), i's end wi joins j's end wj
    for d, i, wi, j, wj in candidates:
        if len(connections) == n:
            break
        if (i, wi) in used_port or (j, wj) in used_port:
            continue
        if degree[i] >= 2 or degree[j] >= 2:
            continue
        ri, rj = find(i), find(j)
        if ri == rj and comp_size[ri] < n:
            # Both edges are already part of the SAME growing fragment,
            # but that fragment doesn't yet contain every edge in the
            # selection -- joining them here would close a smaller
            # sub-loop before the rest of the edges have been folded
            # in, which can only be wrong for a selection that's meant
            # to form ONE loop through all of them. Skip this pairing
            # (even though it's short) and let a later, still-valid
            # candidate join this fragment to a DIFFERENT one instead;
            # this fragment's two open ports stay free for exactly that.
            continue
        used_port.add((i, wi))
        used_port.add((j, wj))
        degree[i] += 1
        degree[j] += 1
        if ri != rj:
            parent[ri] = rj
            comp_size[rj] += comp_size[ri]
        connections.append((i, wi, j, wj))

    if len(connections) < n:
        unmatched = [i for i in range(n) if degree[i] < 2]
        raise ValueError(
            f"wire_from_edges(): even with tol={tol}, {n - len(connections)} "
            f"connection(s) couldn't be made -- edge index(es) "
            f"{sorted(set(unmatched))} (within this `edges` list, not the "
            f"original shape's own numbering) still have an unmatched end. "
            f"There's a real gap bigger than tol somewhere, or a genuinely "
            f"missing/extra edge in the selection. Try a bigger tol, or "
            f"double-check those specific edges (max_fillet-style: pull "
            f"one out at a time and see which is actually the problem).")

    # Every edge now has exactly degree 2 and the whole set forms ONE
    # cycle (the union-find bookkeeping above guarantees no smaller
    # sub-loop closed early). Never build a "reversed" copy of
    # anything, and never bridge between position_at() points directly
    # -- two earlier versions of this function tried, respectively,
    # (a) an explicit reversed-and-walked sequence handed to
    # mixed_wire(), and (b) bridging straight between position_at(0)/
    # (1) points, and BOTH were reported to still fail with every
    # computed gap around 1e-5 -- too small to be a real modeling gap,
    # but bigger than build123d's own internal stitching precision.
    # That size of residual is the signature of position_at() drifting
    # slightly from the edge's actual stored Vertex: position_at()
    # re-evaluates the edge's underlying curve at its own parametric
    # 0/1, which is USUALLY right at the vertex but can drift a small
    # real amount after an edge has been through a surface fit / trim /
    # copy -- exactly what edges from surface_from_points_grid() or
    # from a solid that's been through split()/union()/mirror() have
    # been through. So bridges here are built to the edges' own real
    # Vertex coordinates (`vends`, computed above) instead, which is
    # what build123d's own Wire.combine() actually checks against.
    # Then the ORIGINAL edges (never copied or reversed) plus just
    # those bridges go to Wire.combine() ONE more time -- the same
    # call that already correctly assembles the exact-match case at
    # the very top of this function, resolving direction/order from
    # real topology on its own.
    EXACT_TOL = 1e-6
    bridges = []
    for i, wi, j, wj in connections:
        p_i, p_j = vends[i][wi], vends[j][wj]
        if dist(p_i, p_j) > EXACT_TOL:
            bridges.append(bd.Edge.make_line(p_i, p_j))

    wires2 = bd.Wire.combine(edges + bridges)
    if len(wires2) == 1:
        return wires2[0]

    # This SHOULD be unreachable -- every bridge above closes a gap
    # this function's own matching already confirmed was within `tol`,
    # built to each edge's own real Vertex coordinates (not just a
    # re-evaluated curve point), over the SAME edges (never copied/
    # reversed/reordered) that Wire.combine() already knows how to
    # assemble correctly once nothing's missing between them. If it
    # still doesn't reduce to one wire, something more fundamental is
    # going on -- report the actual computed vertex-to-vertex gap for
    # every bridge, in the caller's own edge-list index numbers, so
    # whichever specific pair build123d still doesn't consider
    # touching is obvious instead of a bare "N separate wires".
    gaps = sorted(
        ((dist(vends[i][wi], vends[j][wj]), i, j) for i, wi, j, wj in connections),
        key=lambda t: -t[0])
    worst_desc = "; ".join(f"edges[{i}] <-> edges[{j}] = {g:.6g}" for g, i, j in gaps[:3])
    raise ValueError(
        f"wire_from_edges(): every edge matched up within tol={tol} (a "
        f"short straight bridge was added, to each edge's own real "
        f"Vertex coordinates, at every gap bigger than {EXACT_TOL}), but "
        f"build123d's own Wire.combine() still split the result into "
        f"{len(wires2)} separate wires instead of one -- this points at a "
        f"real geometric disagreement rather than a matching mistake "
        f"(e.g. two edges that only LOOK coincident from their endpoints "
        f"alone but aren't considered touching by build123d's own "
        f"stricter internal tolerance, or a genuinely non-manifold "
        f"vertex where 3+ edges meet at nearly the same point and the "
        f"wrong 2 got paired). Largest matched gaps (in "
        f"this `edges` list's own index numbers): {worst_desc}.")


def mixed_polygon(pieces):
    """
    A B-rep 2D filled polygon like polygon(), but each item in `pieces`
    can be EITHER a plain 2D/3D point ([x,y] -- a straight-line vertex,
    same as polygon()) OR a real build123d Edge (interp_spline(),
    arc_edge(), tangent_arc() output, etc) used as-is for that stretch
    of the boundary instead of a straight line -- see mixed_wire()
    above for the exact chaining rules (this is just mixed_wire(pieces)
    capped with bd.Face(), which -- unlike cap_wire() -- REQUIRES the
    resulting wire to be exactly planar; see mixed_wire()'s own
    docstring for what goes wrong if it isn't and how to route around
    it with mixed_wire()+cap_wire() instead).

    The main use: swapping out a heavily-faceted arc_3p(...)-built
    curve (many short straight edges -- see arc_3p()'s own `s=`
    parameter) for ONE real curved Edge, when the rest of the profile
    should stay sharp-cornered -- e.g. instead of
    `arc_3p(p1, p2, p3, s=30) + [c1, c2]` (a ~30-point faceted arc
    plus 2 straight corners, all straight edges once polygon()-ed),
    use `[interp_spline([p1, p2, p3]), c1, c2]` here: same overall
    profile shape, but the curved portion becomes a single smooth Edge
    -- and that's ~29 fewer edges once extruded/booleaned.

        curve = interp_spline([[10, 0], [0, 50], [10, 100]])
        sec = mixed_polygon([curve, [-10, 100], [-10, 0]])
        show(linear_extrude(sec, 10))

    Raises if `pieces` doesn't chain up into exactly one closed loop
    (e.g. a given Edge points the wrong way, or there's a real gap).
    """
    _require_build123d()
    return bd.Face(mixed_wire(pieces))


def c_polygon(s1,pitch=0.1,interpolation=1):
    """
    A filled Face from a rough, unevenly-spaced closed point list --
    smoothed and evened out first, unlike polygon()/mixed_polygon()
    (straight segments exactly through the given points, however
    unevenly they're spaced). Two steps under the hood:

    1. o.homogenise(s1, pitch, 1) (the opt-in openscad4 bridge -- see
       the module docstring) re-samples `s1` to a fine, EVEN `pitch`
       (default 0.1) around the closed loop, so a boundary with long
       straight runs and tight clustered corners (e.g. raw output
       from a CAD import, or a coarse hand-picked outline) gets
       uniform point density before it's fit with a curve. Lower
       `pitch` = more points = a closer-fitting spline but slower --
       raise it for a coarse `s1` where extra smoothness isn't
       needed.
    2. interp_spline(..., 1) fits one true closed (periodic) spline
       exactly through those resampled points (see interp_spline()
       above), and cap_wire() fills that spline boundary as a real
       Face.

    The result is a smooth, rounded-corner face that follows `s1`'s
    general shape without polygon()'s straight-segment faceting --
    reach for this instead of polygon()/mixed_polygon() when `s1` is
    a rough/organic outline you want smoothed rather than traced
    exactly, e.g.:

        s1 = [[0, 0], [40, 5], [45, 30], [10, 40], [-5, 15]]
        show(linear_extrude(c_polygon(s1), 5))

    Note the extra pass through openscad4 makes this noticeably
    slower than polygon() for large point counts -- prefer polygon()/
    mixed_polygon() when `s1` is already the exact boundary you want.
    """
    import openscad4 as o
    if interpolation == 0:
        sol = mixed_polygon(s1)
    elif interpolation == 1:
        sol = cap_wire(interp_spline(o.homogenise(s1, pitch, 1), 1))
    return sol


def solid_line_vector(sol, vec, both=0):
    """
    A straight prism/beam solid along `vec`, built by lofting between
    two translated copies of the 2D cross-section (build123d
    Sketch/Wire) `sol` -- native build123d translate()/loft(), no
    point-list conversion or c_polygon() smoothing involved.

    `both=0` (the default): the solid runs from `sol` itself (at the
    origin end, i.e. `vec * 0`) to `sol` translated by the FULL `vec`
    -- a one-directional prism of length |vec|.

    `both=1`: the solid runs from `sol` translated by `+vec` to `sol`
    translated by `-vec` instead -- centered ON `sol`'s own position
    rather than starting there, twice as long (2*|vec|) as the
    `both=0` case for the same `vec`. Handy for cutting a groove/slot
    THROUGH a shape along `vec` and out both sides, without having to
    work out the two translated copies by hand -- see
    14_wall_hook_dome_groove.py's own groove cut for the
    hand-rolled version of exactly this pattern
    (`loft([translate([0, i, 0], l2) for i in [-30, 30]])`), which this
    function generalizes.

        sol = circle(5)
        beam = solid_line_vector(sol, [0, 0, 40], both=1)
        show(beam)  # a prism running 40 up AND 40 down from sol
    """
    if both == 0:
        return loft([translate(np.array(vec) * i, sol) for i in [0, 1]])
    elif both == 1:
        return loft([translate(np.array(vec) * i, sol) for i in [1, -1]])


def c_solid(s1, planarize=True):
    """
    A solid lofted through an explicit LIST of cross-sections, each
    given as a raw mixed_polygon()-style piece list rather than an
    already-built Face -- the "many independent sections" counterpart
    to solid_line_vector() above (which pushes a SINGLE section along
    one vector) and the mixed_polygon()-based counterpart to
    c_polygon()-driven lofts (which smooth a rough/organic outline
    instead of tracing it exactly).

    `s1` is a list of cross-sections; each item `p` in it is itself a
    list of plain 2D/3D points and/or real build123d Edges -- exactly
    what mixed_polygon() takes (straight lines between consecutive
    points, any given Edge dropped in as-is for that stretch of the
    boundary) -- see mixed_polygon()'s own docstring for the full
    rules, including that each `p` must chain into exactly one closed
    loop or mixed_polygon() raises. Each section needs to already be
    positioned where it belongs, same requirement as loft()'s own
    sections -- but since `p` is a raw POINT list here, not a Face yet,
    that means shifting the points themselves (plain Python/numpy math,
    or the openscad4 bridge's o.translate(), which -- unlike brep.py's
    own translate()/rotate(), which only operate on already-built
    Shapes -- works directly on raw point lists like these).

    Under the hood this is just `loft([mixed_polygon(p) for p in s1])`
    -- a straight-edged Face per section, smoothly lofted (loft()'s
    default `ruled=False`) between them. If you need a piecewise-
    straight ("ruled") loft instead, or want to mix mixed_polygon()
    sections with sections built some other way, skip c_solid() and
    call `loft(*faces, ruled=True)` directly -- c_solid() always uses
    the smooth default and always builds every section via
    mixed_polygon().

        diamond = [[10, 0], [0, 10], [-10, 0], [0, -10]]
        square = [[7, 7], [-7, 7], [-7, -7], [7, -7]]
        at_z = lambda pts, z: [[x, y, z] for x, y in pts]
        rings = [at_z(diamond, 0), at_z(square, 15), at_z(diamond, 25)]
        show(c_solid(rings))

    With planarize=True (the default), each section that's a plain
    point list (no Edge mixed in) is first run through
    planarize_ring() -- projected onto its own best-fit plane, see that
    function's own docstring -- before mixed_polygon() is tried, so a
    section that's only a fraction of a unit out of plane (independently
    computed points drifting station to station, same real case
    solid_from_wedge_grid() handles) still builds instead of raising
    "wires not planar". A section containing a real Edge is left
    untouched either way (planarize_ring() can't project an Edge's own
    control points the same way a plain point does, so it's skipped
    automatically -- not something you need to steer around by hand).
    Pass planarize=False to restore the old always-exact behavior.
    """
    _require_build123d()
    def _maybe_planarize(p):
        if not planarize:
            return p
        try:
            return planarize_ring(p)
        except Exception:
            return p  # contains a real Edge or other non-point item -- leave as-is
    return loft([mixed_polygon(_maybe_planarize(p)) for p in s1])


def s_int1(points, closed=True):
    """
    Every point where the segments of a 2D point-list loop cross
    themselves -- openscad4.py's own s_int1(), ported: e.g. run this on
    an inward offset() of a sharp-cornered profile to find where the
    offset has crossed itself (gone invalid). Checks every pair of
    non-adjacent segments for a PROPER crossing (both segments' own
    interior, not just their infinite extensions -- see i_p2d() for
    that unclipped version) and returns the list of actual crossing
    points. `closed=True` (default) also checks the closing segment
    from the last point back to the first, same as polygon()'s own
    convention; `closed=False` treats `points` as an open polyline.
    """
    pts = [(float(p[0]), float(p[1])) for p in points]
    n = len(pts)
    if n < 3:
        return []
    edges = list(zip(pts, pts[1:])) + ([(pts[-1], pts[0])] if closed else [])
    m = len(edges)
    out = []
    for i in range(m):
        for j in range(i + 1, m):
            if j == i + 1 or (closed and i == 0 and j == m - 1):
                continue
            (x1, y1), (x2, y2) = edges[i]
            (x3, y3), (x4, y4) = edges[j]
            denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
            if abs(denom) < 1e-12:
                continue
            t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom
            u = ((x1 - x3) * (y1 - y2) - (y1 - y3) * (x1 - x2)) / denom
            if 1e-9 < t < 1 - 1e-9 and 1e-9 < u < 1 - 1e-9:
                out.append([x1 + t * (x2 - x1), y1 + t * (y2 - y1)])
    return out


def project_curve_on_face(curve, target, direction, closest=True):
    """
    Projects `curve` (a real build123d Edge/Wire, e.g. from
    interp_spline()/turtle3d()+a helper, or `shape.edges()[i]`) onto
    `target` (a Face/Solid -- e.g. `some_solid.faces()[0]`) along
    `direction` ([x,y,z]) -- exact B-rep projection, computed by OCCT
    (build123d's own Edge/Wire.project()), not a nearest-point search
    over a triangulated approximation. For projecting a raw point list
    or point grid instead of an actual curve, see psos() below.

    `closest=True` (default) returns the single nearest result if the
    curve's shadow lands on the target more than once; `closest=False`
    returns every hit (a list).
    """
    _require_build123d()
    return curve.project(target, tuple(float(c) for c in direction), closest=bool(closest))


def project_face_on_shape(face, target, direction):
    """
    Projects a whole Face (or every face of a Solid/Shape) onto
    `target` (a Face/Solid) along `direction` ([x,y,z]) -- extends
    project_curve_on_face()'s same idea (exact B-rep projection,
    computed by OCCT, no sampling) up one dimension, from a single
    curve to an entire surface. Uses build123d's own native
    Face.project_to_shape(): `face` is swept along `direction` far
    enough to clear `target` entirely, then intersected with it --
    unlike psos()+surface_from_points_grid() (project a raw point
    grid, then fit a NURBS surface back through the results), this
    returns the REAL projected Face(s)/Shell(s) directly, exact, with
    no sampling or fitting step at all.

        a = sphere(10)
        b = plane([0, 0, 1], [50, 50])
        c = project_face_on_shape(a, b, [0, 0, 1])
        show(a, alpha=0.2)
        show(color(c, "cyan"))

    `face`: a real Face (circle()/polygon()/a shape's own
        `.faces()[i]`), OR any Shape with `.faces()` (e.g. a Solid
        like sphere()/box()'s output) -- every one of its faces is
        projected in turn and all results combined into one list.
    `target`: the real Face/Solid to project onto.

    Returns a list of the projected Face(s)/Shell(s) -- there can be
    more than one per source face (e.g. the "front" and "back" of a
    closed target Solid both catch a projection); faces that would
    land "behind" the projection direction are never returned.
    """
    _require_build123d()
    d = tuple(float(c) for c in direction)
    faces = face.faces() if hasattr(face, "faces") else [face]
    out = []
    for f in faces:
        out.extend(f.project_to_shape(target, d))
    return out


def psos(points, target, direction, dist=None, unidirection=True):
    """
    Projects a raw point list or point grid onto a real target Face or
    Solid along `direction` -- openscad4.py's own psos() family
    (psos/psos_v/psos_n/psos_v_1/psos_v_2/psos_n_b, ~10 near-duplicate
    variants total), collapsed into ONE real B-rep function instead of
    ported literally. The originals all triangulate `target` into a
    mesh first (several different triangulation helpers depending on
    the shape's topology -- open/closed/donut-like/etc), then do
    manual ray-triangle intersection math (numpy) to find where each
    point's projection ray crosses that triangle soup -- real, working
    code, but the exact kind of mesh-native machinery this app has
    consistently avoided (see concave_hull()'s own drop for the same
    reasoning). None of that triangulation is needed here: build123d's
    own Face.find_intersection_points(axis) answers "where does this
    ray hit the real surface" EXACTLY, against the actual analytic/
    NURBS geometry, no faceting step at all. For projecting a real
    curve/Edge instead of raw points, see project_curve_on_face()
    above; for projecting a whole real Face/Shape (not points sampled
    off one), see project_face_on_shape() above -- exact there too,
    with no point grid or NURBS re-fit involved at all.

    `points`: a flat [[x,y,z], ...] list, OR a 2D grid ([[[x,y,z],
        ...], ...], a "surface" the same shape openscad4.py's own
        psos() `s3` argument took) -- either way every point is
        projected independently and the result comes back in the
        exact same shape/nesting `points` was given in.
    `target`: the real Face (or Solid -- all its faces are tried) to
        project onto.
    `direction`: the projection direction ([x,y,z]), the same vector
        for every point.
    `dist`: the maximum projection distance -- a point whose nearest
        hit is farther than this, or that never hits `target` at all,
        is left unmoved at its original position (same "don't lose
        the original points" fallback openscad4.py's psos() used).
        None (default) means no distance limit.
    `unidirection`: True (default) only projects forward along
        `direction`; False also considers hits found going backward
        (openscad4.py's unidirection=0). Either way, the single
        CLOSEST valid hit is used per point.

        pts = [[x, y, 0] for x in range(-10, 11, 2) for y in range(-10, 11, 2)]
        target = sphere(20)
        projected = psos(pts, target, [0, 0, -1])
        show(target, alpha=0.3)
        show(color(points(projected, .3), "cyan"))
    """
    _require_build123d()
    is_grid = len(points) > 0 and isinstance(points[0][0], (list, tuple))
    rows = points if is_grid else [points]
    d = tuple(float(c) for c in direction)
    dlen = math.sqrt(sum(c * c for c in d))
    if dlen < 1e-12:
        raise ValueError("psos(): direction must be nonzero")
    du = tuple(c / dlen for c in d)
    faces = target.faces() if hasattr(target, "faces") else [target]

    def _project_one(p):
        p3 = (float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0)
        axis = bd.Axis(p3, d)
        best = None
        for f in faces:
            for hit_pt, _hit_normal in f.find_intersection_points(axis):
                delta = (hit_pt.X - p3[0], hit_pt.Y - p3[1], hit_pt.Z - p3[2])
                signed = delta[0] * du[0] + delta[1] * du[1] + delta[2] * du[2]
                if unidirection and signed < -1e-9:
                    continue
                distance = abs(signed)
                if dist is not None and distance > float(dist):
                    continue
                if best is None or distance < best[0]:
                    best = (distance, [hit_pt.X, hit_pt.Y, hit_pt.Z])
        return best[1] if best is not None else list(p3)

    out_rows = [[_project_one(p) for p in row] for row in rows]
    return out_rows if is_grid else out_rows[0]


def tangent_arc(a, b, radius, side=0):
    """
    A circular arc of `radius`, tangent to both `a` and `b`, where each
    of `a`/`b` is either a real build123d Edge (e.g. `circle(5).edges()[0]`
    for a circle, or a straight Edge for a line) or a raw 2-point line
    `[[x1,y1],[x2,y2]]`/`[[x1,y1,z1],[x2,y2,z2]]` (auto-built into a
    line Edge for you). Covers openscad4.py's whole tangent-construction
    family in one call -- two_cir_tarc() (circle-circle), two_cir_tarc_
    internal(), fillet_line_circle()/fillet_line_circle_internal()
    (line-circle) -- since build123d's own native ConstrainedArcs solves
    all of these the same way regardless of what `a`/`b` are, there's no
    need for openscad4.py's four separate hand-rolled trig functions.

        c1 = circle(10).edges()[0]
        c2 = translate([20, 0, 0], circle(6)).edges()[0]
        show(show_edges([tangent_arc(c1, c2, radius=4)]))

    There are usually 2 valid tangent arcs for a given radius/side
    pair -- `side` (0 or 1) picks between them; if only one exists,
    `side` is ignored. `radius` is a real geometric constraint, not
    just a style knob: too small to bridge the gap between `a` and `b`
    and no tangent arc exists at all -- for two circles of radius
    r1/r2 whose centers are `d` apart, a fillet nestled between them
    needs roughly radius >= (d - r1 - r2) / 2 at minimum. Raises a
    clear error (not a cryptic one) if that happens.
    """
    _require_build123d()

    def _as_edge(x):
        if not isinstance(x, (list, tuple)):
            return x  # already a real build123d Edge
        pts = _flatten_points(x)
        if len(pts) != 2:
            raise ValueError("tangent_arc(): a raw line must be exactly 2 points")
        p0 = pts[0] + (0.0,) * (3 - len(pts[0]))
        p1 = pts[1] + (0.0,) * (3 - len(pts[1]))
        return bd.Edge.make_line(p0, p1)

    e1, e2 = _as_edge(a), _as_edge(b)
    try:
        arcs = bd.ConstrainedArcs(e1, e2, radius=float(radius), sagitta=bd.Sagitta.BOTH)
        arc_list = list(arcs.edges()) if hasattr(arcs, "edges") else list(arcs)
    except Exception as exc:
        raise ValueError(
            f"tangent_arc(): no arc of radius {radius} is tangent to both given "
            f"edges ({exc}). This is a real geometric constraint, not a bug -- "
            f"most commonly `radius` is too SMALL to bridge the gap between `a` "
            f"and `b` (for two circles of radius r1/r2 whose centers are `d` "
            f"apart, a fillet nestled between them needs roughly "
            f"radius >= (d - r1 - r2) / 2 at minimum). Try a larger radius, or "
            f"move `a`/`b` closer together."
        ) from exc
    if not arc_list:
        raise ValueError(f"tangent_arc(): no arc of radius {radius} is tangent to both given edges")
    return arc_list[int(side) % len(arc_list)]


def _flatten(shapes):
    """internal: lets union(a,b,c) and union([a,b,c]) both work."""
    out = []
    for s in shapes:
        if isinstance(s, (list, tuple)):
            out.extend(_flatten(s))
        else:
            out.append(s)
    return out


def volume(shape):
    """
    The shape's EXACT enclosed volume, computed by OCCT from the real
    B-rep geometry -- not a discrete/mesh estimate like the divergence-
    theorem-over-triangles trick used to sanity-check mcm()/
    repair_mesh() output elsewhere in this project. Useful as a ground-
    truth check if you ever want to compare a B-rep shape's true volume
    against a mesh reconstruction of "the same" shape.
    """
    _require_build123d()
    return shape.volume


def area(shape):
    """
    The shape's total surface area (every face's area, summed) --
    build123d's own `shape.area`, exposed here as a plain function to
    match volume()'s own convention (`volume(shape)` -> `shape.volume`,
    `area(shape)` -> `shape.area`).

    This is the shape's REAL surface area, not its "shadow" -- a
    curved or folded surface's own area is always >= the area of the
    flat outline it casts when viewed from any one direction; those
    only coincide for a flat face viewed exactly head-on. For that
    "shadow" instead, see projected_area() below.
    """
    _require_build123d()
    return shape.area


def _stitch_loops_fast(segs, tol=1e-4):
    """internal, used only by projected_area(): stitches a flat list of
    2-point segments into closed loops, same endpoint-matching contract
    as contiguous_chains() (snap each point to a grid of spacing `tol`,
    weld matching endpoints together; first point of a genuinely closed
    result equals its own last point) -- but via a hash-map endpoint
    lookup instead of contiguous_chains()'s own linear scan over
    whatever's still unmatched at each step.

    That difference matters a lot here specifically: contiguous_chains()
    (shared by two_solids_intersection() and others) is O(n^2) in the
    number of segments, fine for the modest segment counts its other
    callers deal with, but a REAL, reported hang on complex geometry --
    projected_area() can end up with many thousands of sampled segments
    (lots of visible edges x n_samples each), and a Python-level O(n^2)
    loop over thousands of items is genuinely minutes of pure CPU, not
    a "still computing" progress bar; the app's own kernel subprocess
    has no way to show progress mid-script, so all a stuck user sees is
    a render that "never" finishes. This is a dedicated O(n) (amortized)
    replacement scoped ONLY to projected_area()'s own call site --
    contiguous_chains()/its own _chain_segments() helper are left
    completely untouched, so nothing else in this app changes behavior.

    `tol`: the absolute welding distance -- 2 endpoints match iff they
    land in the same `tol`-wide grid cell (used to be a fixed `round(p,
    4)` -- i.e. a hardcoded 0.0001 -- until a real customer STEP import
    (a complex machined bracket) showed just how easily that fixed
    absolute value can be too tight: HLR's own project_to_viewport()
    evaluates each visible edge's endpoints independently (including at
    edges HLR itself split mid-curve at a visibility transition), and
    the floating-point noise that piles up through that transform
    naturally scales with the MODEL's own coordinate magnitudes, not a
    universal constant -- projected_area() now derives `tol` from the
    shape's own bounding-box diagonal instead of hardcoding it (see its
    own `weld_tol` parameter).

    Returns a list of point loops, same shape as contiguous_chains()'s
    own return value.
    """
    def key(p):
        return (round(p[0] / tol), round(p[1] / tol))

    # endpoint key -> [(seg_index, which_end), ...] still available to
    # extend a chain from -- a plain list-as-stack per key, entries for
    # already-used segments are lazily discarded as they're encountered
    ends = {}
    for i, (p0, p1) in enumerate(segs):
        ends.setdefault(key(p0), []).append((i, 0))
        ends.setdefault(key(p1), []).append((i, 1))

    used = [False] * len(segs)

    def pop_match(k):
        bucket = ends.get(k)
        if not bucket:
            return None
        while bucket:
            i, end = bucket.pop()
            if not used[i]:
                return i, end
        return None

    loops = []
    for start in range(len(segs)):
        if used[start]:
            continue
        used[start] = True
        chain = [segs[start][0], segs[start][1]]

        while True:
            nxt = pop_match(key(chain[-1]))
            if nxt is None:
                break
            i, end = nxt
            used[i] = True
            a, b = segs[i]
            chain.append(b if end == 0 else a)  # the OTHER end of the matched segment

        while True:
            nxt = pop_match(key(chain[0]))
            if nxt is None:
                break
            i, end = nxt
            used[i] = True
            a, b = segs[i]
            chain.insert(0, b if end == 0 else a)

        loops.append(chain)

    return loops


def projected_area(shape, direction, n_samples=16, strict=True, weld_tol=None):
    """
    The area of the "shadow" `shape` would cast on a screen
    perpendicular to `direction` -- its silhouette area as seen
    looking straight along `direction`, NOT its real surface area (see
    area() above for that; they're only equal for a flat face viewed
    head-on). `direction`: [x, y, z], the direction you're looking
    ALONG (e.g. [0, 0, -1] to see the shape from above, looking down).

    Built on the SAME hidden-line-removal this app's own
    technical_drawing_views() uses for engineering drawings
    (Shape.project_to_viewport(), OCCT's real HLRBRep_Algo) rather
    than a boolean union of every face's own individual projection.
    That alternative -- project() every face onto one flat target
    plane, then union() the results to avoid double-counting overlaps
    -- sounds simpler, but every one of those projected faces would
    land on the exact same plane, and union()'s own docstring
    documents a CONFIRMED real OCCT fragility fusing large, exactly
    coplanar shapes (`AttributeError: 'NoneType' object has no
    attribute 'NbNodes'`) -- precisely what that approach guarantees
    on every call. Using HLR instead sidesteps that risk entirely:
    project_to_viewport() already resolves true visibility (which
    parts of the shape are actually visible from `direction`,
    correctly leaving a genuine hole in the silhouette where the shape
    is actually hollow from that view, never double-counting a near/
    far surface pair), so this just samples the VISIBLE edges it
    returns into 2D polylines (same position_at(t) sampling
    _hlr_polylines() uses, but skipping the sampling entirely on
    straight edges -- their own 2 endpoints already describe them
    exactly), stitches them into closed loops with the O(n)
    _stitch_loops_fast() (NOT this app's shared contiguous_chains(),
    which is O(n^2) and a real, reported hang on complex geometry --
    see _stitch_loops_fast()'s own docstring), and sums each loop's
    own area.

    Silhouette loops from HLR can legitimately nest (an outer boundary
    plus one or more hole boundaries, e.g. a flange's own bolt holes,
    or a pipe/torus viewed straight down its axis) -- but a raw edge's
    own parametric direction has no reliable relationship to whether
    it's tracing an outer boundary or a hole from THIS particular
    view, so this does NOT just add up each loop's own signed shoelace
    area and trust the sign (that would only work if every loop's
    winding direction reliably meant the same thing, which isn't a
    safe assumption for arbitrary HLR edges). Instead each loop's
    UNSIGNED area is added or subtracted based on actual geometric
    nesting depth (point_in_polygon() against every other loop,
    standard even-odd fill rule: contained in an even number of other
    loops -- 0, 2, 4, ... -- counts as solid material; an odd number
    means it's a hole, or a hole inside a boss inside a hole, etc.),
    which is correct regardless of any individual edge's own winding.

    `n_samples` controls how finely curved visible edges are sampled
    into polyline points before computing area -- same tradeoff as
    technical_drawing_views()'s own `n_samples` (higher = smoother
    curves = more accurate area on anything that isn't all straight
    edges, at the cost of more sampling work).

    `strict` (default True): raises ValueError if any of the visible-
    edge chains _stitch_loops_fast() built didn't actually stitch back
    into a CLOSED loop (its own first and last point coinciding) --
    REAL BUG FIX (user report: projected_area() on a complex organic
    part -- a steering wheel, multiple spokes/blended surfaces -- came
    back roughly 1/3 of the true manually-computed minimum area). The
    loop-building step used to accept ANY chain with >= 3 points,
    closed or not, straight into the area sum -- an OPEN chain has no
    real "enclosed area" at all; folding it into the shoelace formula
    anyway implicitly closes it with a straight line from its last
    point back to its first, which has nothing to do with the actual
    shape's boundary and can make the total badly wrong in either
    direction (usually an undercount in practice, since the same
    numerical fragmentation that broke one loop into several open
    pieces tends to scatter the true boundary's own area across those
    pieces' bogus closing-line contributions rather than the real
    silhouette). This false-closure fabrication is now never done: a
    chain has to genuinely close before it's treated as a polygon at
    all. Complex organic/heavily-blended geometry (lots of curved
    surfaces meeting at shared vertices) is exactly where a handful of
    edges can fail to weld under the stitcher's own coordinate-rounding
    match (see _stitch_loops_fast()'s own docstring) -- when that
    happens, `strict=True` raises rather than silently returning a
    number that LOOKS plausible but may have entire real regions of the
    silhouette dropped or double-counted; the error message reports how
    much unstitched edge length was found. Pass `strict=False` only if
    you specifically want the old best-effort behavior back (excluding
    the open chains from the sum, same as `strict=True` computes
    internally, just without raising) -- e.g. for a quick approximate
    number on a model you already know has imperfect geometry.

    `weld_tol`: how close 2 sampled endpoints need to be (in `shape`'s
    own units) to be treated as the SAME point when stitching visible
    edges back into loops (see _stitch_loops_fast()'s own `tol`).
    `None` (the default) derives it from `shape`'s own bounding-box
    diagonal (roughly diagonal * 1e-5, floored at 1e-6) rather than a
    fixed constant -- ANOTHER REAL FIX from that same customer STEP
    import: even after the `strict` fix above stopped silently
    fabricating area from open chains, that model's own visible edges
    still failed to weld into closed loops at all (hundreds of open
    chains, `strict=True` correctly raising every time) under the OLD
    hardcoded 0.0001 absolute tolerance -- a real STEP import from
    another CAD system, combined with OCCT's own HLR splitting edges at
    visibility transitions (position_at() evaluated independently on
    each resulting piece), can easily accumulate more floating-point
    noise than that at a shared vertex, and that noise naturally scales
    with the model's own coordinate magnitudes (a large part's
    transform pipeline has more room for it than a small one) -- a
    fixed constant can't track that, but `diag`-relative can. Pass this
    explicitly (try something a bit looser, e.g. 10x the auto value) if
    `strict=True` still raises with the default; going too loose risks
    welding 2 genuinely DIFFERENT nearby points together instead
    (silently wrong topology, no error) -- so widen it gradually rather
    than jumping straight to something huge.
    """
    _require_build123d()
    d = [float(c) for c in direction]
    dlen = math.sqrt(sum(c * c for c in d))
    if dlen < 1e-12:
        raise ValueError("projected_area(): direction can't be the zero vector")
    d = [c / dlen for c in d]

    # CONFIRMED real cause (real user report, a multi-body automotive STEP
    # import): a COMPOUND of several separate solids that merely TOUCH --
    # e.g. a cast bracket + ribs/bosses modeled as their own bodies in the
    # source CAD assembly, never boolean-fused into one -- has REAL,
    # independent boundary edges running along every seam where 2 solids
    # meet, even though that seam is genuinely interior material once you
    # look at the assembly as a whole. HLR doesn't know to erase those
    # (that's exactly what union() does, and this compound was never
    # union()'d), so the "visible edges" set can include redundant/
    # near-but-not-quite-coincident edges from BOTH touching solids at
    # every seam -- exactly the kind of persistent stitching fragmentation
    # NO weld tolerance can fix (see weld_tol's own docstring for the
    # noise-vs-structural distinction), since it isn't noise, it's real
    # (if redundant) topology. Counted here, best-effort, just so the
    # `strict=True` error below can name this directly instead of leaving
    # the only lead as "try a looser weld_tol", which alone won't help.
    try:
        n_solids = len(shape.solids())
    except Exception:
        n_solids = None

    bbox = shape.bounding_box()
    cx, cy, cz = (bbox.min.X + bbox.max.X) / 2.0, (bbox.min.Y + bbox.max.Y) / 2.0, (bbox.min.Z + bbox.max.Z) / 2.0
    diag = math.sqrt(
        (bbox.max.X - bbox.min.X) ** 2 + (bbox.max.Y - bbox.min.Y) ** 2 + (bbox.max.Z - bbox.min.Z) ** 2
    )
    tol = weld_tol if weld_tol is not None else max(diag * 1e-5, 1e-6)  # see this function's own `weld_tol` docstring
    dist = max(diag * 10.0, 100.0)  # far enough for a near-orthographic view, same convention as _drawing_view_directions()
    origin = (cx - d[0] * dist, cy - d[1] * dist, cz - d[2] * dist)
    up = (0.0, 0.0, 1.0) if abs(d[2]) < 0.9 else (0.0, 1.0, 0.0)  # anything not parallel to `d`

    try:
        visible, _hidden = shape.project_to_viewport(
            viewport_origin=origin, viewport_up=up, look_at=(cx, cy, cz))
    except AttributeError as e:
        raise ImportError(
            "projected_area(): this build123d install doesn't have "
            "Shape.project_to_viewport() (added in a newer build123d release "
            "than this app was written against) -- try `pip install -U "
            f"build123d`. (original error: {e})")

    segs = []
    for e in visible:
        # straight edges don't need subdividing -- their own 2 endpoints
        # already describe them exactly, and skipping the extra samples
        # matters a LOT on a part that's mostly straight edges (most
        # prismatic/machined parts are): every sample point not taken is
        # one less segment for the O(n) stitching pass below to chew
        # through. Falls back to full n_samples sampling for anything
        # this build123d install doesn't recognize the geom_type of
        # (older installs, or a genuinely exotic curve type) -- slower,
        # not wrong.
        try:
            is_line = e.geom_type == bd.GeomType.LINE
        except Exception:
            is_line = False
        n = 2 if is_line else n_samples + 1
        pts = [e.position_at(k / (n - 1)) for k in range(n)]
        for p0, p1 in zip(pts, pts[1:]):
            segs.append([[p0.X, p0.Y], [p1.X, p1.Y]])
    if not segs:
        return 0.0

    def _pt_eq(p0, p1):
        return math.hypot(p0[0] - p1[0], p0[1] - p1[1]) <= tol

    polys = []
    open_chains = 0
    open_chain_len = 0.0
    for loop in _stitch_loops_fast(segs, tol=tol):
        is_closed = len(loop) > 1 and _pt_eq(loop[0], loop[-1])
        if not is_closed:
            # NEVER fold an open chain into the area sum -- see this
            # function's own docstring (`strict`) for exactly why: it has
            # no real enclosed area, and pretending it does (by implicitly
            # closing it with a straight line back to its own start, which
            # is all the shoelace formula below would otherwise do) can
            # make the total badly wrong. Just tally how much went missing
            # so `strict=True` can report something actionable below.
            open_chains += 1
            open_chain_len += sum(
                math.hypot(loop[k + 1][0] - loop[k][0], loop[k + 1][1] - loop[k][1])
                for k in range(len(loop) - 1)
            )
            continue
        pts = loop[:-1]
        if len(pts) >= 3:
            polys.append(pts)
    if open_chains and strict:
        multi_solid_hint = ""
        if n_solids is not None and n_solids > 1:
            multi_solid_hint = (
                f"\n\nLIKELY CAUSE: this shape has {n_solids} separate solids, not one "
                f"fused body (a compound like this is common straight out of a STEP "
                f"import -- an assembly of parts modeled as their own bodies, e.g. a "
                f"cast bracket plus ribs/bosses that only TOUCH in the final assembly, "
                f"never boolean-fused into one). Every seam where 2 solids merely touch "
                f"has REAL boundary edges from BOTH solids independently -- edges that "
                f"are genuinely interior material once you look at the assembly as a "
                f"whole, but HLR doesn't know that (only union() actually erases them). "
                f"No weld_tol can fix this -- it isn't numerical noise, it's real "
                f"(redundant) topology. Try fusing the solids first:\n"
                f"    fused = union(*shape.solids())\n"
                f"    projected_area(fused, direction)\n"
                f"(union() can itself fail on tricky touching-but-not-quite-coincident "
                f"geometry -- see its own docstring -- but this is the real fix if it "
                f"succeeds, not a tolerance workaround.)"
            )
        raise ValueError(
            f"projected_area(): {open_chains} of this view's visible-edge chain(s) "
            f"never stitched back into a closed loop (~{open_chain_len:.3g} units of "
            f"unclosed boundary total, weld_tol={tol:.3g} used) -- refusing to guess "
            f"an area from that, since treating an open chain as if it were closed "
            f"can make the total badly wrong (see this function's own `strict` "
            f"docstring)."
            + multi_solid_hint +
            f"\n\nIf this ISN'T a multi-solid shape (or fusing it doesn't fully help), "
            f"this is more likely numerical fragmentation -- a few sampled edge "
            f"endpoints that SHOULD coincide landing just far enough apart that they "
            f"don't match at this tolerance -- try passing a LOOSER weld_tol explicitly "
            f"(e.g. {tol * 10:.3g} or {tol * 100:.3g}) first; a higher n_samples can "
            f"also help but only for curved edges specifically (see weld_tol's own "
            f"docstring for the risk of going too loose). Pass strict=False for a "
            f"best-effort number (excludes the unclosed chains rather than raising) if "
            f"you just need an approximate figure on a model you know has imperfect "
            f"geometry."
        )
    if not polys:
        return 0.0

    def _unsigned_area(pts):
        n = len(pts)
        s = sum(pts[i][0] * pts[(i + 1) % n][1] - pts[(i + 1) % n][0] * pts[i][1] for i in range(n))
        return abs(s) / 2.0

    # REAL BUG FIX (user report: projected_area() "still not happening
    # and it keeps rendering indefinitely" even after _stitch_loops_fast()
    # -- see that function's own docstring -- had already fixed the
    # segment-stitching step above). _stitch_loops_fast() only fixed
    # building the LOOPS; this nesting-depth pass, which decides which
    # loops are holes by testing each loop's own representative point
    # against every OTHER loop with point_in_polygon() (itself an
    # O(len(other)) ray-cast over every vertex of `other`), was still
    # the original O(loops^2 * points-per-loop) approach -- a SEPARATE
    # hotspot _stitch_loops_fast() never touched. On complex/HLR-heavy
    # geometry (many small holes/fillets, each becoming its own loop)
    # loops^2 alone can reach the hundreds of thousands to millions, and
    # each of those pays a full per-vertex ray-cast on top -- genuinely
    # unbounded runtime, not "still computing".
    #
    # Fixed with a cheap O(1) bounding-box reject before ever calling
    # point_in_polygon(): a point can't be inside a polygon it isn't even
    # inside the bounding box of, so this only pays the real per-vertex
    # ray-cast for loop pairs whose boxes actually overlap -- for any
    # real part (e.g. a flange with a dozen bolt holes: each hole's own
    # bbox overlaps the outer boundary's, but not any OTHER hole's), that
    # is a small fraction of all loops^2 pairs. Turns the common case
    # from O(loops^2 * points) into O(loops^2) (cheap) plus a genuine
    # O(points) ray-cast only where two loops could plausibly nest.
    def _bbox(pts):
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        return min(xs), min(ys), max(xs), max(ys)

    bboxes = [_bbox(p) for p in polys]

    total = 0.0
    for i, poly in enumerate(polys):
        rep = poly[0]  # a vertex of `poly` itself -- only ever tested against OTHER loops below
        rx, ry = rep[0], rep[1]
        depth = 0
        for j, other in enumerate(polys):
            if j == i:
                continue
            bx0, by0, bx1, by1 = bboxes[j]
            if rx < bx0 or rx > bx1 or ry < by0 or ry > by1:
                continue  # can't be inside `other` if it's outside `other`'s own bbox
            if point_in_polygon(rep, other):
                depth += 1
        a = _unsigned_area(poly)
        total += -a if depth % 2 == 1 else a
    return total


def projected_area_mesh(shape, direction, resolution=600, tolerance=0.1, angular_tolerance=0.3):
    """
    A ROBUST fallback for projected_area() -- reach for this one when
    THAT one is too slow or genuinely hangs on a particular shape.

    REAL, CONFIRMED motivation (real customer STEP part): projected_area()
    (built on OCCT's own Shape.project_to_viewport() hidden-line-removal
    -- see its own docstring) was still taking 30+ minutes / never
    finishing on a real automotive bracket even AFTER union()-ing its 5
    originally-separate solids into one -- and that fused shape had only
    39 faces, ruling out "just too many faces/edges" as the explanation.
    That points at OCCT's own HLR algorithm having a genuine pathological
    slowdown on this shape's specific geometry (near-tangent surfaces,
    an ill-conditioned trim curve from the union, etc.) -- something NO
    amount of pre/post-processing in projected_area()'s own Python code
    can fix, since it happens inside OCCT's own C++ implementation, with
    no way to safely interrupt it short of killing the whole process
    (see kernel_manager.py's restart() for why THAT'S the only thing
    that reliably works on a truly stuck native call).

    This sidesteps project_to_viewport() entirely -- it never calls it,
    so it can't inherit its fragility. Instead it uses the SAME
    tessellation pipeline the 3D viewer already displays this exact
    shape with just fine (to_mesh() -- if show() renders it, this can
    tessellate it): every triangle gets projected onto a 2D plane
    perpendicular to `direction`, then rasterized onto a `resolution` x
    `resolution` grid covering the projected bounding box. A grid cell
    counts as covered the instant ANY triangle overlaps it -- boolean,
    not additive -- which handles occlusion/overlap for free: a near
    surface and a far surface covering the same 2D region (or two
    triangles from the same curved face overlapping at the raster
    scale) is never double-counted the way naively summing every
    triangle's own projected area would be.

    This is an APPROXIMATION -- accuracy is bounded by `resolution` (the
    grid cell size), unlike projected_area()'s own exact loop-geometry
    answer -- so try projected_area() FIRST and only reach for this if
    that one is unreasonably slow or raises. The default `resolution`
    (600, i.e. up to 360,000 cells) is usually accurate to a small
    fraction of a percent for a normally-proportioned part; raise it
    for a very thin/elongated silhouette, where 600 cells across the
    LONG axis still leaves the short axis coarse (this always keeps the
    grid's own aspect ratio matched to the shape's own projected
    bounding box, so `resolution` is "cells across the longer side").

    `tolerance`/`angular_tolerance`: passed straight through to
    to_mesh() -- finer tessellation costs more triangles to rasterize
    but tracks curved surfaces more closely.
    """
    _require_build123d()
    d = [float(c) for c in direction]
    dlen = math.sqrt(sum(c * c for c in d))
    if dlen < 1e-12:
        raise ValueError("projected_area_mesh(): direction can't be the zero vector")
    d = [c / dlen for c in d]

    verts, tris = to_mesh(shape, tolerance=tolerance, angular_tolerance=angular_tolerance)
    if not tris:
        return 0.0

    verts_arr = np.asarray(verts, dtype=float)
    tris_arr = np.asarray(tris, dtype=int)

    dirvec = np.array(d)
    arbitrary = np.array([1.0, 0.0, 0.0]) if abs(dirvec[0]) < 0.9 else np.array([0.0, 1.0, 0.0])
    u = np.cross(dirvec, arbitrary)
    u = u / np.linalg.norm(u)
    v = np.cross(dirvec, u)

    pts2d = np.stack([verts_arr @ u, verts_arr @ v], axis=1)  # (n_verts, 2)
    tri2d = pts2d[tris_arr]  # (n_tris, 3, 2)

    xmin, ymin = pts2d.min(axis=0)
    xmax, ymax = pts2d.max(axis=0)
    w, h = float(xmax - xmin), float(ymax - ymin)
    if w <= 0 or h <= 0:
        return 0.0
    if w >= h:
        nx = int(resolution)
        ny = max(1, int(round(resolution * h / w)))
    else:
        ny = int(resolution)
        nx = max(1, int(round(resolution * w / h)))
    cell_w, cell_h = w / nx, h / ny

    covered = np.zeros((ny, nx), dtype=bool)
    for tri in tri2d:
        (x1, y1), (x2, y2), (x3, y3) = tri
        txmin, txmax = min(x1, x2, x3), max(x1, x2, x3)
        tymin, tymax = min(y1, y2, y3), max(y1, y2, y3)
        cx0 = max(0, int((txmin - xmin) / cell_w))
        cx1 = min(nx, int((txmax - xmin) / cell_w) + 1)
        cy0 = max(0, int((tymin - ymin) / cell_h))
        cy1 = min(ny, int((tymax - ymin) / cell_h) + 1)
        if cx1 <= cx0 or cy1 <= cy0:
            continue
        denom = (y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3)
        if abs(denom) < 1e-15:
            continue  # a degenerate (zero-area) triangle -- no coverage to add
        xs = xmin + (np.arange(cx0, cx1) + 0.5) * cell_w
        ys = ymin + (np.arange(cy0, cy1) + 0.5) * cell_h
        gx, gy = np.meshgrid(xs, ys)
        a = ((y2 - y3) * (gx - x3) + (x3 - x2) * (gy - y3)) / denom
        b = ((y3 - y1) * (gx - x3) + (x1 - x3) * (gy - y3)) / denom
        c = 1.0 - a - b
        eps = 1e-9
        inside = (a >= -eps) & (b >= -eps) & (c >= -eps)
        covered[cy0:cy1, cx0:cx1] |= inside

    return float(covered.sum()) * cell_w * cell_h


def to_mesh(shape, tolerance=0.1, angular_tolerance=0.3):
    """
    Tessellates a B-rep shape into a triangle mesh in the SAME [V, F]
    convention used throughout openscad4.py (repair_mesh()/
    offset_mesh()/mcm() all return this, polyhedron() expects it) --
    the bridge for viewing a B-rep result in SanPyCAD's existing mesh
    viewer, or feeding it into any of openscad4.py's own mesh
    functions, without needing a real CAD program:
        v, f = to_mesh(some_brep_shape)
        fo(f'''polyhedron({v},{f});''')

    tolerance/angular_tolerance control facet density for this
    tessellation ONLY -- the underlying shape stays exact B-rep;
    export_step()/export_brep() ignore these entirely and write the
    real analytic/NURBS geometry, not this mesh. Smaller tolerance =
    more triangles = closer to the true curved surface, same idea as
    openscad4.py's own grid/samples_per_edge tradeoffs, just for
    display rather than for a computed result.

    UNVERIFIED against a real build123d install (see module
    docstring) -- shape.tessellate(tolerance, angular_tolerance) is
    expected to return (vertices, triangle_index_tuples); if the real
    API differs slightly (e.g. vertices as build123d Vector objects
    needing an explicit .to_tuple()/(.X,.Y,.Z) conversion rather than
    unpacking directly), that conversion is what would need adjusting
    here.

    This is the SAME OCCT/OCP NbNodes fragility class documented on
    import_step()/_reraise_nbnodes() -- tessellate() (OCCT's
    BRepMesh_IncrementalMesh under the hood) is actually the MORE
    common real-world trigger of it than the STEP reader itself: a
    shape whose import itself succeeded can still hit this the moment
    it's first displayed, if triangulating one of its faces trips the
    same null internal handle. Caught and re-raised with the same
    clearer explanation as import_step()'s for exactly that reason.
    Called directly, this always fails outright on that bug -- see
    _to_mesh_lenient() below for the best-effort fallback the Drawing
    tab's own show()/auto-show path actually uses, which can still
    display everything EXCEPT whatever specific solid/face triggers it.
    """
    _require_build123d()
    try:
        verts, tris = shape.tessellate(tolerance, angular_tolerance)
    except AttributeError as e:
        _reraise_nbnodes(e, "to_mesh(): failed tessellating shape for display")
    v = [[float(p.X), float(p.Y), float(p.Z)] for p in verts]
    f = [[int(i) for i in t] for t in tris]
    return v, f


def _tessellate_lenient(shape, tolerance, angular_tolerance):
    """internal, used only by _to_mesh_lenient(): tessellates `shape`
    the normal way first, but on the recurring OCCT/OCP NbNodes
    fragility (see _reraise_nbnodes()) falls back to tessellating its
    own SOLIDS (or, if that doesn't give more than one piece to work
    with, its own FACES) one at a time, skipping only whichever
    specific piece(s) actually trip the bug instead of failing the
    whole shape.

    REAL, CONFIRMED motivation (user report): a real imported .stp file
    still hit this even after trying several different tessellation
    tolerances -- confirming it's not a numerically-marginal case a
    different facet tolerance can dodge (see show()'s own docstring for
    that first, cheaper attempt), but a genuinely degenerate face
    (zero-area, self-intersecting, non-manifold) that OCCT's mesher
    simply cannot triangulate at ANY tolerance. On a multi-solid STEP
    assembly (the common case for anything large enough to hit this),
    that's very often ONE bad solid/face out of many good ones -- there
    is no reason the other 99% of the model should be completely
    unviewable because of it.

    Returns (verts, tris, n_failed, n_total) where verts/tris are in
    shape.tessellate()'s own native (pre-.X/.Y/.Z-unpacked) format,
    n_failed is how many of the parts tried couldn't be tessellated at
    all (0 if the whole-shape tessellation just worked, same as
    to_mesh()'s own plain path), and n_total is how many parts were
    attempted (1 if the whole-shape attempt succeeded). Raises the same
    clear AttributeError to_mesh() would if EVERY part -- including
    every individual face of every solid -- fails too (nothing left to
    fall back to)."""
    try:
        v, t = shape.tessellate(tolerance, angular_tolerance)
        return v, t, 0, 1
    except AttributeError as e:
        if "nbnodes" not in str(e).lower():
            raise
        original = e

    try:
        parts = list(shape.solids())
    except Exception:
        parts = []
    if len(parts) <= 1:
        # either solids() isn't supported here, or this shape IS just one
        # solid already (no partition benefit) -- try one level finer
        try:
            parts = list(shape.faces())
        except Exception:
            parts = []
    if not parts:
        raise original  # nothing more granular to try -- the original failure stands

    all_verts = []
    all_tris = []
    n_failed = 0
    for part in parts:
        try:
            pv, pt = part.tessellate(tolerance, angular_tolerance)
        except AttributeError as e2:
            if "nbnodes" in str(e2).lower():
                n_failed += 1
                continue
            raise
        offset = len(all_verts)
        all_verts.extend(pv)
        all_tris.extend([tuple(i + offset for i in tri) for tri in pt])
    if not all_verts:
        raise original  # every single part failed too -- genuinely nothing to show
    return all_verts, all_tris, n_failed, len(parts)


def _to_mesh_lenient(shape, tolerance=0.1, angular_tolerance=0.3):
    """internal: the display pipeline's own tessellation entry point
    (python_eval.py's show()/color()/auto-show path -- NOT to_mesh()
    itself, which stays a plain "succeed or raise clearly" function for
    direct script use). Same [V, F] output convention as to_mesh(), plus
    a third element: None on a completely normal tessellation, or a
    short warning string if the NbNodes bug forced falling back to a
    per-solid/per-face best-effort tessellation that skipped one or
    more pieces (see _tessellate_lenient() for why/how) -- the caller
    is expected to surface that warning to the user rather than
    silently showing an incomplete model with no explanation."""
    try:
        verts, tris, n_failed, n_total = _tessellate_lenient(shape, tolerance, angular_tolerance)
    except AttributeError as e:
        # _tessellate_lenient() ran out of fallbacks (even individual
        # faces failed) and re-raised the ORIGINAL bare AttributeError
        # unchanged -- route it through the same clear-message rewrite
        # to_mesh() gets, rather than surfacing that bare error here.
        _reraise_nbnodes(e, "to_mesh(): failed tessellating shape for display")
    v = [[float(p.X), float(p.Y), float(p.Z)] for p in verts]
    f = [[int(i) for i in t] for t in tris]
    warning = None
    if n_failed:
        warning = (
            f"{n_failed} of {n_total} solid(s)/face(s) in this shape couldn't be "
            "tessellated for display (the recurring OCCT/OCP 'NbNodes' bug -- "
            "see to_mesh()'s own docstring) and were skipped -- what's shown is "
            "everything ELSE in the model, real geometry, just missing that "
            "specific part. export_step()/export_brep() are unaffected (they "
            "write the exact original geometry, not this display mesh) -- the "
            "missing piece is still there in any file you export, only the "
            "on-screen preview of it is incomplete."
        )
    return v, f, warning


def to_triangles(shape, tolerance=0.1, angular_tolerance=0.3):
    """
    Tessellates a B-rep shape straight into a FLAT list of resolved
    triangles [[p0, p1, p2], ...] (each p a plain [x, y, z]) -- the
    format openscad4.py's own low-level mesh-intersection building
    blocks expect (two_tri_intersection(a1, b1), triangle_triangle_
    intersection(), triangulate_solid_openx()'s own output), which is
    NOT the same as to_mesh()'s [V, F] indexed format (a vertex list
    plus face-index triples). Passing to_mesh()'s [V, F] tuple directly
    into one of those functions is a common mistake once `import
    openscad4` is in the picture -- it fails with something like
    "ValueError: setting an array element with a sequence... inhomogeneous
    shape", because V and F are two differently-shaped arrays being
    stuffed into one, not a triangle list at all. Use to_mesh() when you
    want the compact indexed form (e.g. to feed polyhedron()); use
    to_triangles() when a function needs each triangle spelled out in
    full, like this:

        import openscad4 as o4
        segs = o4.two_tri_intersection(to_triangles(a), to_triangles(b))
        loops = o4.contiguous_chains(segs)
    """
    v, f = to_mesh(shape, tolerance, angular_tolerance)
    return [[v[i] for i in tri] for tri in f]


def to_points(shape):
    """
    Extracts the ordered boundary point list [[x,y,z], ...] from a
    real build123d Shape (e.g. circle()/polygon()/square()/mirror()/
    rotate()'s own output) -- the reverse direction of polygon(): walks
    the outer wire's edges in winding order and collects each edge's
    own start point. For a polygon()-built Face with only straight
    edges (e.g. circle(r, s=n)'s faceted n-gon form), this reconstructs
    exactly the original point list that built it, same count and
    order, even after real Shape-level operations (rotate()/translate()
    /mirror()/etc) have moved it around.

    Handy for round-tripping a real Shape back into plain point-list
    territory to use numpy directly (array stacking/pairing/transpose
    tricks, same style as openscad4.py scripts), or any of brep.py's
    own point-list functions (fit_pline2line(), corner_n_radius_list(),
    etc) that don't accept a Shape:

        a = circle(15, s=5)
        b = rot('z36', circle(7, s=5))
        pa, pb = to_points(a), to_points(b)
        pairs = array([pa, pb]).transpose(1, 0, 2)   # (5, 2, 3) -- pa[i]/pb[i] paired

    For a Face/Wire with any CURVED edges (a `s=None` exact circle(),
    or a mixed_polygon() with a spline segment), each curved edge
    still only contributes its own start point here -- the curve
    itself isn't resampled into more points along the way. Use
    to_mesh() instead if you need a faceted approximation of a
    genuinely curved boundary.
    """
    _require_build123d()
    wire = _as_path_wire(shape, "to_points")
    edges = list(wire.edges()) if hasattr(wire, "edges") else [wire]
    pts = []
    for e in edges:
        p = e.position_at(0)
        pts.append([float(p.X), float(p.Y), float(p.Z)])
    return pts


def solid_from_faces(*faces, tol=1e-6):
    """
    Sews several B-rep Faces that TOGETHER bound one closed, watertight
    volume into a real Solid -- build123d's own native Shell(faces)
    (sews the faces together along their shared edges) + Solid(shell)
    (ShapeFix_Solid().SolidFromShell() under the hood, which both
    finishes closing the shell into a solid and repairs a shell that's
    almost-but-not-quite perfectly watertight).

    This is the real B-rep answer to "I have several curved surface
    patches, how do I turn the volume they enclose into one solid" --
    the case loft() specifically CANNOT handle: loft() needs every
    cross-section to already be a flat/planar Face (it calls
    section.faces() then uses each face's own outer_wire() -- a Face
    can only be built from a wire that's planar in the first place), so
    a part that genuinely bends/twists in 3D (most of its intermediate
    cross-sections non-planar) can't be lofted through directly no
    matter how many sections you feed it. surface_from_points_grid()
    has no such restriction (a true 3D NURBS fit through a whole point
    grid, curvature and all) -- fit the curved wall(s) with that, then
    sew them to their flat end caps here:

        wall = surface_from_points_grid(surf)      # the bent tube's own curved wall
        cap_a = mixed_polygon(a)                    # flat profile at one end
        cap_b = mixed_polygon(b)                    # flat profile at the other end
        solid = solid_from_faces(wall, cap_a, cap_b)
        show(solid)

    `tol` (default 1e-6): the sewing tolerance -- see _sew_faces_to_shell()
    for when to loosen this (a large face selection, e.g. faces_facing()'s
    output, built up through several prior loft/boolean steps).

    Raises whatever build123d itself raises if the given faces don't
    actually close up into a single watertight volume (a gap, an
    overlap, mismatched edges) -- try a looser `tol` first if that
    seems like a real possibility given how `faces` was built.

    Sews via OCCT's own BRepBuilderAPI_Sewing directly (through OCP,
    build123d's own underlying binding) rather than build123d's own
    Shell(list_of_faces) Python constructor -- on at least one
    build123d version that constructor raised "Unable to create
    Shell, invalid input type" on a perfectly valid list of Faces (a
    curved wall Face plus two cap_wire()-built end caps), even though
    each individual Face rendered/behaved fine on its own; sewing at
    the OCCT level first and only wrapping the ALREADY-CORRECTLY-TYPED
    single result (a Shell, or occasionally a lone Face/Compound of
    shells if sewing didn't fully close things up) sidesteps whatever
    that mismatch was.
    """
    _require_build123d()
    faces = _flatten(faces)
    if len(faces) < 2:
        raise ValueError("solid_from_faces(): need at least 2 faces")
    shell = _sew_faces_to_shell(faces, _caller="solid_from_faces", tol=tol)
    return bd.Solid(shell)


def _sew_faces_to_shell(faces, _caller="shell_from_faces", tol=1e-6):
    """Shared sewing core behind shell_from_faces()/solid_from_faces()
    -- pulled out on its own so both can reuse the exact same OCCT-
    level sewing (see solid_from_faces()'s own docstring for why this
    goes through OCP's BRepBuilderAPI_Sewing directly rather than
    build123d's own Shell(list_of_faces) constructor) without
    duplicating it. `_caller` is only used to name the right function
    in an error message -- not part of the public API.

    `tol`: the sewing tolerance itself (default 1e-6, tight -- fine for
    faces that genuinely share exact edges). Loosen this for a large
    face selection (hundreds+) built up through several prior
    operations (loft, boolean, a face-normal filter like
    faces_facing()) -- real floating-point drift from each of those
    steps can leave two faces' "same" shared edge off by more than
    1e-6, and sewing at too tight a tolerance doesn't raise for this;
    it just silently leaves that seam UNMERGED (two separate near-
    duplicate edges instead of one shared one). That's invisible in the
    3D view (both faces still render in the right place) but breaks
    anything that walks the result's own topology afterward -- most
    notably close_faces_to_plane()/faces_within_boundary()'s own free-
    edge detection, which then sees every one of those unmerged interior
    seams as if it were part of the outer boundary."""
    try:
        import OCP.TopAbs as _ta
        from OCP.TopoDS import TopoDS as _TopoDS
        from OCP.BRepBuilderAPI import BRepBuilderAPI_Sewing as _Sewing

        sewing = _Sewing(float(tol))
        for f in faces:
            sewing.Add(f.wrapped)
        sewing.Perform()
        sewn = sewing.SewedShape()
        shape_type = sewn.ShapeType()
        if shape_type == _ta.TopAbs_SHELL:
            return bd.Shell(_TopoDS.Shell(sewn))
        elif shape_type == _ta.TopAbs_FACE:
            return bd.Shell([bd.Face(_TopoDS.Face(sewn))])
        else:
            return bd.Shell(list(bd.Compound(_TopoDS.Compound(sewn)).faces()))
    except Exception as _sew_err:
        # Fall back to build123d's own higher-level constructor, in case
        # the OCP-level route above hit something environment-specific
        # (unlikely, but cheap insurance) -- surface BOTH errors if this
        # also fails, since at that point it's a genuine geometry problem
        # (gap/overlap/mismatched edges) worth seeing in full.
        try:
            return bd.Shell(list(faces))
        except Exception as _shell_err:
            raise RuntimeError(
                f"{_caller}(): OCCT sewing failed ({_sew_err!r}), "
                f"and the build123d Shell() fallback also failed "
                f"({_shell_err!r})"
            ) from _shell_err


def shell_from_faces(*faces, tol=1e-6):
    """
    Sews several B-rep Faces that share edges into ONE connected Shell
    -- the same OCCT sewing solid_from_faces() uses, but stops there
    instead of also closing the result into a watertight Solid.

    Use this (not solid_from_faces()) whenever the faces you have
    DON'T necessarily bound a closed volume on their own -- e.g. a
    bunch of adjacent faces picked straight off an existing shape (say,
    a cavity's flat wall plus the fillet blends around it) that you
    just want stitched into one real multi-face surface, typically to
    hand straight to thicken() to build a matching tool/slider body:

        f1 = [c.faces()[i] for i in [11, 12, 9, 8, 10, 13, 14, 2, 3, 5, 7, 6, 1, 4]]
        wall = shell_from_faces(f1)
        slider = thicken(wall, 10)
        show(slider)

    Don't reach for union() here instead -- union() boolean-FUSES
    shapes (meant for solids, not bare Faces) and, on a large set of
    Faces that are exactly edge-adjacent like these (never a genuine
    volumetric overlap), it's exactly the fragile case union()'s own
    docstring already warns about: it can come back as a Compound
    rather than a clean single Face/Shell, and thicken()/other
    surface-only tools then fail on it (e.g. "'Compound' object is not
    subscriptable") since a Compound is a looser, less specific
    grouping than the Shell they actually need.

    `tol` (default 1e-6): the sewing tolerance itself -- see
    _sew_faces_to_shell()'s own docstring for the full explanation, but
    in short: a LARGE face selection (hundreds+, e.g. faces_facing()'s
    own output) that's already been through a loft/boolean/face-filter
    pipeline can carry real floating-point drift bigger than 1e-6
    between two faces' "same" shared edge -- sewing that tight doesn't
    raise for it, it just leaves that seam unmerged, which then shows up
    downstream as far too many "free" boundary edges (e.g. from
    close_faces_to_plane()/faces_within_boundary()) even though the
    Shell itself still renders looking perfectly fine. If a function
    built on top of this Shell's own free edges is finding way more of
    them than the true outer boundary should have, re-sew with a
    looser `tol` (start small -- 1e-4 to 1e-2 depending on your model's
    scale -- and increase only if needed) BEFORE running that function
    again, rather than trying to bridge the resulting mess downstream.

    Raises whatever build123d/OCCT itself raises if the given faces
    don't share edges cleanly enough to sew into one connected shell
    at all, even at the given `tol` (a real gap, an overlap, or
    genuinely mismatched edges).
    """
    _require_build123d()
    faces = _flatten(faces)
    if len(faces) < 2:
        raise ValueError("shell_from_faces(): need at least 2 faces")
    return _sew_faces_to_shell(faces, tol=tol)


def group(*shapes):
    """
    Bundles two or more shapes into one Compound "assembly" -- unlike
    union(), this does NOT boolean-fuse them into a single solid; each
    shape stays its own separate, distinct solid inside the Compound,
    exactly as it was. Mainly for export_step()/export_brep(): passing
    a group() of several shapes writes them all into ONE file as
    separate parts (an assembly), same idea as `to_export` being
    "object or assembly" per build123d's own export_step() docstring
    -- rather than calling export_step() once per shape into separate
    files, or fusing everything into one solid with union() just to
    get a single file out.

        a = cylinder(r=10, h=40)
        b = box(30, 30, 5)
        export_step(group(a, b), "both_parts.step")   # 2 distinct
                                                        # solids, 1 file

    show() only ever takes ONE shape per call (call it once per shape,
    same as every other example does, to see them all in the viewer) --
    group() is specifically for bundling shapes together for export,
    not for display. show(group(a, b)) still works (it tessellates the
    whole Compound into one combined display mesh), but you lose each
    part's own separate color/selectability in the viewer that way, so
    prefer plain show(a); show(b) for viewing and save group() for the
    export_step()/export_brep() call itself.
    """
    _require_build123d()
    shapes = _flatten(shapes)
    if len(shapes) == 0:
        raise ValueError("group(): need at least one shape")
    return bd.Compound(shapes)


def _draft_direction(direction, caller):
    d = [float(x) for x in direction]
    dlen = math.sqrt(sum(x * x for x in d))
    if dlen < 1e-12:
        raise ValueError(f"{caller}(): direction must be nonzero")
    return [x / dlen for x in d]


def _draft_samples(face, du, tolerance):
    """Yields (point [x,y,z], draft_angle_deg) for sample points spread
    across `face`'s own surface (via this app's to_mesh()), falling
    back to just the face's center if tessellation fails or returns
    nothing. Shared core behind draft_check() (aggregates to one
    worst-case status per FACE) and draft_check_points()/
    draft_check_markers() (keep every individual POINT -- see
    draft_check()'s own docstring for why per-face granularity alone
    can be badly misleading on a single large curved face)."""
    try:
        verts, _tris = to_mesh(face, tolerance=float(tolerance), angular_tolerance=0.3)
    except Exception:
        verts = []
    sample_pts = verts if verts else [face.center()]
    for p in sample_pts:
        try:
            px, py, pz = (p.X, p.Y, p.Z) if hasattr(p, "X") else (p[0], p[1], p[2])
            n = face.normal_at((float(px), float(py), float(pz)))
            dot = n.X * du[0] + n.Y * du[1] + n.Z * du[2]
            dot = max(-1.0, min(1.0, dot))
            angle = math.degrees(math.asin(dot))
            yield [float(px), float(py), float(pz)], angle
        except Exception:
            continue


def _draft_status(angle, min_draft):
    if angle < 0:
        return "undercut"
    if angle < float(min_draft):
        return "insufficient"
    return "ok"


def draft_check(shape, direction, min_draft=1.0, tolerance=0.2):
    """
    Checks every face of `shape` for UNDERCUTS and INSUFFICIENT DRAFT
    relative to a chosen pull direction -- the same analysis a real
    mold/die design package's "draft angle analysis" does, scriptable
    here instead.

    `direction`: the pull direction ([x, y, z], e.g. [0, 0, 1] for a
        top die pulling straight up) -- doesn't need to already be
        unit length, normalized internally.
    `min_draft`: the minimum acceptable draft angle in degrees
        (default 1.0 -- a common injection-molding minimum; a deeper
        die-cast draw or a shallow snap-fit wall might need something
        different -- pass whatever your process actually requires).
    `tolerance`: passed straight through to this app's own to_mesh()
        to control how densely each face gets sampled -- a face's
        normal can vary a lot across a curved surface, so checking
        only its center can miss a locally-undercut patch on an
        otherwise-fine face; a smaller tolerance samples more points
        (slower, more thorough).

    A face's DRAFT ANGLE here is measured between the face and the
    pull direction itself (not the face's normal): a wall running
    exactly PARALLEL to the pull direction has 0 degrees of draft (it
    will scuff/gall on ejection, no clearance at all); a wall that
    tilts outward, away from the core, as you go in the pull
    direction has some POSITIVE draft (the more positive, the more
    clearance); a face that tilts the other way -- inward, back over
    itself -- has NEGATIVE draft, meaning the tool would have to pass
    back through material it already cleared to release: a genuine
    UNDERCUT, needing a slider/side-action (or an entirely different
    pull direction) rather than just "more draft", the same class of
    problem 17_slider_extraction_from_cavity_wall.py's example works
    around.

    Returns a list of dicts, one per face, SAME ORDER/INDICES as
    shape.faces() (so they line up with every other probe/pick tool
    in this app):
        {"index": i, "min_draft_deg": ..., "status": "undercut" |
         "insufficient" | "ok"}
    "min_draft_deg" is the WORST (smallest) draft angle found anywhere
    on that face -- negative means "undercut", 0 up to `min_draft`
    means "insufficient" (releases, but shallower than your minimum),
    at or above `min_draft` means "ok".

        e1 = [c.faces()[i] for i in [3, 7]]  # pulled straight from the
                                               # Pick tool, faces=kind
        report = draft_check(c, [0, 0, 1], min_draft=1.5)
        for r in report:
            if r["status"] != "ok":
                print(r)

    IMPORTANT LIMITATION -- one status covers the WHOLE face: a face
    that's mostly fine but dips bad somewhere on it still gets that
    one worst status for its entire area. Usually harmless (most real
    part walls/ribs are already their own separate, small faces), but
    on one large curved face whose normal sweeps through a wide range
    of directions -- a plain sphere is the extreme case, a single
    Face spanning nearly the whole surface -- this can mark the ENTIRE
    face as one uniform status even though roughly half of it is
    actually fine. Use draft_check_points()/draft_check_markers()
    instead for an accurate picture on shapes like that (or just to
    see a smooth per-point gradient rather than hard face boundaries).

    To see THIS (per-face) version, color each face by its own status
    and show() them one at a time (this app's show() only ever takes
    one shape per call, so a loop of individually-colored show() calls
    is how anything multi-colored gets displayed here; see e.g.
    mirror_surface()'s own example):

        colors = {"undercut": "red", "insufficient": "orange", "ok": "green"}
        faces = list(c.faces())
        for r in report:
            show(color(faces[r["index"]], colors[r["status"]]))

    UNVERIFIED against a real build123d install (see module
    docstring) -- built on Face.normal_at(point) and this app's own
    to_mesh() (itself already flagged UNVERIFIED for the same reason).
    If every draft angle comes back roughly 180 degrees off from what
    you'd expect (e.g. a flat top face facing straight along
    `direction` reading as -90 instead of +90), that's a face-
    orientation sign flip -- the first thing to check here.
    """
    _require_build123d()
    du = _draft_direction(direction, "draft_check")
    report = []
    for i, f in enumerate(shape.faces()):
        worst = None
        for _pt, angle in _draft_samples(f, du, tolerance):
            if worst is None or angle < worst:
                worst = angle
        if worst is None:
            worst = 0.0
        report.append({"index": i, "min_draft_deg": worst, "status": _draft_status(worst, min_draft)})
    return report


def draft_check_points(shape, direction, min_draft=1.0, tolerance=0.2):
    """
    The same draft-angle check as draft_check(), but returns every
    individual SAMPLE POINT instead of one aggregated worst-case
    status per face -- reach for this (not draft_check()) whenever a
    shape has a large curved face that's fine over MOST of its area
    but dips bad somewhere on it. A plain sphere is the extreme
    example: its outward normal sweeps through every possible
    direction across ONE single Face, so draft_check()'s per-face
    worst-case marks the WHOLE sphere as one uniform status even
    though roughly half its surface is actually fine -- this instead
    keeps each sample point's own true status, so you get a smooth,
    accurate boundary between good and bad regions rather than one
    hard face-wide cutoff.

    Same `direction`/`min_draft`/`tolerance` meaning as draft_check().

    Returns a flat list across every face, one entry per sample point:
        {"point": [x, y, z], "draft_deg": ..., "status": "undercut" |
         "insufficient" | "ok"}

    Meant to be visualized as a "heat map" of small colored dots
    rather than colored whole-faces -- see draft_check_markers() for a
    ready-to-show() version of exactly that.
    """
    _require_build123d()
    du = _draft_direction(direction, "draft_check_points")
    out = []
    for f in shape.faces():
        for pt, angle in _draft_samples(f, du, tolerance):
            out.append({"point": pt, "draft_deg": angle, "status": _draft_status(angle, min_draft)})
    return out


def draft_check_markers(shape, direction, min_draft=1.0, tolerance=0.2, marker_size=None):
    """
    Convenience wrapper around draft_check_points(): builds a small
    sphere marker at every sample point, grouped by status, ready to
    show() directly (3 show() calls total -- one per status -- instead
    of one per point):

        markers = draft_check_markers(c, [0, 0, 1], min_draft=1.5)
        colors = {"undercut": "red", "insufficient": "orange", "ok": "green"}
        for status, m in markers.items():
            if m is not None:
                show(color(m, colors[status]))

    This is the accurate, per-point picture -- on a plain sphere, for
    instance, you'll see roughly one hemisphere's worth of green dots
    and the other red, meeting in a clean band around the "equator"
    relative to `direction`, instead of draft_check()'s single whole-
    shape worst-case status (see its docstring's own limitation note).

    `marker_size`, if not given, defaults to ~0.8% of the shape's own
    largest bounding-box dimension -- small enough not to obscure the
    surface, big enough to actually see at normal zoom.

    Returns {"undercut": shape_or_None, "insufficient": ..., "ok":
    ...} -- a status with no points at all (e.g. a shape with zero
    undercuts) comes back None rather than an empty/invalid group().
    """
    _require_build123d()
    pts = draft_check_points(shape, direction, min_draft=min_draft, tolerance=tolerance)
    if marker_size is None:
        size = shape.bounding_box().size
        marker_size = max(max(size.X, size.Y, size.Z) * 0.008, 1e-6)
    by_status = {"undercut": [], "insufficient": [], "ok": []}
    for p in pts:
        by_status[p["status"]].append(p["point"])
    out = {}
    for status, plist in by_status.items():
        if not plist:
            out[status] = None
            continue
        markers = [translate(p, sphere(float(marker_size))) for p in plist]
        out[status] = group(*markers) if len(markers) > 1 else markers[0]
    return out


def export_step(shape, path):
    """
    Writes `shape` to a STEP file -- real B-rep, exact geometry,
    openable/editable in any real CAD program (SolidWorks, Fusion 360,
    FreeCAD, etc.), unlike anything openscad4.py's own mesh functions
    can produce.
    """
    _require_build123d()
    return bd.export_step(shape, str(path))


def export_stl(shape, path, tolerance=0.001, angular_tolerance=0.1, ascii_format=False):
    """
    Writes `shape` to an STL file -- tessellated (faceted) on export,
    same idea as to_mesh() above but written straight to disk by OCCT
    rather than returned as [V, F]. tolerance/angular_tolerance are the
    same facet-density controls as to_mesh()'s.
    """
    _require_build123d()
    return bd.export_stl(shape, str(path), tolerance=tolerance, angular_tolerance=angular_tolerance, ascii_format=ascii_format)


def export_brep(shape, path):
    """
    Writes `shape` to a native OCCT BREP file -- exact geometry like
    export_step(), but BREP is OCCT's own format rather than the
    cross-CAD-vendor ISO 10303 standard STEP is. Useful mainly for
    round-tripping back into build123d/OCCT itself (import_brep())
    without any STEP-specific overhead; use export_step() if the file
    needs to open in a different CAD program.
    """
    _require_build123d()
    return bd.export_brep(shape, str(path))


def _reraise_nbnodes(e, where):
    """internal, shared by import_step()/to_mesh(): re-raises an
    AttributeError as a clearer, actionable one if it looks like the
    recurring `'NoneType' object has no attribute 'NbNodes'` (or
    lowercase 'nbnodes') OCCT/OCP fragility -- same fragility class
    documented throughout this module (union()'s, sweep_sec2path()'s,
    "round"'s own docstrings) -- a None internal curve/mesh-adaptor
    handle getting queried deep inside OCCT's own C++ layer, not a bug
    in whatever this app's own code called right before it. `where`:
    a short description of what was being attempted, prefixed onto the
    clearer message (e.g. "import_step(): failed reading 'foo.stp'").
    Any OTHER AttributeError is re-raised completely unchanged -- this
    only ever rewrites the one specific, confirmed pattern.

    There's no reliable way to detect or repair this from Python before
    it happens (OCCT doesn't expose a "skip healing"/"tolerant" switch
    through build123d), so this is purely a clarity fix: the bare
    AttributeError becomes an explanation plus concrete workarounds
    that have fixed it for other, similarly affected files instead of a
    cryptic one-liner with no indication of what's actually wrong or
    what to try next.
    """
    if "nbnodes" in str(e).lower():
        raise AttributeError(
            f"{where} -- {e}. This is a known OCCT/OCP internal issue "
            "(not a bug in this app) triggered by certain degenerate "
            "geometry (zero-area faces, duplicate vertices, non-manifold "
            "edges are the usual culprits) -- especially likely on a "
            "large/complex imported STEP file. Things that have fixed "
            "this for other, similarly affected files: re-opening and "
            "re-exporting the file from its original CAD program with "
            "geometry repair/healing turned on, or opening it in FreeCAD "
            "and using Part > Check geometry / \"Refine shape\" + "
            "re-export STEP, which often cleans up exactly this kind of "
            "degenerate geometry before OCCT ever sees it again."
        ) from e
    raise


def import_step(path):
    """
    Reads a STEP file (.step/.stp) from disk and returns it as a real
    B-rep Shape -- build123d's own import_step(), exposed directly so a
    script can pull in a part made elsewhere (another CAD program, or a
    file this app itself wrote with export_step()) and keep working on
    it with every other function here: union()/difference() it against
    new geometry, split() it for a cross-section, fillet()/chamfer()
    its edges, measure it with volume()/bb(), or just show() it to look
    at what's inside.

    Returns whatever build123d's own importer produces -- usually a
    Compound wrapping one or more Solids (assemblies/multi-body STEP
    files come back as multiple solids inside that one Compound; call
    .solids() on the result to pull them apart if a later step, e.g.
    fillet(), needs a single Solid rather than the whole Compound --
    same convention split()'s own docstring uses for "both").

    This reads the file's real geometry (exact B-rep), unlike
    SanPyCAD's mesh-based sibling app, which can only ever pull in a
    STEP file's *tessellated* (faceted) surface as a triangle soup --
    reading it here keeps it exact, so a subsequent split()/fillet()/
    offset() stays exact too, not limited by however coarse the mesh
    version's triangles happen to be. A common way to "section" an
    imported part for a good look inside -- cut with a plane through
    the shape's own center, sized off its own bounding box so the
    cutting plane is always comfortably bigger than the part itself:

        part = import_step("assembly.step")
        mid = part.bounding_box().center()
        span = max(part.bounding_box().size) * 2
        cut_plane = plane([0, 1, 0], size=span, intercept=(mid.X, mid.Y, mid.Z))
        half = split(part, bisect_by=cut_plane, keep="bottom")
        show(half)

    CONFIRMED real failure mode (real user report): some .stp files take
    a very long time to import and then raise
    `AttributeError: 'NoneType' object has no attribute 'NbNodes'` (or
    the lowercase 'nbnodes' some OCP builds use for the same internal
    attribute). This is the SAME OCCT/OCP fragility class already
    documented elsewhere in this module (see union()'s and
    sweep_sec2path()'s own docstrings for two other, unrelated call
    sites that can hit it) -- a None internal curve/mesh-adaptor handle
    getting queried deep inside OCCT's own C++ layer, not a bug in this
    thin wrapper (`bd.import_step()` is called here with nothing else
    happening first). For import specifically it means the STEP reader's
    own geometry-healing/validation pass choked on something in the
    file -- most often a handful of degenerate faces (zero area,
    duplicate/near-duplicate vertices, non-manifold edges) left behind
    by whatever CAD system wrote it, especially likely on a large,
    complex, multi-body assembly (the "very long time" beforehand is
    that same healing pass working through everything else in the file
    first). There's no reliable way to detect or repair this from
    Python before it happens -- OCCT doesn't expose a "skip healing" or
    "tolerant read" switch through build123d's import_step() -- so this
    just re-raises with a clearer explanation instead of the bare
    AttributeError. Things that have fixed this for other, similarly
    affected files: re-opening and re-exporting the STEP file from its
    original CAD program with geometry repair/healing turned on, or
    opening it in FreeCAD and using its Part > Check geometry /
    "Refine shape" + re-export STEP, which often cleans up exactly this
    kind of degenerate geometry before OCCT ever sees it again.

    Automatically runs the freshly imported shape through OCCT's own
    ShapeFix_Shape repair pass (see _heal_imported_shape() below) before
    returning it -- the SAME class of automatic healing FreeCAD (and
    most other CAD software) already applies on STEP import, which is
    the real reason a file that crashes THIS app's tessellation can
    still open "in a few seconds, completely clean" in FreeCAD: it's
    not that FreeCAD is reading different geometry, it's that FreeCAD
    silently repairs small defects (gaps, degenerate edges, slightly
    inconsistent face orientations) before ever handing the shape to
    its own mesher, and this app's raw build123d import_step() call
    didn't used to do that at all. This is a genuine best-effort fix,
    not just a clearer error message -- if it works, whatever was
    tripping the NbNodes tessellation bug may simply not be there
    anymore, and show()/to_mesh() should just work without needing the
    tolerance-override or lenient-fallback workarounds at all. Entirely
    fail-safe either way: if healing itself raises for any reason (e.g.
    this OCP build's ShapeFix module isn't importable, or the repair
    pass itself errors), this silently falls back to the original,
    unhealed shape rather than turning a healing attempt into a NEW
    failure -- see _heal_imported_shape()'s own docstring.
    """
    _require_build123d()
    try:
        shape = bd.import_step(str(path))
    except AttributeError as e:
        _reraise_nbnodes(e, f"import_step(): failed reading {path!r}")
    return _heal_imported_shape(shape)


def _heal_imported_shape(shape):
    """internal, used only by import_step(): runs OCCT's own
    ShapeFix_Shape repair pass over a freshly imported shape and
    returns the healed result -- or, if healing doesn't work for any
    reason, the ORIGINAL shape unchanged. Never raises.

    WHY: a STEP file is just a description of geometry -- an exact
    B-rep isn't guaranteed to be perfectly consistent the instant it's
    parsed (tiny gaps between edges, a degenerate zero-length edge left
    over from whatever CAD system wrote the file, faces whose normals
    don't quite agree at a shared edge). Most of the time this doesn't
    matter -- build123d/OCCT tolerate small inconsistencies fine for
    booleans/measurements -- but OCCT's own MESHER (BRepMesh_
    IncrementalMesh, what tessellate() calls, see to_mesh()'s own
    docstring) can be much less forgiving of exactly this kind of small
    defect, which is the leading real-world cause of the recurring
    NbNodes crash. ShapeFix_Shape is OCCT's own standard repair tool
    for precisely this -- it does NOT add, remove, or reshape real
    material; it normalizes small topological inconsistencies so the
    REST of OCCT (including its mesher) has an easier time with the
    result. This is the same repair class FreeCAD's own STEP import
    already runs automatically, which is why a file that fails here can
    still open cleanly there.

    UNVERIFIED against a real build123d/OCP install (see this module's
    own header docstring) -- `shape.wrapped` (the raw OCP TopoDS_Shape
    build123d Shape objects wrap) and reconstructing
    `type(shape)(healed_topods)` afterward are both standard, widely-
    used build123d patterns, but haven't been checked against a real
    install in this environment (no network access to pip install
    build123d here). If this turns out not to actually run (e.g.
    `from OCP.ShapeFix import ShapeFix_Shape` fails, or the real
    build123d Shape constructor doesn't accept a raw TopoDS_Shape the
    way assumed here), the broad `except Exception` below means it
    just silently no-ops back to the unhealed shape -- a STEP file that
    already imported fine keeps working exactly as before either way;
    the only thing that changes is whether the NbNodes fallback
    workarounds (tolerance override, lenient per-solid/per-face
    tessellation) turn out to still be necessary."""
    try:
        from OCP.ShapeFix import ShapeFix_Shape
        fixer = ShapeFix_Shape(shape.wrapped)
        fixer.Perform()
        healed = fixer.Shape()
        return type(shape)(healed)
    except Exception:
        return shape


def import_brep(path):
    """
    Reads a native OCCT BREP file (.brep) -- the exact round-trip
    counterpart to this app's own export_brep(), no STEP-specific
    overhead. Use import_step() instead for a file made by (or meant to
    open in) a different CAD program; BREP is OCCT's own format, not
    the cross-vendor ISO 10303 standard STEP is.
    """
    _require_build123d()
    return bd.import_brep(str(path))


def _drawing_view_directions(shape):
    """internal: camera position + up-vector for the 4 standard views
    (FRONT/TOP/RIGHT/ISO), placed far enough from `shape`'s own
    bounding box that project_to_viewport()'s projection is
    effectively orthographic (no visible perspective convergence) --
    same idea as a real camera very far from a small subject giving a
    near-parallel projection, without needing project_to_viewport()
    itself to expose an explicit "orthographic" switch (it may not;
    see technical_drawing_views()'s own docstring for what's actually
    verified about this API here).

    Z-up convention throughout, matching every other angle/direction
    in this app (rot()'s own 'x'/'y'/'z' axis letters, draft_check()'s
    pull direction, etc): FRONT looks along +Y (camera out at -Y),
    TOP looks straight down (camera above, +Z), RIGHT looks along -X
    (camera out at +X), ISO looks from a (+X,-Y,+Z) corner. `look_at`
    is always the bounding box's own center, not the origin -- so a
    shape built or translate()'d away from [0,0,0] still ends up
    centered in its own views instead of off in a corner.
    """
    _require_build123d()
    bbox = shape.bounding_box()
    cx = (bbox.min.X + bbox.max.X) / 2.0
    cy = (bbox.min.Y + bbox.max.Y) / 2.0
    cz = (bbox.min.Z + bbox.max.Z) / 2.0
    look_at = (cx, cy, cz)
    diag = math.sqrt(
        (bbox.max.X - bbox.min.X) ** 2 +
        (bbox.max.Y - bbox.min.Y) ** 2 +
        (bbox.max.Z - bbox.min.Z) ** 2
    )
    dist = max(diag * 10.0, 100.0)  # far enough for a near-orthographic view

    def cam(dir_x, dir_y, dir_z):
        n = math.sqrt(dir_x ** 2 + dir_y ** 2 + dir_z ** 2)
        return (cx + dir_x / n * dist, cy + dir_y / n * dist, cz + dir_z / n * dist)

    return {
        "FRONT": {"viewport_origin": cam(0, -1, 0), "viewport_up": (0, 0, 1), "look_at": look_at},
        "TOP":   {"viewport_origin": cam(0, 0, 1),  "viewport_up": (0, 1, 0), "look_at": look_at},
        "RIGHT": {"viewport_origin": cam(1, 0, 0),  "viewport_up": (0, 0, 1), "look_at": look_at},
        "ISO":   {"viewport_origin": cam(1, -1, 1), "viewport_up": (0, 0, 1), "look_at": look_at},
    }


def _custom_view_direction(shape, direction, up):
    """Same far-enough-for-near-orthographic camera placement as
    _drawing_view_directions() above, just parametrized on an arbitrary
    caller-supplied direction/up instead of one of the 4 fixed presets
    -- what lets technical_drawing_views()'s `custom_views` add a view
    from ANY angle, not just FRONT/TOP/RIGHT/ISO. The frontend's own
    "Add View" button captures this straight from the live 3D viewer's
    own camera (direction = normalized camera-position-minus-target,
    up = the camera's own up vector, both already in this app's
    Z-up world convention -- see index.html's captureCurrentViewForDrawing()
    for exactly how those 2 vectors are read off the three.js camera).
    """
    _require_build123d()
    bbox = shape.bounding_box()
    cx = (bbox.min.X + bbox.max.X) / 2.0
    cy = (bbox.min.Y + bbox.max.Y) / 2.0
    cz = (bbox.min.Z + bbox.max.Z) / 2.0
    look_at = (cx, cy, cz)
    diag = math.sqrt(
        (bbox.max.X - bbox.min.X) ** 2 +
        (bbox.max.Y - bbox.min.Y) ** 2 +
        (bbox.max.Z - bbox.min.Z) ** 2
    )
    dist = max(diag * 10.0, 100.0)
    dx, dy, dz = direction
    n = math.sqrt(dx * dx + dy * dy + dz * dz) or 1.0
    origin = (cx + dx / n * dist, cy + dy / n * dist, cz + dz / n * dist)
    return {"viewport_origin": origin, "viewport_up": tuple(up), "look_at": look_at}


# axis-aligned normal/up pairs for section_view() below -- "up" for each
# axis mirrors the same choice _drawing_view_directions() already makes
# for the standard view that looks along that same axis (TOP looks down
# +Z and uses up=(0,1,0) specifically because (0,0,1) is degenerate
# looking straight down Z; FRONT/RIGHT look along Y/X and both use
# up=(0,0,1) safely, so a Y or X section reuses that same up too).
_AXIS_VEC = {"x": (1.0, 0.0, 0.0), "y": (0.0, 1.0, 0.0), "z": (0.0, 0.0, 1.0)}
_AXIS_UP = {"x": (0.0, 0.0, 1.0), "y": (0.0, 0.0, 1.0), "z": (0.0, 1.0, 0.0)}


def section_view(shapes, axis, offset, keep="positive"):
    """internal: cuts each shape in `shapes` with a plane perpendicular
    to `axis` ('x'/'y'/'z') at `offset` along that axis, keeping the
    'positive' (>= offset) or 'negative' (<= offset) side -- the exact
    same plane()+split() idiom already verified working in
    examples/21_import_and_section_step_library.py's own
    _safe_quarter_cut(), just parametrized on a caller-chosen axis/
    offset/side (from the Drawing tab's own Section tool) instead of
    that example's fixed through-the-center quarter cut.

    Returns (halves, cam_dir, up, errors):
      halves: the surviving half of each shape that could be cut (one
        per input shape that didn't raise -- see `errors` below)
      cam_dir: unit-ish direction (center-to-camera, same convention as
        _drawing_view_directions()) that looks straight at the freshly
        exposed cut face -- the "positive" side keeps material whose
        cut face points -axis, so the camera needs to sit on the -axis
        side looking back along +axis to face it head-on (and vice
        versa for "negative")
      up: this axis's viewport_up (see _AXIS_UP above)
      errors: one message per shape the cut plane missed entirely (a
        real, expected outcome on a disconnected multi-body assembly --
        see _safe_quarter_cut()'s own docstring -- not a bug), so the
        caller can report a partial result instead of silently losing
        shapes with no explanation.
    """
    _require_build123d()
    axis = str(axis).strip().lower()
    if axis not in _AXIS_VEC:
        raise ValueError(f"section_view(): axis must be 'x', 'y', or 'z', got {axis!r}")
    if keep not in ("positive", "negative"):
        raise ValueError(f"section_view(): keep must be 'positive' or 'negative', got {keep!r}")
    normal = _AXIS_VEC[axis]
    offset = float(offset)
    intercept = {"x": (offset, 0.0, 0.0), "y": (0.0, offset, 0.0), "z": (0.0, 0.0, offset)}[axis]

    halves = []
    errors = []
    for s in shapes:
        box = s.bounding_box()
        span = max(box.size.X, box.size.Y, box.size.Z) * 3 + abs(offset) * 2 + 10
        cut = plane(list(normal), size=span, intercept=intercept)
        try:
            halves.append(split(s, bisect_by=cut, keep=("top" if keep == "positive" else "bottom")))
        except ValueError as e:
            errors.append(str(e))

    cam_dir = tuple(-c for c in normal) if keep == "positive" else normal
    return halves, cam_dir, _AXIS_UP[axis], errors


def _hlr_polylines(shape, viewport_origin, viewport_up, look_at, n_samples=48, include_hidden=True):
    """internal: one hidden-line-removed view of `shape`, as plain 2D
    polyline point lists -- ({"visible": [...], "hidden": [...]}, same
    format drawing_layout.py's build_sheet_svg() expects).

    `include_hidden=False` skips turning the `hidden` edge list
    project_to_viewport() returns into polylines at all (returns
    "hidden": [] instead) -- a real, reported request: "if the hidden
    lines in the drawings make it so slow, it can be removed". Worth
    being upfront about exactly what this does and doesn't save, though:
    project_to_viewport() below is ONE call that returns BOTH the
    visible and hidden edge lists together already computed -- OCCT's
    HLRBRep_Algo has to resolve which parts of EVERY edge are occluded
    to produce the visible set at all, so the expensive part (the actual
    hidden-line-removal math) runs regardless of this flag, not skipped.
    What this DOES skip is real, just smaller: sampling every hidden
    Edge into a polyline (each a position_at() call per point, straight
    into OCCT/OCP curve-adaptor code, not free Python -- see the loop
    below), plus every hidden point this app would otherwise then have
    to serialize to JSON, ship over HTTP, and render as dashed SVG
    lines. For a mechanical part with a lot of INTERNAL geometry (ribs,
    bores, pockets) sitting behind its outer walls, hidden edges can
    easily outnumber visible ones, so this is a genuine, sometimes
    substantial, partial win -- just not a full fix for a view whose
    slowness is dominated by HLRBRep_Algo's own visibility computation
    itself.

    Runs build123d's Shape.project_to_viewport() (added to build123d
    specifically for this -- it wraps OCCT's own HLRBRep_Algo, the
    real hidden-line-removal algorithm every "show hidden edges dashed"
    CAD drawing view is built on) to get 2 lists of Edges -- visible
    and hidden from that camera position -- then samples each Edge
    into a plain polyline via position_at(t), t=0..1, the same
    approach sample_curve()/kernel_process.py's own probe-highlight
    code already use elsewhere in this app.

    UNVERIFIED against a real build123d install, same caveat as this
    whole module's own header docstring: project_to_viewport() is
    assumed to return Edges already expressed in the VIEW's own local
    2D-ish frame (so a returned edge's own position_at(t).X/.Y are
    directly usable as flat 2D drawing coordinates) rather than still
    in the original 3D world frame -- if a rendered drawing instead
    looks like a full skewed 3D wireframe rather than a flat 2D view,
    that assumption is what's wrong and needs revisiting here. Also
    assumes this build123d version actually HAS project_to_viewport()
    at all (added in a fairly recent build123d release) -- an older
    install raises a plain AttributeError, caught below and re-raised
    with a clearer "upgrade build123d" message instead.

    Each point is [X, Y, Z] -- Z is the point's own residual view-depth
    (how far toward/away from the camera it sits, along the view
    direction), kept rather than discarded specifically so the Drawing
    tab's own dimensioning tools can compute TRUE 3D distances between
    features that aren't coplanar with this particular view (e.g. 2
    holes on perpendicular faces of the same part, both visible in one
    ISO view but at different depths) -- see index.html's own
    dimensioning code for why this matters. This is safe to add
    unconditionally: setting up a view's own camera frame via
    viewport_origin/viewport_up/look_at is a pure rotation+translation
    of the original world coordinates (an isometry -- it doesn't scale
    anything), so distances computed directly from this [X,Y,Z] data
    are exactly the same real-world distances they'd be from the
    original, un-transformed 3D geometry; nothing about this changes
    the FLAT 2D drawing itself (drawing_layout.py and every existing
    piece of frontend rendering code only ever read a point's own [0]/
    [1] elements, so a 3rd element already passes through both
    completely harmlessly).
    """
    _require_build123d()
    try:
        visible, hidden = shape.project_to_viewport(
            viewport_origin=viewport_origin, viewport_up=viewport_up, look_at=look_at)
    except AttributeError as e:
        raise ImportError(
            "technical_drawing_views(): this build123d install doesn't have "
            "Shape.project_to_viewport() (added in a newer build123d release "
            "than this app was written against) -- try `pip install -U "
            f"build123d`. (original error: {e})")

    def to_polylines(edges):
        out = []
        for e in edges:
            # REAL PERFORMANCE FIX (user report: a large/complex imported
            # STEP file's Drawing tab "loading drawing" never finishing,
            # even though the same file's 3D viewer -- which only
            # tessellates once -- renders fast): this used to sample
            # EVERY edge at n_samples+1 points regardless of shape,
            # straight or curved alike. A straight edge's own 2 endpoints
            # already describe it exactly (same reasoning
            # projected_area() already uses, see its own docstring/loop
            # below) -- skipping the other n_samples-1 position_at() calls
            # on every straight edge matters a lot here specifically,
            # since most mechanical/machined parts (exactly the kind of
            # thing likely to arrive as an imported STEP file) are mostly
            # straight edges, this runs once per view (4x for the default
            # FRONT/TOP/RIGHT/ISO set, each a completely independent HLR
            # pass -- see technical_drawing_views()'s own loop), and a
            # position_at() call crosses into real OCCT/OCP curve-adaptor
            # code, not free Python. Falls back to full n_samples
            # sampling for anything whose geom_type this build123d
            # install doesn't recognize (older installs, or a genuinely
            # exotic curve type) -- slower, not wrong.
            try:
                is_line = e.geom_type == bd.GeomType.LINE
            except Exception:
                is_line = False
            n = 2 if is_line else n_samples + 1
            pts = []
            for k in range(n):
                t = k / (n - 1)
                p = e.position_at(t)
                pts.append([p.X, p.Y, p.Z])
            out.append(pts)
        return out

    return {"visible": to_polylines(visible), "hidden": to_polylines(hidden) if include_hidden else []}


def technical_drawing_views(shape, views=None, n_samples=48, custom_views=None, sections=None, time_budget_s=None, include_hidden=True):
    """
    Computes hidden-line-removed 2D views of `shape` (or a list of
    shapes -- e.g. everything a script show()'d) from the standard
    FRONT/TOP/RIGHT/ISO camera angles (see _drawing_view_directions()),
    and returns them as plain JSON-safe data:

        {"FRONT": {"visible": [[[x,y],...], ...], "hidden": [...]},
         "TOP": {...}, "RIGHT": {...}, "ISO": {...}}

    This is the geometry half of an engineering drawing -- SHEET
    LAYOUT (border, title block, arranging these 4 views on one page)
    is deliberately NOT done here; that's drawing_layout.py's
    build_sheet_svg(), which takes exactly this dict as input and has
    zero build123d/OCCT dependency of its own (see its module
    docstring for why that split exists). export_drawing_svg() below
    does both steps for you in one call, if a plain SVG file is all
    you need:

        show(part)
        views = technical_drawing_views(part)
        # -- or, for the finished sheet directly --
        export_drawing_svg(part, "part_drawing.svg", part_name="Bracket")

    `shape`: a single Shape, or a list of Shapes (e.g. [a, b] if a
    script show()'d more than one separate part) -- each shape's own
    visible/hidden edges for a given view are computed independently
    and simply concatenated into that view's polyline lists. This is
    a real limitation worth knowing, not just a simplification: if 2
    shapes actually OCCLUDE each other from some camera angle (one
    genuinely hides part of the other), that occlusion is NOT
    accounted for -- each shape's own hidden-line-removal only knows
    about itself. union()ing shapes that should occlude each other
    into one shape first, before calling this, avoids that.

    `views`: which views to compute -- defaults to all 4
    ("FRONT"/"TOP"/"RIGHT"/"ISO"); pass e.g. views=["FRONT","TOP"] to
    only compute (and pay the OCCT computation cost for) a subset.

    `n_samples`: how many points each Edge (straight or curved alike)
    is sampled into along its own length -- higher = smoother curves
    in the output, at the cost of larger polyline lists. A straight
    edge doesn't need many, but this doesn't try to detect straight-
    vs-curved automatically and skip sampling those (unlike
    projected_area(), which does exactly that via Edge.geom_type --
    see its own docstring -- because there the segment COUNT itself
    was the actual problem; here it's the visual SMOOTHNESS of curves
    that matters, so keeping every edge uniformly sampled, straight or
    not, is simpler and one less thing to get subtly wrong for a
    cosmetic win). 48 was chosen over a lower default (this used to
    default to 16) after real-world use showed circles/fillets coming
    out visibly faceted in the drawing tab at that resolution --
    especially noticeable on larger circles, where each of the 16
    facets spans more actual distance. Pass a lower n_samples yourself
    if a very edge-dense model renders too slowly at 48 and you'd
    rather trade smoothness for speed on a case-by-case basis.

    `custom_views`: extra views from an ARBITRARY angle, beyond the 4
    fixed presets -- a list of {"name": str, "direction": [x,y,z],
    "up": [x,y,z]} dicts (see _custom_view_direction()). This is what
    the Drawing tab's "Add View" button (captured live from the 3D
    viewer's own camera orientation) feeds in. Each name becomes its
    own extra key in the returned dict, laid out alongside FRONT/TOP/
    RIGHT/ISO by drawing_layout.py.

    `sections`: user-defined cross-section views -- a list of
    {"name": str, "axis": "x"/"y"/"z", "offset": float,
    "keep": "positive"/"negative"} dicts (see section_view()). Each
    one cuts every shape at that plane and looks straight at the
    freshly exposed cut face, rather than reusing FRONT/TOP/RIGHT/ISO's
    fixed uncut angles -- this is how you get a section through a
    SPECIFIC area of the part instead of always the same 4 outside
    views. A cutting plane that misses a shape entirely (see
    section_view()'s own docstring -- expected on a disconnected
    multi-body assembly, not a bug) is reported back as that view's
    own "error"/"warning" key rather than failing the whole request.

    `time_budget_s`: an optional total wall-clock budget (seconds),
    shared across every view this call would otherwise compute
    (default 4 + every custom_views/sections entry) -- once already-
    spent time exceeds it, any view that HASN'T started yet is skipped
    (marked with an "error" explaining why) rather than started. This
    exists for a real, reported problem: on a large/complex imported
    STEP file, each view is a completely independent, genuinely
    expensive OCCT HLR computation (see _hlr_polylines()'s own
    docstring) with wildly different costs depending on that view's own
    silhouette complexity -- an ISO view (3/4 angle, lots of overlapping
    geometry) can easily cost far more than a FRONT/TOP view of the
    same part. Without a budget, one slow view blocks every view queued
    after it, even ones that would have finished in seconds -- a user
    waiting on the Drawing tab sees nothing at all until literally
    everything is done. `None` (the default) means no budget, same
    behavior as before this parameter existed -- export_drawing_svg()
    callers who are fine waiting as long as it takes should leave this
    unset. Does NOT (cannot) interrupt a view that's ALREADY running --
    Python has no safe way to abort a call already inside OCCT's own
    C++ code -- so a single view that is itself slower than the whole
    budget still runs to completion; this only ever prevents starting
    MORE work on top of that.

    `include_hidden=False` drops every view's "hidden" (dashed) edges
    entirely -- see _hlr_polylines()'s own docstring for exactly what
    this does and doesn't save (real, but partial: skips sampling/
    returning hidden edges, not OCCT's own underlying visibility
    computation, which runs regardless either way).
    """
    _require_build123d()
    shapes = shape if isinstance(shape, (list, tuple)) else [shape]
    if not shapes:
        raise ValueError("technical_drawing_views(): no shape given")
    all_view_names = ["FRONT", "TOP", "RIGHT", "ISO"]
    view_names = list(views) if views else all_view_names
    unknown = [v for v in view_names if v not in all_view_names]
    if unknown:
        raise ValueError(
            f"technical_drawing_views(): unknown view name(s) {unknown} -- "
            f"choose from {all_view_names}")

    start = time.monotonic()

    def _budget_exceeded():
        return time_budget_s is not None and (time.monotonic() - start) > time_budget_s

    def _skip_reason(elapsed):
        return (
            f"skipped -- this model is taking a long time to draw (already "
            f"{elapsed:.0f}s spent on other views, budget was "
            f"{time_budget_s:.0f}s). Whichever views finished in time are "
            f"shown; reduce to just the view(s) you actually need (the "
            f"views=[...] argument, or the Drawing tab's own view "
            f"selector) rather than waiting for all of them, or call "
            f"export_drawing_svg() from a script directly if you're "
            f"willing to wait as long as it takes for the full set."
        )

    out = {v: {"visible": [], "hidden": []} for v in view_names}
    directions_by_shape = [(s, _drawing_view_directions(s)) for s in shapes]
    for v in view_names:
        if _budget_exceeded():
            out[v]["error"] = _skip_reason(time.monotonic() - start)
            continue
        for s, directions in directions_by_shape:
            d = directions[v]
            one = _hlr_polylines(
                s, d["viewport_origin"], d["viewport_up"], d["look_at"],
                n_samples=n_samples, include_hidden=include_hidden)
            out[v]["visible"].extend(one["visible"])
            out[v]["hidden"].extend(one["hidden"])

    for spec in (custom_views or []):
        name = str(spec.get("name") or "VIEW")
        direction = spec.get("direction")
        up = spec.get("up") or (0, 0, 1)
        if not direction or len(direction) != 3:
            out[name] = {"visible": [], "hidden": [], "error": "missing/invalid direction"}
            continue
        if _budget_exceeded():
            out[name] = {"visible": [], "hidden": [], "error": _skip_reason(time.monotonic() - start)}
            continue
        acc = {"visible": [], "hidden": []}
        for s in shapes:
            d = _custom_view_direction(s, direction, up)
            one = _hlr_polylines(
                s, d["viewport_origin"], d["viewport_up"], d["look_at"],
                n_samples=n_samples, include_hidden=include_hidden)
            acc["visible"].extend(one["visible"])
            acc["hidden"].extend(one["hidden"])
        out[name] = acc

    for spec in (sections or []):
        name = str(spec.get("name") or "SECTION")
        axis = spec.get("axis", "z")
        try:
            offset = float(spec.get("offset", 0.0))
        except (TypeError, ValueError):
            out[name] = {"visible": [], "hidden": [], "error": "invalid offset"}
            continue
        if _budget_exceeded():
            out[name] = {"visible": [], "hidden": [], "error": _skip_reason(time.monotonic() - start)}
            continue
        keep = spec.get("keep", "positive")
        try:
            halves, cam_dir, up, errors = section_view(shapes, axis, offset, keep)
        except ValueError as e:
            out[name] = {"visible": [], "hidden": [], "error": str(e)}
            continue
        if not halves:
            reason = "; ".join(errors) if errors else "no shapes to cut"
            out[name] = {
                "visible": [], "hidden": [],
                "error": f"the cutting plane missed every shape ({reason}) -- try a different offset",
            }
            continue
        acc = {"visible": [], "hidden": []}
        for half in halves:
            d = _custom_view_direction(half, cam_dir, up)
            one = _hlr_polylines(
                half, d["viewport_origin"], d["viewport_up"], d["look_at"],
                n_samples=n_samples, include_hidden=include_hidden)
            acc["visible"].extend(one["visible"])
            acc["hidden"].extend(one["hidden"])
        if errors:
            acc["warning"] = "some shapes couldn't be cut and were skipped: " + "; ".join(errors)
        out[name] = acc

    return out


def export_drawing_svg(shape, path, part_name=None, author=None, date=None,
                        views=None, n_samples=48):
    """
    Writes a complete engineering-drawing SVG sheet for `shape` (or a
    list of shapes) straight to `path` -- FRONT/TOP/RIGHT/ISO views
    (hidden edges dashed) laid out on one bordered sheet with a title
    block, in one call:

        export_drawing_svg(part, "bracket_drawing.svg", part_name="Bracket")

    Just technical_drawing_views(shape, views, n_samples) followed by
    drawing_layout.build_sheet_svg() -- see both of those for exactly
    what each half does/assumes (technical_drawing_views() in
    particular has real caveats worth reading, since HLR-based
    drawings are new in this app and only checked against a MOCKED
    build123d so far -- see this module's own header docstring).

    `part_name`/`author`/`date`: title block text; `part_name`
    defaults to `path`'s own filename (without extension) if not
    given, `date` defaults to today.
    """
    _require_build123d()
    if part_name is None:
        base = re.sub(r"\.[^.]+$", "", str(path).replace("\\", "/").rsplit("/", 1)[-1])
        part_name = base or "Part"
    view_data = technical_drawing_views(shape, views=views, n_samples=n_samples)
    svg_bytes = drawing_layout.build_sheet_svg(
        view_data, part_name=part_name, author=author, date=date)
    with open(path, "wb") as f:
        f.write(svg_bytes)
    return str(path)


if __name__ == "__main__":
    # quick manual smoke test -- run this file directly (after
    # pip install build123d) to sanity-check the wiring against a real
    # install. Builds a notched cone, prints its exact volume, exports
    # STEP/STL, tessellates it for the mesh viewer, and (new) generates
    # an engineering-drawing SVG -- open brep_smoke_test_drawing.svg
    # afterward and eyeball it: 4 correctly labeled, flat 2D views (not
    # a skewed 3D wireframe -- see _hlr_polylines()'s own docstring for
    # exactly what would look wrong and why, if project_to_viewport()'s
    # actual output convention turns out to differ from what's assumed
    # here), with the notch's hidden edges showing dashed where they're
    # behind the outer cone surface from that particular view angle.
    _require_build123d()
    a = cylinder(r1=20, r2=0, h=20)
    b = box([10, 10, 40], center=True)
    c = difference(a, translate([0, 0, -10], b))
    print("volume:", volume(c))
    export_step(c, "brep_smoke_test.step")
    export_stl(c, "brep_smoke_test.stl")
    v, f = to_mesh(c)
    print("tessellated:", len(v), "vertices,", len(f), "triangles")
    export_drawing_svg(c, "brep_smoke_test_drawing.svg", part_name="Notched Cone")
    print("wrote brep_smoke_test_drawing.svg -- open it and check all 4 views "
          "look like flat, correctly labeled 2D projections")
