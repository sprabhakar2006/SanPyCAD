"""
brep.py -- an OpenSCAD-flavored wrapper around build123d: this IS the
geometry engine for SanPyCAD Brep. Every primitive/transform/boolean/
fillet a script calls (see python_eval.py's make_namespace()) is one of
the functions below, producing genuine boundary-representation (B-rep)
solids, not triangle meshes -- exact analytic surfaces (planes,
cylinders, cones, spheres) or exact NURBS surfaces, exact curves for
edges, held together as an exact topological structure (faces bounded
by edge loops, edges bounded by vertices) rather than a pile of flat
triangles. STEP files are built entirely around that model -- that's
why a mesh can only ever be SMUGGLED into a STEP file as "tessellated"
(faceted) geometry, not real B-rep; export_step()/export_brep() below
write the genuine thing.

Writing an actual B-rep kernel (robust NURBS intersection, exact
booleans, fillets, tolerance handling) from scratch is a many-person-
years undertaking -- not something to reproduce here. Instead this
module builds on OpenCASCADE Technology (OCCT), the same open-source
B-rep kernel FreeCAD itself is built on, via build123d -- a Python CAD
library with a code-first style, in an OpenSCAD-like vocabulary
(cube/cylinder/sphere, translate/rotate, union/difference/intersection)
so it reads like the mesh-based SanPyCAD apps' scripts, just backed by
real exact solids instead of triangle soup.

Requires build123d -- the one hard third-party dependency of this whole
app (see requirements.txt / README.md):
    pip install build123d
build123d itself pulls in OCP (the OpenCASCADE Python bindings) as a
pip-installable wheel, no conda/compiling required on a normal
Windows/macOS/Linux install. If it isn't installed, this module still
imports cleanly (so e.g. the doc/reference scanner in server.py can
still load it) -- every function just raises a clear "pip install
build123d" ImportError the moment a script actually calls one (see
_require_build123d()).

IMPORTANT -- this module has been written and structurally checked
against a MOCKED build123d (fake bd.Box/bd.Cylinder/etc recording every
call) but has NOT been run against a real build123d install: this
sandbox has no network access to pip install it. The wiring (which
build123d functions get called, with what arguments, in what order) has
been verified; the actual geometry math (is a Cone's r1/r2/h convention
really what cube()/cylinder()'s docstrings below claim, does
translate() move things the direction you'd expect) has NOT. Please
pip install build123d, run the examples in examples/, or the smoke test
at the bottom of this file (`python3 backend/brep.py`), and report back
what breaks or looks wrong. rotate()/rot() are built entirely out of
single-axis rotations chained together (never a combined multi-axis
call), specifically so they don't depend on build123d's own multi-axis
composition convention, which its docs don't pin down clearly enough to
rely on directly -- so those two should be trustworthy even though the
rest of this is unverified.

Basic usage:
    a = cylinder(r1=20, r2=0, h=20)
    b = box([10, 10, 40], center=True)
    c = difference(a, translate([0, 0, -10], b))
    export_step(c, "cone_notched.step")
    show(c)   # SanPyCAD Brep's own viewer (see python_eval.py's show())
"""

import math
import re

try:
    import build123d as bd
    _HAVE_BUILD123D = True
    _IMPORT_ERROR = None
except Exception as _e:  # pragma: no cover - exercised via test_brep.py mocking
    bd = None
    _HAVE_BUILD123D = False
    _IMPORT_ERROR = _e


def _require_build123d():
    """
    internal: importing brep.py itself never fails just because
    build123d isn't installed yet (so e.g. a doc/reference scanner can
    still load this file) -- but every function that actually needs it
    calls this first, so you get one clear, actionable error instead of
    a confusing AttributeError on `bd`.
    """
    if not _HAVE_BUILD123D:
        raise ImportError(
            "brep.py needs the 'build123d' package, which isn't installed "
            "in this Python environment. Install it with:\n"
            "    pip install build123d\n"
            f"(original import error: {_IMPORT_ERROR!r})"
        )


def _align(center):
    """
    internal: openscad4.py's cube() uses a plain `center` bool (True =
    centered on the origin, False = one corner sitting at the origin,
    same as real OpenSCAD) -- build123d instead uses an explicit Align
    enum per axis. This is the single place that translates one
    convention into the other for BOX-shaped primitives (a box has an
    actual corner on every axis, so `center` genuinely applies to
    X/Y/Z alike) -- for circular-cross-section primitives (cylinder()/
    cone()) use _align_radial() below instead, NOT this.
    """
    a = bd.Align.CENTER if center else bd.Align.MIN
    return (a, a, a)


def _align_radial(center):
    """
    internal: real OpenSCAD's cylinder(center=...) ONLY ever affects
    Z (False: base circle sits at z=0, spanning up to z=h; True:
    centered on Z too) -- X and Y are ALWAYS centered on the shape's
    own axis regardless of `center`, because a circle has no "corner"
    the way a box does. REAL BUG FIX (found via a real user report --
    a cylinder(center=False) landing with its axis offset to (r,r)
    instead of (0,0)): cylinder() used to reuse _align() above, which
    applies the SAME Align enum to all three axes -- correct for box()
    (whose corner really is at (0,0,0) when center=False), but wrong
    here, since build123d's Align.MIN on a circular Face/Solid shifts
    its BOUNDING BOX's corner to the origin, i.e. shifts the axis
    itself to (radius, radius) -- not the "base circle centered at
    (0,0), sitting at z=0" real OpenSCAD gives you. This function is
    the fix: X/Y are unconditionally CENTER, only Z follows `center`.
    """
    z = bd.Align.CENTER if center else bd.Align.MIN
    return (bd.Align.CENTER, bd.Align.CENTER, z)


def box(size=1, center=False):
    """
    A B-rep rectangular solid -- `size` is either one number (a cube) or
    [x,y,z] (a box), `center` follows real OpenSCAD's meaning (False:
    one corner sits at the origin; True: centered on the origin).
    Builds a build123d Box under the hood.
    """
    _require_build123d()
    if isinstance(size, (int, float)):
        sx = sy = sz = float(size)
    else:
        sx, sy, sz = [float(v) for v in size]
    return bd.Box(sx, sy, sz, align=_align(center))


def cube(size=1, center=False):
    """Alias for box() under OpenSCAD's own name for this primitive."""
    return box(size, center)


def cylinder(r1=None, r2=None, h=1, r=None, center=False, s=None):
    """
    A B-rep cylinder or (truncated) cone -- same r1/r2/h/r/center
    parameters as real OpenSCAD's cylinder(). `s` (segment count /
    $fn) is accepted only for drop-in call compatibility and is
    IGNORED: this is exact geometry, there's no facet count to choose
    -- a cylinder here really is round, not a many-sided prism
    approximating one.

    r1/r2 both given (and different) -> build123d Cone(r1, r2, h).
    Otherwise (r, or matching r1==r2) -> build123d Cylinder(radius, h).
    """
    _require_build123d()
    if r is not None:
        rad1 = rad2 = float(r)
    else:
        rad1 = float(r1) if r1 is not None else 1.0
        rad2 = float(r2) if r2 is not None else rad1
    align = _align_radial(center)
    if rad1 == rad2:
        return bd.Cylinder(rad1, float(h), align=align)
    return bd.Cone(rad1, rad2, float(h), align=align)


def sphere(r=1):
    """A B-rep sphere -- same `r` meaning as openscad4.py's sphere()."""
    _require_build123d()
    return bd.Sphere(float(r))


# ---------------------------------------------------------------------
# 2D profiles -- feed these into linear_extrude()/rotate_extrude() to
# turn them into a solid, the same role openscad4.py's own circle()/
# square()/polygon() play there, just returning a real build123d Sketch
# (a bounded planar Face) instead of a bare [x,y] point list.
# ---------------------------------------------------------------------

def circle(r=1, cp=[0, 0], s=None):
    """
    A B-rep 2D disc, centered at the origin by default -- same as real
    OpenSCAD's circle(r) (which is likewise always centered; real
    OpenSCAD's circle() has no `center` parameter -- use `cp` to shift
    it instead, or translate() the result).

    `s` (segment count -- same name/meaning as openscad4.py's own
    circle(r, cp, s)) controls whether this is exact or faceted:

      s=None (the default) -- an exact round B-rep circle. No facet
      count needed, since the underlying curve is exact -- this is
      different from openscad4.py's circle() (which always faceted,
      defaulting to s=50) and from real OpenSCAD's circle() (which
      always faceted too, at whatever $fn/$fa/$fs resolve to); deviates
      from both on purpose, since "exact" is strictly better than "a
      50-sided polygon" when nothing forces a facet count in the first
      place.

      s=<some integer> -- instead builds an s-sided regular polygon
      approximating a circle (via polygon()), the same way
      openscad4.py's circle() does (this is also how real OpenSCAD's
      own circle($fn=...) behaves at a low $fn/segment count). Useful
      for genuinely wanting flat sides, not just an approximation:
      circle(10, s=6) is a hexagon, circle(10, s=3) a triangle, etc.
    """
    _require_build123d()
    if s is None:
        out = bd.Circle(float(r))
    else:
        n = int(s)
        if n < 3:
            raise ValueError(
                f"circle(): s must be at least 3 (a triangle) to form a polygon, got {s!r}")
        pts = [[r * math.cos(2 * math.pi * i / n), r * math.sin(2 * math.pi * i / n)]
               for i in range(n)]
        out = polygon(pts)
    if cp[0] or cp[1]:
        out = translate([cp[0], cp[1], 0], out)
    return out


def square(size=1, center=False):
    """
    A B-rep 2D rectangle -- same call convention as OpenSCAD's
    square(): `size` is either one number (a square) or [x,y], `center`
    follows OpenSCAD's meaning (False: one corner sits at the origin;
    True: centered on the origin).
    """
    _require_build123d()
    if isinstance(size, (int, float)):
        sx = sy = float(size)
    else:
        sx, sy = [float(v) for v in size]
    a = bd.Align.CENTER if center else bd.Align.MIN
    return bd.Rectangle(sx, sy, align=(a, a))


def _segments_cross(p1, p2, p3, p4):
    """internal: True if 2D segments p1-p2 and p3-p4 PROPERLY cross
    each other (excluding merely touching at a shared point/endpoint,
    which is fine for a polygon loop -- only an actual crossing makes
    it self-intersecting)."""
    def ccw(a, b, c):
        return (c[1] - a[1]) * (b[0] - a[0]) - (b[1] - a[1]) * (c[0] - a[0])
    d1, d2 = ccw(p3, p4, p1), ccw(p3, p4, p2)
    d3, d4 = ccw(p1, p2, p3), ccw(p1, p2, p4)
    return (d1 != 0 and d2 != 0 and (d1 > 0) != (d2 > 0)
            and d3 != 0 and d4 != 0 and (d3 > 0) != (d4 > 0))


def _find_self_intersection(pts):
    """internal: (i, j) indices of the first pair of non-adjacent
    closed-loop edges of `pts` that cross each other, or None if the
    loop is simple (no self-intersections)."""
    n = len(pts)
    edges = [(pts[i], pts[(i + 1) % n]) for i in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            if j == i + 1 or (i == 0 and j == n - 1):
                continue
            if _segments_cross(edges[i][0], edges[i][1], edges[j][0], edges[j][1]):
                return (i, j)
    return None


def polygon(points):
    """
    A B-rep 2D filled polygon through `points` ([[x,y], ...] -- the same
    shape openscad4.py's own circle()/square() return, and what
    OpenSCAD's polygon(points) takes). Unlike those, the winding order
    of `points` controls which way the resulting face's normal points
    (counter-clockwise -> +Z-facing normal, clockwise -> -Z-facing) --
    which matters for linear_extrude()'s default extrude direction.

    The loop is closed automatically (the last point connects straight
    back to the first) -- don't append `points[0]` again to "close" it
    yourself, that creates a zero-length closing edge (invalid
    geometry, since the polygon is then closed twice) rather than
    actually closing anything; if `points` does end with a near-exact
    repeat of its own first point, that repeat is dropped for you.

    That auto-added closing edge has to not cross `points`' own
    outline anywhere, or the result is a self-intersecting (invalid)
    shape -- easy to hit by accident when `points` comes from an open
    curve (bezier()/bspline_open()/etc) whose two ends don't line up
    with its own overall direction. Checked and raised here with a
    clear error pointing at which two points cross, rather than
    silently building invalid geometry that only fails much later,
    cryptically, when the viewer tries to tessellate it.

    Only builds a FLAT profile in the XY plane -- a nonzero z on any
    point RAISES rather than being silently dropped (a real user hit
    this: axis_rot_1_pts()-ing a point list out of the XY plane, then
    handing it to polygon() expecting the bend to carry through --
    it didn't, since a flat Face has no way to represent it, and the
    z values were just discarded with no warning). If `points` is
    already positioned/bent in 3D, use p_line3d(points, ...) to trace
    it directly as a tube instead (no flattening); if you actually
    want a flat profile repositioned in 3D, build it flat here first
    and move/rotate the resulting real Shape afterward with
    translate()/rotate()/axis_rot_1() instead of pre-rotating the raw
    points.
    """
    _require_build123d()
    for i, p in enumerate(points):
        if len(p) > 2 and abs(float(p[2])) > 1e-6:
            raise ValueError(
                f"polygon(): point {i} has a nonzero z ({p[2]!r}) -- polygon() "
                f"only builds a flat profile in the XY plane and would silently "
                f"drop it (see polygon()'s own docstring). Use p_line3d(points, "
                f"...) to trace an already-3D point list directly instead, or "
                f"build the flat profile here and reposition the resulting "
                f"Shape afterward with translate()/rotate()/axis_rot_1().")
    pts = [(float(p[0]), float(p[1])) for p in points]
    if len(pts) > 1 and math.hypot(pts[-1][0] - pts[0][0], pts[-1][1] - pts[0][1]) < 1e-9:
        pts = pts[:-1]
    hit = _find_self_intersection(pts)
    if hit is not None:
        i, j = hit
        raise ValueError(
            f"polygon(): the closed loop through `points` crosses itself, "
            f"between the edge after point {i} and the edge after point {j} "
            f"-- not a valid simple polygon. If `points` came from an open "
            f"curve, check whether its own closing edge (last point back to "
            f"first) crosses the curve -- see polygon()'s own docstring.")
    return bd.Polygon(*pts)


def turtle2d(offsets):
    """
    Converts a list of relative [dx, dy] offsets into absolute [x, y]
    points via a running cumulative sum -- "turtle graphics" style path
    building: each entry means "move this far from wherever you just
    were", not an absolute coordinate. Feed the result into polygon()
    to sketch a closed outline from turtle-style steps instead of
    typing out absolute coordinates by hand:
        sec = turtle2d([[0,0],[10,0],[0,5],[-10,0]])   # a 10x5 rectangle
        show(linear_extrude(polygon(sec), h=3))

    Plain Python -- no build123d involved, just produces the point list
    polygon() then turns into a real B-rep face.
    """
    x, y = 0.0, 0.0
    out = []
    for dx, dy in offsets:
        x += float(dx)
        y += float(dy)
        out.append([x, y])
    return out


def turtle3d(offsets):
    """
    Converts a list of relative [dx, dy, dz] offsets into absolute
    [x, y, z] points via a running cumulative sum -- the 3D counterpart
    of turtle2d() (see its docstring). Each entry means "move this far
    from wherever you just were", not an absolute coordinate:
        path = turtle3d([[0,0,0],[10,0,0],[0,0,10],[0,10,0]])
        # -> [[0,0,0], [10,0,0], [10,0,10], [10,10,10]]

    Plain Python -- no build123d involved. There's no 3D polyline/sweep
    primitive in brep.py yet to feed this straight into, but it's handy
    for building a 3D point path to pass to your own build123d curve
    construction in a script, e.g.:
        from build123d import Polyline
        wire = Polyline(*turtle3d(offsets))
    or for sanity-checking a path's shape with echo()/show_edges()-style
    inspection before using it elsewhere.
    """
    x, y, z = 0.0, 0.0, 0.0
    out = []
    for dx, dy, dz in offsets:
        x += float(dx)
        y += float(dy)
        z += float(dz)
        out.append([x, y, z])
    return out


def _2d_unit(v):
    """internal: unit 2D vector, or raises if `v` is (numerically) zero."""
    n = math.hypot(v[0], v[1])
    if n < 1e-12:
        raise ValueError("cr2dt(): a zero-length edge in the path")
    return (v[0] / n, v[1] / n)


def _3d_unit(v):
    """internal: unit 3D vector, or raises if `v` is (numerically) zero."""
    n = math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
    if n < 1e-12:
        raise ValueError("cr3dt(): a zero-length edge in the path")
    return (v[0] / n, v[1] / n, v[2] / n)


def _3d_cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _3d_dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def cr2dt(sec, s=20):
    """
    Builds a closed 2D point-list outline from turtle-style relative
    [dx,dy] (or [dx,dy,r]) offsets, rounding each vertex with a fillet
    arc of radius r (0 -- the default when a point omits it -- means
    "leave this vertex sharp"). Feed the result into polygon() for a
    rounded-corner 2D profile:
        sec = cr2dt([[0,0,2],[10,0,2],[0,10,2],[-10,0,2]], 10)
        show(linear_extrude(polygon(sec), h=3))
    The short name of openscad4.py's corner_radius_with_turtle()
    (cr2dt is that function's own alias there too), reimplemented from
    scratch here -- plain trig (an unsigned "shortest way around" arc
    between the two tangent points at each corner), not a port of the
    original's own ~15-branch case analysis by incoming/outgoing corner
    orientation, since the shortest-way-around trick handles either
    polygon winding direction without needing to tell them apart.

    sec: [[dx,dy], ...] or [[dx,dy,r], ...] -- same turtle convention as
        turtle2d() (each entry moves relative to wherever you just
        were; the first entry is effectively the absolute starting
        point, since the running sum starts at [0,0]), with an optional
        trailing fillet radius per point.
    s: segments per rounded corner (a sharp vertex, r=0, is always just
        1 point either way).

    Like corner_radius_with_turtle() itself, this ALWAYS treats `sec`
    as a closed loop -- the corner-rounding at point 0 uses the LAST
    point as its "previous" neighbor, and vice versa -- so if you want
    the first/last points left exactly as given (e.g. building one edge
    of an open profile, not a closed polygon), leave their radius at 0
    (the default when omitted).

    Raises if a requested radius doesn't fit between a vertex and
    either neighboring point (same "radius too large" check the
    original makes, just against each corner's own two edges directly
    here, rather than needing the original's incoming/outgoing-radius
    bookkeeping across the whole loop).
    """
    pts = []
    radii = []
    x, y = 0.0, 0.0
    for p in sec:
        x += float(p[0])
        y += float(p[1])
        pts.append((x, y))
        radii.append(float(p[2]) if len(p) > 2 else 0.0)
    n = len(pts)
    if n < 3:
        raise ValueError("cr2dt(): need at least 3 points")

    out = []
    for i in range(n):
        cur = pts[i]
        prev_pt = pts[i - 1]
        next_pt = pts[(i + 1) % n]
        r = radii[i]
        if r == 0:
            out.append([cur[0], cur[1]])
            continue
        d1 = (prev_pt[0] - cur[0], prev_pt[1] - cur[1])
        d2 = (next_pt[0] - cur[0], next_pt[1] - cur[1])
        len1 = math.hypot(*d1)
        len2 = math.hypot(*d2)
        u1 = _2d_unit(d1)
        u2 = _2d_unit(d2)
        dot = max(-1.0, min(1.0, u1[0] * u2[0] + u1[1] * u2[1]))
        theta = math.acos(dot)
        if theta < 1e-9 or theta > math.pi - 1e-9:
            # straight-through or fully-reversed vertex -- no
            # well-defined corner to round; keep the vertex as-is
            out.append([cur[0], cur[1]])
            continue
        tlen = r / math.tan(theta / 2)
        if tlen > len1 or tlen > len2:
            raise ValueError(
                f"cr2dt(): radius {r} at point {i} is too large for its "
                f"adjacent edges (needs {tlen:.6g}, edges are "
                f"{len1:.6g}/{len2:.6g} long)")
        t1 = (cur[0] + u1[0] * tlen, cur[1] + u1[1] * tlen)
        t2 = (cur[0] + u2[0] * tlen, cur[1] + u2[1] * tlen)
        bis_u = _2d_unit((u1[0] + u2[0], u1[1] + u2[1]))
        center_dist = r / math.sin(theta / 2)
        center = (cur[0] + bis_u[0] * center_dist, cur[1] + bis_u[1] * center_dist)
        a1 = math.atan2(t1[1] - center[1], t1[0] - center[0])
        a2 = math.atan2(t2[1] - center[1], t2[0] - center[0])
        d_angle = (a2 - a1 + math.pi) % (2 * math.pi) - math.pi  # shortest way around
        for k in range(s + 1):
            a = a1 + d_angle * k / s
            out.append([center[0] + r * math.cos(a), center[1] + r * math.sin(a)])
    return out


def cr3dt(pnts, s=5):
    """
    3D counterpart of cr2dt() -- builds a closed 3D point-list outline
    from turtle-style relative [dx,dy,dz] (or [dx,dy,dz,r]) offsets,
    rounding each vertex with a fillet arc of radius r. Any two edges
    meeting at a vertex share a plane (two lines through a common point
    always do), so this is the exact same fillet-arc construction
    cr2dt() uses, just built inside that per-corner plane instead of
    always the flat XY one. The short name of openscad4.py's
    corner_radius3d_with_turtle() -- reimplemented from scratch, not a
    port (see cr2dt()'s docstring for why).

    pnts: [[dx,dy,dz], ...] or [[dx,dy,dz,r], ...] -- same turtle
        convention as turtle3d(), with an optional trailing fillet
        radius per point.
    s: segments per rounded corner.

    Same closed-loop wraparound behavior as cr2dt() -- leave the radius
    at 0 (the default) on any point you don't want rounded using a
    wraparound neighbor (e.g. the first/last point of what's
    conceptually an open path -- see cr2dt()'s docstring). Feed the
    result straight into sweep_sec2path()'s path3d for a pre-rounded
    path (an alternative to that function's own transition="round").
    """
    pts = []
    radii = []
    x, y, z = 0.0, 0.0, 0.0
    for p in pnts:
        x += float(p[0])
        y += float(p[1])
        z += float(p[2])
        pts.append((x, y, z))
        radii.append(float(p[3]) if len(p) > 3 else 0.0)
    n = len(pts)
    if n < 3:
        raise ValueError("cr3dt(): need at least 3 points")

    out = []
    for i in range(n):
        cur = pts[i]
        prev_pt = pts[i - 1]
        next_pt = pts[(i + 1) % n]
        r = radii[i]
        if r == 0:
            out.append(list(cur))
            continue
        d1 = (prev_pt[0] - cur[0], prev_pt[1] - cur[1], prev_pt[2] - cur[2])
        d2 = (next_pt[0] - cur[0], next_pt[1] - cur[1], next_pt[2] - cur[2])
        len1 = math.sqrt(d1[0] * d1[0] + d1[1] * d1[1] + d1[2] * d1[2])
        len2 = math.sqrt(d2[0] * d2[0] + d2[1] * d2[1] + d2[2] * d2[2])
        u1 = _3d_unit(d1)
        u2 = _3d_unit(d2)
        dot = max(-1.0, min(1.0, _3d_dot(u1, u2)))
        theta = math.acos(dot)
        if theta < 1e-9 or theta > math.pi - 1e-9:
            out.append(list(cur))
            continue
        tlen = r / math.tan(theta / 2)
        if tlen > len1 or tlen > len2:
            raise ValueError(
                f"cr3dt(): radius {r} at point {i} is too large for its "
                f"adjacent edges (needs {tlen:.6g}, edges are "
                f"{len1:.6g}/{len2:.6g} long)")
        t1 = (cur[0] + u1[0] * tlen, cur[1] + u1[1] * tlen, cur[2] + u1[2] * tlen)
        t2 = (cur[0] + u2[0] * tlen, cur[1] + u2[1] * tlen, cur[2] + u2[2] * tlen)
        bis_u = _3d_unit((u1[0] + u2[0], u1[1] + u2[1], u1[2] + u2[2]))
        center_dist = r / math.sin(theta / 2)
        center = (
            cur[0] + bis_u[0] * center_dist,
            cur[1] + bis_u[1] * center_dist,
            cur[2] + bis_u[2] * center_dist,
        )
        e1 = _3d_unit((t1[0] - center[0], t1[1] - center[1], t1[2] - center[2]))
        normal = _3d_unit(_3d_cross(u1, u2))
        e2 = _3d_cross(normal, e1)  # unit length: normal, e1 are unit & perpendicular
        t2_dir = _3d_unit((t2[0] - center[0], t2[1] - center[1], t2[2] - center[2]))
        span = math.atan2(_3d_dot(t2_dir, e2), _3d_dot(t2_dir, e1))  # shortest way around
        for k in range(s + 1):
            a = span * k / s
            ca, sa = math.cos(a), math.sin(a)
            out.append([
                center[0] + r * (ca * e1[0] + sa * e2[0]),
                center[1] + r * (ca * e1[1] + sa * e2[1]),
                center[2] + r * (ca * e1[2] + sa * e2[2]),
            ])
    return out


def corner_n_radius_list(p0, r_l, n=10):
    """
    Rounds each corner of the ABSOLUTE 2D point list `p0` (a closed
    loop) using the matching radius from the parallel list `r_l` (same
    length as p0; 0 means "leave this vertex sharp") -- cr2dt()'s
    sibling for when you already have a fixed set of absolute corner
    points (e.g. a rectangle's 4 known corners) rather than a chain of
    turtle-style relative offsets: openscad4.py's own
    corner_n_radius_list(), ported. `n` is the number of segments per
    rounded corner (a sharp vertex, r=0, is always just 1 point either
    way -- same convention as cr2dt()'s `s`).

        sec = corner_n_radius_list([[0,0],[10,0],[10,10],[0,10]], [1,2,3,4], 10)
        show(linear_extrude(polygon(sec), h=3))

    Like cr2dt(), always treats `p0` as a CLOSED loop -- corner 0's
    rounding uses the LAST point as its "previous" neighbor, and vice
    versa, so leave a point's radius at 0 if you want it left exactly
    as given (e.g. the end of what's conceptually an open path).
    Raises if a requested radius doesn't fit between a vertex and
    either neighboring edge -- same check as cr2dt().

    openscad4.py also has a corner_n_radius_list_3d() 3D counterpart
    (absolute 3D points, corners rounded in each one's own local
    plane, same idea as cr3dt() vs cr2dt()) -- not ported here, ask if
    you want it too.
    """
    n_pts = len(p0)
    if n_pts < 3:
        raise ValueError("corner_n_radius_list(): need at least 3 points")
    if len(r_l) != n_pts:
        raise ValueError(
            f"corner_n_radius_list(): r_l has {len(r_l)} entries but p0 has "
            f"{n_pts} points -- they need to be the same length (one radius "
            f"per corner, 0 for a sharp one).")
    pts = [(float(p[0]), float(p[1])) for p in p0]

    out = []
    for i in range(n_pts):
        cur = pts[i]
        prev_pt = pts[i - 1]
        next_pt = pts[(i + 1) % n_pts]
        r = float(r_l[i])
        if r == 0:
            out.append([cur[0], cur[1]])
            continue
        d1 = (prev_pt[0] - cur[0], prev_pt[1] - cur[1])
        d2 = (next_pt[0] - cur[0], next_pt[1] - cur[1])
        len1 = math.hypot(*d1)
        len2 = math.hypot(*d2)
        u1 = _2d_unit(d1)
        u2 = _2d_unit(d2)
        dot = max(-1.0, min(1.0, u1[0] * u2[0] + u1[1] * u2[1]))
        theta = math.acos(dot)
        if theta < 1e-9 or theta > math.pi - 1e-9:
            # straight-through or fully-reversed vertex -- no
            # well-defined corner to round; keep the vertex as-is
            out.append([cur[0], cur[1]])
            continue
        tlen = r / math.tan(theta / 2)
        if tlen > len1 or tlen > len2:
            raise ValueError(
                f"corner_n_radius_list(): radius {r} at point {i} is too "
                f"large for its adjacent edges (needs {tlen:.6g}, edges are "
                f"{len1:.6g}/{len2:.6g} long)")
        t1 = (cur[0] + u1[0] * tlen, cur[1] + u1[1] * tlen)
        t2 = (cur[0] + u2[0] * tlen, cur[1] + u2[1] * tlen)
        bis_u = _2d_unit((u1[0] + u2[0], u1[1] + u2[1]))
        center_dist = r / math.sin(theta / 2)
        center = (cur[0] + bis_u[0] * center_dist, cur[1] + bis_u[1] * center_dist)
        a1 = math.atan2(t1[1] - center[1], t1[0] - center[0])
        a2 = math.atan2(t2[1] - center[1], t2[0] - center[0])
        d_angle = (a2 - a1 + math.pi) % (2 * math.pi) - math.pi  # shortest way around
        for k in range(n + 1):
            a = a1 + d_angle * k / n
            out.append([center[0] + r * math.cos(a), center[1] + r * math.sin(a)])
    return out


# ---------------------------------------------------------------------------
# Core point-list/vector-math toolkit, ported from openscad4.py -- pure
# Python (no build123d), same spirit as turtle2d()/turtle3d()/cr2dt()/
# cr3dt() above: build/inspect plain [[x,y],...] or [[x,y,z],...] point
# lists by hand, then feed the result into polygon()/sweep_sec2path()/
# your own script logic. openscad4.py has ~580 top-level functions in
# this vein; this is a first, curated batch of ~36 of the most broadly
# useful ones (arcs/circles, line/vector math, intersections, mirror/
# rotate, sorting/cleanup, convex hull, plane/normal, bezier/b-spline)
# -- reimplemented from scratch against each one's documented behavior
# (openscad4.py's own versions are numpy-vectorized internals not meant
# to be read function-by-function), not ported line-for-line. A few
# related functions (path/polygon offset, line-circle fillets, the more
# exotic derived-curve smoothers) need deeper follow-up work and were
# deliberately left out of this batch -- ask if you want those next.
# ---------------------------------------------------------------------------

def _flatten_points(nested):
    """internal: flattens an arbitrarily-nested list of points (a plain
    point list, a stack of sections, or a mesh vertex list) down to a
    flat list of point tuples."""
    out = []

    def walk(x):
        if isinstance(x, (list, tuple)) and len(x) > 0 and isinstance(x[0], (int, float)):
            out.append(tuple(float(c) for c in x))
        elif isinstance(x, (list, tuple)):
            for y in x:
                walk(y)

    walk(nested)
    return out


def _polar_angle_deg(vx, vy):
    """internal: polar angle of (vx,vy) in degrees, 0-360."""
    a = math.degrees(math.atan2(vy, vx))
    return a + 360 if a < 0 else a


def _cw_2d(pts):
    """internal: 1 if `pts` (>=3 2D points) winds clockwise, -1 if
    counter-clockwise, 0 if collinear/degenerate -- matches arc_2p()/
    cir_2p()'s own cw=1(clockwise)/-1(counter-clockwise) convention."""
    area2 = 0.0
    n = len(pts)
    for i in range(n):
        x0, y0 = pts[i][0], pts[i][1]
        x1, y1 = pts[(i + 1) % n][0], pts[(i + 1) % n][1]
        area2 += x0 * y1 - x1 * y0
    if area2 > 1e-12:
        return -1
    if area2 < -1e-12:
        return 1
    return 0


def _arc_deg(r, a1, a2, cp, s):
    """internal: point list tracing an arc of radius `r` centered at
    2D point `cp`, from angle `a1` to `a2` degrees (0 = +X axis,
    counter-clockwise-positive, same convention math.atan2 uses), as
    `s` segments (s+1 points)."""
    out = []
    for k in range(s + 1):
        a = math.radians(a1 + (a2 - a1) * k / s)
        out.append([cp[0] + r * math.cos(a), cp[1] + r * math.sin(a)])
    return out


def _project_point_on_segment(p, seg_pts):
    """internal: perpendicular foot of `p` on segment seg_pts=[a,b] (2D
    or 3D), the fraction `t` along it (0=a, 1=b, NOT clamped -- caller
    decides what an out-of-[0,1] t means), and the distance from `p` to
    that foot."""
    a, b = seg_pts
    dim = len(a)
    v = [b[i] - a[i] for i in range(dim)]
    vlen2 = sum(c * c for c in v)
    if vlen2 < 1e-18:
        return list(a), 0.0, l_len([p, a])
    w = [p[i] - a[i] for i in range(dim)]
    t = sum(v[i] * w[i] for i in range(dim)) / vlen2
    foot = [a[i] + v[i] * t for i in range(dim)]
    return foot, t, l_len([p, foot])


def seg(sec):
    """
    Consecutive [p_i, p_{i+1}] pairs from `sec`, wrapping the last
    point back to the first -- e.g. seg([[0,0],[10,0],[10,10]]) ->
    [[[0,0],[10,0]], [[10,0],[10,10]], [[10,10],[0,0]]]. Works on plain
    values too: seg([1,2,3]) -> [[1,2],[2,3],[3,1]]. A small building
    block several of the other functions below (and your own scripts)
    are built on.
    """
    n = len(sec)
    return [[sec[i], sec[(i + 1) % n]] for i in range(n)]


def flip(sec):
    """Reverses the order of a list -- e.g. flip([1,2,3]) -> [3,2,1].
    Handy for reversing a point list's winding direction."""
    return list(sec[::-1])


def l_len(line):
    """The length of a 2-point line [p0,p1] -- 2D or 3D. l_len([[0,0],
    [10,0]]) -> 10.0"""
    p0, p1 = line
    return math.sqrt(sum((float(p1[i]) - float(p0[i])) ** 2 for i in range(len(p0))))


def l_lenv(sec):
    """Perimeter of the closed point list `sec` -- the sum of every
    segment length from seg(sec)."""
    return sum(l_len(s) for s in seg(sec))


def mid_point(line):
    """
    The point exactly halfway along `line` by arc length -- for a
    plain 2-point line that's just the average of the endpoints; for a
    longer polyline, the point half its total length along the path
    (not the average of all the points).
    """
    if len(line) == 2:
        p0, p1 = line
        return [(float(p0[i]) + float(p1[i])) / 2.0 for i in range(len(p0))]
    segs = [(line[i], line[i + 1]) for i in range(len(line) - 1)]
    lengths = [l_len(list(s)) for s in segs]
    half = sum(lengths) / 2.0
    walked = 0.0
    for (p0, p1), length in zip(segs, lengths):
        if walked + length >= half or length == 0:
            t = 0.0 if length == 0 else (half - walked) / length
            return [float(p0[i]) + (float(p1[i]) - float(p0[i])) * t for i in range(len(p0))]
        walked += length
    return list(line[-1])


def bb(prism):
    """The 3D bounding-box size [width, height, depth] of a point list
    or nested list of point lists (e.g. to_mesh()'s vertex list, or a
    stack of sections)."""
    pts = _flatten_points(prism)
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    zs = [p[2] for p in pts]
    return [max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs)]


def bb2d(sec):
    """2D counterpart of bb() -- [width, height] of a 2D point list."""
    pts = _flatten_points(sec)
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return [max(xs) - min(xs), max(ys) - min(ys)]


def cog(sol):
    """Center of gravity (plain centroid, not area/volume-weighted) of
    a point list or nested list of point lists."""
    pts = _flatten_points(sol)
    n = len(pts)
    dim = len(pts[0])
    return [sum(p[i] for p in pts) / n for i in range(dim)]


def line_as_vector(line):
    """The vector from a 2-point line's start to its end -- e.g.
    line_as_vector([[0,0],[10,0]]) -> [10.0, 0.0]."""
    p0, p1 = line
    return [float(p1[i]) - float(p0[i]) for i in range(len(p0))]


def line_as_unit_vector(line):
    """Unit-length version of line_as_vector()."""
    v = line_as_vector(line)
    n = math.sqrt(sum(c * c for c in v))
    if n < 1e-12:
        raise ValueError("line_as_unit_vector(): a zero-length line")
    return [c / n for c in v]


def _rotate_points_about_axis(pts, axis_dir, axis_point, theta_deg):
    """
    internal: rotates each 3D point in `pts` by `theta_deg` degrees
    around the axis through `axis_point` in direction `axis_dir` --
    plain Rodrigues'-formula point rotation, no build123d needed. The
    point-list counterpart of axis_rot_1() (which rotates a real
    build123d Shape the same way via its own native .rotate()), used
    by functions like fit_pline2line() below that work on raw point
    lists rather than B-rep solids.
    """
    kx, ky, kz = _3d_unit(tuple(float(c) for c in axis_dir))
    ox, oy, oz = (float(c) for c in axis_point)
    theta = math.radians(theta_deg)
    cos_t, sin_t = math.cos(theta), math.sin(theta)
    out = []
    for p in pts:
        vx, vy, vz = float(p[0]) - ox, float(p[1]) - oy, float(p[2]) - oz
        dot = vx * kx + vy * ky + vz * kz
        cx, cy, cz = _3d_cross((kx, ky, kz), (vx, vy, vz))
        rx = vx * cos_t + cx * sin_t + kx * dot * (1 - cos_t)
        ry = vy * cos_t + cy * sin_t + ky * dot * (1 - cos_t)
        rz = vz * cos_t + cz * sin_t + kz * dot * (1 - cos_t)
        out.append([ox + rx, oy + ry, oz + rz])
    return out


def fit_pline2line(polyline, line):
    """
    Fits `polyline` (an open 2D or 3D point list, e.g. sinewave()/
    bezier()/turtle3d() output) onto `line` (a straight 2-point
    line/vector) -- openscad4.py's own fit_pline2line(), ported as
    plain point-list math (no build123d needed, like turtle3d()/
    sinewave()/l_len() above): scales every segment of `polyline` by
    the same factor so its start-to-end chord length matches `line`'s
    length, slides it so its start point lands on `line`'s start
    point, then rotates it about that point so its own chord points
    the same direction as `line` -- the polyline's own shape (bends,
    wiggles, etc) is preserved throughout; only its overall position,
    length, and orientation change. Handy for laying a wavy/curved
    profile down along an arbitrary 3D line before sweeping/lofting
    it (see surface_from_4_lines-style workflows: fit each edge curve
    between the right pair of corner points first).

    Always returns 3D points ([x,y,z]), even if `polyline` was given
    as 2D -- the whole point is usually to lay a flat curve down along
    an arbitrary 3D `line`, which generally means it has to leave the
    XY plane to line up, so flattening the result back to 2D would
    just throw away the fit. `line` can be given as just its 2
    endpoints, or a longer point list (e.g. turtle3d() output) -- only
    its first and last points are used.

        l1 = turtle3d([[0, 10, 0], [0, 0, 20]])
        l2 = sinewave(50, 3, 2, 50)
        l3 = fit_pline2line(l2, l1)
        show(color(p_line3d(l1, 0.1), "blue"))
        show(color(p_line3d(l2, 0.3), "magenta"))
        show(color(p_line3d(l3, 0.3), "cyan"))
    """
    if len(polyline) < 2:
        raise ValueError("fit_pline2line(): polyline needs at least 2 points")
    a = c23(polyline)
    l1 = c23([line[0], line[-1]])
    chord = l_len([a[0], a[-1]])
    if chord < 1e-12:
        raise ValueError("fit_pline2line(): polyline's start and end points coincide (zero chord length)")
    rt = l_len(l1) / chord

    # rescale every segment's vector by the same factor rt (stretches/
    # shrinks the polyline's overall chord length by rt while
    # preserving its shape), rebuilt as a running cumulative sum from
    # the origin.
    b = [[0.0, 0.0, 0.0]]
    x, y, z = 0.0, 0.0, 0.0
    for p0, p1 in seg(a)[:-1]:
        x += (p1[0] - p0[0]) * rt
        y += (p1[1] - p0[1]) * rt
        z += (p1[2] - p0[2]) * rt
        b.append([x, y, z])

    # slide b so its first point lands exactly on line's first point.
    t = [l1[0][i] - b[0][i] for i in range(3)]
    b = [[p[0] + t[0], p[1] + t[1], p[2] + t[2]] for p in b]

    # rotate b about its own (now-placed) first point so its chord
    # direction matches line's direction.
    u1 = line_as_unit_vector(l1)
    u2 = line_as_unit_vector([b[0], b[-1]])
    axis = _3d_cross(u1, u2)
    if all(round(c, 4) == 0 for c in axis):
        return b
    dot = max(-1.0, min(1.0, _3d_dot(u1, u2)))
    theta = -math.degrees(math.acos(dot))
    return _rotate_points_about_axis(b, axis, b[0], theta)


def _chain_segments(seg_list):
    """
    internal helper for contiguous_chains() -- greedily walks `seg_list`
    (a list of disconnected 2-point segments) starting from the first
    one, extending a single chain at either end wherever a matching
    endpoint is found, until no more segments connect. Returns [the
    resulting chain of points, the remaining not-yet-used segments].
    """
    def pt_eq(p0, p1):
        return all(round(float(a), 4) == round(float(b), 4) for a, b in zip(p0, p1))

    remaining = [list(s) for s in seg_list]
    chain = [remaining.pop(0)]
    while remaining:
        added = False
        for i, s in enumerate(remaining):
            if pt_eq(s[0], chain[-1][1]):
                chain.append(s)
            elif pt_eq(s[1], chain[-1][1]):
                chain.append(flip(s))
            elif pt_eq(s[1], chain[0][0]):
                chain.insert(0, s)
            elif pt_eq(s[0], chain[0][0]):
                chain.insert(0, flip(s))
            else:
                continue
            remaining.pop(i)
            added = True
            break
        if not added:
            break
    pts = [s[0] for s in chain] + [chain[-1][1]]
    return pts, remaining


def contiguous_chains(seg_list):
    """
    Stitches a flat, unordered list of 2-point line segments `seg_list`
    into one or more separate continuous chains/loops of points --
    openscad4.py's own contiguous_chains(), ported as plain point-list
    math (no build123d needed). A real build123d boolean's own Wire
    (intersection()'s result, say) already comes back as a proper
    ordered point list, so you won't need this for that -- but
    two_solids_intersection() below (the mesh-based, more robust
    alternative to a real B-rep boolean for genuinely hard cases) DOES
    return raw, disconnected triangle-intersection segments that
    genuinely need stitching -- exactly the pairing this was ported
    for. Also handy for the rare case of feeding in your own
    disconnected segment list from an external data source. It is NOT
    a way to reduce the edge count of an existing B-rep Shape -- for
    that, see arc_3p()'s `s=` parameter or interp_spline().

    Repeatedly pulls out one connected run of segments (matching
    endpoints to 4 decimal places) until every segment has been
    consumed, so the result may contain more than one chain if the
    input isn't all one connected network. A chain whose two ends meet
    back up comes back as a closed loop (first point == last point).

        segs = [[[0,0],[10,0]], [[10,10],[10,0]], [[0,0],[0,10]]]
        contiguous_chains(segs) => [[[10,10],[10,0],[0,0],[0,10]]]
    """
    remaining = [list(s) for s in seg_list]
    chains = []
    while remaining:
        chain, remaining = _chain_segments(remaining)
        chains.append(chain)
    return chains


def _sub3(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _add3(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def _scale3(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def _dot3(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _cross3(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _triangle_line_intersection(triangle, line):
    """internal: openscad4.py's own triangle_line_intersection(),
    ported -- the point where segment `line` ([p, q]) pierces
    `triangle` ([a, b, c]), or None if it doesn't (parametric
    triangle/segment intersection, same Cramer's-rule-style solve as
    the original, just plain-tuple 3D vector math instead of numpy)."""
    a, b, c = triangle
    p, q = line
    ab, ac, pq = _sub3(b, a), _sub3(c, a), _sub3(q, p)
    x = _cross3(ab, ac)
    denom = -_dot3(pq, x)
    if abs(denom) < 1e-12:
        return None
    pa = _sub3(p, a)
    t = _dot3(x, pa) / denom
    neg_pq = _scale3(pq, -1)
    u = _dot3(_cross3(ac, neg_pq), pa) / denom
    v = _dot3(_cross3(neg_pq, ab), pa) / denom
    if 0 <= t <= 1 and 0 <= u <= 1 and 0 <= v <= 1 and (u + v) <= 1:
        return list(_add3(p, _scale3(pq, t)))
    return None


def _triangle_triangle_intersection(triangle1, triangle2):
    """internal: openscad4.py's own triangle_triangle_intersection(),
    ported -- the intersection segment (2 points) between two
    triangles, or None if they don't intersect: tests each triangle's
    3 edges against the OTHER triangle, same as the original."""
    a, b, c = triangle1
    d, e, f = triangle2
    edges1 = [(a, b), (b, c), (c, a)]
    edges2 = [(d, e), (e, f), (f, d)]
    p1 = [pt for pt in (_triangle_line_intersection(triangle2, edge) for edge in edges1) if pt is not None]
    p2 = [pt for pt in (_triangle_line_intersection(triangle1, edge) for edge in edges2) if pt is not None]
    if len(p1) == 2:
        return p1
    if len(p2) == 2:
        return p2
    if len(p1) == 1 and len(p2) == 1:
        return [p1[0], p2[0]]
    return None


def two_solids_intersection(a, b, tolerance=0.1, angular_tolerance=0.3):
    """
    The raw intersection LINE SEGMENTS between two real B-rep shapes
    `a`/`b` -- openscad4.py's own two_solids_intersection(), ported:
    tessellates each into a triangle mesh (to_mesh(), same tolerance/
    angular_tolerance meaning as there) and tests every pair of
    nearby triangles (after a bounding-sphere prefilter) for a genuine
    triangle-triangle crossing. Returns the raw, DISCONNECTED list of
    2-point segments -- feed it through contiguous_chains() to stitch
    them into one or more ordered curves:

        segs = two_solids_intersection(a, b)
        spine = contiguous_chains(segs)[0]   # the first (often only) chain

    WHY REACH FOR THIS instead of intersection() (the real B-rep
    boolean, exact and usually the right first choice): OCCT's exact
    boolean intersection can be numerically fragile on genuinely hard
    curved cases (see fillet()'s own docstring for the same class of
    real failure mode) -- a mesh-vs-mesh triangle intersection test
    doesn't care about exact analytic surfaces at all, just triangle
    soup, so it tends to be far more forgiving when intersection()
    itself struggles or errors. The tradeoff: the result is a faceted
    APPROXIMATION of the true curve (as accurate as `tolerance`/
    `angular_tolerance` make the underlying tessellation), not an
    exact analytic curve.

    The full manual-fillet recipe this exists for (see
    convert_3lines2fillet()'s own docstring for the rest of the
    pipeline once you have `spine`):

        spine = contiguous_chains(two_solids_intersection(a, b))[0]
        line_b = sample_curve(intersection(offset_face(a, blend), b), len(spine))
        line_a = sample_curve(intersection(a, offset_face(b, blend)), len(spine))
        grid = convert_3lines2fillet(line_a, line_b, spine, s=15)
        patch = surface_from_points_grid(grid)

    (mixing a mesh-derived `spine` with real-B-rep-derived `line_a`/
    `line_b` like this is fine -- they're just point lists by the time
    convert_3lines2fillet() sees them.)

    REAL PERFORMANCE NOTE: this is a plain O(len(mesh_a) * len(mesh_b))
    pair of nested loops (with a cheap bounding-sphere distance check
    to skip clearly-far pairs) -- brep.py deliberately has no numpy
    dependency (see xrot()'s own docstring), so this doesn't get
    openscad4.py's fully vectorized einsum version. Fine for the
    moderate mesh sizes to_mesh() produces at normal tolerances; if
    it's slow, tessellate coarser first (a bigger `tolerance` here) --
    fewer, larger triangles means far fewer pairs to test.
    """
    _require_build123d()
    va, fa = to_mesh(a, tolerance, angular_tolerance)
    vb, fb = to_mesh(b, tolerance, angular_tolerance)
    tris_a = [[tuple(va[i]) for i in f] for f in fa]
    tris_b = [[tuple(vb[i]) for i in f] for f in fb]

    def centroid(tri):
        return (sum(p[0] for p in tri) / 3.0, sum(p[1] for p in tri) / 3.0, sum(p[2] for p in tri) / 3.0)

    def bounding_radius_sq(tri, cen):
        return max(_dot3(_sub3(p, cen), _sub3(p, cen)) for p in tri)

    cens_a = [centroid(t) for t in tris_a]
    rad2_a = [bounding_radius_sq(t, c) for t, c in zip(tris_a, cens_a)]
    cens_b = [centroid(t) for t in tris_b]
    rad2_b = [bounding_radius_sq(t, c) for t, c in zip(tris_b, cens_b)]

    segments = []
    for i, tri_a in enumerate(tris_a):
        ca, ra2 = cens_a[i], rad2_a[i]
        for j, tri_b in enumerate(tris_b):
            cb, rb2 = cens_b[j], rad2_b[j]
            d = _sub3(ca, cb)
            if _dot3(d, d) > ra2 + rb2:
                continue
            seg = _triangle_triangle_intersection(tri_a, tri_b)
            if seg is not None:
                segments.append(seg)
    return segments


def ang(x, y):
    """
    The polar angle (degrees, 0-360) of the 2D vector (x, y) measured
    from the origin -- openscad4.py's own ang(), ported. Same
    computation as math.degrees(math.atan2(y, x)), just wrapped into
    0-360 instead of -180..180 (and the exact same math already used
    internally throughout this file, e.g. by arc_3p()/ang_2lineccw()/
    etc, via the internal _polar_angle_deg() helper -- ang() just
    exposes that under its original name for direct use in your own
    scripts):

        p1, p2 = [3, 4], [-3, 2]
        v = [p2[0] - p1[0], p2[1] - p1[1]]
        a = ang(v[0], v[1])
    """
    return _polar_angle_deg(x, y)


def ang_2lineccw(p0, p1, p2):
    """
    The counter-clockwise angle (degrees, 0-360) of the ray p0->p2
    measured from the ray p0->p1 -- "how far ccw do you turn from
    pointing at p1 to pointing at p2, both from p0". 2D.
    """
    v1 = (p1[0] - p0[0], p1[1] - p0[1])
    v2 = (p2[0] - p0[0], p2[1] - p0[1])
    a1 = _polar_angle_deg(*v1)
    a2 = _polar_angle_deg(*v2)
    if a1 == a2:
        return 360.0
    return (360 - (a1 - a2)) if a2 < a1 else (a2 - a1)


def ang_2linecw(p0, p1, p2):
    """Clockwise counterpart of ang_2lineccw()."""
    v1 = (p1[0] - p0[0], p1[1] - p0[1])
    v2 = (p2[0] - p0[0], p2[1] - p0[1])
    a = _polar_angle_deg(*v1)
    b = _polar_angle_deg(*v2)
    return abs(a - b) if b <= a else (360 - b) + a


def ang3points(p0, p1, p2):
    """
    The interior angle (degrees, 0-360 -- not clamped to 0-180, so it
    tells you which way the path bends) at the middle point of the
    3-point path p0-p1-p2. 2D.
    """
    orientation = _cw_2d([p0, p1, p2])
    if orientation == 1:
        return ang_2lineccw(p1, p0, p2)
    if orientation == -1:
        return ang_2linecw(p1, p0, p2)
    raise ValueError("ang3points(): p0, p1, p2 are collinear")


def i_p2d(l1, l2):
    """
    The intersection point of two 2D lines l1=[p0,p1], l2=[p2,p3],
    extended infinitely (not clipped to the segments) -- e.g.
    i_p2d([[0,0],[1,4]], [[10,0],[7,2]]) -> [1.4286, 5.7143]. Raises if
    the lines are parallel.
    """
    (x1, y1), (x2, y2) = l1[0], l1[1]
    (x3, y3), (x4, y4) = l2[0], l2[1]
    denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if abs(denom) < 1e-12:
        raise ValueError("i_p2d(): the two lines are parallel (no unique intersection)")
    a = x1 * y2 - y1 * x2
    b = x3 * y4 - y3 * x4
    return [(a * (x3 - x4) - (x1 - x2) * b) / denom, (a * (y3 - y4) - (y1 - y2) * b) / denom]


def perpendicularProjectionOfPointOnLine(p0, l1):
    """
    The perpendicular projection of `p0` onto polyline `l1` -- the
    closest point that actually lies ON one of `l1`'s segments (foot
    strictly between that segment's endpoints); [] if no segment has a
    valid perpendicular foot.
    """
    candidates = []
    for a, b in zip(l1[:-1], l1[1:]):
        foot, t, dist = _project_point_on_segment(p0, [a, b])
        if 0 <= t <= 1:
            candidates.append((dist, foot))
    if not candidates:
        return []
    candidates.sort(key=lambda c: c[0])
    return candidates[0][1]


def distanceOfPointFromLine(p0, l1):
    """Perpendicular distance of `p0` from polyline `l1` -- [] if
    perpendicularProjectionOfPointOnLine() finds no valid foot."""
    foot = perpendicularProjectionOfPointOnLine(p0, l1)
    return l_len([foot, p0]) if foot != [] else []


def mirror_line(pts, n1, loc):
    """
    Mirrors every point in `pts` across the plane through `loc` with
    normal `n1` -- e.g. mirror_line(circle_pts, [1,1,0], [0,0,0])
    reflects a 2D point list across the plane x+y=0. 2D points are
    treated as z=0 while mirroring; the result comes back 2D too
    unless mirroring genuinely moves a point off the z=0 plane.
    """
    n = _3d_unit((float(n1[0]), float(n1[1]), float(n1[2])))
    loc3 = (float(loc[0]), float(loc[1]), float(loc[2]))
    was_2d = all(len(p) <= 2 for p in pts)
    out = []
    for p in pts:
        p3 = (float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0)
        d = _3d_dot((p3[0] - loc3[0], p3[1] - loc3[1], p3[2] - loc3[2]), n)
        out.append((p3[0] - 2 * d * n[0], p3[1] - 2 * d * n[1], p3[2] - 2 * d * n[2]))
    if was_2d and all(abs(p[2]) < 1e-9 for p in out):
        return [[p[0], p[1]] for p in out]
    return [list(p) for p in out]


def mirror_point(pnt, n1, loc):
    """Mirrors a single point `pnt` -- see mirror_line()."""
    return mirror_line([pnt], n1, loc)[0]


def rot2d(a, sec):
    """Rotates 2D point list `sec` by `a` degrees counter-clockwise
    around the origin (any extra coordinates beyond x,y pass through
    unchanged)."""
    rad = math.radians(a)
    c, s = math.cos(rad), math.sin(rad)
    out = []
    for p in sec:
        x, y = float(p[0]), float(p[1])
        nx, ny = x * c - y * s, x * s + y * c
        out.append([nx, ny] + list(p[2:]) if len(p) > 2 else [nx, ny])
    return out


def xrot(theta):
    """
    The 3x3 rotation matrix for rotating a point around the X axis by
    `theta` degrees (right-hand rule) -- openscad4.py's own xrot(),
    ported as a plain nested Python list (3 rows of 3 numbers)
    instead of a numpy array, matching brep.py's other point-list
    math (no numpy dependency needed inside brep.py itself). Apply it
    to a point as a row vector times this matrix, same convention the
    original used (see xrot4d() below for a ready-made point-rotation
    helper that does exactly that, or write your own with numpy if
    you already have `np`/`numpy` imported in your script:
    `array(v) @ array(xrot(theta))`).
    """
    c, s = math.cos(math.radians(theta)), math.sin(math.radians(theta))
    return [
        [1.0, 0.0, 0.0],
        [0.0, c, s],
        [0.0, -s, c],
    ]


def yrot(theta):
    """Same as xrot(), but the rotation matrix for the Y axis."""
    c, s = math.cos(math.radians(theta)), math.sin(math.radians(theta))
    return [
        [c, 0.0, -s],
        [0.0, 1.0, 0.0],
        [s, 0.0, c],
    ]


def zrot(theta):
    """Same as xrot(), but the rotation matrix for the Z axis."""
    c, s = math.cos(math.radians(theta)), math.sin(math.radians(theta))
    return [
        [c, s, 0.0],
        [-s, c, 0.0],
        [0.0, 0.0, 1.0],
    ]


def _mat3_vec_mul(v3, m):
    """internal: v3 @ m -- v3 as a row vector times the 3x3 matrix m,
    matching xrot()/yrot()/zrot()'s own row-vector convention."""
    return [sum(v3[i] * m[i][j] for i in range(3)) for j in range(3)]


def xrot4d(theta, v):
    """
    Rotates a point `v` (a [x,y,z] point, or a longer one like
    [x,y,z,extra,...] -- e.g. pts3()/corner_radius3d()-style points
    with a trailing corner-radius value) around the X axis by `theta`
    degrees, using xrot() -- openscad4.py's own xrot4d(), ported. Any
    elements beyond the first 3 (x,y,z) pass through unchanged.
    """
    return _mat3_vec_mul([float(c) for c in v[:3]], xrot(theta)) + list(v[3:])


def yrot4d(theta, v):
    """Same as xrot4d(), but rotates around the Y axis (via yrot())."""
    return _mat3_vec_mul([float(c) for c in v[:3]], yrot(theta)) + list(v[3:])


def zrot4d(theta, v):
    """Same as xrot4d(), but rotates around the Z axis (via zrot())."""
    return _mat3_vec_mul([float(c) for c in v[:3]], zrot(theta)) + list(v[3:])


def c23(pts):
    """
    Converts a 2D point list to 3D by padding each point with z=0 --
    openscad4.py's own c23()/c2t3(), ported. Points that are already
    3D pass through unchanged. Handy right before feeding a plain 2D
    point list (turtle2d()/cr2dt()'s output, etc) to a function that
    expects real 3D points:

        c23([[0, 0], [10, 0]])   # -> [[0, 0, 0], [10, 0, 0]]
    """
    return [[float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0] for p in pts]


def c32(pts):
    """
    Converts a 3D point list to 2D by dropping z -- openscad4.py's own
    c32()/c3t2(), ported (the inverse of c23()). Points that are
    already 2D pass through unchanged.

        c32([[1, 2, 3], [4, 5, 6]])   # -> [[1, 2], [4, 5]]
    """
    return [[float(p[0]), float(p[1])] for p in pts]


def rot_p(a, points):
    """
    Rotates a point list `points` (2D or 3D -- sinewave()/cosinewave()
    output, cr2dt()'s output, etc) by axis letters and angles packed
    into a single string `a` -- the point-list sibling of rot()/
    rotate(), which only work on real Shapes. Same string convention
    as openscad4.py's own rot()/brep.py's own rot(): each axis is
    applied in the ORDER it appears in the string.

        rot_p('x90', [[0, 0], [10, 0]])
        # rotates around X by 90 deg

        rot_p('z30x70y-90', points)
        # rotates z by 30, then x by 70, then y by -90, in that order

    2D points are padded to z=0 first (via c23()); extra trailing
    values on a point (e.g. a corner-radius column) pass through
    unchanged, same as xrot4d()/yrot4d()/zrot4d() (which this is built
    from). This is the tool for the sinewave/cosinewave-into-a-plane
    trick used throughout the surface_from_2_waves() examples --
    instead of building each wave directly in its target plane
    (`[[x, 0, y] for x, y in sinewave(...)]`), you can now do:

        l1 = rot_p('x90', sinewave(60, 3, 8, 60))
        l2 = rot_p('x90z90', cosinewave(60, 3, 8, 60))
    """
    axis_idx = [i for i, ch in enumerate(a) if ch in "xyz"] + [len(a)]
    segments = list(zip(axis_idx[:-1], axis_idx[1:]))
    if not segments:
        raise ValueError(f"rot_p(): couldn't find any x/y/z axis letters in {a!r}")
    rotors = {"x": xrot4d, "y": yrot4d, "z": zrot4d}
    pts = c23(points)
    for i, j in segments:
        axis = a[i]
        theta = float(a[i + 1:j])
        pts = [rotors[axis](theta, p) for p in pts]
    return pts


def xyc(pnts):
    """
    Zeroes the z-coordinate of every point in a 3D point list --
    openscad4.py's own xyc(), ported: projects onto the XY plane while
    keeping the points 3D (unlike c32(), which drops z entirely and
    returns 2D points).

        xyc([[1, 2, 3], [4, 5, 6]])   # -> [[1, 2, 0], [4, 5, 0]]
    """
    return [[float(p[0]), float(p[1]), 0.0] for p in pnts]


def xzc(pnts):
    """
    Zeroes the y-coordinate of every point in a 3D point list --
    openscad4.py's own xzc(), ported: projects onto the XZ plane.

        xzc([[1, 2, 3], [4, 5, 6]])   # -> [[1, 0, 3], [4, 0, 6]]
    """
    return [[float(p[0]), 0.0, float(p[2])] for p in pnts]


def yzc(pnts):
    """
    Zeroes the x-coordinate of every point in a 3D point list --
    openscad4.py's own yzc(), ported: projects onto the YZ plane.

        yzc([[1, 2, 3], [4, 5, 6]])   # -> [[0, 2, 3], [0, 5, 6]]
    """
    return [[0.0, float(p[1]), float(p[2])] for p in pnts]


def _arc_2p_center(p1, p2, r, cw):
    """internal: the center of a radius-`r` circle through `p1`,`p2`,
    on the side `cw` picks (see arc_2p()'s docstring)."""
    mid = [(p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2]
    d = l_len([mid, p1])
    if abs(r) < d - 1e-9:
        raise ValueError(f"radius {r} is too small to span the two points (need at least {d:.6g})")
    h = math.sqrt(max(0.0, r * r - d * d))
    vx, vy = p1[0] - mid[0], p1[1] - mid[1]
    vlen = math.hypot(vx, vy)
    if vlen < 1e-12:
        raise ValueError("the two points coincide")
    ux, uy = vx / vlen, vy / vlen
    perpx, perpy = (-uy, ux) if cw == 1 else (uy, -ux)
    return [mid[0] + perpx * h, mid[1] + perpy * h]


def arc(radius=0, start_angle=0, end_angle=0, cp=(0, 0), s=20):
    """
    The most basic arc primitive: a point list tracing a circle of
    `radius` around center `cp`, sweeping from `start_angle` to
    `end_angle` degrees (0 = +X axis, counter-clockwise-positive), as
    `s` segments (s+1 points) -- openscad4.py's own arc(), ported
    directly (angles/center/radius given explicitly, unlike
    arc_2p()/arc_3p() below, which instead *fit* an arc to given
    points). Handy for a simple pie-slice/fillet-by-hand/dial-gauge
    curve where you already know the center and sweep you want:

        a1 = arc(radius=10, start_angle=180, end_angle=270, cp=[10, 10], s=20)
        show(p_line3d(a1, .3))
    """
    return _arc_deg(float(radius), float(start_angle), float(end_angle), [float(cp[0]), float(cp[1])], int(s))


def arc_edge(radius, start_angle=0, end_angle=360, cp=(0, 0)):
    """
    The exact, real-B-rep counterpart of arc(): a genuine analytic
    circular-arc Edge (build123d's own Edge.make_circle(), a true
    curved curve, not a faceted point list), same
    radius/start_angle/end_angle/cp meaning as arc(). No `s` -- there's
    no facet count to choose, same reasoning as circle(s=None).

    Use this (not arc()) anywhere a *real curve* is wanted, especially
    as sweep_sec2path()'s `path3d`: feeding arc()'s point list straight
    in (even via c23()) turns it into a 20-straight-segment Polyline,
    and with the default transition="round" that means OCCT has to
    build a rounded joint at every one of those ~19 corners -- slow,
    and pointless when the path is really just a circular arc. arc_edge()
    sweeps as one smooth analytic curve instead, same as circle()
    already does for a *full* circle:

        path = arc_edge(20, -90, 90)
        a = sweep_sec2path(circle(5), path)   # fast, exact
        show(a)

    arc() itself is still the right choice for turtle-path point-list
    math (feeding into p_line3d(), s_int1(), offset() trimming, etc) --
    this is only for when you specifically want a real curved Edge.
    """
    _require_build123d()
    p = bd.Plane(origin=(float(cp[0]), float(cp[1]), 0.0), z_dir=(0, 0, 1))
    return bd.Edge.make_circle(float(radius), plane=p, start_angle=float(start_angle), end_angle=float(end_angle))


def arc_2p(p1, p2, r, cw=1, s=20):
    """
    An arc between 2 points `p1`,`p2` with radius `r`, as an
    `s`-segment point list. There are always two circles of radius `r`
    through 2 points (centers on either side of the chord); `cw`=1
    (default) traces the clockwise arc between them (the one on that
    circle), `cw`=-1 the counter-clockwise one (the other circle).
    """
    p1 = [float(c) for c in p1]
    p2 = [float(c) for c in p2]
    cp = _arc_2p_center(p1, p2, r, cw)
    a1 = _polar_angle_deg(p1[0] - cp[0], p1[1] - cp[1])
    a2 = _polar_angle_deg(p2[0] - cp[0], p2[1] - cp[1])
    a2f = (a2 + 360 if a2 < a1 else a2) if cw == -1 else (a2 if a2 < a1 else a2 - 360)
    return _arc_deg(r, a1, a2f, cp, s)


def cir_2p(p1, p2, r, cw=1, s=20):
    """A full circle of radius `r` through both `p1` and `p2`, as an
    `s`-segment point list -- `cw` picks which of the two possible
    circles (see arc_2p()'s docstring)."""
    p1 = [float(c) for c in p1]
    p2 = [float(c) for c in p2]
    cp = _arc_2p_center(p1, p2, r, cw)
    a1 = _polar_angle_deg(p1[0] - cp[0], p1[1] - cp[1])
    return _arc_deg(r, a1, a1 + 360, cp, s)


def cp_3p(p1, p2, p3):
    """The center (circumcenter) of the circle through 3 points `p1`,
    `p2`, `p3` -- 2D or 3D (3 points always share a plane)."""
    a = l_len([p2, p3])
    b = l_len([p1, p3])
    c = l_len([p1, p2])
    a2, b2, c2 = a * a, b * b, c * c
    wa = a2 * (b2 + c2 - a2)
    wb = b2 * (a2 + c2 - b2)
    wc = c2 * (a2 + b2 - c2)
    wsum = wa + wb + wc
    if abs(wsum) < 1e-9:
        raise ValueError("cp_3p(): the 3 points are (nearly) collinear")
    dim = len(p1)
    return [(wa * p1[i] + wb * p2[i] + wc * p3[i]) / wsum for i in range(dim)]


def arc_3p(p1, p2, p3, s=30):
    """An arc through 3 2D points `p1`,`p2`,`p3` (their circumcircle's
    arc from p1 through p2 to p3), as an `s`-segment point list."""
    cp = cp_3p(p1, p2, p3)
    r = l_len([p1, cp])
    a1 = _polar_angle_deg(p1[0] - cp[0], p1[1] - cp[1])
    a3 = _polar_angle_deg(p3[0] - cp[0], p3[1] - cp[1])
    orientation = _cw_2d([p1, p2, p3])
    a3f = (a3 + 360 if a3 < a1 else a3) if orientation == -1 else (a3 if a3 < a1 else a3 - 360)
    return _arc_deg(r, a1, a3f, cp, s)


def cir_3p(p1, p2, p3, s=50):
    """A full circle through 3 2D points, as an `s`-segment point
    list -- same circumcenter/radius as arc_3p()/cp_3p()."""
    cp = cp_3p(p1, p2, p3)
    r = l_len([p1, cp])
    return _arc_deg(r, 0, 360, cp, s)


def arc_2p_3d(n1, p0, p1, r, cw=1, s=20):
    """
    3D counterpart of arc_2p() -- an arc between two 3D points `p0`,
    `p1`, lying in the plane with normal `n1` through `p0`.
    """
    n = _3d_unit((float(n1[0]), float(n1[1]), float(n1[2])))
    p0 = [float(c) for c in p0]
    p1 = [float(c) for c in p1]
    origin = p0
    raw = (p1[0] - origin[0], p1[1] - origin[1], p1[2] - origin[2])
    if math.sqrt(sum(c * c for c in raw)) < 1e-9:
        raise ValueError("arc_2p_3d(): p0 and p1 coincide")
    d = _3d_dot(raw, n)
    e1_raw = (raw[0] - d * n[0], raw[1] - d * n[1], raw[2] - d * n[2])
    e1len = math.sqrt(sum(c * c for c in e1_raw))
    if e1len < 1e-9:
        raise ValueError("arc_2p_3d(): p0->p1 is parallel to n1 -- they can't both lie in that plane")
    e1 = (e1_raw[0] / e1len, e1_raw[1] / e1len, e1_raw[2] / e1len)
    e2 = _3d_cross(n, e1)

    def to_2d(p):
        v = (p[0] - origin[0], p[1] - origin[1], p[2] - origin[2])
        return [_3d_dot(v, e1), _3d_dot(v, e2)]

    def to_3d(p2):
        return [origin[0] + p2[0] * e1[0] + p2[1] * e2[0],
                origin[1] + p2[0] * e1[1] + p2[1] * e2[1],
                origin[2] + p2[0] * e1[2] + p2[1] * e2[2]]

    arc2d = arc_2p(to_2d(p0), to_2d(p1), r, cw, s)
    return [to_3d(p) for p in arc2d]


def tcct(r1, r2, cp1, cp2, cw=1):
    """
    The internal (crossing) tangent line between two circles -- radius
    `r1` centered at `cp1`, radius `r2` centered at `cp2` -- as
    [touch_point_on_circle1, touch_point_on_circle2]. Only exists when
    the circles don't overlap (center distance >= r1+r2); raises
    otherwise. There are always two internal tangent lines (mirrored
    across the line joining the centers); `cw`=1 (default) picks one,
    `cw`=-1 the other.
    """
    cp1 = [float(c) for c in cp1]
    cp2 = [float(c) for c in cp2]
    d_vec = (cp2[0] - cp1[0], cp2[1] - cp1[1])
    d = math.hypot(*d_vec)
    if d < 1e-9:
        raise ValueError("tcct(): the two circles have coincident centers")
    if d < r1 + r2 - 1e-9:
        raise ValueError(
            f"tcct(): circles overlap (center distance {d:.6g} < r1+r2 "
            f"{r1 + r2:.6g}) -- no internal tangent exists")
    d_hat = (d_vec[0] / d, d_vec[1] / d)
    d_perp = (-d_hat[1], d_hat[0])
    cos_t = max(-1.0, min(1.0, -(r1 + r2) / d))
    theta = math.acos(cos_t)
    sin_t = math.sin(theta) if cw == 1 else -math.sin(theta)
    n = (cos_t * d_hat[0] + sin_t * d_perp[0], cos_t * d_hat[1] + sin_t * d_perp[1])
    p0 = [cp1[0] - r1 * n[0], cp1[1] - r1 * n[1]]
    p1 = [cp2[0] + r2 * n[0], cp2[1] + r2 * n[1]]
    return [p0, p1]


def remove_extra_points(points_list):
    """Removes duplicate entries from `points_list`, keeping each
    one's FIRST occurrence and original order -- works on plain values
    or point lists alike."""
    seen = []
    out = []
    for p in points_list:
        key = tuple(p) if isinstance(p, (list, tuple)) else p
        if key not in seen:
            seen.append(key)
            out.append(p)
    return out


def min_d_points(sec, min_d=0.1):
    """Thins `sec` so consecutive KEPT points are always at least
    `min_d` apart (measured from the last point actually kept, not
    just each point's immediate predecessor in `sec`)."""
    if not sec:
        return []
    out = [sec[0]]
    last = sec[0]
    for p in sec[1:]:
        if l_len([last, p]) >= min_d:
            out.append(p)
            last = p
    return out


def sort_points(sec, list1):
    """
    For every point in `sec`, finds its nearest point in `list1` --
    returns a list the same length as `sec`. Brute-force nearest-
    neighbor search (fine for hand-built profile/path point counts).
    """
    out = []
    for p in sec:
        nearest = min(list1, key=lambda q: l_len([p, q]))
        out.append(nearest)
    return out


def convex_hull(pnts):
    """
    The convex hull of 2D point list `pnts`, as an ordered point list
    of just the hull's own vertices (the outline you'd get wrapping a
    rubber band around every point). Andrew's monotone chain
    algorithm.
    """
    pts = sorted(set(tuple(p) for p in pnts))
    if len(pts) <= 2:
        return [list(p) for p in pts]

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    lower = []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    upper = []
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return [list(p) for p in lower[:-1] + upper[:-1]]


def normal_vector(sec):
    """
    The unit normal vector of a planar point list `sec` (3+ points) --
    exactly 3 points uses a plain cross product; more uses Newell's
    method (robust for any planar polygon, convex or not, as long as
    the points are genuinely coplanar).
    """
    n = len(sec)
    if n < 3:
        raise ValueError("normal_vector(): need at least 3 points")
    pts = [[float(c) for c in p] + ([0.0] if len(p) == 2 else []) for p in sec]
    if n == 3:
        v1 = [pts[1][i] - pts[0][i] for i in range(3)]
        v2 = [pts[2][i] - pts[0][i] for i in range(3)]
        nrm = _3d_cross(v1, v2)
    else:
        nx = ny = nz = 0.0
        for i in range(n):
            x0, y0, z0 = pts[i]
            x1, y1, z1 = pts[(i + 1) % n]
            nx += (y0 - y1) * (z0 + z1)
            ny += (z0 - z1) * (x0 + x1)
            nz += (x0 - x1) * (y0 + y1)
        nrm = (nx, ny, nz)
    return list(_3d_unit(nrm))


def equation_of_plane(pts):
    """The equation of the plane through `pts` (3+ coplanar points),
    as [a,b,c,d] where ax+by+cz=d -- built on normal_vector()."""
    n = normal_vector(pts)
    p0 = pts[0]
    p0_3 = [float(p0[0]), float(p0[1]), float(p0[2]) if len(p0) > 2 else 0.0]
    d = sum(n[i] * p0_3[i] for i in range(3))
    return list(n) + [d]


def fillet3points(sec, r=1, s=20):
    """
    The fillet arc rounding the corner at the middle point of the
    3-point path `sec`=[p0,p1,p2], radius `r`, as an `s`-segment point
    list -- the single-corner building block cr2dt() applies at every
    vertex of a whole profile at once (see its docstring for the
    underlying math).
    """
    p0, p1, p2 = sec
    u1 = _2d_unit((p0[0] - p1[0], p0[1] - p1[1]))
    u2 = _2d_unit((p2[0] - p1[0], p2[1] - p1[1]))
    len1 = l_len([p1, p0])
    len2 = l_len([p1, p2])
    dot = max(-1.0, min(1.0, u1[0] * u2[0] + u1[1] * u2[1]))
    theta = math.acos(dot)
    if theta < 1e-9 or theta > math.pi - 1e-9:
        raise ValueError("fillet3points(): p0, p1, p2 are (nearly) collinear -- no corner to fillet")
    tlen = r / math.tan(theta / 2)
    if tlen > len1 or tlen > len2:
        raise ValueError(
            f"fillet3points(): radius {r} is too large for the given points "
            f"(needs {tlen:.6g}, edges are {len1:.6g}/{len2:.6g} long)")
    t1 = (p1[0] + u1[0] * tlen, p1[1] + u1[1] * tlen)
    t2 = (p1[0] + u2[0] * tlen, p1[1] + u2[1] * tlen)
    bis_u = _2d_unit((u1[0] + u2[0], u1[1] + u2[1]))
    center_dist = r / math.sin(theta / 2)
    center = (p1[0] + bis_u[0] * center_dist, p1[1] + bis_u[1] * center_dist)
    a1 = math.degrees(math.atan2(t1[1] - center[1], t1[0] - center[0]))
    a2 = math.degrees(math.atan2(t2[1] - center[1], t2[0] - center[0]))
    d_angle = (a2 - a1 + 180) % 360 - 180
    return _arc_deg(r, a1, a1 + d_angle, center, s)


def bezier(pl, s=20):
    """A Bezier curve through control points `pl` (passes through the
    first/last point only, pulled toward the others), as an `s`-point
    list -- standard Bernstein-polynomial construction. 2D or 3D."""
    n = len(pl) - 1
    dim = len(pl[0])
    out = []
    for k in range(s):
        t = k / (s - 1) if s > 1 else 0.0
        pt = [0.0] * dim
        for i, p in enumerate(pl):
            b = math.comb(n, i) * (t ** i) * ((1 - t) ** (n - i))
            for d in range(dim):
                pt[d] += float(p[d]) * b
        out.append(pt)
    return out


def bspline_open(pl, deg=3, s=100):
    """
    An open (clamped) B-spline curve through control points `pl`,
    degree `deg` (0 <= deg < len(pl)), as an `s`-point list -- passes
    through the first and last control points; `deg`=1 gives a plain
    polyline through every point, higher degrees smooth it out more.
    Standard Cox-de Boor recursive basis functions. 2D or 3D.
    """
    n = len(pl) - 1
    k = deg
    if not (0 <= k < len(pl)):
        raise ValueError(f"bspline_open(): deg must be 0 <= deg < {len(pl)}, got {deg}")
    dim = len(pl[0])

    def knot(i):
        if i <= k:
            return 0
        if i <= n:
            return i - k
        return n - k + 1

    def basis(i, kk, u):
        if kk == 0:
            return 1.0 if knot(i) < u <= knot(i + 1) else 0.0
        t_i, t_ik, t_i1, t_ik1 = knot(i), knot(i + kk), knot(i + 1), knot(i + kk + 1)
        a = 0.0 if t_ik == t_i else (u - t_i) / (t_ik - t_i)
        b = 0.0 if t_ik1 == t_i1 else (t_ik1 - u) / (t_ik1 - t_i1)
        return a * basis(i, kk - 1, u) + b * basis(i + 1, kk - 1, u)

    us = [(n - k + 1) * j / (s - 1) for j in range(s)] if s > 1 else [0.0]
    out = []
    for u in us:
        pt = [0.0] * dim
        for i, p in enumerate(pl):
            b = basis(i, k, u)
            for d in range(dim):
                pt[d] += float(p[d]) * b
        out.append(pt)
    out[0] = [float(c) for c in pl[0]]  # the clamped basis is degenerate exactly at u=0
    return out


def bspline_closed(pl, deg=3, s=100):
    """
    Closed-loop counterpart of bspline_open() -- a periodic B-spline
    curve through control points `pl` (wraps back to its own start),
    degree `deg`, as an `s`-point list. 2D or 3D.
    """
    k = deg
    pl2 = pl + pl[:k]
    n = len(pl2) - 1
    if not (0 <= k < len(pl)):
        raise ValueError(f"bspline_closed(): deg must be 0 <= deg < {len(pl)}, got {deg}")
    dim = len(pl[0])

    def knot(i):
        return i - k

    def basis(i, kk, u):
        if kk == 0:
            return 1.0 if knot(i) < u <= knot(i + 1) else 0.0
        t_i, t_ik, t_i1, t_ik1 = knot(i), knot(i + kk), knot(i + 1), knot(i + kk + 1)
        a = 0.0 if t_ik == t_i else (u - t_i) / (t_ik - t_i)
        b = 0.0 if t_ik1 == t_i1 else (t_ik1 - u) / (t_ik1 - t_i1)
        return a * basis(i, kk - 1, u) + b * basis(i + 1, kk - 1, u)

    us = [(n - k + 1) * j / (s - 1) for j in range(s)] if s > 1 else [0.0]
    out = []
    for u in us:
        pt = [0.0] * dim
        for i, p in enumerate(pl2):
            b = basis(i, k, u)
            for d in range(dim):
                pt[d] += float(p[d]) * b
        out.append(pt)
    return out[:-1]


def linear_extrude(profile, h=1, center=False, twist=0, scale=1, dir=None):
    """
    Extrudes a 2D profile (from circle()/square()/polygon(), or any
    build123d Sketch/Face) into a real solid by height `h` -- same
    call convention as openscad4.py's own linear_extrude(sec, h, a,
    steps), just real B-rep in and out. `center` follows OpenSCAD's
    linear_extrude(..., center=...) meaning (False: extrudes from the
    profile's own plane up to h; True: centered on that plane instead).

    Extrudes along +Z by default -- but that's really "the profile's
    own local normal", which only happens to be +Z because circle()/
    square()/polygon() build flat in the XY plane by default. If
    you've since rot()/translate()d the profile (or its winding order
    makes its normal point the "wrong" way), the actual extrusion
    direction moves with it -- pass `dir` ([x,y,z], only its direction
    matters, `h` still controls the distance) to pin the extrusion to
    a specific direction regardless of the profile's own orientation,
    e.g. to match a surface_line_vector() sweep vector exactly:

        a = rot('x90', polygon(cr2dt([...], s=10)))
        wall = surface_line_vector(a, [0, 100, 0])   # side surface only
        solid = linear_extrude(a, h=100, dir=[0, 1, 0])  # the real solid

    twist/scale (OpenSCAD's linear_extrude(twist=, scale=) -- a helical/
    tapered extrusion) are NOT implemented yet: build123d's own
    extrude() has no direct equivalent for either (that shape needs a
    loft between rotated/scaled copies of the profile, or a genuine
    helical sweep, neither wired up here yet) -- passing a non-default
    value raises rather than silently extruding straight with no
    explanation.
    """
    _require_build123d()
    if twist:
        raise NotImplementedError(
            "linear_extrude(twist=...) isn't implemented in brep.py yet "
            "(no direct build123d equivalent -- would need a loft between "
            "rotated copies of the profile). Use h/center only for now.")
    if scale != 1:
        raise NotImplementedError(
            "linear_extrude(scale=...) isn't implemented in brep.py yet "
            "(no direct build123d equivalent -- would need a loft between "
            "differently-scaled copies of the profile). Use h/center only for now.")
    dvec = None
    unit_dir = (0.0, 0.0, 1.0)
    if dir is not None:
        dvec = tuple(float(c) for c in dir)
        n = math.sqrt(sum(c * c for c in dvec))
        if n < 1e-12:
            raise ValueError("linear_extrude(): dir must be nonzero")
        unit_dir = tuple(c / n for c in dvec)
    out = bd.extrude(profile, amount=float(h), dir=dvec)
    if center:
        out = translate([-float(h) / 2.0 * c for c in unit_dir], out)
    return out


def rotate_extrude(profile, angle=360):
    """
    Revolves a 2D profile around the Z axis into a solid -- same idea as
    OpenSCAD's rotate_extrude(angle=...): `profile`'s local X becomes
    the resulting solid's radius, local Y becomes its height, same
    convention real OpenSCAD's rotate_extrude has. `profile` should lie
    on the +X side of the Z axis (a profile straddling or crossing the
    axis produces self-intersecting/invalid geometry).

    REAL BUG FIX (found via a real user report -- "rotate_extrude did
    not work"): circle()/square()/polygon()/cr2dt()+polygon() all build
    `profile` flat on the XY plane (z=0 everywhere), same as they need
    to be for linear_extrude(). But build123d's own revolve() sweeps a
    Face rigidly around the literal 3D axis given -- per its own
    docs, "the most common use case is when the axis is in the same
    plane as the face to be revolved". Axis.Z is PERPENDICULAR to the
    XY plane, not in it, so hand build123d's revolve() a profile
    straight off circle()/polygon()/etc and every point just spins in
    place within its own z=0 plane -- a degenerate, zero-height
    "solid" (or an outright OCCT error), not the swept solid OpenSCAD's
    rotate_extrude() produces. The fix: rotate the profile 90 degrees
    about X first, carrying it from the XY plane onto the XZ plane
    (local (x,y) -> world (x,0,y)) -- NOW Axis.Z lies IN the profile's
    plane, exactly the case revolve() is built for, and local X/Y map
    onto radius/height exactly like real OpenSCAD.
    """
    _require_build123d()
    reoriented = _rotate_single_axis('x', 90.0, profile)
    return bd.revolve(reoriented, axis=bd.Axis.Z, revolution_arc=float(angle))


_SWEEP_TRANSITIONS = {"round": "ROUND", "transformed": "TRANSFORMED", "right_corner": "RIGHT"}


def _as_path_wire(shape, fn_name):
    """
    internal: turns a real Shape into a sweep/trace-able Wire/Edge,
    pulling a filled 2D shape's (circle()/square()/polygon()/cr2dt()+
    polygon()/etc) boundary wire out automatically -- a filled Face
    isn't itself a valid path (that needs an actual curve, a Wire/
    Edge), so this does the same "grab its outline instead" step
    sweep_sec2path() always did for a Shape path3d, now shared with
    p_line3d() too so a real Shape works the same way as an argument
    to either.
    """
    path_wire = shape
    faces = path_wire.faces() if hasattr(path_wire, "faces") else []
    if faces:
        wires = path_wire.wires() if hasattr(path_wire, "wires") else []
        if not wires:
            raise ValueError(
                f"{fn_name}(): path is a filled 2D shape with no boundary wire to trace")
        path_wire = wires[0]
    return path_wire


def sweep_sec2path(section2d, path3d, mirror=0, orientation=0, closed_loop=0,
                    is_frenet=False, transition="round"):
    """
    Sweeps a 2D cross-section along a 3D path to build a solid -- the
    B-rep counterpart of openscad4.py's sweep_sec2path(). Calls
    build123d's own native sweep() (OCCT's pipe-shell sweep) directly --
    this went through two home-rolled reimplementations first (manually
    extruding+unioning each straight path segment, to work around
    sweep() apparently choking on sharp path corners) before landing
    back here, because the actual problem was a single missing
    argument, not sweep() itself: `transition=`.

    `transition` controls how OCCT joins two straight (or curved)
    stretches of `path3d` at a corner:
      "round" (default here -- see below): inserts a rounded fillet-like
        surface at the joint. The one that reliably produces valid
        geometry through a sharp corner, which is why it's the default
        here -- build123d's own default (used if you pass
        transition="transformed" instead) is the "transformed" one
        below, which is fine for gentle bends but is a well-known way to
        get an invalid/self-intersecting solid through a genuinely sharp
        corner (a mitered/extended-face joint whose faces cross each
        other), which is almost certainly what a couple of earlier real
        bug reports against this function actually were.
      "transformed": each cross-section is rigidly carried along the
        path and the resulting faces are extended/trimmed to meet at a
        flat mitered joint. Sharper-looking corners on GENTLE bends;
        prone to invalid geometry on sharp ones (see above).
      "right_corner": a hard-edged corner join, no rounding.
    If your path has any tight turns and the default doesn't look
    right, this is the first thing to try changing.

    section2d: the cross-section to sweep -- either a [[x,y], ...] point
        list (same shape circle()/square()/turtle2d() produce; turned
        into a polygon() automatically) or an already-built 2D shape
        (circle(), square(), polygon(), ...). Defined once in the XY
        plane; this function moves/orients a copy of it to the start of
        `path3d` for you -- you don't need to position it there
        yourself.
    path3d: the path to sweep along -- either a [[x,y,z], ...] point
        list (same shape turtle3d() produces; turned into a straight-
        line-segment Wire automatically, i.e. build123d's Polyline --
        2D [[x,y], ...] points, like arc()'s or sinewave()'s output,
        are accepted too and padded to z=0 automatically, so a path
        built entirely in the XY plane doesn't need c23()'d by hand
        first), an already-built build123d Edge/Wire (e.g. from your
        own build123d Spline/Helix/ThreePointArc, for a smoothly
        curved path instead of straight segments), or a filled 2D
        shape like circle()/
        square()/polygon() -- its boundary is used as the path
        automatically (e.g. sweep_sec2path(circle(2), circle(20)) sweeps
        a small circle around a big one, a torus -- circle()/etc return
        a filled face, not just its outline, but a face isn't itself a
        valid sweep path, so the outline is pulled out for you here).
        Only reliable for a simple outline with a single boundary (like
        circle()/square()/a plain polygon()) -- for anything with holes
        or multiple boundaries, build your own explicit Wire/Edge and
        pass that instead.
    mirror: 0 (default) or 1 -- flips the section across its own local
        X axis before sweeping (same as openscad4.py's mirror= flag).
    orientation: 0/1/2/3 -- rotates the section 0/90/180/270 degrees
        about the path's own tangent direction before sweeping. A 2D
        cross-section has no inherent "up" once it's swept along an
        arbitrary 3D path -- there's no single correct answer for which
        way it should face, only a family of 4 that differ by which
        edge points which way -- so, same as openscad4.py's own
        orientation= flag, this is a "try 0, look at it, bump to
        1/2/3 if it's facing the wrong way" knob, not something
        computed automatically.
    closed_loop: 0 (default, open path) or 1 -- set 1 if `path3d`'s
        last point should connect back to its first (a closed-loop
        path, e.g. swept around a ring) rather than stopping there.
        Only meaningful when `path3d` is a point list; if you pass your
        own Edge/Wire, close it yourself before calling this.
    is_frenet: passed straight through to build123d's own
        sweep(is_frenet=...) -- False (default) uses OCCT's twist-
        minimizing "corrected" frame as the section travels the path;
        True uses a strict Frenet frame instead, which can flip
        abruptly at inflection points on some paths. Leave this False
        unless you have a specific reason to want strict Frenet
        behavior -- ONE such reason: cutting a helical thread/groove
        with an off-axis profile (e.g. a V-shaped point meant to face
        radially inward). The default frame has no guaranteed
        relationship to "radially inward" -- it just avoids twisting,
        so the profile's point can end up facing sideways or outward
        instead, making a difference() with it barely touch the solid
        (see examples/14_loft_and_helix.py's thread-cutting example).
        is_frenet=True fixes this FOR A HELIX SPECIFICALLY, since a
        helix's own principal normal always points straight at its
        central axis. If the cut still comes out inverted (cutting
        outward instead of in), try mirror=1 or orientation=2 on top.

    IMPORTANT -- this has been through several rounds of real bug fixes
    against a real build123d install (invalid geometry and a crash with
    orientation != 0; then, after switching to a hand-rolled
    segment-union approach, visibly disjointed segments; then switching
    to native sweep() plus transition="round"; then a filled 2D shape
    like circle() passed as path3d raising AttributeError, since a Face
    isn't itself a valid sweep path -- fixed by extracting its boundary
    wire automatically) but this exact version has NOT itself been
    re-verified against that real install (no network access in this
    environment to pip install build123d) -- only wiring-checked with a
    mock. Please report back what you see -- if "round" still doesn't
    look right for your geometry, try transition="right_corner" or
    "transformed" before assuming something else is wrong.

    CONFIRMED real failure mode (real user report): a many-segment,
    NON-PLANAR path3d (e.g. one bent out of flat via axis_rot_1_pts()
    or similar) with the default transition="round" can raise
    `AttributeError: 'NoneType' object has no attribute 'NbNodes'` --
    a real OCCT/OCP error deep in the "round" transition's per-corner
    fillet-surface construction, not a bug in this wrapper. Switching
    to transition="right_corner" (no fillet surfaces at all) fixed it.
    Same fragility class documented in p_line3d()'s own docstring
    (and examples/20_3d_knots.py's story) -- many segments + sharp/
    varying turns + "round" is the pattern to watch for; try
    "right_corner" or "transformed" first before digging further.
    """
    _require_build123d()

    if isinstance(path3d, bd.Shape):
        path_wire = _as_path_wire(path3d, "sweep_sec2path")
        start_pt = path_wire.position_at(0)
        start_tangent = path_wire.tangent_at(0)
    else:
        pts = [(float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0) for p in path3d]
        if len(pts) < 2:
            raise ValueError("sweep_sec2path(): path3d needs at least 2 points")
        if closed_loop and pts[0] != pts[-1]:
            pts = pts + [pts[0]]
        path_wire = bd.Polyline(*pts)
        # REAL BUG FIX (found via a real user report -- a many-point,
        # non-planar path, an axis_rot_1_pts()-bent profile fed
        # straight to p_line3d()): calling path_wire.position_at(0)/
        # .tangent_at(0) on a JUST-BUILT multi-segment Polyline can hit
        # a real OCCT/OCP rough edge in some build123d versions --
        # "'NoneType' object has no attribute 'NbNodes'" -- deep in
        # OCCT's own curve-adaptor code, unrelated to anything wrong
        # with the geometry itself. But there's no reason to ask OCCT
        # for this Wire's own start point/tangent at all here -- we
        # just built it FROM these exact points, so pts[0] IS the
        # start point, and the direction to the next point that isn't
        # a duplicate of it IS the start tangent, both known directly
        # with no Wire query (and no chance of hitting that bug).
        start_pt = pts[0]
        j = 1
        while j < len(pts) and pts[j] == pts[0]:
            j += 1
        if j >= len(pts):
            raise ValueError("sweep_sec2path(): path3d's points are all the same point")
        dx, dy, dz = pts[j][0] - pts[0][0], pts[j][1] - pts[0][1], pts[j][2] - pts[0][2]
        n = math.sqrt(dx * dx + dy * dy + dz * dz)
        start_tangent = (dx / n, dy / n, dz / n)

    section = section2d if isinstance(section2d, bd.Shape) else polygon(section2d)

    if mirror:
        section = bd.mirror(section, about=bd.Plane(origin=(0, 0, 0), z_dir=(1, 0, 0)))
    if orientation:
        section = rotate([0, 0, 90 * (int(orientation) % 4)], section)

    section = bd.Plane(origin=start_pt, z_dir=start_tangent) * section

    key = str(transition).lower()
    if key not in _SWEEP_TRANSITIONS:
        raise ValueError(
            f"sweep_sec2path(): transition must be one of "
            f"{sorted(_SWEEP_TRANSITIONS)}, got {transition!r}")
    transition_enum = getattr(bd.Transition, _SWEEP_TRANSITIONS[key])

    return bd.sweep(section, path=path_wire, is_frenet=bool(is_frenet), transition=transition_enum)


def translate(v, shape):
    """
    Moves `shape` by [x,y,z] -- same convention as openscad4.py's own
    translate(p, sec), just with build123d's B-rep Shape instead of a
    prism/section point list. Returns a new shape; doesn't mutate the
    original (build123d shapes are immutable under these operators).
    """
    _require_build123d()
    x, y, z = [float(c) for c in v]
    return bd.Pos(x, y, z) * shape


def _rotate_single_axis(axis_letter, angle, shape):
    """
    internal: rotate `shape` by `angle` degrees about ONE axis only.
    Unlike a combined bd.Rotation(x,y,z) call (which depends on
    whichever multi-axis composition convention build123d uses
    internally -- extrinsic vs intrinsic, XYZ vs ZYX, etc., not
    something worth guessing at), a single nonzero component has no
    such ambiguity: "rotate 37 degrees around X" means exactly one
    thing regardless of convention. rotate()/rot() below both build on
    this rather than ever calling bd.Rotation with more than one
    nonzero component at once, so neither depends on knowing
    build123d's internal convention.
    """
    x, y, z = (angle, 0.0, 0.0) if axis_letter == 'x' else (0.0, angle, 0.0) if axis_letter == 'y' else (0.0, 0.0, angle)
    return bd.Rotation(x, y, z) * shape


def rotate(angles, shape):
    """
    Rotates `shape` by [x, y, z] degrees -- same convention as real
    OpenSCAD's rotate([x,y,z], ...): applied as three separate single-
    axis rotations in sequence, first x degrees about X, then y about
    Y, then z about Z (OpenSCAD's own documented order for the vector
    form). Implemented as three chained single-axis rotations (see
    _rotate_single_axis()) specifically so this doesn't depend on
    build123d's own internal convention for a combined multi-axis
    Rotation(x,y,z) call, which isn't pinned down clearly enough in its
    docs to rely on directly.
    """
    _require_build123d()
    x, y, z = [float(a) for a in angles]
    out = shape
    if x:
        out = _rotate_single_axis('x', x, out)
    if y:
        out = _rotate_single_axis('y', y, out)
    if z:
        out = _rotate_single_axis('z', z, out)
    return out


def rot(a, shape):
    """
    A string-based axis+angle rotation DSL -- e.g. rot('z30x70y-90',
    shape) rotates first about Z by 30 degrees, then X by 70, then Y by
    -90, strictly in the order the axis letters appear in the string
    (not always x-then-y-then-z like rotate() above -- whatever order
    you write it in).

    Like rotate() above, each individual step here is a pure single-
    axis rotation (see _rotate_single_axis()), so there's no dependence
    on build123d's own multi-axis composition convention.
    """
    _require_build123d()
    tokens = re.findall(r'([xyz])(-?\d+\.?\d*)', a)
    if not tokens:
        raise ValueError(f"rot(): couldn't parse any x<angle>/y<angle>/z<angle> tokens out of {a!r}")
    out = shape
    for axis_letter, angle_str in tokens:
        out = _rotate_single_axis(axis_letter, float(angle_str), out)
    return out


def axis_rot_1(sol, ax1, loc1, theta):
    """
    Rotates `sol` by `theta` degrees about an ARBITRARY axis -- the
    axis passes through point `loc1` with direction `ax1`, unlike
    rotate()/rot() above, which only ever rotate about an axis through
    the origin. openscad4.py's own axis_rot_1(), ported: the original
    built this out of a translate-to-the-solid's-own-centroid/apply-a-
    rotation-matrix/translate-back dance; here it's just build123d's
    own native Shape.rotate(axis, angle), which already IS "rotate
    about an arbitrary axis" directly -- no centroid math needed.

        c1 = cylinder(r=5, h=20)
        c2 = axis_rot_1(c1, [1, 1, 0], [0, 0, 20], -90)
        show(c1)
        show(color(c2, "blue", alpha=0.5))
    """
    _require_build123d()
    axis = bd.Axis(tuple(float(c) for c in loc1), tuple(float(c) for c in ax1))
    return sol.rotate(axis, float(theta))


def axis_rot_1_pts(pts, ax1, loc1, theta):
    """
    Rotates a raw point list `pts` ([x,y] or [x,y,z] points -- 2D
    points are padded to z=0 first) by `theta` degrees about an
    ARBITRARY axis (direction `ax1` through point `loc1`) -- the
    point-list counterpart of axis_rot_1() (which rotates a real
    build123d Shape the same way, via its own native .rotate()), for
    when you have a plain point list rather than a Shape (no
    build123d needed, same spirit as fit_pline2line()/xrot4d() above).

    Always returns 3D points, even for 2D input (see fit_pline2line()'s
    own note on why -- rotating about an arbitrary axis generally
    needs to leave whatever plane the input started in, so flattening
    back to 2D would just throw the rotation away).

    Handy for rotating a profile's points BEFORE building a real
    shape from them -- e.g. `polygon(axis_rot_1_pts(pts, ax, loc,
    theta))` -- instead of building the shape first and rotating it
    afterward with axis_rot_1(); this also sidesteps a real build123d/
    OCCT rough edge some rotated Face boundary wires can hit later
    (position_at() raising "'NoneType' object has no attribute
    'NbNodes'" when passed to p_line3d()/sweep_sec2path()).

        pts = arc_3p([10, 0], [0, 50], [10, 100]) + [[-10, 100], [-10, 0]]
        pts = axis_rot_1_pts(pts, [0, 1, 0], [10, 0, 0], 60)
        d = polygon(pts)
        show(p_line3d(d, 0.1))
    """
    pts3 = c23(pts)
    return _rotate_points_about_axis(pts3, ax1, loc1, theta)


def mirror(v, shape):
    """
    Mirrors `shape` across the plane through the origin whose normal is
    `v` -- same convention as OpenSCAD's mirror(v, ...), e.g. mirror([1,
    0, 0], shape) flips it across the YZ plane.
    """
    _require_build123d()
    x, y, z = [float(c) for c in v]
    plane = bd.Plane(origin=(0, 0, 0), z_dir=(x, y, z))
    return bd.mirror(shape, about=plane)


def surface_line_vector(line, vector, both_sides=False):
    """
    Builds a real ruled Face by sweeping `line` (a point list, e.g.
    sinewave()/turtle3d()/fit_pline2line() output) straight along
    `vector` -- openscad4.py's own surface_line_vector(), ported as a
    real B-rep ruled surface (build123d's own native
    Face.make_surface_from_curves(), an exact ruled surface between
    two curves computed by OCCT) instead of a 2-row point-list
    "surface" meant for swp_surf()'s later mesh triangulation -- like
    the rest of the mesh-native surface family, that intermediate
    representation is dropped here in favor of returning a real,
    already-usable Face directly (union/loft/extrude/export-ready, no
    separate meshing step needed).

    `both_sides=False` (default) sweeps from `line` itself out to
    `line` translated by `vector` (a one-sided sweep -- `line` runs
    along one edge of the resulting Face). `both_sides=True` sweeps
    from `line` shifted by `-vector` to `line` shifted by `+vector`
    instead (a symmetric sweep -- `line` runs through the middle of
    the resulting Face, not along either edge).

    `line` can also be a real Shape instead of a raw point list -- a
    Wire/Edge (e.g. arc_edge(), interp_spline()'s output), or a filled
    2D shape like polygon()/circle()'s output (its boundary is used
    automatically, same _as_path_wire() step p_line3d()/
    sweep_sec2path() use for a Shape argument). Translating a real
    Shape by `vector` uses translate()'s own real B-rep move (exact,
    no faceting), rather than shifting individual points.

        # rotate()/translate() only work on real Shapes, not raw point
        # lists (see fit_pline2line()'s own note) -- for a point list
        # like sinewave()'s output, build it straight into the plane
        # you want instead (here XZ: local (x,y) -> world (x,0,y)).
        l1 = [[x, 0, y] for x, y in sinewave(50, 3, 2, 50)]
        s1 = surface_line_vector(l1, [0, 20, 0], both_sides=True)
        show(color(p_line3d(l1, 0.3), "blue"))
        show(color(s1, "cyan", alpha=0.5))
    """
    _require_build123d()
    vx, vy, vz = [float(c) for c in vector]

    if isinstance(line, bd.Shape):
        path_wire = _as_path_wire(line, "surface_line_vector")
        if both_sides:
            w0 = bd.Pos(-vx, -vy, -vz) * path_wire
            w1 = bd.Pos(vx, vy, vz) * path_wire
        else:
            w0 = path_wire
            w1 = bd.Pos(vx, vy, vz) * path_wire
        return bd.Face.make_surface_from_curves(w0, w1)

    pts = _flatten_points(line)
    if len(pts) < 2:
        raise ValueError("surface_line_vector(): line needs at least 2 points")
    pts3 = [(p[0], p[1], p[2] if len(p) > 2 else 0.0) for p in pts]
    if both_sides:
        row0 = [(x - vx, y - vy, z - vz) for x, y, z in pts3]
        row1 = [(x + vx, y + vy, z + vz) for x, y, z in pts3]
    else:
        row0 = pts3
        row1 = [(x + vx, y + vy, z + vz) for x, y, z in pts3]
    w0 = bd.Polyline(*row0)
    w1 = bd.Polyline(*row1)
    return bd.Face.make_surface_from_curves(w0, w1)


def convert_3lines2fillet(line_a, line_b, spine, s=20, closed_loop=0):
    """
    Builds a fillet surface (as a 2D point grid) by blending 3
    matching-length point lists station-by-station -- openscad4.py's
    own convert_3lines2fillet(), ported: openscad4.py called these
    positional args l2, l3, l1 respectively (matching that exact
    positional order if you're porting an old script), describing the
    order as "starting line, ending line, anchor line" -- `spine` here
    is that 3rd "anchor" argument.

    The manual, explicit-geometry way to build a fillet when
    fillet()/max_fillet_radius() genuinely can't find one -- a deep or
    sharp cut, a seam edge, edges too close together (see fillet()'s
    own docstring for the real failure modes this is the fallback
    for).

    `spine` is the actual sharp edge you're rounding off -- e.g. a
    real intersection curve between two surfaces `a`/`b`, sampled into
    a point list. `line_a`/`line_b` are two curves tracing where the
    fillet should blend INTO each of the two original surfaces --
    pulled a little way off `spine`, onto each surface respectively.
    All 3 lists must be the SAME length, in the SAME station order --
    station i on `spine` must correspond to station i on `line_a`/
    `line_b`.

    The general recipe for getting all 3 from two real surfaces `a`/
    `b`, using ONLY real B-rep booleans (no surface-projection math
    needed): nudge one surface off its own plane with offset_face(),
    then intersect it with the OTHER (un-nudged) surface -- the
    resulting curve lies exactly on the un-nudged surface, shifted
    away from the true spine by roughly the nudge amount:

        blend = 2                                       # how far the fillet reaches
        n = 40                                           # station count
        spine  = sample_curve(intersection(a, b), n)
        line_b = sample_curve(intersection(offset_face(a, blend), b), n)
        line_a = sample_curve(intersection(a, offset_face(b, blend)), n)
        grid = convert_3lines2fillet(line_a, line_b, spine, s=15)
        patch = surface_from_points_grid(grid)
        show(patch)

    (project_curve_on_face()/psos() are the other real B-rep tools for
    getting a curve to lie on a specific surface, if you already have
    one from elsewhere instead of deriving it via offset_face()+
    intersection() above.)

    At every station, builds a small bezier() arc through
    `[line_a[i], spine[i], line_b[i]]` (`s` points, pulled toward the
    spine point in the middle, same as any bezier() control point).
    The result is a 2D point grid (one row per station) -- feed it
    straight into surface_from_points_grid() for the real B-rep fillet
    Face:

        grid = convert_3lines2fillet(line_a, line_b, spine, s=15)
        patch = surface_from_points_grid(grid)
        show(patch)

    DIFFERS from openscad4.py's own version in one deliberate way: the
    original appended the spine point again at the end of every
    station (`+[p1]`), closing each cross-section into a wedge shape
    for its own mesh-based swp_c() (a closed-section sweep -- see
    swp_c()'s own real behavior: it auto-closes the LAST point of
    every row back to the FIRST, so appending the spine point again at
    the end there actually built a closed, pinched-at-the-spine wedge
    profile per station, not just a cosmetic extra point). This
    function returns the OPEN row instead (no reclosing point) since
    it's meant for surface_from_points_grid() below, which fits one
    smooth surface through the whole grid directly and doesn't need
    (or want) a closed per-row loop. If you want the actual closed-
    wedge-per-station behavior for a REAL solid via loft() -- the
    build123d equivalent of swp_c() -- see loft_fillet() right below
    instead, which reconstructs that exact reclosing.

    `closed_loop=1` also repeats the FIRST station as one more row at
    the end -- for a fillet that wraps all the way around a closed
    spine (a full loop, not two open ends), same closed_loop
    convention as turtle3d()/p_line3d()/sweep_sec2path().
    """
    n = len(spine)
    if len(line_a) != n or len(line_b) != n:
        raise ValueError(
            f"convert_3lines2fillet(): line_a/line_b/spine must all have "
            f"the same number of points (got line_a={len(line_a)}, "
            f"line_b={len(line_b)}, spine={n})")
    if n < 1:
        raise ValueError("convert_3lines2fillet(): need at least 1 station")
    grid = [bezier([line_a[i], spine[i], line_b[i]], s) for i in range(n)]
    return grid if not closed_loop else grid + [grid[0]]


def loft_fillet(line_a, line_b, spine, s=20, closed_loop=0, ruled=False):
    """
    Builds a real B-rep SOLID filling the corner between two surfaces,
    by lofting through MANY small closed cross-section wedges (one per
    station) instead of fitting a single open surface patch
    (convert_3lines2fillet()+surface_from_points_grid() above) -- the
    real B-rep equivalent of openscad4.py's own swp_c()-based closed-
    section sweep. Same 3-line input (spine/line_a/line_b -- see
    convert_3lines2fillet()'s own docstring for the full recipe for
    deriving all 3, including the mesh-based two_solids_intersection()
    route for genuinely hard cases where a real B-rep boolean
    struggles).

    At every station, builds a small CLOSED wedge profile: the bezier
    arc from line_a[i] through spine[i] (pulled toward it) out to
    line_b[i], then back to spine[i], closed back to line_a[i]
    (mixed_polygon() does the explicit closing build123d has no auto-
    close for, matching swp_c()'s own real auto-close-last-to-first
    behavior). Lofting through the whole stack of these wedges fills
    exactly the corner between the two original surfaces, pinched down
    to the sharp spine at every cross-section.

        blend = 2
        n = 40
        spine  = sample_curve(intersection(a, b), n)
        line_b = sample_curve(intersection(offset_face(a, blend), b), n)
        line_a = sample_curve(intersection(a, offset_face(b, blend)), n)
        solid = loft_fillet(line_a, line_b, spine, s=10)
        show(solid)

    Each station's wedge needs to be at least CLOSE to planar for
    mixed_polygon()'s underlying Face(Wire) construction to succeed --
    true for most reasonable blend widths relative to how sharply the
    spine curves, but a spine that twists tightly relative to `blend`
    can produce a station too warped to build (mixed_polygon() or
    loft() itself will raise). If you hit that,
    surface_from_points_grid(convert_3lines2fillet(...)) is the more
    robust fallback -- fits one smooth surface through the whole grid
    at once instead of building/lofting individual station Faces,
    trading the solid result for an open patch you'd thicken()
    yourself.

    `closed_loop`/`ruled` mean the same as convert_3lines2fillet()'s/
    loft()'s own (see their docstrings) -- `ruled=True` if you want a
    piecewise-straight fillet between stations instead of the smooth
    default.
    """
    _require_build123d()
    n = len(spine)
    if len(line_a) != n or len(line_b) != n:
        raise ValueError(
            f"loft_fillet(): line_a/line_b/spine must all have the same "
            f"number of points (got line_a={len(line_a)}, line_b={len(line_b)}, spine={n})")
    if n < 2:
        raise ValueError("loft_fillet(): need at least 2 stations to loft through")
    stations = [bezier([line_a[i], spine[i], line_b[i]], s) + [spine[i]] for i in range(n)]
    if closed_loop:
        stations = stations + [stations[0]]
    sections = [mixed_polygon(row) for row in stations]
    return loft(*sections, ruled=bool(ruled))


def surface_from_points_grid(points, tol=0.01, min_deg=1, max_deg=3):
    """
    Fits a real B-rep surface (a Face, generally non-planar) through a
    2D grid of 3D points -- build123d's own native
    Face.make_surface_from_array_of_points() (GeomAPI_PointsToBSplineSurface
    under the hood: a genuine NURBS surface approximation through the
    whole grid), instead of a triangle mesh. `points` is a list of
    rows, each row a same-length list of [x,y,z] (or [x,y], z=0)
    points -- a rectangular V x U grid.

    The general-purpose building block behind surface_from_2_waves()
    below -- reach for this one directly whenever you already have
    your own 2D point grid (your own height-field/parametric math, a
    grid sampled off some other surface, etc) and just want it as one
    real curved Face rather than assembling it from wave curves.

    `tol`/`min_deg`/`max_deg` control the fitting accuracy/degree --
    same meaning as build123d's own parameters, defaults are fine for
    most cases. Raises ValueError ("B-spline approximation failed") if
    the grid is too irregular/self-overlapping for a single surface to
    fit through at the given tolerance -- try loosening `tol` first.
    """
    _require_build123d()
    grid = [[(float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0)
             for p in row] for row in points]
    return bd.Face.make_surface_from_array_of_points(
        grid, tol=float(tol), min_deg=int(min_deg), max_deg=int(max_deg))


def surface_from_2_waves(p0, p1, amplitude=1):
    """
    A wavy real B-rep surface combining two wave-like point lists
    `p0`/`p1` (each meant to run along its OWN axis, perpendicular to
    the other -- see the example below) -- openscad4.py's own
    surface_from_2_waves(), ported as a real fitted NURBS Face
    (surface_from_points_grid() above) instead of a triangle-mesh grid.

    For every combination of a point `i` from `p0` (the grid's "row"
    direction) and a point `j` from `p1` (the "column" direction),
    builds a grid point at [i.x, j.y, i . j] (i and j's own 3D dot
    product -- so the two waves' heights multiply together, the
    classic combined-wave "basket weave"/ripple look), then rescales
    the whole grid's height so its max is exactly `amplitude`.

    `p0`/`p1` are typically sinewave()/cosinewave() output laid out
    directly in their own plane (NOT rotated afterward with rot() --
    that only works on real Shapes, not point lists -- build the wave
    straight into the plane you want instead, same trick
    surface_line_vector()'s own docstring uses):

        l1 = [[x, 0, y] for x, y in sinewave(50, 3, 2, 50)]      # XZ plane
        l2 = [[0, x, y] for x, y in cosinewave(50, 3, 2, 50)]    # YZ plane
        s1 = surface_from_2_waves(l1, l2, 2)
        show(s1)

    A ripple with a small `amplitude` relative to `p0`/`p1`'s own
    length (e.g. amplitude=2 over a length=100 wave -- only a ~2%
    grade) will genuinely look almost flat at normal zoom, in any
    renderer -- that's not a bug, just perspective. Use a bigger
    amplitude:length ratio to see it clearly, or check
    `s1.bounding_box().size.Z` (should be close to 2*amplitude, since
    the surface genuinely swings +amplitude to -amplitude) to confirm
    the ripple is really there before assuming something's wrong.
    """
    _require_build123d()
    pts0 = [(float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0) for p in p0]
    pts1 = [(float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0) for p in p1]
    grid = [[(i[0], j[1], i[0] * j[0] + i[1] * j[1] + i[2] * j[2]) for j in pts1] for i in pts0]
    max_z = max(pt[2] for row in grid for pt in row)
    if max_z == 0:
        raise ValueError(
            "surface_from_2_waves(): the combined grid height is all zero "
            "-- can't rescale to `amplitude` (check p0/p1 aren't both flat).")
    grid = [[(pt[0], pt[1], pt[2] / max_z * float(amplitude)) for pt in row] for row in grid]
    return surface_from_points_grid(grid)


def thicken(shape, amount, both=False):
    """
    Thickens a Face (e.g. surface_line_vector()'s own output, or any
    Face at all -- planar or not) into a real solid, offset along its
    own surface normal at every point -- build123d's own native
    thicken(). Unlike linear_extrude(), which needs the extrusion
    direction spelled out yourself, this follows whatever direction
    the surface itself curves in point by point, which matters for a
    non-planar surface (surface_line_vector()'s ruled Face, most of
    the time) that has no single straight-line extrusion direction to
    begin with.

    `amount`'s SIGN picks which side gets the material: positive
    thickens along the surface's own normal ("outside", from however
    it was built/wound), negative thickens against it ("inside") -- a
    Face's normal direction isn't always obvious up front, so if it
    comes out on the wrong side, just flip the sign and try again.

    `both=True` thickens in BOTH directions at once and fuses the
    result into one solid centered on the original surface -- note
    this means `amount` on EACH side (2*`amount` total thickness
    across the surface), not `amount` split between the two.

        a = rot('x90', polygon(cr2dt([...], s=10)))
        wall = surface_line_vector(a, [0, 100, 0])
        solid = thicken(wall, 2)             # 2 units thick, one side only
        shell = thicken(wall, 1, both=True)  # 2 units thick total, centered
    """
    _require_build123d()
    return bd.thicken(shape, amount=float(amount), both=bool(both))


def mirror_surface(shape, n1, loc=(0, 0, 0)):
    """
    Mirrors a real `shape` (solid/face/wire/edge) across the plane
    through `loc` with normal `n1` -- openscad4.py's own
    mirror_surface(), ported. The original mirrored a mesh "surface"
    (a grid of point-list rows) row-by-row via mirror_line(); here
    it's just build123d's own native mirror() applied straight to a
    real shape, with an arbitrary `loc` offset -- the general form of
    this app's own mirror(v, shape) above, which always mirrors
    through the origin. For mirroring a raw 2D/3D point list instead
    of a real shape, see mirror_line()/mirror_point().

        s1 = translate([0, -30, 0], sphere(10))
        s2 = mirror_surface(s1, [1, 1, 0], [0, -30, 0])
        show(s1)
        show(color(s2, "cyan"))
    """
    _require_build123d()
    n = tuple(float(c) for c in n1)
    p = bd.Plane(origin=tuple(float(c) for c in loc), z_dir=n)
    return bd.mirror(shape, about=p)


def scale(v, shape):
    """
    Scales `shape` about the origin -- same convention as OpenSCAD's
    scale(v, ...): `v` is either one number (uniform scale) or [x,y,z]
    (independent per-axis scale).
    """
    _require_build123d()
    if isinstance(v, (int, float)):
        factor = float(v)
    else:
        factor = tuple(float(c) for c in v)
    return bd.scale(shape, by=factor)


_OFFSET_KINDS = {"arc": "ARC", "intersection": "INTERSECTION", "tangent": "TANGENT"}


def offset(shape, amount, kind="arc", openings=None):
    """
    Grows (amount > 0) or shrinks (amount < 0) `shape` by `amount` --
    same idea as OpenSCAD's offset(), just calling build123d's own
    native offset() directly rather than a hand-rolled polygon-offset
    algorithm (2D polygon offsetting -- correctly handling corners,
    self-intersections after a large inward offset, holes, etc -- is
    a genuinely hard problem in its own right, exactly the kind of
    thing this app leans on the real OCCT kernel for rather than
    reimplementing; see sweep_sec2path()'s own docstring for a case
    where a hand-rolled attempt at something similar didn't go well).

    `shape` can be:
      - a 2D shape (circle()/square()/polygon()/etc): grows/shrinks its
        outline -- e.g. offset(square(10, center=True), 2) is a 14x14
        square; offset(..., -2) a 6x6 one. A shape with holes has its
        holes offset the opposite direction automatically (so growing
        the outer boundary shrinks the holes, like OpenSCAD's own
        offset()), so e.g. offsetting a ring outward makes it a wider
        ring, not a filled disc.
      - a 3D solid: SHELLS it -- hollows it out to a uniform wall
        thickness `amount`, sealed on every face by default (a closed
        hollow shell) unless you open some of them via `openings=`
        (e.g. openings=box.faces().sort_by(Axis.Z)[-1] leaves the top
        face open, like a hollow box with no lid -- same edges()/
        faces() selector API fillet()/chamfer() use; see the README's
        "Manually selecting edges" section).

        A FULLY SEALED shell (openings=None) of a solid that's
        entirely curved with no flat face to anchor on -- a sphere or
        a capped cylinder are the classic cases -- is a known-fragile
        operation in OCCT itself: the thicken algorithm can fail
        outright there (an "offset Error"), and unlike a mitered-vs-
        rounded-corner problem, trying a different `kind` often does
        NOT fix it (it's not a corner-handling issue at all -- it's
        that a fully closed offset of a shape with no flat "seam" to
        start stitching from is a genuinely hard case for the
        algorithm). If you hit that, don't bother cycling through
        `kind` values -- either open at least one face via `openings=`
        (even a small one), or, most robust of all, skip offset()
        entirely and build the hollow shape directly out of two nested
        copies with difference() instead -- e.g.
        difference(sphere(10), sphere(8)) for a hollow sphere with a
        2-unit wall. That's a plain boolean, not dependent on the
        thicken algorithm at all, so it always works.

    kind picks how corners are handled where the offset outline can't
    stay parallel to a sharp original corner:
      "arc" (default): rounds the corner.
      "intersection": a sharp, mitered corner (extends both offset
        edges until they meet -- can fail on a corner sharp/tight
        enough for that extension to self-intersect, same class of
        issue as sweep_sec2path()'s "transformed" transition).
      "tangent": a straight-line transition between the two edges.
    """
    _require_build123d()
    key = str(kind).lower()
    if key not in _OFFSET_KINDS:
        raise ValueError(f"offset(): kind must be one of {sorted(_OFFSET_KINDS)}, got {kind!r}")
    kind_enum = getattr(bd.Kind, _OFFSET_KINDS[key])
    kwargs = {} if openings is None else {"openings": openings}
    try:
        return bd.offset(shape, amount=float(amount), kind=kind_enum, **kwargs)
    except Exception as exc:
        raise RuntimeError(
            f"offset(): OCCT couldn't compute this offset with kind={kind!r} "
            f"({exc}). Note this is often NOT a `kind` problem -- a fully "
            f"sealed shell (openings=None) of a solid that's entirely "
            f"curved with no flat face (a sphere, a capped cylinder) is a "
            f"known-fragile case in OCCT regardless of `kind`. Two more "
            f"reliable fixes: open at least one face via `openings=`, or "
            f"skip offset() and build the hollow shape directly with "
            f"difference() of two nested copies instead -- e.g. "
            f"difference(sphere(10), sphere(8)) for a hollow sphere."
        ) from exc


def offset_face(face, amount):
    """
    Moves a Face (or Shell) `amount` along its own surface normal --
    build123d's own native Face.offset()/Shell.offset() INSTANCE
    method. This is deliberately a DIFFERENT function from offset()
    above, because they do genuinely different things for a Face:
    offset() (the top-level function above) offsets the face's OUTER
    WIRE sideways, WITHIN its own plane (bigger/smaller outline, same
    plane) -- offset_face() instead pushes the whole face OFF its own
    plane, along its normal (a plain flat plate pushed straight up).

    EXACT for a planar Face (plane()'s own output, say): every point
    genuinely moves `amount` along the same constant normal, so this
    is a true parallel copy of the plane.

    APPROXIMATE for a curved Face (a cylinder's lateral surface, a
    fitted NURBS patch): build123d implements this as one RIGID
    TRANSLATION by (the face's own reference-point normal) * amount,
    not a true "every point grows along ITS OWN local normal" offset
    surface (that operation isn't exposed as a simple one-line call in
    build123d). Good enough as a nearby stand-in surface for finding a
    shifted intersection curve (see convert_3lines2fillet()'s own
    docstring for the full recipe this is built for) -- not a
    substitute for a real, precise offset surface.

        line_b = sample_curve(intersection(offset_face(a, 1), b), 40)
        line_a = sample_curve(intersection(a, offset_face(b, 1)), 40)
    """
    _require_build123d()
    return face.offset(float(amount))


def union(*shapes):
    """
    CSG union of two or more B-rep shapes (the `+` operator).

    CONFIRMED real failure mode (real user report): fusing several
    already-unioned shapes against one more shape that meets them
    across a large EXACTLY COPLANAR shared area (e.g. a flat base
    plate whose top face sits flush with several standing panels'
    bottom edges, all resting at the same z) can raise `AttributeError:
    'NoneType' object has no attribute 'NbNodes'` deep inside OCCT --
    same fragility class already documented in sweep_sec2path()'s/
    p_line3d()'s own docstrings, here triggered inside the boolean
    fuse itself rather than a sweep. It reliably showed up only once
    SEVERAL pieces' coincident contact area had accumulated (each
    piece unioned individually against the base worked fine) -- OCCT's
    fuse is well known to be far more fragile on large flush/coplanar
    contact than on a genuine volumetric overlap or a small contact
    patch.

    FIX: don't let two pieces meet across an exactly flush shared
    plane -- give the piece real volumetric overlap into the others
    instead (a thicker base shifted to poke slightly INTO whatever
    sits on top of it, say), e.g.:

        base = translate([0, 0, -0.5], linear_extrude(square(70), 2))
        # instead of: linear_extrude(square(70), 1)  # flush at z=0

    `.clean()`-ing operands right before a fuse that's struggling is
    also worth trying, but didn't fix this particular case on its own
    -- the real fix was removing the flush/coincident contact.
    """
    _require_build123d()
    shapes = _flatten(shapes)
    if len(shapes) == 0:
        raise ValueError("union(): need at least one shape")
    out = shapes[0]
    for s in shapes[1:]:
        out = out + s
    return out


def difference(base, *shapes):
    """
    CSG difference: `base` minus every shape in `shapes` (the `-`
    operator) -- same argument order as openscad4.py's usual
    difference(first_child, remaining_children...) convention.
    """
    _require_build123d()
    shapes = _flatten(shapes)
    out = base
    for s in shapes:
        out = out - s
    return out


def face_from_wire(wire):
    """
    Wraps an EXISTING closed Wire directly into a Face -- build123d's
    own native Face(wire) constructor. The point of this over
    mixed_polygon()/polygon() (which both build a brand new Wire from a
    plain point list) is EXACT edge matching: when you need a cap Face
    whose boundary is guaranteed to coincide exactly with another real
    shape's own boundary edges (e.g. one end of a
    surface_from_points_grid() surface), rebuilding that boundary
    independently from raw points (even the SAME points) traces a
    close-but-not-identical curve -- a fitted NURBS boundary and a
    fresh straight-line polygon through the same points are two
    genuinely different curves, and OCCT's exact-topology sewing
    (solid_from_faces()) needs edges to coincide, not just look close,
    or it fails to zip them into one watertight shell.

        wall = surface_from_points_grid(surf)      # a curved wall Face
        w = wall.wires()                            # its own boundary wire(s)
        cap_a = face_from_wire(w[0])                 # exact match to wall's own edge
        cap_b = face_from_wire(w[1])
        solid = solid_from_faces(wall, cap_a, cap_b)

    Raises whatever build123d itself raises if `wire` isn't planar (a
    Face can only be built from a wire that lies in one flat plane --
    same restriction polygon()/mixed_polygon() have).
    """
    _require_build123d()
    return bd.Face(wire)


def cap_wire(boundary, surface_points=None):
    """
    Caps a closed boundary with a real, potentially NON-planar Face --
    build123d's own native Face.make_surface() (OCCT's
    BRepOffsetAPI_MakeFilling under the hood: a genuine curvature-
    aware surface fill through the given boundary, not a flat cap).
    The non-planar counterpart to face_from_wire() above -- reach for
    this one instead whenever the ring you need to cap does NOT lie in
    one flat plane (face_from_wire()/polygon()/mixed_polygon() all
    require planarity; this doesn't).

    `boundary` is either a closed loop of raw [x,y,z] points (built
    into one periodic interpolating spline Edge via interp_spline()
    first) or an existing Wire/Edge/list of Edges to use directly --
    e.g. one of a Shape's own wall.wires(), for the closest possible
    edge match when sewing with solid_from_faces() (an independently
    built spline through the same points is still a genuinely
    different curve, so it won't sew edge-exact the way face_from_wire()
    does for a planar cap).

    `surface_points`, if given, are extra raw [x,y,z] points the fill
    is pulled through in addition to the boundary -- use this to keep
    a bulging/non-planar cap closer to the true shape in the middle
    instead of just bridging flat-ish between the boundary points.

        wall = surface_from_points_grid(grid)   # a tube, open at both ends
        cap_a = cap_wire(grid[0])                # first ring, however curved
        cap_b = cap_wire(grid[-1])               # last ring
        solid = solid_from_faces(wall, cap_a, cap_b)
    """
    _require_build123d()
    if isinstance(boundary, bd.Wire):
        exterior = boundary
    elif isinstance(boundary, bd.Edge):
        exterior = [boundary]
    elif isinstance(boundary, (list, tuple)) and boundary and isinstance(boundary[0], bd.Edge):
        exterior = list(boundary)
    else:
        exterior = [interp_spline(boundary, closed=True)]
    pts = None
    if surface_points:
        flat = _flatten_points(surface_points)
        pts = [(p[0], p[1], p[2] if len(p) > 2 else 0.0) for p in flat]
    return bd.Face.make_surface(exterior, surface_points=pts)


def intersection(*shapes):
    """CSG intersection of two or more B-rep shapes (the `&` operator)."""
    _require_build123d()
    shapes = _flatten(shapes)
    if len(shapes) == 0:
        raise ValueError("intersection(): need at least one shape")
    out = shapes[0]
    for s in shapes[1:]:
        out = out & s
    return out


def sample_curve(shape, n):
    """
    `n` evenly-parametrized points along a Wire/Edge (or a filled
    Face's own boundary wire, pulled out automatically -- same "grab
    the outline" step sweep_sec2path()/p_line3d() use internally) --
    the general-purpose way to turn a real curve into a plain point
    list, for when to_points() isn't enough: to_points() only grabs
    each EDGE's own START point, so a Wire made of few but long/curved
    edges (an intersection() result, most commonly -- often just ONE
    single curved edge) comes back as far too few points from
    to_points() to be useful as a station list. sample_curve() instead
    walks the WHOLE wire's own combined parametrization evenly,
    regardless of how many edges it's actually built from.

    Reach for this whenever you need a real curve (an intersection()
    result, an arc_edge(), any Wire/Edge) as a point list for one of
    brep.py's point-list functions -- convert_3lines2fillet()'s own
    spine/line_a/line_b, most commonly:

        curve = intersection(a, b)
        pts = sample_curve(curve, 40)

    UNVERIFIED against a real build123d install (see module
    docstring) -- Wire.position_at(t) is expected to parametrize
    evenly by ARC LENGTH across the whole wire (t=0.5 landing on the
    true geometric midpoint) rather than by the wire's raw underlying
    parameter space (which could bunch points unevenly if the wire's
    edges have very different natural parameter ranges); if station
    spacing looks uneven in practice, that assumption is what to
    revisit here.
    """
    _require_build123d()
    wire = _as_path_wire(shape, "sample_curve")
    n = int(n)
    if n < 2:
        raise ValueError("sample_curve(): need at least 2 points")
    pts = []
    for i in range(n):
        t = i / (n - 1)
        p = wire.position_at(t)
        pts.append([float(p.X), float(p.Y), float(p.Z)])
    return pts


def hull(*shapes):
    """
    The convex hull enclosing all the given shapes -- real B-rep, built
    from build123d's own ConvexPolyhedron (which computes the hull of a
    point cloud itself; there's no need to compute hull faces here).

    Every shape is tessellated first (to_mesh(), default tolerance) and
    every triangle vertex from all of them is fed into the hull
    together. For a shape made only of flat faces (box(), a union() of
    boxes, etc), tessellating doesn't add or move any true corner --
    triangulating a flat face just adds a diagonal across it -- so the
    result is exact. For a shape with curved faces (cylinder(),
    sphere(), a fillet()ed edge), it's only an approximation, accurate
    to roughly that default tessellation tolerance -- tessellate the
    shape yourself first with a tighter to_mesh(shape, tolerance=...)
    and pass the resulting points through bd.ConvexPolyhedron directly
    if you need closer than that.
    """
    _require_build123d()
    shapes = _flatten(shapes)
    if len(shapes) == 0:
        raise ValueError("hull(): need at least one shape")
    all_points = []
    for s in shapes:
        v, _f = to_mesh(s)
        all_points.extend(tuple(p) for p in v)
    if not all_points:
        raise ValueError("hull(): no points found on any given shape")
    return bd.ConvexPolyhedron(all_points)


def fillet(shape, edges, radius):
    """
    Rounds `edges` of `shape` with the given radius -- a real, exact
    B-rep fillet (a genuine curved/cylindrical blend surface computed by
    OCCT), not a faceted approximation built out of extra geometry the
    way OpenSCAD scripts usually fake a fillet (e.g. unioning in a
    rotate_extrude()'d quarter-circle profile, or minkowski() with a
    sphere).

    `edges` is a selection of edges FROM `shape` itself -- most simply
    `shape.edges()` for every edge (real build123d Shape objects, which
    is what box()/cylinder()/union()/etc all return here, have this
    method directly), or narrowed down first, e.g.
    `shape.edges().filter_by(Axis.Z)` for only the vertical ones (needs
    `from build123d import Axis`), or `shape.edges().sort_by(Axis.Z)[-4:]`
    for just the top 4. See build123d's own docs for the full edge-
    selector API -- brep.py doesn't wrap that part, `shape` is a real
    build123d object so its own methods are already there to use
    directly.

    `edges` can also be a single bare Edge (not wrapped in a list) --
    e.g. `fillet(a, a.edges()[3], 2)` works the same as
    `fillet(a, [a.edges()[3]], 2)` -- same convenience as
    show_edges()/label_edges().

    Example:
        a = cube([20,20,20])
        rounded = fillet(a, a.edges(), 3)

    If `radius` is too big for the local geometry at one of `edges`
    (blend surfaces from adjacent edges would collide/overlap), OCCT
    raises "Failed creating a fillet with radius of X" -- a real
    geometric limit, not a bug: some edges in your selection just can't
    take that big a rounding given how close they are to other
    features. Try a smaller radius, fillet a smaller edge subset at a
    time, or call max_fillet_radius(shape, edges) first to get the
    largest radius that actually works for that exact selection.

    UNVERIFIED against a real build123d install, same caveat as the
    rest of this file (see module docstring) -- fillet()/chamfer() are
    thin passthroughs to build123d's own top-level fillet()/chamfer()
    functions, so if something's wrong here it's most likely just the
    argument order/names, not the underlying operation.
    """
    _require_build123d()
    try:
        edge_list = list(edges)
    except TypeError:
        edge_list = [edges]
    try:
        return bd.fillet(edge_list, radius)
    except Exception as exc:
        raise ValueError(
            f"fillet(): radius {radius} doesn't fit at (at least) one of the "
            f"selected edges ({exc}). This is a real geometric limit -- the "
            f"blend surface at that radius would collide with a neighboring "
            f"face/edge -- not a bug. Try a smaller radius, split `edges` into "
            f"smaller groups to isolate which one is the problem, or call "
            f"max_fillet_radius(shape, edges) to get the largest radius that "
            f"actually works for this exact selection."
        ) from exc


def max_fillet_radius(shape, edges, tolerance=0.1, max_iterations=10):
    """
    The largest radius that fillet(shape, edges, radius) will actually
    succeed with, for this exact `shape`/`edges` selection -- a thin
    wrapper around build123d's own Shape.max_fillet() (a binary search
    over candidate radii, each checked by actually attempting the
    fillet). Directly answers the question fillet()'s own error message
    points you at ("...try a smaller value or use max_fillet() to find
    the largest valid fillet radius") without you having to guess-and-
    check radii by hand:

        edges = [c.edges()[i] for i in [-4,-8,-9,-10,-11,-12]]
        r = max_fillet_radius(c, edges)
        show(fillet(c, edges, r))

    `tolerance`/`max_iterations` control the binary search's precision
    and effort, same meaning as build123d's own parameters -- the
    defaults are usually fine, but see the important caveat below for
    models with small features relative to their overall size.

    IMPORTANT (verified against build123d's own max_fillet() source):
    the binary search's STARTING window is always (0, 2 * shape's own
    overall bounding_box().diagonal) -- the whole model's size, not
    anything related to the specific edges/feature you're testing. On
    a model where the actual achievable radius is small relative to
    the whole shape (a thin wall on a much bigger part, e.g. a 2mm
    wall on an 80mm-tall tube), the search can spend most/all of its
    max_iterations budget just narrowing that huge starting window
    down into the right neighborhood, and run out before ever
    converging -- reporting "couldn't find ANY radius" even though a
    real small radius likely DOES exist, it just wasn't found in time.
    This is a genuine false negative, not proof of unfilletability --
    raising max_iterations well above the default (e.g. 30-40) CAN and
    often does fix this, and is the first thing to try before
    concluding an edge is really unfilletable:

        max_fillet_radius(shape, edges, max_iterations=40)

    If THAT still raises "Failed to find the max value within
    <tolerance> in <max_iterations>", NOW it's more likely a genuinely
    different, more fundamental problem: at least one edge in your
    selection can't be filleted no matter how small the radius is --
    not "1 was too big", but "this particular edge is unfilletable" (a
    seam edge on a periodic/cylindrical surface, or an edge at a vertex
    where too many filleted faces would need to meet, are the two most
    common real causes). The fix at that point is to find out WHICH
    edge in the group is the problem by testing them one at a time
    (still with a generous max_iterations):

        edges = [c.edges()[i] for i in [-4,-8,-9,-10,-11,-12]]
        for i, e in enumerate(edges):
            try:
                print(i, max_fillet_radius(c, [e]))
            except Exception as exc:
                print(i, "UNFILLETABLE:", exc)

    then drop whichever index(es) print UNFILLETABLE from the group (or
    fillet them separately with chamfer() or a different radius/edge
    choice instead).

    `edges` can also be a single bare Edge (not wrapped in a list) --
    e.g. `max_fillet_radius(shape, e)` works the same as
    `max_fillet_radius(shape, [e])`, so a per-edge testing loop like the
    one above doesn't need to wrap each `e` itself -- same convenience
    as fillet()/show_edges()/label_edges(). (Forgetting this wrapping
    used to surface as a confusing "'Edge' object is not iterable"
    buried inside the generic "couldn't find ANY radius" message below
    -- a plain Python usage error masquerading as a geometric one; now
    it just works instead.)
    """
    _require_build123d()
    try:
        edge_list = list(edges)
    except TypeError:
        edge_list = [edges]
    try:
        return shape.max_fillet(edge_list, tolerance=float(tolerance), max_iterations=int(max_iterations))
    except Exception as exc:
        raise RuntimeError(
            f"max_fillet_radius(): couldn't find ANY radius that works for this "
            f"edge group within {max_iterations} iterations ({exc}). The search "
            f"always starts from a window sized off the WHOLE shape's own "
            f"bounding_box().diagonal, not the local feature -- so on a small "
            f"feature (a thin wall, a small fillet) on a much bigger overall "
            f"shape, it can genuinely run out of iterations before converging, "
            f"even though a real small radius exists. TRY A BIGGER "
            f"max_iterations FIRST (e.g. max_fillet_radius(shape, edges, "
            f"max_iterations=40)) before concluding the edge is really "
            f"unfilletable. If a generous max_iterations STILL fails, then it's "
            f"more likely a genuine geometric dead end -- at least one edge in "
            f"the selection can't be filleted at all (a seam edge, or a vertex "
            f"where too many fillets would need to meet). Test the edges one at "
            f"a time (still with a generous max_iterations) with "
            f"max_fillet_radius(shape, e, max_iterations=40) for each e to find "
            f"out which one is the problem -- see this function's own docstring "
            f"for the exact snippet."
        ) from exc


def chamfer(shape, edges, length):
    """
    Bevels `edges` of `shape` by `length` -- a real, exact B-rep
    chamfer, same idea as fillet() above but a flat angled cut instead
    of a rounded one. See fillet()'s docstring for how to select
    `edges` (e.g. `shape.edges()` for all of them) -- `edges` can also
    be a single bare Edge, same convenience as fillet().
    """
    _require_build123d()
    try:
        edge_list = list(edges)
    except TypeError:
        edge_list = [edges]
    return bd.chamfer(edge_list, length)


def show_edges(edges, radius=0.3, samples=12):
    """
    Turns an edge selection into a visible "beaded string" of small
    spheres following each edge's own curve (straight or curved -- e.g.
    a cylinder's round rim comes out as a curved string of beads, not a
    straight line between its endpoints) -- a debug/visualization aid
    for confirming EXACTLY which edges a selector expression picked out
    (see fillet()'s docstring for selector examples) before actually
    handing them to fillet()/chamfer(). The viewer has no click-to-
    identify-a-B-rep-edge tool yet (its picking tool works on the
    tessellated display mesh, not the exact underlying topology), so
    this is the practical way to check a selection visually in the
    meantime: show it alongside your real model in a different color.

        edges = a.edges().filter_by(Axis.Z)
        show(a, alpha=0.3)                    # the model, faded
        show(show_edges(edges), c="red")      # just the selected edges, highlighted
        # once the highlighted edges look right:
        r = fillet(a, edges, 3)

    `edges` is exactly what you'd pass to fillet()/chamfer() -- e.g.
    a.edges(), or a filtered/sorted/sliced selection of it.

    `radius` controls how thick the beads are -- there's no automatic
    scaling to your model's size, so adjust it by hand for a very large
    or very small model (the default (0.3) is a reasonable starting
    point for a model with dimensions in the tens, not hundreds or
    fractions of a unit). `samples` is how many points are sampled
    along each edge's own curve (more = a smoother-looking curve for a
    rounded edge, at the cost of more spheres -- doesn't affect a
    straight edge's appearance either way).
    """
    _require_build123d()
    try:
        edge_list = list(edges)
    except TypeError:
        # a single bare Edge (e.g. edges[3], not a slice) isn't
        # iterable itself -- treat it as a one-edge selection instead
        # of erroring, so show_edges(edges[3]) works same as
        # show_edges(edges[3:4]) or show_edges([edges[3]]).
        edge_list = [edges]
    if not edge_list:
        raise ValueError("show_edges(): no edges given (empty selection)")
    n = max(2, int(samples))
    beads = []
    for e in edge_list:
        for i in range(n + 1):
            t = i / n
            p = e.position_at(t)
            beads.append(bd.Pos(float(p.X), float(p.Y), float(p.Z)) * bd.Sphere(radius))
    out = beads[0]
    for b in beads[1:]:
        out = out + b
    return out


def label_edges(edges, text_size=1, h=0.1):
    """
    Labels each edge in `edges` with its own index (0, 1, 2, ...) as
    small flat text at that edge's midpoint -- the edge-selection
    counterpart of track_points() (same idea, indices instead of point
    numbers), for exactly the workflow fillet()'s/max_fillet_radius()'s
    own docstrings point at: figuring out which index(es) into
    shape.edges() are the ones you actually want, before calling
    fillet(shape, [shape.edges()[i] for i in [...]], radius) -- no more
    guessing indices blind or filleting the whole shape to see what
    happens.

    Pass the SAME list you'd index into for fillet()/chamfer() --
    almost always shape.edges() itself, unfiltered, so the numbers
    shown line up with shape.edges()[i]:

        a = cube([20, 20, 20])
        show(a, alpha=0.2)
        show(label_edges(a.edges()), 'red')
        # read the indices you want off the viewer, then:
        show(fillet(a, [a.edges()[i] for i in [3, 7, 11]], 2))

    If you pass an already-filtered/sorted/sliced selection instead
    (e.g. a.edges().filter_by(Axis.Z)), the numbers are just that
    selection's own 0-based position in the order given -- NOT the
    original shape.edges() index -- so that's only useful once you've
    already narrowed a group down and want to double check which ones
    ended up in it, not for picking indices back out of the full
    shape.edges() list.

    `text_size`/`h` control the label size/thickness, same meaning as
    track_points()'s own parameters -- there's no automatic scaling to
    your model's size, adjust by hand. Combine with show_edges(edges)
    to see the actual edge curves highlighted alongside the numbers:

        show(show_edges(a.edges()), 'blue')
        show(label_edges(a.edges()), 'red')
    """
    _require_build123d()
    try:
        edge_list = list(edges)
    except TypeError:
        # a single bare Edge isn't iterable itself -- same convenience
        # as show_edges() above.
        edge_list = [edges]
    if not edge_list:
        raise ValueError("label_edges(): no edges given (empty selection)")
    labels = []
    for i, e in enumerate(edge_list):
        p = e.position_at(0.5)
        labels.append(bd.Pos(float(p.X), float(p.Y), float(p.Z))
                       * text(str(i), size=text_size, h=h, center=True))
    return bd.Compound(labels)


def label_faces(faces, text_size=1, h=0.1):
    """
    Labels each face in `faces` with its own index (0, 1, 2, ...) as
    small flat text at that face's own center -- label_edges()'s
    counterpart for face selectors, for the exact same workflow: figure
    out which index(es) into shape.faces() are the ones you want before
    handing them to something that takes a face selection (e.g. an
    offset()'s `openings=` argument, or picking a face to build a
    workplane/sketch on) instead of guessing blind.

    Pass the SAME list you'd index into afterward -- almost always
    shape.faces() itself, unfiltered, so the numbers shown line up with
    shape.faces()[i]:

        a = cube([20, 20, 20])
        show(a, alpha=0.2)
        show(label_faces(a.faces()), 'red')
        # read the index you want off the viewer, then e.g.:
        hollow = offset(a, -2, openings=[a.faces()[i] for i in [4]])

    If you pass an already-filtered/sorted/sliced selection instead
    (e.g. a.faces().sort_by(Axis.Z)[-1:]), the numbers are just that
    selection's own 0-based position in the order given -- NOT the
    original shape.faces() index -- same caveat as label_edges().

    `text_size`/`h` control the label size/thickness, same meaning as
    label_edges()'s/track_points()'s own parameters -- no automatic
    scaling to your model's size, adjust by hand.
    """
    _require_build123d()
    try:
        face_list = list(faces)
    except TypeError:
        # a single bare Face isn't iterable itself -- same convenience
        # as label_edges()/show_edges() above.
        face_list = [faces]
    if not face_list:
        raise ValueError("label_faces(): no faces given (empty selection)")
    labels = []
    for i, f in enumerate(face_list):
        p = f.center()
        labels.append(bd.Pos(float(p.X), float(p.Y), float(p.Z))
                       * text(str(i), size=text_size, h=h, center=True))
    return bd.Compound(labels)


def edges_in_box(edges, box, mode="inside", tolerance=1e-6):
    """
    Picks edges by drawing a probe box around/through them, instead of
    reading indices off label_edges()'s numbers -- build, position, and
    size any shape (almost always just box([dx, dy, dz]), translate()'d/
    rotate()'d into place) around the region you want, pass it in as
    `box`, and get back exactly the edges that fall inside or cross it.
    Only `box`'s own bounding_box() is used -- its actual geometry never
    matters, so a plain axis-aligned box() is normally enough even to
    isolate edges on a tilted/curved shape.

    `mode`:
      "inside"   -- (default) only edges FULLY CONTAINED in the probe
                    box's extent -- draw a box that ENCLOSES just the
                    edges you want and nothing else.
      "crossing" -- edges whose own bounding box overlaps the probe box
                    AT ALL, including ones only partly inside it -- draw
                    a (usually thin) box that CUTS THROUGH the edges you
                    want, even if it doesn't fully contain them.

        a = cube([20, 20, 20])
        show(a, alpha=0.2)
        probe = translate([-10, -10, 8], box([20, 20, 4]))
        show(probe, alpha=0.15, color='red')  # eyeball/adjust probe first
        picked = edges_in_box(a.edges(), probe)
        show(sol := fillet(a, picked, 1))

    Pass the SAME list you'd index into for fillet()/chamfer() --
    almost always shape.edges() itself, unfiltered -- and the returned
    list is already the plain list of Edge objects fillet()/chamfer()
    expect, no further indexing needed. Combine with the other
    filter_by()/sort_by()/label_edges() techniques as needed -- e.g.
    `edges_in_box(a.edges(), probe, mode="crossing")` still returns a
    real ShapeList-friendly list, so
    `[e for e in edges_in_box(...) if e.length > 5]` works fine on top.
    """
    _require_build123d()
    try:
        edge_list = list(edges)
    except TypeError:
        edge_list = [edges]
    ref = box.bounding_box() if hasattr(box, "bounding_box") else box
    if mode == "inside":
        def _keep(e):
            eb = e.bounding_box()
            return (
                eb.min.X >= ref.min.X - tolerance and eb.max.X <= ref.max.X + tolerance
                and eb.min.Y >= ref.min.Y - tolerance and eb.max.Y <= ref.max.Y + tolerance
                and eb.min.Z >= ref.min.Z - tolerance and eb.max.Z <= ref.max.Z + tolerance
            )
    elif mode == "crossing":
        def _keep(e):
            return ref.overlaps(e.bounding_box(), tolerance=tolerance)
    else:
        raise ValueError(
            f"edges_in_box(): mode must be 'inside' or 'crossing', got {mode!r}")
    return [e for e in edge_list if _keep(e)]


def faces_in_box(faces, box, mode="inside", tolerance=1e-6):
    """
    faces_in_box()'s own counterpart for face selectors -- the exact
    same probe-box picking workflow as edges_in_box(), but for
    shape.faces() instead of shape.edges(). Useful for things like
    offset()'s `openings=` argument or picking which faces to fillet()/
    chamfer() by drawing a box around/through them instead of reading
    label_faces()'s numbers.

    `box`: any B-rep shape (usually box([dx, dy, dz]), translate()'d/
    rotate()'d into place) -- only its own bounding_box() is used, its
    actual geometry never matters.

    `mode`:
      "inside"   -- (default) only faces FULLY CONTAINED in the probe
                    box's extent -- draw a box that ENCLOSES just the
                    faces you want and nothing else.
      "crossing" -- faces whose own bounding box overlaps the probe box
                    AT ALL, including ones only partly inside it -- draw
                    a (usually thin) box that CUTS THROUGH the faces you
                    want, even if it doesn't fully contain them.

        a = cube([20, 20, 20])
        show(a, alpha=0.2)
        probe = translate([-10, -10, 18], box([20, 20, 4]))
        show(probe, 'red', alpha=0.15)  # eyeball/adjust probe first
        top_face = faces_in_box(a.faces(), probe)
        hollow = offset(a, -2, openings=top_face)

    Pass the SAME list you'd index into for offset()/fillet()/chamfer()
    -- almost always shape.faces() itself, unfiltered -- and the
    returned list is already the plain list of Face objects those
    functions expect, no further indexing needed. Combine with the
    other filter_by()/sort_by()/label_faces() techniques as needed --
    e.g. `[f for f in faces_in_box(...) if f.area > 50]` works fine on
    top of this.
    """
    _require_build123d()
    try:
        face_list = list(faces)
    except TypeError:
        face_list = [faces]
    ref = box.bounding_box() if hasattr(box, "bounding_box") else box
    if mode == "inside":
        def _keep(f):
            fb = f.bounding_box()
            return (
                fb.min.X >= ref.min.X - tolerance and fb.max.X <= ref.max.X + tolerance
                and fb.min.Y >= ref.min.Y - tolerance and fb.max.Y <= ref.max.Y + tolerance
                and fb.min.Z >= ref.min.Z - tolerance and fb.max.Z <= ref.max.Z + tolerance
            )
    elif mode == "crossing":
        def _keep(f):
            return ref.overlaps(f.bounding_box(), tolerance=tolerance)
    else:
        raise ValueError(
            f"faces_in_box(): mode must be 'inside' or 'crossing', got {mode!r}")
    return [f for f in face_list if _keep(f)]


def text(txt, size=10, h=1, font="Arial", center=False):
    """
    A real, extruded 3D text solid -- build123d's own native Text()
    (real glyph outlines rendered from an installed system font, not
    a flat placeholder), pre-extruded by `h` in one call, the same
    convenience real OpenSCAD's own text()+linear_extrude() two-step
    idiom gives you. openscad4.py never had a real text() of its own
    (its own text()/fo() only ever emitted raw OpenSCAD source, for
    OpenSCAD itself to render later) -- this is a genuine new
    primitive here, not a line-for-line port.

    `size` is the font size (roughly the cap height, in model units).
    `center=False` (default) leaves the text's own baseline-left
    origin at [0,0,0] (matches real OpenSCAD's text() default
    halign="left"/valign="baseline"); `center=True` centers the text
    on the origin on both axes instead -- handy for labels you're
    about to position by their own middle (see track_points() below).

    Needs a font actually installed wherever this runs -- `font`
    defaults to "Arial", which may not exist on every system
    (especially Linux); pass a font name that IS installed there
    instead if you hit a missing-font error.

    `h<=0` skips the extrude step entirely and returns the flat 2D
    text sketch instead (a real Face per glyph, not a solid) -- the
    real per-label cost here is rendering the font glyphs themselves
    (bd.Text()), not the extrude on top, but skipping the extrude
    still saves a real operation per call, which matters if you're
    calling text() many times (see track_points()'s own perf note).
    Still union()/translate()/etc-able like any other Shape either way.

        show(translate([0, 0, 0], text("Hello", size=10, h=2)))
    """
    _require_build123d()
    align = (bd.Align.CENTER, bd.Align.CENTER) if center else None
    sketch = bd.Text(str(txt), float(size), font=str(font), align=align)
    if h <= 0:
        return sketch
    return linear_extrude(sketch, h=float(h))


def points(pts, d=0.5, shape="cube"):
    """
    Marker geometry at each point in `pts` (a flat list of 2D or 3D
    points) -- openscad4.py's own points() module, ported: a small
    cube (or sphere) of size `d` at every point, unioned into one
    shape, so you can show() a raw point list (turtle2d()/turtle3d()'s
    output, a bezier()/bspline_closed() control polygon, anything) to
    see exactly where its points land -- the same debugging role
    show_edges() plays for a real B-rep edge selection, but for plain
    point lists that never became a shape at all.

        ctrl = [[0, 0], [5, 15], [15, 15], [20, 0]]
        show(points(ctrl, 1), c="red")   # where are the control points?
        show(linear_extrude(polygon(bezier(ctrl, 30)), h=2))

    `shape` is `"cube"` (default, matches openscad4.py's own points()
    exactly) or `"sphere"`. 2D points are placed at z=0.

    REAL PERFORMANCE NOTE: markers are grouped with a lightweight
    Compound() rather than union()'d together -- for a big point list
    (a densely-sampled cr2dt()/bezier()/etc curve, say), union()ing
    every marker one at a time is the same real O(N) chained-boolean
    cost documented in p_line3d()'s own docstring, and completely
    unnecessary here: these markers are disjoint, disposable debug
    dots that never need to be a single watertight solid, so a real
    boolean fuse between them is pure wasted CSG work. Compound()
    just groups them for display/export with no solving at all.
    """
    _require_build123d()
    pt_list = _flatten_points(pts)
    if not pt_list:
        raise ValueError("points(): need at least one point")
    key = str(shape).lower()
    if key not in ("cube", "sphere"):
        raise ValueError(f"points(): shape must be 'cube' or 'sphere', got {shape!r}")
    markers = []
    for p in pt_list:
        x, y, z = p[0], p[1], (p[2] if len(p) > 2 else 0.0)
        marker = cube(d, center=True) if key == "cube" else sphere(d / 2)
        markers.append(bd.Pos(x, y, z) * marker)
    return bd.Compound(markers)


def line3d(points, d=0.5, closed=False):
    """
    A polyline made of small real cylinder segments (diameter `d`)
    connecting each consecutive point in `points` -- a lightweight,
    genuinely different construction from p_line3d()/sweep_sec2path()
    (no sweep() call at all, and no rounded end caps): one plain
    bd.Cylinder primitive per segment, oriented with a real build123d
    Plane (the same origin/z_dir trick sweep_sec2path()/
    surface_line_vector() use internally to orient a cross-section
    along a direction), grouped with bd.Compound() -- the same "don't
    union disjoint debug geometry" trick points()/show_edges() already
    use (a real boolean fuse between segments would be pure wasted CSG
    work for something that's just meant to be looked at).

    The point-list sibling of show_edges() (which does the same job
    for a real Shape's edge selection, not a raw point list) -- handy
    for a quick, cheap look at ANY point list (sinewave()/cosinewave()/
    rot_p()'s output, cr3dt()'s output, a bezier() control path, l1/l2
    before combining them with surface_from_2_waves(), etc) without
    the tessellate()-only-works-on-Faces limitation a bare
    Edge/Wire (e.g. bd.Polyline(*points) on its own) would hit trying
    to show() it directly:

        l1 = rot_p('x90', sinewave(60, 3, 8, 60))
        l2 = rot_p('x90z90', cosinewave(60, 3, 8, 60))
        show(line3d(l1, 0.3), 'blue')
        show(line3d(l2, 0.3), 'magenta')

    `closed=True` also connects the last point back to the first (same
    closed_loop convention as turtle3d()/p_line3d()/sweep_sec2path()).
    2D points are placed at z=0.
    """
    _require_build123d()
    pts = _flatten_points(points)
    if len(pts) < 2:
        raise ValueError("line3d(): need at least 2 points")
    pts3 = [(p[0], p[1], p[2] if len(p) > 2 else 0.0) for p in pts]
    pairs = list(zip(pts3, pts3[1:]))
    if closed:
        pairs.append((pts3[-1], pts3[0]))
    align = _align_radial(False)
    segs = []
    for p0, p1 in pairs:
        v = tuple(b - a for a, b in zip(p0, p1))
        length = math.sqrt(sum(c * c for c in v))
        if length < 1e-9:
            continue
        segs.append(bd.Plane(origin=p0, z_dir=v) * bd.Cylinder(d / 2, length, align=align))
    if not segs:
        raise ValueError("line3d(): all consecutive points coincide")
    return bd.Compound(segs)


def track_points(line, text_size=1, h=0.1, step=1):
    """
    Labels each point in `line` with its own index number (0, 1, 2,
    ...) as small real 3D text -- openscad4.py's own track_points(),
    ported: the original generated raw OpenSCAD source text() calls,
    only usable through fo(); this returns one real, already-
    positioned Shape (every digit label grouped together) you
    show()/color() directly, no text-code step needed. Handy for
    figuring out which index in a point list corresponds to which
    point when debugging a curve/path/profile -- the numeric sibling
    of points() above (which just marks each point, without saying
    which is which).

        pts = bezier([[0, 0], [5, 15], [15, 15], [20, 0]], 8)
        show(color(polygon(pts), "lightgray", alpha=0.3))
        show(track_points(pts, text_size=1.5), "blue")

    `text_size`/`h` are passed straight through to text() (font size,
    extrusion height). No text_color parameter here (unlike the
    original) -- same convention as points() above: pass a color to
    show()/color() yourself when you actually display the result.

    REAL PERFORMANCE NOTE: rendering N real text labels is N real
    font-render-and-extrude operations no matter how the results get
    grouped afterward -- Compound() (used here instead of union(),
    see below) only removes an EXTRA, unnecessary cost on top of
    that, not this one. For a path with many points (a densely-
    sampled cr2dt() outline, say), the label count itself is usually
    the real bottleneck, so two direct levers:
      `step` (default 1, every point) -- e.g. step=5 labels only
        every 5th point, cutting the label count (and cost) by 5x.
        Each label still shows its point's TRUE index in `line`, not
        a renumbered 0,1,2,... count, so it stays meaningful even
        skipped.
      `h=0` -- skips the extrude step per label (see text()'s own
        note), rendering flat labels instead of solids -- meaningful
        savings if you don't need solid/printable labels, just
        something to look at.
    Labels are grouped with a lightweight Compound() rather than
    union()'d together regardless -- these are disjoint, disposable
    debug labels that never need to be one watertight solid, so a
    real boolean fuse between them (the O(N) chained-boolean cost
    documented in p_line3d()'s own docstring) was pure wasted CSG
    work on top of whatever building each label itself costs.
    """
    _require_build123d()
    pts = _flatten_points(line)
    if not pts:
        raise ValueError("track_points(): need at least one point")
    stride = max(1, int(step))
    labels = []
    for i in range(0, len(pts), stride):
        p = pts[i]
        x, y, z = p[0], p[1], (p[2] if len(p) > 2 else 0.0)
        labels.append(bd.Pos(x, y, z) * text(str(i), size=text_size, h=h, center=True))
    return bd.Compound(labels)


def p_line3d(path, d=1, closed=0, transition="round"):
    """
    A tube/rope of diameter `d` following `path`, real B-rep --
    openscad4.py's own p_line3d()/p_line3dc() modules, ported. Handy
    for turning a bare 3D point list (turtle3d()'s output, cr3dt()'s
    output, any hand-built polyline) straight into a real solid you
    can show() directly, without setting up sweep_sec2path()'s 2D-
    section-and-path call yourself -- e.g. a quick tube/wireframe-
    style rendering of a 3D path, or an actual rope/cable model.
    `closed=1` also connects the last point back to the first
    (openscad4.py's separate p_line3dc()) -- same closed_loop
    convention as turtle3d()/sweep_sec2path().

    `path` can also be a real Shape instead of a raw point list -- a
    Wire/Edge (e.g. arc_edge(), or a Face's own `.wires()[0]`), or a
    filled 2D shape like polygon()/circle()/cr2dt()+polygon()'s output
    (its boundary outline is traced automatically, same "pull the
    outline out of a filled Face" step sweep_sec2path() already does
    for a Shape path3d -- see _as_path_wire()). A genuinely closed
    Shape (a closed Wire, or a filled Face's boundary -- polygon()'s
    output, say) skips the end caps automatically, the same as
    `closed=1` does for a raw point list, since there's no open end to
    round off either way.

    REAL PERFORMANCE FIX: this used to build a capsule (hull() of two
    spheres, or two cubes with rec=1 -- that parameter's gone now, see
    below) for EVERY consecutive pair of points, then union() them all
    together -- one hull() plus one boolean per segment, chained. That
    was a real user-reported slowdown: unioning N solids one at a time
    is O(N) booleans, each re-solving against the whole accumulated
    result so far, and a path with even a few dozen points made this
    genuinely slow. Now it's ONE sweep_sec2path() call along the whole
    path plus 2 small sphere() caps unioned on at the very ends --
    same rounded-tube-with-rounded-ends look, a handful of real B-rep
    operations total instead of one per segment (the exact fix applied
    by hand in examples/21_drill_bit.py before it was folded back into
    this function directly).

    No more `rec` (square vs round caps) -- a round tube with round
    end-caps is what this function is actually for now; if you
    specifically want flat/square caps instead, call
    sweep_sec2path(square(d, center=True), path) yourself.

    `transition` is passed straight through to sweep_sec2path() (see
    its own docstring for what it does) -- "round" (the default) is
    fine for most paths, but a path with many points and/or tight,
    sharp turns relative to `d` can hit the same fragility any long
    multi-segment sweep can (see examples/20_3d_knots.py for the full
    story on that failure mode) -- try "right_corner" or "transformed"
    if you hit it here too. CONFIRMED via a real user report: a
    many-point, non-planar path (e.g. axis_rot_1_pts()-bent) with the
    default "round" raised `AttributeError: 'NoneType' object has no
    attribute 'NbNodes'` -- a real OCCT/OCP error in "round"'s per-
    corner fillet construction -- and transition="right_corner" fixed
    it. If you see that exact error, this is almost certainly why.

    `closed=1` skips the end caps entirely (there's no exposed end
    left to round off once the loop connects back to itself) -- just
    the one sweep, closed all the way around.
    """
    _require_build123d()
    r = float(d) / 2

    if isinstance(path, bd.Shape):
        path_wire = _as_path_wire(path, "p_line3d")
        tube = sweep_sec2path(circle(r), path_wire, transition=transition)
        if closed or getattr(path_wire, "is_closed", False):
            return tube
        start, end = path_wire.position_at(0), path_wire.position_at(1)
        caps = union(bd.Pos(start.X, start.Y, start.Z) * sphere(r),
                     bd.Pos(end.X, end.Y, end.Z) * sphere(r))
        return union(tube, caps)

    pts = _flatten_points(path)
    if len(pts) < 2:
        raise ValueError("p_line3d(): path needs at least 2 points")
    pts = [(p[0], p[1], p[2] if len(p) > 2 else 0.0) for p in pts]
    if closed:
        return sweep_sec2path(circle(r), pts + [pts[0]], transition=transition)
    tube = sweep_sec2path(circle(r), pts, transition=transition)
    caps = union(bd.Pos(*pts[0]) * sphere(r), bd.Pos(*pts[-1]) * sphere(r))
    return union(tube, caps)


# ---------------------------------------------------------------------------
# A second batch of openscad4.py ports: plane(), sinewave()/cosinewave(),
# loft(), helix(), interp_spline(), s_int1(), project_curve_on_face(),
# tangent_arc(). Same spirit as the core toolkit above -- reimplemented
# against documented behavior, preferring a real build123d native
# operation wherever one exists (loft/Helix/Spline/ConstrainedArcs/
# project all replace what was hand-rolled point-list math in the mesh
# version) rather than a line-for-line port. concave_hull() was
# attempted and DROPPED -- a naive nearest-neighbor nearest-angle walk
# turned out to be genuinely unreliable at correctly tracing a concave
# boundary (verified wrong on a simple L-shaped test case), and getting
# it right needs more careful work than this batch had room for. A few
# other openscad4.py mesh-only helpers in this same family
# (wrap_around(), prism(), o_solid(), swp_prism_h(), h_lines_sec(),
# surround(), honeycomb()) were also deliberately left out to focus on
# the functions that map onto genuinely new B-rep capability -- ask if
# you want those next.
# ---------------------------------------------------------------------------

def plane(normal, size=(100, 100), intercept=(0, 0, 0)):
    """
    A flat rectangular Face of the given `size` ([width, height]), lying
    in the plane through `intercept` with the given `normal` -- e.g.
    plane([1,0,0]) is a rectangle in the YZ plane; plane([0,0,1]) is a
    rectangle in the XY plane. openscad4.py's own plane(), ported --
    real B-rep, build123d's own Plane+Rectangle rather than the
    hand-built surface-from-2-vectors construction the mesh version
    needed. Mostly useful as a visual reference plane, or as the
    `target` for project_curve_on_face()/a cutting tool for split()-
    style operations you build yourself with build123d's own Shape
    methods.
    """
    _require_build123d()
    if isinstance(size, (int, float)):
        w = h = float(size)
    else:
        w, h = float(size[0]), float(size[1])
    n = tuple(float(c) for c in normal)
    p = bd.Plane(origin=tuple(float(c) for c in intercept), z_dir=n)
    return p * bd.Rectangle(w, h)


def sinewave(length, cycles, amplitude, n):
    """
    A 2D point list tracing a sine wave: x runs 0 to `length`, y =
    `amplitude` * sin(2*pi*`cycles`*x/`length`), sampled at `n` points.
    openscad4.py's own sinewave(), ported. Feed it to polygon()/
    linear_extrude(), or wrap it into 3D yourself (translate/rotate)
    for a rippled profile.
    """
    l, n_cyc, a, p = float(length), float(cycles), float(amplitude), int(n)
    return [
        [x, a * math.sin(2 * math.pi * n_cyc * x / l)]
        for x in [l * i / (p - 1) for i in range(p)]
    ]


def cosinewave(length, cycles, amplitude, n):
    """Same as sinewave() but starting at the wave's peak (cosine phase)
    instead of zero -- openscad4.py's own cosinewave(), ported."""
    l, n_cyc, a, p = float(length), float(cycles), float(amplitude), int(n)
    return [
        [x, a * math.cos(2 * math.pi * n_cyc * x / l)]
        for x in [l * i / (p - 1) for i in range(p)]
    ]


def honeycomb(r, n1, n2):
    """
    A hex grid of `n1` x `n2` regular hexagons of "radius" `r` (center
    to vertex) -- openscad4.py's own honeycomb(), reimplemented as
    plain hex-grid math: returns a list of hexagons, each a closed
    6-point 2D loop, ready for `[polygon(h) for h in honeycomb(...)]`
    or filtering with point_in_polygon().
    """
    r, n1, n2 = float(r), int(n1), int(n2)
    dx = 1.5 * r
    dy = r * math.sqrt(3)
    hexes = []
    for col in range(n1):
        cx = col * dx
        cy0 = (dy / 2) if col % 2 else 0.0
        for row in range(n2):
            cy = cy0 + row * dy
            hexes.append([
                [cx + r * math.cos(math.radians(60 * i)), cy + r * math.sin(math.radians(60 * i))]
                for i in range(6)
            ])
    return hexes


def point_in_polygon(point, poly):
    """
    True if `point` ([x,y]) lies inside the closed 2D polygon `poly`
    ([[x,y], ...]) -- standard ray-casting test. Handy for filtering a
    point set (or, per-vertex, a shape like honeycomb()'s hexagons)
    down to whatever's actually inside an arbitrary boundary:

        cells = honeycomb(3, 8, 8)
        boundary = cr2dt([[3,2,1],[8,3,3],[5,7,1],[-8,0,2],[-5,20,1]])
        inside = [h for h in cells if all(point_in_polygon(v, boundary) for v in h)]
    """
    x, y = float(point[0]), float(point[1])
    inside = False
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i][0], poly[i][1]
        x2, y2 = poly[(i + 1) % n][0], poly[(i + 1) % n][1]
        if (y1 > y) != (y2 > y):
            x_cross = (x2 - x1) * (y - y1) / (y2 - y1) + x1
            if x < x_cross:
                inside = not inside
    return inside


def pies1(section, pnts):
    """
    Filters a list of 2D points down to just the ones that lie inside
    the closed polygon `section` -- openscad4.py's own pies1(), ported
    as a thin wrapper around point_in_polygon() rather than its
    original numpy line-intersection formulation (same result, much
    simpler): returns the subset of `pnts` for which
    point_in_polygon(p, section) is True.

        pts = [[random.uniform(-5,20), random.uniform(-2,25)] for _ in range(10000)]
        sec = cr2dt([[2,1,.1],[7,5,2],[5,7,3],[-5,7,2],[-7,5,3]])
        inside = pies1(sec, pts)
        show(p_line3d(sec, .05, 0, 1))
        show(color(points(inside, .2), "magenta"))
    """
    poly = _flatten_points(section)
    return [p for p in pnts if point_in_polygon(p, poly)]


def vertex(point):
    """
    A single real B-rep Vertex at `point` ([x,y] or [x,y,z]) --
    build123d's own native Vertex. Mainly useful as a loft() section:
    passing a Vertex as the FIRST and/or LAST section (instead of
    another Face) tells loft() to taper smoothly to a single point
    there instead of blending into another ring -- the standard,
    numerically robust way to cap a lofted stack of rings with a
    genuine rounded/pointed tip, instead of feeding loft() a nearly-
    degenerate near-zero-size ring (real curve/surface fitting --
    interp_spline()/cap_wire()/Face-building in general -- can easily
    choke on a ring that's collapsed down to a tiny cluster of
    near-coincident points; "BRep_API: command not done" is a typical
    symptom of exactly that).

        rings = [translate([0, 0, h], circle(r)) for h, r in
                 [(2, 8), (8, 8)]]
        show(loft([vertex([0, 0, 0]), *rings, vertex([0, 0, 10])]))
    """
    _require_build123d()
    p = (point[0], point[1], point[2] if len(point) > 2 else 0.0)
    return bd.Vertex(*[float(c) for c in p])


def loft(*sections, ruled=False):
    """
    A solid lofted through a sequence of 2D cross-sections -- e.g.
    `loft(square(20, center=True), translate([0,0,20], circle(8)))`
    smoothly blends a square base into a round top 20 units up.
    Real B-rep, build123d's own native loft() (an exact ruled/smooth
    surface between the section boundaries, not a stack of thin mesh
    slices) -- accepts 2 or more sections, each already positioned
    where you want it (translate()/rotate() them into place first,
    same as sweep_sec2path()'s section). This is what openscad4.py's
    prism()/swp_prism_h() and the various "stitch two rail curves
    together" part-building tricks are standing in for by hand --
    build123d's loft() does the same underlying job natively and more
    robustly, so those weren't ported as separate point-list functions.

    `ruled` controls how the surface behaves AT each intermediate
    section, which matters a lot as soon as there are 3+ sections:
      False (default): a smooth spline surface threading through every
        section with continuous tangency -- if section 2's radius
        jumps up and section 3's jumps back down, the surface eases
        into and out of that bulge rather than kinking, so you will
        NOT see a sharp corner exactly at an intermediate section's
        height even though its radius is a local max/min. This is
        almost certainly why a profile built from rings of varying
        radius (e.g. a stack of circles at different heights/radii)
        comes out looking rounded/blobby instead of angular.
      True: straight-line ("ruled") surface between each consecutive
        pair of sections instead -- ends up as a stack of conical
        frustums, with a visible sharp corner exactly at every
        intermediate section's height. This is what you want if the
        rings/sections were meant to define a piecewise-straight
        profile (a vase with angular shoulders, a stepped cone, etc).

        rings = [translate([0,0,h], circle(r)) for h, r in
                 [(0,10),(10,14),(20,9),(30,15),(40,8)]]
        show(loft(*rings, ruled=True))   # sharp corner at each ring
    """
    _require_build123d()
    secs = _flatten(sections)
    if len(secs) < 2:
        raise ValueError("loft(): need at least 2 sections")
    return bd.loft(list(secs), ruled=bool(ruled))


def helix(radius=10, pitch=10, turns=1, center=(0, 0, 0), direction=(0, 0, 1), lefthand=False):
    """
    A helical Wire (a coil/spring/thread path) -- real B-rep, build123d's
    own native Helix curve (exact, not a polyline approximation), of
    the given `radius` and `pitch` (rise per full turn), `turns` long,
    starting at `center` and winding along `direction`. openscad4.py's
    own helix(), ported (its `number_of_coils`/`step_angle` become
    `turns`/build123d's own exact curve -- no facet-angle step needed).
    Feed it straight to sweep_sec2path() as path3d for a coil spring or
    a screw thread:

        show(sweep_sec2path(circle(1), helix(radius=10, pitch=5, turns=4)))
    """
    _require_build123d()
    return bd.Helix(float(pitch), float(pitch) * float(turns), float(radius),
                     center=tuple(float(c) for c in center),
                     direction=tuple(float(c) for c in direction),
                     lefthand=bool(lefthand))


def interp_spline(points, closed=False):
    """
    A smooth curve that passes EXACTLY through every point in `points`
    (2D or 3D) -- unlike bezier()/bspline_open()/bspline_closed() above
    (which only approximate through their control points), this is a
    true interpolating spline: openscad4.py's own
    interpolation_bspline_open()/interpolation_bspline_closed(),
    ported, as a thin wrapper around build123d's native
    Edge.make_spline() (GeomAPI_Interpolate under the hood -- exact,
    not fitted). `closed=True` makes a periodic (closed-loop) spline
    through the points instead of an open curve -- same idea as
    bspline_closed()'s closed_loop convention. Returns a real B-rep
    Edge, feed it to polygon()-style usage yourself if you need a
    filled face (Face(Wire([...]))-equivalent isn't wrapped here since
    the point-list functions above already cover the common polygon()
    case for approximating curves).
    """
    _require_build123d()
    pts = _flatten_points(points)
    if len(pts) < 2:
        raise ValueError("interp_spline(): need at least 2 points")
    pts3d = [(p[0], p[1], p[2] if len(p) > 2 else 0.0) for p in pts]
    return bd.Spline(*pts3d, periodic=bool(closed))


def mixed_polygon(pieces):
    """
    A B-rep 2D filled polygon like polygon(), but each item in `pieces`
    can be EITHER a plain 2D/3D point ([x,y] -- a straight-line vertex,
    same as polygon()) OR a real build123d Edge (interp_spline(),
    arc_edge(), tangent_arc() output, etc) used as-is for that stretch
    of the boundary instead of a straight line. Walks `pieces` in
    order, connecting consecutive plain points with straight lines and
    dropping in each given Edge directly (adding a straight line from
    the previous point to the Edge's own start if there's a gap),
    then closes the loop from the last item back to the first the same
    way -- combines the whole chain into one Wire (bd.Wire.combine())
    and returns the filled Face.

    The main use: swapping out a heavily-faceted arc_3p(...)-built
    curve (many short straight edges -- see arc_3p()'s own `s=`
    parameter) for ONE real curved Edge, when the rest of the profile
    should stay sharp-cornered -- e.g. instead of
    `arc_3p(p1, p2, p3, s=30) + [c1, c2]` (a ~30-point faceted arc
    plus 2 straight corners, all straight edges once polygon()-ed),
    use `[interp_spline([p1, p2, p3]), c1, c2]` here: same overall
    profile shape, but the curved portion becomes a single smooth Edge
    -- and that's ~29 fewer edges once extruded/booleaned.

        curve = interp_spline([[10, 0], [0, 50], [10, 100]])
        sec = mixed_polygon([curve, [-10, 100], [-10, 0]])
        show(linear_extrude(sec, 10))

    Raises if `pieces` doesn't chain up into exactly one closed loop
    (e.g. a given Edge points the wrong way, or there's a real gap).
    """
    _require_build123d()
    if len(pieces) < 2:
        raise ValueError("mixed_polygon(): need at least 2 pieces")

    def as_pt3(p):
        return (float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0)

    def dist(p0, p1):
        return math.sqrt(sum((p1[i] - p0[i]) ** 2 for i in range(3)))

    edges = []
    first_pt = None
    cursor = None
    for item in pieces:
        if isinstance(item, bd.Shape):
            start_v, end_v = item.position_at(0), item.position_at(1)
            start_pt = (start_v.X, start_v.Y, start_v.Z)
            end_pt = (end_v.X, end_v.Y, end_v.Z)
            if cursor is not None and dist(cursor, start_pt) > 1e-6:
                edges.append(bd.Edge.make_line(cursor, start_pt))
            edges.append(item)
            if first_pt is None:
                first_pt = start_pt
            cursor = end_pt
        else:
            pt = as_pt3(item)
            if cursor is not None and dist(cursor, pt) > 1e-6:
                edges.append(bd.Edge.make_line(cursor, pt))
            if first_pt is None:
                first_pt = pt
            cursor = pt
    if dist(cursor, first_pt) > 1e-6:
        edges.append(bd.Edge.make_line(cursor, first_pt))

    wires = bd.Wire.combine(edges)
    if len(wires) != 1:
        raise ValueError(
            f"mixed_polygon(): pieces didn't chain into a single closed "
            f"loop ({len(wires)} separate wires came out) -- check for a "
            f"real gap, or an Edge whose start/end is reversed from the "
            f"direction you're walking `pieces` in.")
    return bd.Face(wires[0])


def s_int1(points, closed=True):
    """
    Every point where the segments of a 2D point-list loop cross
    themselves -- openscad4.py's own s_int1(), ported: e.g. run this on
    an inward offset() of a sharp-cornered profile to find where the
    offset has crossed itself (gone invalid). Checks every pair of
    non-adjacent segments for a PROPER crossing (both segments' own
    interior, not just their infinite extensions -- see i_p2d() for
    that unclipped version) and returns the list of actual crossing
    points. `closed=True` (default) also checks the closing segment
    from the last point back to the first, same as polygon()'s own
    convention; `closed=False` treats `points` as an open polyline.
    """
    pts = [(float(p[0]), float(p[1])) for p in points]
    n = len(pts)
    if n < 3:
        return []
    edges = list(zip(pts, pts[1:])) + ([(pts[-1], pts[0])] if closed else [])
    m = len(edges)
    out = []
    for i in range(m):
        for j in range(i + 1, m):
            if j == i + 1 or (closed and i == 0 and j == m - 1):
                continue
            (x1, y1), (x2, y2) = edges[i]
            (x3, y3), (x4, y4) = edges[j]
            denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
            if abs(denom) < 1e-12:
                continue
            t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom
            u = ((x1 - x3) * (y1 - y2) - (y1 - y3) * (x1 - x2)) / denom
            if 1e-9 < t < 1 - 1e-9 and 1e-9 < u < 1 - 1e-9:
                out.append([x1 + t * (x2 - x1), y1 + t * (y2 - y1)])
    return out


def project_curve_on_face(curve, target, direction, closest=True):
    """
    Projects `curve` (a real build123d Edge/Wire, e.g. from
    interp_spline()/turtle3d()+a helper, or `shape.edges()[i]`) onto
    `target` (a Face/Solid -- e.g. `some_solid.faces()[0]`) along
    `direction` ([x,y,z]) -- exact B-rep projection, computed by OCCT
    (build123d's own Edge/Wire.project()), not a nearest-point search
    over a triangulated approximation. For projecting a raw point list
    or point grid instead of an actual curve, see psos() below.

    `closest=True` (default) returns the single nearest result if the
    curve's shadow lands on the target more than once; `closest=False`
    returns every hit (a list).
    """
    _require_build123d()
    return curve.project(target, tuple(float(c) for c in direction), closest=bool(closest))


def project_face_on_shape(face, target, direction):
    """
    Projects a whole Face (or every face of a Solid/Shape) onto
    `target` (a Face/Solid) along `direction` ([x,y,z]) -- extends
    project_curve_on_face()'s same idea (exact B-rep projection,
    computed by OCCT, no sampling) up one dimension, from a single
    curve to an entire surface. Uses build123d's own native
    Face.project_to_shape(): `face` is swept along `direction` far
    enough to clear `target` entirely, then intersected with it --
    unlike psos()+surface_from_points_grid() (project a raw point
    grid, then fit a NURBS surface back through the results), this
    returns the REAL projected Face(s)/Shell(s) directly, exact, with
    no sampling or fitting step at all.

        a = sphere(10)
        b = plane([0, 0, 1], [50, 50])
        c = project_face_on_shape(a, b, [0, 0, 1])
        show(a, alpha=0.2)
        show(color(c, "cyan"))

    `face`: a real Face (circle()/polygon()/a shape's own
        `.faces()[i]`), OR any Shape with `.faces()` (e.g. a Solid
        like sphere()/box()'s output) -- every one of its faces is
        projected in turn and all results combined into one list.
    `target`: the real Face/Solid to project onto.

    Returns a list of the projected Face(s)/Shell(s) -- there can be
    more than one per source face (e.g. the "front" and "back" of a
    closed target Solid both catch a projection); faces that would
    land "behind" the projection direction are never returned.
    """
    _require_build123d()
    d = tuple(float(c) for c in direction)
    faces = face.faces() if hasattr(face, "faces") else [face]
    out = []
    for f in faces:
        out.extend(f.project_to_shape(target, d))
    return out


def psos(points, target, direction, dist=None, unidirection=True):
    """
    Projects a raw point list or point grid onto a real target Face or
    Solid along `direction` -- openscad4.py's own psos() family
    (psos/psos_v/psos_n/psos_v_1/psos_v_2/psos_n_b, ~10 near-duplicate
    variants total), collapsed into ONE real B-rep function instead of
    ported literally. The originals all triangulate `target` into a
    mesh first (several different triangulation helpers depending on
    the shape's topology -- open/closed/donut-like/etc), then do
    manual ray-triangle intersection math (numpy) to find where each
    point's projection ray crosses that triangle soup -- real, working
    code, but the exact kind of mesh-native machinery this app has
    consistently avoided (see concave_hull()'s own drop for the same
    reasoning). None of that triangulation is needed here: build123d's
    own Face.find_intersection_points(axis) answers "where does this
    ray hit the real surface" EXACTLY, against the actual analytic/
    NURBS geometry, no faceting step at all. For projecting a real
    curve/Edge instead of raw points, see project_curve_on_face()
    above; for projecting a whole real Face/Shape (not points sampled
    off one), see project_face_on_shape() above -- exact there too,
    with no point grid or NURBS re-fit involved at all.

    `points`: a flat [[x,y,z], ...] list, OR a 2D grid ([[[x,y,z],
        ...], ...], a "surface" the same shape openscad4.py's own
        psos() `s3` argument took) -- either way every point is
        projected independently and the result comes back in the
        exact same shape/nesting `points` was given in.
    `target`: the real Face (or Solid -- all its faces are tried) to
        project onto.
    `direction`: the projection direction ([x,y,z]), the same vector
        for every point.
    `dist`: the maximum projection distance -- a point whose nearest
        hit is farther than this, or that never hits `target` at all,
        is left unmoved at its original position (same "don't lose
        the original points" fallback openscad4.py's psos() used).
        None (default) means no distance limit.
    `unidirection`: True (default) only projects forward along
        `direction`; False also considers hits found going backward
        (openscad4.py's unidirection=0). Either way, the single
        CLOSEST valid hit is used per point.

        pts = [[x, y, 0] for x in range(-10, 11, 2) for y in range(-10, 11, 2)]
        target = sphere(20)
        projected = psos(pts, target, [0, 0, -1])
        show(target, alpha=0.3)
        show(color(points(projected, .3), "cyan"))
    """
    _require_build123d()
    is_grid = len(points) > 0 and isinstance(points[0][0], (list, tuple))
    rows = points if is_grid else [points]
    d = tuple(float(c) for c in direction)
    dlen = math.sqrt(sum(c * c for c in d))
    if dlen < 1e-12:
        raise ValueError("psos(): direction must be nonzero")
    du = tuple(c / dlen for c in d)
    faces = target.faces() if hasattr(target, "faces") else [target]

    def _project_one(p):
        p3 = (float(p[0]), float(p[1]), float(p[2]) if len(p) > 2 else 0.0)
        axis = bd.Axis(p3, d)
        best = None
        for f in faces:
            for hit_pt, _hit_normal in f.find_intersection_points(axis):
                delta = (hit_pt.X - p3[0], hit_pt.Y - p3[1], hit_pt.Z - p3[2])
                signed = delta[0] * du[0] + delta[1] * du[1] + delta[2] * du[2]
                if unidirection and signed < -1e-9:
                    continue
                distance = abs(signed)
                if dist is not None and distance > float(dist):
                    continue
                if best is None or distance < best[0]:
                    best = (distance, [hit_pt.X, hit_pt.Y, hit_pt.Z])
        return best[1] if best is not None else list(p3)

    out_rows = [[_project_one(p) for p in row] for row in rows]
    return out_rows if is_grid else out_rows[0]


def tangent_arc(a, b, radius, side=0):
    """
    A circular arc of `radius`, tangent to both `a` and `b`, where each
    of `a`/`b` is either a real build123d Edge (e.g. `circle(5).edges()[0]`
    for a circle, or a straight Edge for a line) or a raw 2-point line
    `[[x1,y1],[x2,y2]]`/`[[x1,y1,z1],[x2,y2,z2]]` (auto-built into a
    line Edge for you). Covers openscad4.py's whole tangent-construction
    family in one call -- two_cir_tarc() (circle-circle), two_cir_tarc_
    internal(), fillet_line_circle()/fillet_line_circle_internal()
    (line-circle) -- since build123d's own native ConstrainedArcs solves
    all of these the same way regardless of what `a`/`b` are, there's no
    need for openscad4.py's four separate hand-rolled trig functions.

        c1 = circle(10).edges()[0]
        c2 = translate([20, 0, 0], circle(6)).edges()[0]
        show(show_edges([tangent_arc(c1, c2, radius=4)]))

    There are usually 2 valid tangent arcs for a given radius/side
    pair -- `side` (0 or 1) picks between them; if only one exists,
    `side` is ignored. `radius` is a real geometric constraint, not
    just a style knob: too small to bridge the gap between `a` and `b`
    and no tangent arc exists at all -- for two circles of radius
    r1/r2 whose centers are `d` apart, a fillet nestled between them
    needs roughly radius >= (d - r1 - r2) / 2 at minimum. Raises a
    clear error (not a cryptic one) if that happens.
    """
    _require_build123d()

    def _as_edge(x):
        if not isinstance(x, (list, tuple)):
            return x  # already a real build123d Edge
        pts = _flatten_points(x)
        if len(pts) != 2:
            raise ValueError("tangent_arc(): a raw line must be exactly 2 points")
        p0 = pts[0] + (0.0,) * (3 - len(pts[0]))
        p1 = pts[1] + (0.0,) * (3 - len(pts[1]))
        return bd.Edge.make_line(p0, p1)

    e1, e2 = _as_edge(a), _as_edge(b)
    try:
        arcs = bd.ConstrainedArcs(e1, e2, radius=float(radius), sagitta=bd.Sagitta.BOTH)
        arc_list = list(arcs.edges()) if hasattr(arcs, "edges") else list(arcs)
    except Exception as exc:
        raise ValueError(
            f"tangent_arc(): no arc of radius {radius} is tangent to both given "
            f"edges ({exc}). This is a real geometric constraint, not a bug -- "
            f"most commonly `radius` is too SMALL to bridge the gap between `a` "
            f"and `b` (for two circles of radius r1/r2 whose centers are `d` "
            f"apart, a fillet nestled between them needs roughly "
            f"radius >= (d - r1 - r2) / 2 at minimum). Try a larger radius, or "
            f"move `a`/`b` closer together."
        ) from exc
    if not arc_list:
        raise ValueError(f"tangent_arc(): no arc of radius {radius} is tangent to both given edges")
    return arc_list[int(side) % len(arc_list)]


def _flatten(shapes):
    """internal: lets union(a,b,c) and union([a,b,c]) both work."""
    out = []
    for s in shapes:
        if isinstance(s, (list, tuple)):
            out.extend(_flatten(s))
        else:
            out.append(s)
    return out


def volume(shape):
    """
    The shape's EXACT enclosed volume, computed by OCCT from the real
    B-rep geometry -- not a discrete/mesh estimate like the divergence-
    theorem-over-triangles trick used to sanity-check mcm()/
    repair_mesh() output elsewhere in this project. Useful as a ground-
    truth check if you ever want to compare a B-rep shape's true volume
    against a mesh reconstruction of "the same" shape.
    """
    _require_build123d()
    return shape.volume


def to_mesh(shape, tolerance=0.1, angular_tolerance=0.3):
    """
    Tessellates a B-rep shape into a triangle mesh in the SAME [V, F]
    convention used throughout openscad4.py (repair_mesh()/
    offset_mesh()/mcm() all return this, polyhedron() expects it) --
    the bridge for viewing a B-rep result in SanPyCAD's existing mesh
    viewer, or feeding it into any of openscad4.py's own mesh
    functions, without needing a real CAD program:
        v, f = to_mesh(some_brep_shape)
        fo(f'''polyhedron({v},{f});''')

    tolerance/angular_tolerance control facet density for this
    tessellation ONLY -- the underlying shape stays exact B-rep;
    export_step()/export_brep() ignore these entirely and write the
    real analytic/NURBS geometry, not this mesh. Smaller tolerance =
    more triangles = closer to the true curved surface, same idea as
    openscad4.py's own grid/samples_per_edge tradeoffs, just for
    display rather than for a computed result.

    UNVERIFIED against a real build123d install (see module
    docstring) -- shape.tessellate(tolerance, angular_tolerance) is
    expected to return (vertices, triangle_index_tuples); if the real
    API differs slightly (e.g. vertices as build123d Vector objects
    needing an explicit .to_tuple()/(.X,.Y,.Z) conversion rather than
    unpacking directly), that conversion is what would need adjusting
    here.
    """
    _require_build123d()
    verts, tris = shape.tessellate(tolerance, angular_tolerance)
    v = [[float(p.X), float(p.Y), float(p.Z)] for p in verts]
    f = [[int(i) for i in t] for t in tris]
    return v, f


def to_triangles(shape, tolerance=0.1, angular_tolerance=0.3):
    """
    Tessellates a B-rep shape straight into a FLAT list of resolved
    triangles [[p0, p1, p2], ...] (each p a plain [x, y, z]) -- the
    format openscad4.py's own low-level mesh-intersection building
    blocks expect (two_tri_intersection(a1, b1), triangle_triangle_
    intersection(), triangulate_solid_openx()'s own output), which is
    NOT the same as to_mesh()'s [V, F] indexed format (a vertex list
    plus face-index triples). Passing to_mesh()'s [V, F] tuple directly
    into one of those functions is a common mistake once `import
    openscad4` is in the picture -- it fails with something like
    "ValueError: setting an array element with a sequence... inhomogeneous
    shape", because V and F are two differently-shaped arrays being
    stuffed into one, not a triangle list at all. Use to_mesh() when you
    want the compact indexed form (e.g. to feed polyhedron()); use
    to_triangles() when a function needs each triangle spelled out in
    full, like this:

        import openscad4 as o4
        segs = o4.two_tri_intersection(to_triangles(a), to_triangles(b))
        loops = o4.contiguous_chains(segs)
    """
    v, f = to_mesh(shape, tolerance, angular_tolerance)
    return [[v[i] for i in tri] for tri in f]


def to_points(shape):
    """
    Extracts the ordered boundary point list [[x,y,z], ...] from a
    real build123d Shape (e.g. circle()/polygon()/square()/mirror()/
    rotate()'s own output) -- the reverse direction of polygon(): walks
    the outer wire's edges in winding order and collects each edge's
    own start point. For a polygon()-built Face with only straight
    edges (e.g. circle(r, s=n)'s faceted n-gon form), this reconstructs
    exactly the original point list that built it, same count and
    order, even after real Shape-level operations (rotate()/translate()
    /mirror()/etc) have moved it around.

    Handy for round-tripping a real Shape back into plain point-list
    territory to use numpy directly (array stacking/pairing/transpose
    tricks, same style as openscad4.py scripts), or any of brep.py's
    own point-list functions (fit_pline2line(), corner_n_radius_list(),
    etc) that don't accept a Shape:

        a = circle(15, s=5)
        b = rot('z36', circle(7, s=5))
        pa, pb = to_points(a), to_points(b)
        pairs = array([pa, pb]).transpose(1, 0, 2)   # (5, 2, 3) -- pa[i]/pb[i] paired

    For a Face/Wire with any CURVED edges (a `s=None` exact circle(),
    or a mixed_polygon() with a spline segment), each curved edge
    still only contributes its own start point here -- the curve
    itself isn't resampled into more points along the way. Use
    to_mesh() instead if you need a faceted approximation of a
    genuinely curved boundary.
    """
    _require_build123d()
    wire = _as_path_wire(shape, "to_points")
    edges = list(wire.edges()) if hasattr(wire, "edges") else [wire]
    pts = []
    for e in edges:
        p = e.position_at(0)
        pts.append([float(p.X), float(p.Y), float(p.Z)])
    return pts


def solid_from_faces(*faces):
    """
    Sews several B-rep Faces that TOGETHER bound one closed, watertight
    volume into a real Solid -- build123d's own native Shell(faces)
    (sews the faces together along their shared edges) + Solid(shell)
    (ShapeFix_Solid().SolidFromShell() under the hood, which both
    finishes closing the shell into a solid and repairs a shell that's
    almost-but-not-quite perfectly watertight).

    This is the real B-rep answer to "I have several curved surface
    patches, how do I turn the volume they enclose into one solid" --
    the case loft() specifically CANNOT handle: loft() needs every
    cross-section to already be a flat/planar Face (it calls
    section.faces() then uses each face's own outer_wire() -- a Face
    can only be built from a wire that's planar in the first place), so
    a part that genuinely bends/twists in 3D (most of its intermediate
    cross-sections non-planar) can't be lofted through directly no
    matter how many sections you feed it. surface_from_points_grid()
    has no such restriction (a true 3D NURBS fit through a whole point
    grid, curvature and all) -- fit the curved wall(s) with that, then
    sew them to their flat end caps here:

        wall = surface_from_points_grid(surf)      # the bent tube's own curved wall
        cap_a = mixed_polygon(a)                    # flat profile at one end
        cap_b = mixed_polygon(b)                    # flat profile at the other end
        solid = solid_from_faces(wall, cap_a, cap_b)
        show(solid)

    Raises whatever build123d itself raises if the given faces don't
    actually close up into a single watertight volume (a gap, an
    overlap, mismatched edges) -- there's no tolerance-loosening knob
    exposed here beyond what ShapeFix_Solid already does internally.

    Sews via OCCT's own BRepBuilderAPI_Sewing directly (through OCP,
    build123d's own underlying binding) rather than build123d's own
    Shell(list_of_faces) Python constructor -- on at least one
    build123d version that constructor raised "Unable to create
    Shell, invalid input type" on a perfectly valid list of Faces (a
    curved wall Face plus two cap_wire()-built end caps), even though
    each individual Face rendered/behaved fine on its own; sewing at
    the OCCT level first and only wrapping the ALREADY-CORRECTLY-TYPED
    single result (a Shell, or occasionally a lone Face/Compound of
    shells if sewing didn't fully close things up) sidesteps whatever
    that mismatch was.
    """
    _require_build123d()
    faces = _flatten(faces)
    if len(faces) < 2:
        raise ValueError("solid_from_faces(): need at least 2 faces")

    try:
        import OCP.TopAbs as _ta
        from OCP.TopoDS import TopoDS as _TopoDS
        from OCP.BRepBuilderAPI import BRepBuilderAPI_Sewing as _Sewing

        sewing = _Sewing(1e-6)
        for f in faces:
            sewing.Add(f.wrapped)
        sewing.Perform()
        sewn = sewing.SewedShape()
        shape_type = sewn.ShapeType()
        if shape_type == _ta.TopAbs_SHELL:
            shell = bd.Shell(_TopoDS.Shell(sewn))
        elif shape_type == _ta.TopAbs_FACE:
            shell = bd.Shell([bd.Face(_TopoDS.Face(sewn))])
        else:
            shell = bd.Shell(list(bd.Compound(_TopoDS.Compound(sewn)).faces()))
    except Exception as _sew_err:
        # Fall back to build123d's own higher-level constructor, in case
        # the OCP-level route above hit something environment-specific
        # (unlikely, but cheap insurance) -- surface BOTH errors if this
        # also fails, since at that point it's a genuine geometry problem
        # (gap/overlap/mismatched edges) worth seeing in full.
        try:
            shell = bd.Shell(list(faces))
        except Exception as _shell_err:
            raise RuntimeError(
                f"solid_from_faces(): OCCT sewing failed ({_sew_err!r}), "
                f"and the build123d Shell() fallback also failed "
                f"({_shell_err!r})"
            ) from _shell_err
    return bd.Solid(shell)


def group(*shapes):
    """
    Bundles two or more shapes into one Compound "assembly" -- unlike
    union(), this does NOT boolean-fuse them into a single solid; each
    shape stays its own separate, distinct solid inside the Compound,
    exactly as it was. Mainly for export_step()/export_brep(): passing
    a group() of several shapes writes them all into ONE file as
    separate parts (an assembly), same idea as `to_export` being
    "object or assembly" per build123d's own export_step() docstring
    -- rather than calling export_step() once per shape into separate
    files, or fusing everything into one solid with union() just to
    get a single file out.

        a = cylinder(r=10, h=40)
        b = box(30, 30, 5)
        export_step(group(a, b), "both_parts.step")   # 2 distinct
                                                        # solids, 1 file

    show() only ever takes ONE shape per call (call it once per shape,
    same as every other example does, to see them all in the viewer) --
    group() is specifically for bundling shapes together for export,
    not for display. show(group(a, b)) still works (it tessellates the
    whole Compound into one combined display mesh), but you lose each
    part's own separate color/selectability in the viewer that way, so
    prefer plain show(a); show(b) for viewing and save group() for the
    export_step()/export_brep() call itself.
    """
    _require_build123d()
    shapes = _flatten(shapes)
    if len(shapes) == 0:
        raise ValueError("group(): need at least one shape")
    return bd.Compound(shapes)


def export_step(shape, path):
    """
    Writes `shape` to a STEP file -- real B-rep, exact geometry,
    openable/editable in any real CAD program (SolidWorks, Fusion 360,
    FreeCAD, etc.), unlike anything openscad4.py's own mesh functions
    can produce.
    """
    _require_build123d()
    return bd.export_step(shape, str(path))


def export_stl(shape, path, tolerance=0.001, angular_tolerance=0.1, ascii_format=False):
    """
    Writes `shape` to an STL file -- tessellated (faceted) on export,
    same idea as to_mesh() above but written straight to disk by OCCT
    rather than returned as [V, F]. tolerance/angular_tolerance are the
    same facet-density controls as to_mesh()'s.
    """
    _require_build123d()
    return bd.export_stl(shape, str(path), tolerance=tolerance, angular_tolerance=angular_tolerance, ascii_format=ascii_format)


def export_brep(shape, path):
    """
    Writes `shape` to a native OCCT BREP file -- exact geometry like
    export_step(), but BREP is OCCT's own format rather than the
    cross-CAD-vendor ISO 10303 standard STEP is. Useful mainly for
    round-tripping back into build123d/OCCT itself (import_brep())
    without any STEP-specific overhead; use export_step() if the file
    needs to open in a different CAD program.
    """
    _require_build123d()
    return bd.export_brep(shape, str(path))


if __name__ == "__main__":
    # quick manual smoke test -- run this file directly (after
    # pip install build123d) to sanity-check the wiring against a real
    # install. Builds a notched cone, prints its exact volume, exports
    # STEP/STL, and tessellates it for the mesh viewer.
    _require_build123d()
    a = cylinder(r1=20, r2=0, h=20)
    b = box([10, 10, 40], center=True)
    c = difference(a, translate([0, 0, -10], b))
    print("volume:", volume(c))
    export_step(c, "brep_smoke_test.step")
    export_stl(c, "brep_smoke_test.stl")
    v, f = to_mesh(c)
    print("tessellated:", len(v), "vertices,", len(f), "triangles")
