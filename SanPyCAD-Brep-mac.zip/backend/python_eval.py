"""
python_eval.py

The Python-mode evaluator for SanPyCAD-Brep: runs the user's own plain
Python, calling brep.py's functions directly, ending with a call to
show() (or, for a script with exactly one top-level shape and no show()
call, that shape is used automatically).

THIS APP IS B-REP BY DEFAULT: box()/cube()/cylinder()/sphere()/circle()/
square()/polygon()/translate()/rotate()/rot()/mirror()/scale()/
linear_extrude()/rotate_extrude()/union()/difference()/intersection()/
hull()/fillet()/chamfer() all come straight from brep.py and build real
build123d/OCCT solids -- there is no mesh/point-list geometry engine
wired into the default namespace, no swp()/fo() text workflow, no
mesh-based CSG. show()/color() tessellate a B-rep shape into a
triangle Mesh (see mesh_types.py) purely so the (necessarily
triangle-based, since that's all WebGL can draw) viewer has something
to render -- the exact geometry is kept on the resulting Mesh's
.brep_shape attribute, which is what a future STEP/BREP export route
would write, not a re-derivation from that display mesh.

OPT-IN mesh escape hatch: a script may do `import openscad4` (or
`import openscad4 as o4`) to reach the full mesh/point-list toolkit
directly -- two_solids_intersection(), contiguous_chains(), o_3d(),
equidistant_pathc(), swp()/swp_c(), etc. A copy of openscad4.py is
bundled directly in this app's own backend/ (so `import openscad4`
works standalone, with no sibling app required) -- but if the sibling
SanPyCAD app's backend/ is also found on disk (e.g. on a dev machine
that keeps both apps side by side), that sibling copy is added earlier
on sys.path and takes priority, so local development always picks up
its latest edits instead of this bundled snapshot. This is meant for
bridging INTO brep.py, not replacing it: do the hard mesh math (e.g.
intersecting two curved B-rep solids by tessellating them) in
openscad4, then hand the resulting point lists to brep.py's own
convert_3lines2fillet()/loft_fillet()/surface_from_points_grid() to
get back to a real B-rep Face/Solid. openscad4.py itself requires
scipy, sympy, and scikit-image to import (see requirements.txt); if
those aren't installed, `import openscad4` will raise
ModuleNotFoundError.

Trust model: this executes the script's Python directly (no sandboxing
beyond a plain exec() namespace) -- the same trust level as running it in
your own notebook. Don't run scripts you don't trust.
"""

import ast
import io
import os
import sys
import contextlib
import threading
import traceback

import numpy as np

import brep
from mesh_types import Mesh, COLOR_NAMES, DEFAULT_COLOR

# Opt-in mesh escape hatch (see module docstring above): a bundled copy
# of openscad4.py already lives in this backend/ directory (so it's
# importable with no setup on any machine that just has SanPyCAD-Brep).
# If the sibling SanPyCAD app's backend/ is ALSO present on disk (e.g.
# a dev machine with both apps side by side), it's inserted earlier on
# sys.path here so it takes priority over the bundled snapshot --
# SanPyCAD-Brep/backend/python_eval.py -> up two levels -> the common
# parent -> SanPyCAD/backend.
_SIBLING_MESH_APP_BACKEND = os.path.normpath(os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "..", "SanPyCAD", "backend"))
if os.path.isdir(_SIBLING_MESH_APP_BACKEND) and _SIBLING_MESH_APP_BACKEND not in sys.path:
    sys.path.insert(0, _SIBLING_MESH_APP_BACKEND)


class PythonScriptError(Exception):
    def __init__(self, msg, line=None):
        self.line = line
        super().__init__(msg)


# Every name here comes straight from brep.py (see make_namespace()),
# plus this module's own per-run helper closures (color/show/echo) and
# the brep/np/numpy module references -- all considered "library", not
# user data (see _save_persisted_vars()/_find_var_name()).
RESERVED_NAMES = {
    "box", "cube", "cylinder", "sphere", "circle", "square", "polygon",
    "turtle2d", "turtle3d", "cr2dt", "cr3dt", "corner_n_radius_list",
    "translate", "rotate", "rot", "axis_rot_1", "axis_rot_1_pts", "mirror", "mirror_surface", "surface_line_vector", "surface_from_points_grid", "surface_from_2_waves", "convert_3lines2fillet", "loft_fillet", "thicken", "scale", "offset", "offset_face",
    "linear_extrude", "rotate_extrude", "sweep_sec2path",
    "union", "difference", "intersection", "hull", "sample_curve", "group", "solid_from_faces", "face_from_wire",
    "fillet", "max_fillet_radius", "chamfer", "show_edges", "label_edges", "label_faces", "edges_in_box", "faces_in_box", "points", "p_line3d", "line3d", "text", "track_points",
    "plane", "sinewave", "cosinewave", "loft", "helix", "interp_spline", "mixed_polygon", "fit_pline2line",
    "s_int1", "project_curve_on_face", "psos", "tangent_arc", "honeycomb", "point_in_polygon", "pies1",
    "volume", "to_mesh", "to_triangles", "to_points", "export_step", "export_stl", "export_brep",
    "color", "show", "echo",
    "brep", "np", "numpy",
    # core point-list/vector-math toolkit (see brep.py's own section
    # comment above these for the full rationale/scope note)
    "seg", "flip", "contiguous_chains", "two_solids_intersection", "l_len", "l_lenv", "mid_point", "bb", "bb2d", "cog",
    "line_as_vector", "line_as_unit_vector",
    "ang", "ang_2lineccw", "ang_2linecw", "ang3points",
    "i_p2d", "distanceOfPointFromLine", "perpendicularProjectionOfPointOnLine",
    "mirror_point", "mirror_line", "rot2d", "xrot", "yrot", "zrot", "xrot4d", "yrot4d", "zrot4d", "rot_p", "c23", "c32", "xyc", "xzc", "yzc",
    "arc", "arc_edge", "arc_2p", "cir_2p", "arc_3p", "cir_3p", "cp_3p", "arc_2p_3d", "tcct",
    "remove_extra_points", "min_d_points", "sort_points",
    "convex_hull", "normal_vector", "equation_of_plane",
    "fillet3points",
    "bezier", "bspline_open", "bspline_closed",
}


# ---------------------------------------------------------------------
# Persistent kernel state (Jupyter-style): variables a script assigns
# survive from one Render to the next, even if the line that computed
# them gets commented out afterwards -- exactly the "compute the heavy
# thing once, then comment it out and keep iterating on the rest" flow
# a Jupyter notebook supports. This is a plain module-level dict rather
# than anything per-session/per-tab, since this app only ever talks to
# one script editor at a time; a lock just guards against two /render
# (or /reset_kernel) requests landing back-to-back on the threaded HTTP
# server.
_PERSIST_LOCK = threading.Lock()
_PERSISTENT_USER_NS = {}


def reset_kernel():
    """Forget every persisted variable -- the Python-mode equivalent of
    Jupyter's 'Restart Kernel'. The next Render starts from a completely
    fresh namespace again."""
    with _PERSIST_LOCK:
        n = len(_PERSISTENT_USER_NS)
        _PERSISTENT_USER_NS.clear()
    return n


def persisted_variable_names():
    """Sorted names currently held in the persistent kernel namespace, for
    a small "N vars in memory" status indicator in the UI."""
    with _PERSIST_LOCK:
        return sorted(_PERSISTENT_USER_NS)


def get_persisted_var(name):
    """The real value currently held under `name` in the persistent kernel
    namespace, or None if no such variable exists (yet, or ever) --
    server.py's /probe_pick route uses this to reach the actual B-rep
    shape a probe box should be tested against (real Edge/Face bounding
    boxes, live edges_in_box()/faces_in_box() indices) without needing to
    re-run the whole script just to get a handle back on it."""
    with _PERSIST_LOCK:
        return _PERSISTENT_USER_NS.get(name)


def _save_persisted_vars(ns, lib_snapshot):
    """After a run, decide what belongs in the persistent namespace: any
    name that isn't a dunder, isn't one of this app's own per-run helper
    closures (RESERVED_NAMES -- these must always be rebuilt fresh next
    time, since they close over *this* run's scene/warnings/echo_log),
    and either wasn't part of the fresh library baseline at all (a real
    user variable) or now points to a different object than that
    baseline did (the user reassigned a library name, e.g. `pi = 3`).

    Untouched library/helper functions are deliberately left out --
    they're cheap to rebuild every run and keeping them around would
    only risk pinning stale closures. Note this also naturally keeps a
    variable that a previous run set and this run's code never mentions
    at all (its line got commented out): it was merged into `ns` before
    exec ran, exec never removed it, so it's still sitting there
    untouched, with no `lib_snapshot` entry to match -- so it's kept."""
    new_persisted = {}
    for k, v in ns.items():
        if k.startswith("__"):
            continue
        if k in RESERVED_NAMES:
            continue
        if k in lib_snapshot and ns[k] is lib_snapshot[k]:
            continue
        new_persisted[k] = v
    with _PERSIST_LOCK:
        _PERSISTENT_USER_NS.clear()
        _PERSISTENT_USER_NS.update(new_persisted)
    return new_persisted


def _is_brep_shape(x):
    """True if `x` is a real build123d/OCCT Shape (whatever
    box()/cylinder()/sphere()/union()/etc from brep.py return) -- see
    brep.py's module docstring for what that actually means. Guarded on
    brep._HAVE_BUILD123D first so this never touches brep.bd (which is
    None when build123d isn't installed) and just returns False, rather
    than crashing on every single _as_mesh() call in that case."""
    return brep._HAVE_BUILD123D and isinstance(x, brep.bd.Shape)


def _as_mesh(x, what="argument"):
    if isinstance(x, Mesh):
        return x
    if _is_brep_shape(x):
        # Real B-rep -- tessellate ONLY for the viewer's sake; the exact
        # shape itself is kept on brep_shape so a future STEP export can
        # write the genuine geometry later, not a re-triangulated copy
        # of this display mesh (see mesh_types.Mesh.brep_shape's docstring).
        V, F = brep.to_mesh(x)
        return Mesh(V, F, brep_shape=x)
    raise PythonScriptError(
        f"{what} must be a B-rep shape -- whatever cube()/sphere()/cylinder()/"
        f"circle()/square()/polygon()/etc (from brep.py) returns, or the "
        f"result of union()/difference()/intersection()/hull()/fillet()/"
        f"chamfer()/color() -- got {type(x).__name__}")


def _is_degenerate(m):
    """True if m has literally zero triangles, OR every triangle is
    effectively zero-area/zero-volume (e.g. every point coincides) --
    not caught by a plain is_empty() check since the triangle *count*
    can still be nonzero."""
    if m.is_empty():
        return True
    lo = m.V.min(axis=0)
    hi = m.V.max(axis=0)
    return bool(np.all((hi - lo) < 1e-9))


def _resolve_color_arg(c):
    if c is None:
        return None
    if isinstance(c, str):
        s = c.strip()
        if s.startswith('#'):
            hexs = s[1:]
            if len(hexs) in (3, 4):
                hexs = ''.join(ch * 2 for ch in hexs[:3])
            if len(hexs) >= 6:
                try:
                    return tuple(int(hexs[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
                except ValueError:
                    return None
            return None
        return COLOR_NAMES.get(s.lower())
    if isinstance(c, (list, tuple)) and len(c) >= 3:
        return (float(c[0]), float(c[1]), float(c[2]))
    return None


def make_namespace(csg_resolution, scene, warnings, echo_log):
    """`csg_resolution` is accepted purely for call-signature
    compatibility with the rest of the app (server.py passes it through
    uniformly) but is UNUSED here -- B-rep booleans are exact, there's
    no voxel resolution/facet count to tune the way a mesh-CSG engine
    would need."""
    ns = {name: getattr(brep, name) for name in (
        "box", "cube", "cylinder", "sphere", "circle", "square", "polygon",
        "turtle2d", "turtle3d", "cr2dt", "cr3dt", "corner_n_radius_list",
        "translate", "rotate", "rot", "axis_rot_1", "axis_rot_1_pts", "mirror", "mirror_surface", "surface_line_vector", "surface_from_points_grid", "surface_from_2_waves", "convert_3lines2fillet", "loft_fillet", "thicken", "scale", "offset", "offset_face",
        "linear_extrude", "rotate_extrude", "sweep_sec2path",
        "union", "difference", "intersection", "hull", "sample_curve", "group", "solid_from_faces", "face_from_wire",
        "fillet", "max_fillet_radius", "chamfer", "show_edges", "label_edges", "label_faces", "edges_in_box", "faces_in_box", "points", "p_line3d", "line3d", "text", "track_points",
    "plane", "sinewave", "cosinewave", "loft", "helix", "interp_spline", "mixed_polygon", "fit_pline2line",
    "s_int1", "project_curve_on_face", "psos", "tangent_arc", "honeycomb", "point_in_polygon", "pies1",
        "volume", "to_mesh", "to_triangles", "to_points", "export_step", "export_stl", "export_brep",
        "seg", "flip", "contiguous_chains", "two_solids_intersection", "l_len", "l_lenv", "mid_point", "bb", "bb2d", "cog",
        "line_as_vector", "line_as_unit_vector",
        "ang", "ang_2lineccw", "ang_2linecw", "ang3points",
        "i_p2d", "distanceOfPointFromLine", "perpendicularProjectionOfPointOnLine",
        "mirror_point", "mirror_line", "rot2d", "xrot", "yrot", "zrot", "xrot4d", "yrot4d", "zrot4d", "rot_p", "c23", "c32", "xyc", "xzc", "yzc",
        "arc", "arc_edge", "arc_2p", "cir_2p", "arc_3p", "cir_3p", "cp_3p", "arc_2p_3d", "tcct",
        "remove_extra_points", "min_d_points", "sort_points",
        "convex_hull", "normal_vector", "equation_of_plane",
        "fillet3points",
        "bezier", "bspline_open", "bspline_closed",
    )}
    ns["brep"] = brep
    ns["np"] = np
    ns["numpy"] = np

    shown_flag = {"any": False}

    def color(x, c=None, alpha=1.0):
        """color(shape, c=None, alpha=1.0) -> shape
        Returns a copy of `shape` tagged with a color and/or opacity for
        display -- doesn't change the geometry. `c` is a color name
        ("red", "blue", ...), a hex string ("#ff0000"), or an [r,g,b]
        list (0..1 each). Doesn't itself add anything to the scene --
        wrap the result in show() (or return it from a union()/etc that
        eventually gets shown).

        Apply this LAST, right before show() -- like show(), it
        tessellates `shape` into a display-only mesh (see _as_mesh()),
        so the object it returns is no longer a real build123d Shape:
        volume()/fillet()/chamfer()/export_step()/etc, and further
        union()/difference()/intersection()/mirror()/scale() calls, only
        work on brep.py's actual Shape objects, not on a color()ed one.
        Do volume()/fillet()/booleans/export first, color() the finished
        result only when you're ready to show() it."""
        m = _as_mesh(x, "color() first argument")
        out = m.copy_with()
        rgb = _resolve_color_arg(c)
        if rgb is not None:
            out.color = rgb
        out.alpha = float(alpha)
        return out

    def show(x, c=None, alpha=None):
        """show(shape, c=None, alpha=None) -> shape
        Adds `shape` to the viewer scene (optionally overriding its color
        the same way color() does) and returns it unchanged. This is what
        actually makes something appear -- everything else (union(),
        cube(), translate(), ...) just builds/combines geometry. If a
        script has exactly one shape-like variable and never calls
        show(), that one is shown automatically."""
        m = _as_mesh(x, "show() first argument")
        if _is_degenerate(m):
            warnings.append("show() was called on an empty or degenerate shape (0 "
                             "triangles, or every point coincides) -- nothing "
                             "meaningful was added to the scene for this call")
        out = m.copy_with()
        rgb = _resolve_color_arg(c)
        if rgb is not None:
            out.color = rgb
        if alpha is not None:
            out.alpha = float(alpha)
        scene.append(out)
        shown_flag["any"] = True
        return x

    def echo(*args):
        """echo(*values) -> None
        Prints each value to this app's console panel (same idea as
        OpenSCAD's echo(), or a print() that shows up in the UI instead
        of the terminal)."""
        echo_log.append("ECHO: " + ", ".join(_fmt_echo(a) for a in args))

    ns.update({
        "color": color,
        "show": show,
        "echo": echo,
    })
    return ns, shown_flag


def _fmt_echo(v):
    if isinstance(v, float):
        return f"{v:g}"
    if isinstance(v, Mesh) or _is_brep_shape(v):
        return "<shape>"
    return str(v)


def _wrap_toplevel_bare_expressions(tree):
    """Jupyter-notebook-style "just type it to inspect it": rewrite every
    top-level bare expression statement in `tree` (e.g. `len(a)`, `a.shape`,
    `type(a)`) into a call to `__display__(...)` so its value gets echoed
    to this app's console, the same way a Jupyter cell auto-displays a
    bare expression's value -- without needing to wrap it in echo()/
    print() yourself. Only *top-level* statements are rewritten (matching
    Jupyter, which only does this for a cell's own top-level lines, not
    ones nested inside a function/for/if you define in the script) --
    everything else in the tree is left untouched, including assignments
    (`a = len(x)` stays a plain assignment, nothing displayed for it).

    A bare string-literal statement (a triple-quoted note left on its own
    line -- a common way to leave a comment in a cell) is left alone
    rather than echoed, since that's almost always meant as a comment,
    not a value someone wants to see printed.

    __display__ itself (defined in run_python_script) additionally
    suppresses None (matching Jupyter, which never shows `Out: None`) and
    shape objects (a Mesh, or a real B-rep shape straight out of
    cube()/sphere()/etc) -- so a bare top-level `show(x)`/`color(x)`/
    `union(a, b)` call (all of which return a shape, not None) doesn't
    spam "<shape>" into the console on every single script that uses the
    normal show()-based workflow; this is purely for inspecting plain
    values like numbers, strings, lists, lengths, etc."""
    for i, node in enumerate(tree.body):
        if not isinstance(node, ast.Expr):
            continue
        if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            continue  # bare string statement -- treat as a comment, not a value to show
        new_node = ast.Expr(value=ast.Call(
            func=ast.Name(id="__display__", ctx=ast.Load()),
            args=[node.value], keywords=[]))
        ast.copy_location(new_node, node)
        ast.copy_location(new_node.value, node)
        ast.fix_missing_locations(new_node)
        tree.body[i] = new_node
    return tree


def run_python_script(code, csg_resolution=56, persist=True):
    """Always returns (result_dict, meshes_or_None), same contract as
    server.py's other run functions.

    persist=True (the default) gives the script a Jupyter-style kernel:
    variables from the last run that assigned them are merged back in
    before this run starts, so a heavy computation whose line has since
    been commented out doesn't need to re-run -- its result is still
    sitting in the namespace. Whatever the script's own top-level names
    are after this run (added, changed, or just carried over untouched)
    become the new persisted set, win or lose (a script that errors
    partway through still keeps whatever it assigned before the error,
    same as a Jupyter cell would). Pass persist=False for a one-off run
    that shouldn't read from or write to that shared memory."""
    result = {"meshes": [], "warnings": [], "echo": [], "error": None, "error_line": None}
    scene = []
    warnings = []
    echo_log = []
    ns, shown_flag = make_namespace(csg_resolution, scene, warnings, echo_log)
    lib_snapshot = dict(ns)  # fresh library/helper baseline -- before persisted vars or exec
    if persist:
        with _PERSIST_LOCK:
            ns.update(_PERSISTENT_USER_NS)

    def __display__(v):
        if v is None or isinstance(v, Mesh) or _is_brep_shape(v):
            return
        echo_log.append(_fmt_echo(v))
    ns["__display__"] = __display__

    stdout_buf = io.StringIO()
    try:
        tree = _wrap_toplevel_bare_expressions(ast.parse(code, "<script>", "exec"))
        compiled = compile(tree, "<script>", "exec")
        with contextlib.redirect_stdout(stdout_buf):
            exec(compiled, ns)
    except PythonScriptError as e:
        result["error"] = str(e)
        result["error_line"] = e.line if e.line is not None else _extract_user_line(e)
        result["persisted_vars"] = sorted(_save_persisted_vars(ns, lib_snapshot)) if persist else []
        return result, None
    except SyntaxError as e:
        result["error"] = f"{e.msg} (line {e.lineno})"
        result["error_line"] = e.lineno
        result["persisted_vars"] = persisted_variable_names() if persist else []
        return result, None
    except Exception as e:
        line = _extract_user_line(e)
        result["error"] = "".join(traceback.format_exception_only(type(e), e)).strip()
        result["error_line"] = line
        result["persisted_vars"] = sorted(_save_persisted_vars(ns, lib_snapshot)) if persist else []
        traceback.print_exc()
        return result, None

    printed = stdout_buf.getvalue()
    if printed.strip():
        echo_log.extend(line for line in printed.splitlines() if line.strip())

    if not shown_flag["any"]:
        candidates = [
            (name, val) for name, val in ns.items()
            if name not in RESERVED_NAMES and not name.startswith("_")
            and (isinstance(val, Mesh) or _is_brep_shape(val))
        ]
        if len(candidates) == 1:
            name, val = candidates[0]
            if isinstance(val, Mesh):
                m = val
            else:
                V, F = brep.to_mesh(val)
                m = Mesh(V, F, brep_shape=val)
            scene.append(m)
            warnings.append(
                f"show() was never called -- auto-showing the only shape-like "
                f"variable '{name}'. Call show({name}) explicitly to silence this.")
        elif len(candidates) > 1:
            warnings.append(
                "show() was never called, and there's more than one shape-like "
                "variable (" + ", ".join(n for n, _ in candidates) + ") so nothing "
                "was rendered -- call show(x) on whichever one(s) you want to see.")
        else:
            warnings.append("show() was never called and no shapes were found -- "
                             "call show(x) on the shape(s) you want to render.")

    result["warnings"] = warnings
    result["echo"] = echo_log
    result["persisted_vars"] = sorted(_save_persisted_vars(ns, lib_snapshot)) if persist else []
    for m in scene:
        if m.is_empty():
            continue
        result["meshes"].append({
            "vertices": np.round(m.V, 5).tolist(),
            "faces": m.F.tolist(),
            "color": list(m.color) if m.color else list(DEFAULT_COLOR),
            "alpha": m.alpha,
            "vertex_labels": None,
        })
    return result, scene


def _extract_user_line(exc):
    tb = exc.__traceback__
    line = None
    while tb is not None:
        if tb.tb_frame.f_code.co_filename == "<script>":
            line = tb.tb_lineno
        tb = tb.tb_next
    return line
