"""
server.py

Small dependency-free HTTP backend (uses only the Python standard library --
no Flask/FastAPI install required). This app is B-rep only: the one real
third-party dependency anything here needs is build123d (see brep.py), used
via python_eval.py; numpy is the other hard dependency (viewer JSON, STL/OBJ/
SVG/DXF export triangle math).

Routes:
  GET  /                    -> frontend/index.html
  GET  /status               -> {build123d: bool} -- whether build123d is
                                importable, so the frontend can show a clear
                                "pip install build123d" notice instead of
                                every script silently failing with an
                                ImportError.
  GET  /examples            -> list of bundled example scripts (.py)
  GET  /examples/<name>     -> a single example's source
  GET  /functions           -> {functions: [{name, doc, origin}],
                                openscad4_functions: [{name, doc}]} -- every
                                name brep.py exposes through python_eval.py's
                                namespace (box()/cylinder()/union()/fillet()/
                                etc), for editor autocomplete, the Shift+Tab
                                doc popup, and the Function Reference panel.
                                openscad4_functions is the complete list of
                                real openscad4.py functions reachable via the
                                opt-in `o4.` bridge -- including ones that
                                also exist natively in brep.py under the
                                same bare name (sphere/circle/seg/flip/
                                contiguous_chains) and so don't appear with
                                origin="openscad4" in `functions` above,
                                since a bare unqualified call resolves to
                                the brep.py version, not this one.
  POST /probe_pick          -> {variable, point, kind} -> {indices:
                                [nearest_index], total, distance} -- finds
                                the single real edge (kind="edges", the
                                default) or face (kind="faces") nearest a
                                clicked 3D point, for the viewer's
                                Click-to-Pick tool. Edges are matched by
                                sampling e.position_at(t) (same convention
                                as show_edges()/label_edges()); faces are
                                matched by the exact OCCT point-to-face
                                distance (Face.distance_to()), no
                                sampling needed. Reads the shape from the
                                persisted kernel namespace (see
                                python_eval.py's Jupyter-style memory),
                                so the script must have been Rendered at
                                least once first. Also accepts the older
                                {variable, kind, mode, center, size} box-
                                region form -> {indices, total}, running
                                the real edges_in_box()/faces_in_box()
                                against the same persisted shape.
  POST /probe_max_fillet    -> {variable, indices} -> {radii} -- the
                                largest radius fillet(shape, [edge], radius)
                                will actually succeed with, computed
                                PER EDGE (one independent search each,
                                same order as `indices`) rather than one
                                figure for the whole selection -- a group
                                fillet() attempt can fail outright even
                                when every edge in it is individually
                                fine (e.g. a cube's 4 separate vertical
                                edges, which don't share a face/vertex
                                with each other), which used to collapse
                                the whole readout to a single unhelpful 0
                                for exactly that kind of selection.
                                brep.py's own max_fillet_radius(), same
                                persisted-shape lookup as /probe_pick
                                above. Each entry is 0 whenever that one
                                edge has no positive radius that works at
                                all -- a genuine geometric limit, an
                                out-of-range index, or the search failing
                                to converge in its (deliberately small,
                                UI-responsiveness-sized) iteration budget
                                -- rather than surfacing an HTTP error, or
                                letting one bad edge blank out the rest,
                                for what's meant to be a live, no-fuss
                                readout in the panel.
  POST /probe_highlight     -> {variable, indices, kind} -> {curves:
                                [[[x,y,z], ...], ...]} -- one sampled
                                polyline per selected edge (kind="edges",
                                the default) or per boundary edge of each
                                selected face (kind="faces"), same
                                position_at(t) sampling /probe_pick's
                                click-matching already uses. Powers the
                                Pick panel's "Highlight selected" toggle:
                                the frontend draws these directly over the
                                real curves in the viewer so it's obvious
                                at a glance which edges/faces are
                                currently captured, without needing to
                                mentally map index numbers to geometry.
  POST /render              -> {code, csg_resolution?} -> scene JSON
  POST /export/stl          -> {code, csg_resolution?} -> binary STL file
  POST /export/obj          -> {code, csg_resolution?} -> Wavefront OBJ file
  POST /export/svg          -> {code, csg_resolution?} -> SVG engineering
                                drawing: FRONT/TOP/RIGHT/ISO views of the
                                shown shape(s), hidden edges dashed, on one
                                bordered sheet with a title block. Real
                                hidden-line-removal (OCCT's HLRBRep_Algo, via
                                build123d's Shape.project_to_viewport() --
                                see brep.py's technical_drawing_views()), not
                                a raw triangle-edge wireframe -- needs the
                                shown shape(s) to be genuine B-rep, not the
                                raw openscad4 mesh-bridge escape hatch.
  POST /drawing              -> {code, csg_resolution?, part_name?} -> same
                                SVG sheet as /export/svg above (both call
                                generate_drawing_svg()) -- a plain one-shot
                                flat-file download, used by app.py's native
                                Save-dialog path.
  POST /drawing_data         -> {code, csg_resolution?, part_name?} -> JSON
                                {labels, views, quadrants, sheet, title} --
                                the SAME hidden-line-removed view geometry as
                                /drawing above, but as plain per-view polyline
                                + transform data instead of a flattened SVG.
                                Powers the toolbar's "Drawing" button, which
                                opens an interactive 2D Drawing tab (see
                                index.html) built from this: click points/
                                circles/edges on the views to add real-unit
                                dimensions (linear, radius/diameter, angle,
                                center-distance), then download the result as
                                a dimensioned SVG -- all client-side from
                                this one JSON payload, no further round trip.
  POST /export/dxf          -> {code, csg_resolution?} -> DXF (R12) file,
                                one 3DFACE entity per triangle -- this is what
                                the "DWG" export option in the UI actually
                                produces, since true .dwg needs a proprietary
                                SDK; DXF is the open interchange format AutoCAD
                                and every other major CAD tool reads natively.

`csg_resolution` is still accepted for backward call-signature compatibility
with the frontend but is UNUSED by python_eval.py -- B-rep booleans are exact,
there's no facet/voxel resolution to tune.

There is deliberately no OpenSCAD-text-DSL mode, no OpenSCAD CLI dependency,
and no mesh import route in this app -- SanPyCAD-Brep only ever builds real
build123d/OCCT solids (see python_eval.py's module docstring for why).

Also serves anything under frontend/ by path (e.g. GET /vendor/<...> for
the locally-vendored CodeMirror/Three.js copies -- see vendor_assets.py)
via the plain static-file fallback at the bottom of do_GET, same as any
other frontend/ asset -- no separate route needed for that.
"""

import inspect
import json
import math
import os
import struct
import sys
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import vendor_assets
import python_eval as PE
import brep
import drawing_layout
from kernel_manager import MANAGER

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(os.path.dirname(BASE_DIR), "frontend")

# NOTE on concurrency/crash-safety: this used to be guarded here by a
# module-level _OCCT_LOCK wrapping every POST route, because OCCT (via
# build123d) is a C++ library with plenty of non-reentrant/non-thread-
# safe internal state, AND because a native segfault deep in OCCT would
# otherwise take the whole app down with it. Both of those are now
# handled by kernel_manager.py instead: every route that touches a
# build123d/brep.py shape actually runs inside a single dedicated child
# process (see kernel_process.py), so calls are naturally serialized
# there (one worker, one request at a time) and a segfault only kills
# that child, not this HTTP server -- MANAGER auto-restarts it. The
# thing a same-process lock here could NOT fix -- /reset_kernel being
# unable to do anything while a script was hung, since it used to sit
# behind this exact same lock -- is why this moved out of the server
# process at all; see kernel_manager.py's module docstring.
EXAMPLES_DIR = os.path.join(os.path.dirname(BASE_DIR), "examples")

MIME = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json",
    ".svg": "image/svg+xml",
}


_FUNCTION_DOCS_CACHE = None
_FUNCTION_ORIGIN_CACHE = None
_OPENSCAD4_DOCS_CACHE = None


def _doc_for(name, val):
    """`name(signature)` header (when introspectable) followed by the
    docstring, matching Jupyter's own Shift+Tab inspector. If a
    docstring already opens with its own hand-written `name(...)` line,
    it's left alone rather than getting a second, redundant signature
    line stuck above it. If there's no docstring at all, the signature
    alone is still shown -- better than nothing, same as Jupyter falls
    back to."""
    doc = inspect.getdoc(val) or ""
    try:
        sig = str(inspect.signature(val))
    except (TypeError, ValueError):
        sig = ""
    if doc:
        if sig and not doc.startswith(name + "("):
            return f"{name}{sig}\n{doc}"
        return doc
    if sig:
        return f"{name}{sig}\n(no docstring for this function -- signature only)"
    return ""


def python_function_docs():
    """{name: docstring} for every function python_eval.py's namespace
    exposes to a script -- all of it is brep.py (box()/cylinder()/
    union()/fillet()/etc), plus this app's own show()/color()/echo(),
    plus (best-effort) the sibling SanPyCAD app's openscad4.py toolkit,
    reachable via the opt-in `import openscad4` escape hatch (see
    python_eval.py's module docstring). Used for both editor
    autocomplete and the Shift+Tab doc popup -- computed once and
    cached, since none of this changes at runtime.

    Iterates PE.RESERVED_NAMES (not a separately hand-maintained list
    here) specifically so this can't silently drift out of sync with
    make_namespace() -- see the Shift+Tab bug this fixed, back when this
    app still had an openscad4.py mesh layer underneath brep.py's
    overlay and a stale hardcoded name tuple here missed several of
    brep.py's own names entirely."""
    global _FUNCTION_DOCS_CACHE, _FUNCTION_ORIGIN_CACHE, _OPENSCAD4_DOCS_CACHE
    if _FUNCTION_DOCS_CACHE is not None:
        return _FUNCTION_DOCS_CACHE
    docs = {}
    origins = {}
    openscad4_docs = {}
    # make_namespace() just builds closures (no script is executed), so
    # this is cheap and side-effect-free -- it's the only way to get at
    # these functions' docstrings since they're created fresh per-script
    # rather than defined at module level.
    ns, _shown_flag = PE.make_namespace(csg_resolution=56, scene=[], warnings=[], echo_log=[])
    for name in sorted(PE.RESERVED_NAMES):
        if name in ("np", "numpy", "brep"):
            continue  # not a function
        fn = ns.get(name)
        if fn is not None and callable(fn):
            docs[name] = _doc_for(name, fn)
            origins[name] = "library" if fn is getattr(brep, name, None) else "helper"
    docs.setdefault("np", "numpy, imported as np.")
    docs.setdefault("numpy", "The numpy module.")
    origins.setdefault("np", "external")
    origins.setdefault("numpy", "external")

    # Opt-in mesh escape hatch: a script may `import openscad4 as o4`
    # and call e.g. o4.two_solids_intersection(...) -- surface those
    # functions' docs here too, so Shift+Tab/autocomplete/the Reference
    # panel find them under their bare name (wordAtCursor() in the
    # frontend splits on '.', so `o4.two_tri_intersection(|)` looks up
    # "two_tri_intersection" the same as a plain top-level call would).
    # Best-effort: python_eval.py's sys.path hook only adds the sibling
    # SanPyCAD app's backend/ if that app is actually installed
    # alongside this one, and openscad4.py itself needs scipy -- either
    # missing piece just means this section quietly contributes nothing.
    try:
        import openscad4 as _o4
    except Exception:
        _o4 = None
    if _o4 is not None:
        for name in dir(_o4):
            if name.startswith("_"):
                continue
            val = getattr(_o4, name)
            if not inspect.isfunction(val) or getattr(val, "__module__", None) != "openscad4":
                continue  # skip classes/constants and anything openscad4.py
                          # itself pulled in via `from numpy import *` etc --
                          # only openscad4.py's OWN functions, please
            doc = _doc_for(name, val)
            if not doc:
                continue
            annotated = (
                f"[openscad4 -- needs `import openscad4 as o4` first; "
                f"call as o4.{name}(...)]\n\n" + doc
            )
            # Always recorded here, EVEN when a brep.py/helper name of the
            # same spelling already claimed `docs`/`origins` below -- this
            # is the complete list of every name valid after "o4.", used
            # by the frontend's Tab-completion/Shift+Tab for that qualified
            # context specifically (see wordHint()'s afterOpenscad4Alias
            # branch). Without this separate dict, a name that exists in
            # BOTH places (sphere/circle/seg/flip/contiguous_chains as of
            # this writing) -- a real, working o4.sphere(20) call -- simply
            # never showed up as a completion after typing "o4." at all,
            # since it'd already lost the "openscad4" origin slot below to
            # brep.py's own sphere().
            openscad4_docs[name] = annotated
            if name in docs:
                continue  # bare unqualified docs/origins: brep.py/helper
                          # name of the same spelling always wins there --
                          # that's what an unqualified call resolves to
            docs[name] = annotated
            origins[name] = "openscad4"

    _FUNCTION_DOCS_CACHE = docs
    _FUNCTION_ORIGIN_CACHE = origins
    _OPENSCAD4_DOCS_CACHE = openscad4_docs
    return docs


def python_function_origins():
    """{name: "library"|"helper"|"external"} matching python_function_docs()
    one-for-one -- "library" is a real brep.py function, "helper" is one
    of this app's own Python-mode injections (show()/color()/echo()),
    "external" is np/numpy. Computed as a side effect of
    python_function_docs(), so this just makes sure that's run first."""
    python_function_docs()
    return _FUNCTION_ORIGIN_CACHE


def python_function_openscad4_docs():
    """{name: doc} -- EVERY real openscad4.py function reachable via the
    opt-in `import openscad4 as o4` bridge, keyed by its bare name,
    including ones that also exist natively in brep.py (sphere/circle/
    seg/flip/contiguous_chains as of this writing) and so lost the
    "openscad4" origin slot in python_function_docs()/
    python_function_origins() to the brep.py version. Those names are
    still perfectly valid written as o4.sphere(...) etc -- this is what
    lets the frontend offer them as Tab-completions/Shift+Tab docs
    specifically in that qualified context, see wordHint()'s
    afterOpenscad4Alias branch. Computed as a side effect of
    python_function_docs(), so this just makes sure that's run first."""
    python_function_docs()
    return _OPENSCAD4_DOCS_CACHE


def python_function_names():
    """Sorted list of names from python_function_docs(), for callers that
    only need the names (e.g. editor autocomplete's word list)."""
    return sorted(python_function_docs())


def run_any(code, csg_resolution, persist=True):
    """Thin pass-through -- kept as its own function (rather than calling
    MANAGER.call("render", ...) directly at every call site) purely so a
    future second scripting mode has one obvious place to add a dispatch
    branch, the same role this played back when this app also had an
    OpenSCAD-text-DSL mode.

    Used to call PE.run_python_script(...) directly, in this same
    process. Now delegates to the kernel worker process instead (see
    kernel_manager.py/kernel_process.py) -- the return contract is
    unchanged (a JSON-safe result dict, plus a second element every
    caller in this file already ignores as `_scene`), so nothing else
    in server.py -- or app.py's Api.export_file(), the other caller --
    needed to change."""
    result = MANAGER.call("render", {
        "code": code, "csg_resolution": csg_resolution, "persist": persist,
    })
    return result, None


def generate_drawing_svg(code, csg_resolution, part_name=None, author=None):
    """Runs `code` fresh via the kernel's "drawing" op (NOT "render" --
    see kernel_process.py's own _drawing() docstring for why this needs
    its own op: it's the one place the real, live B-rep Shape objects a
    script show()s are still reachable, which real hidden-line-removal
    needs and the plain triangle-mesh JSON build_svg_text() works from
    does not), then lays the resulting per-view polyline data out onto
    one drawing sheet with drawing_layout.build_sheet_svg().

    Returns (svg_bytes, error) -- exactly one of the two is None, same
    convention as this file's other run_*()-style helpers returning a
    result dict with result["error"] set or not.

    Shared by the POST /drawing route below and app.py's Api.export_file
    (the native-window Save-dialog path -- see that file's own kind ==
    "svg"/"drawing" handling) so there's exactly one place this ever
    gets built, not two copies to keep in sync."""
    reply = MANAGER.call("drawing", {"code": code, "csg_resolution": csg_resolution})
    if reply.get("error"):
        return None, reply["error"]
    views = reply.get("views", {})
    svg_bytes = drawing_layout.build_sheet_svg(views, part_name=part_name or "Part", author=author)
    return svg_bytes, None


def generate_drawing_layout(code, csg_resolution, part_name=None, author=None):
    """Same kernel round-trip as generate_drawing_svg() above (identical
    HLR computation -- this is NOT a second, different drawing, just a
    different last step), but returns plain JSON layout data instead of
    a flat SVG: drawing_layout.layout_for_frontend()'s
    {labels, views, quadrants, sheet, title} dict, straight off
    /drawing_data for index.html's own interactive 2D Drawing tab to
    draw and let a user add real-unit dimensions to (see that module's
    own docstring for why the browser needs the transform NUMBERS
    rather than an already-flattened image).

    Returns (layout_dict, error) -- exactly one of the two is None,
    same convention as generate_drawing_svg()."""
    reply = MANAGER.call("drawing", {"code": code, "csg_resolution": csg_resolution})
    if reply.get("error"):
        return None, reply["error"]
    views = reply.get("views", {})
    layout = drawing_layout.layout_for_frontend(views, part_name=part_name or "Part", author=author)
    return layout, None


def build_stl_binary(meshes):
    """Concatenate all (visible) meshes into one binary STL blob."""
    tri_count = sum(len(m.F) for m in meshes)
    buf = bytearray()
    buf += b"\x00" * 80
    buf += struct.pack("<I", tri_count)
    for m in meshes:
        V, F = m.V, m.F
        if len(F) == 0:
            continue
        p0 = V[F[:, 0]]
        p1 = V[F[:, 1]]
        p2 = V[F[:, 2]]
        normals = np.cross(p1 - p0, p2 - p0)
        norm_len = np.linalg.norm(normals, axis=1, keepdims=True)
        norm_len[norm_len == 0] = 1.0
        normals = normals / norm_len
        for n, a, b, c in zip(normals, p0, p1, p2):
            buf += struct.pack("<3f", *n)
            buf += struct.pack("<3f", *a)
            buf += struct.pack("<3f", *b)
            buf += struct.pack("<3f", *c)
            buf += struct.pack("<H", 0)
    return bytes(buf)


def build_obj_text(meshes):
    """Concatenate all (visible) meshes into one Wavefront OBJ text blob,
    one `o` group per mesh, 1-indexed faces with a running vertex offset
    (OBJ indices are global across the whole file, not per-object)."""
    lines = ["# Exported from SanPyCAD Brep"]
    vertex_offset = 0
    for i, m in enumerate(meshes):
        V, F = m.V, m.F
        if len(F) == 0:
            continue
        lines.append(f"o object{i + 1}")
        for v in V:
            lines.append(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}")
        for tri in F:
            a = int(tri[0]) + 1 + vertex_offset
            b = int(tri[1]) + 1 + vertex_offset
            c = int(tri[2]) + 1 + vertex_offset
            lines.append(f"f {a} {b} {c}")
        vertex_offset += len(V)
    return ("\n".join(lines) + "\n").encode("utf-8")


def build_svg_text(meshes):
    """A 2D isometric wireframe projection of every mesh's edges, as an SVG
    line drawing. This is deliberately NOT the same thing as OpenSCAD's own
    SVG export, which only works on genuinely flat 2D shapes (the output of
    projection()) -- since most scripts here build real 3D solids, an SVG
    export that only worked on 2D shapes would be useless for almost every
    model. A wireframe projection works for anything."""
    COS30 = math.cos(math.radians(30))
    SIN30 = math.sin(math.radians(30))

    def project(v):
        x, y, z = float(v[0]), float(v[1]), float(v[2])
        return (x - y) * COS30, (x + y) * SIN30 - z

    segments = []  # (p1, p2, "#rrggbb")
    for m in meshes:
        V, F = m.V, m.F
        if len(F) == 0:
            continue
        color = getattr(m, "color", None) or (0.6, 0.6, 0.65)
        hexcolor = "#%02x%02x%02x" % tuple(
            min(255, max(0, int(round(c * 255)))) for c in list(color)[:3]
        )
        edges = set()
        for tri in F:
            a, b, c = int(tri[0]), int(tri[1]), int(tri[2])
            for p, q in ((a, b), (b, c), (c, a)):
                edges.add((min(p, q), max(p, q)))
        for a, b in edges:
            segments.append((project(V[a]), project(V[b]), hexcolor))

    if not segments:
        return b'<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"></svg>\n'

    xs = [pt[0] for seg in segments for pt in seg[:2]]
    ys = [pt[1] for seg in segments for pt in seg[:2]]
    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)
    span = max(max_x - min_x, max_y - min_y, 1.0)
    pad = max(1.0, 0.05 * span)
    width = (max_x - min_x) + 2 * pad
    height = (max_y - min_y) + 2 * pad
    stroke_w = max(0.4, width / 500)

    def to_svg_xy(pt):
        x = pt[0] - min_x + pad
        y = height - (pt[1] - min_y + pad)  # SVG's y grows downward
        return x, y

    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width:.3f} {height:.3f}" '
        f'width="{width:.1f}" height="{height:.1f}">',
        "<!-- Exported from SanPyCAD Brep: isometric wireframe projection -->",
        f'<rect x="0" y="0" width="{width:.3f}" height="{height:.3f}" fill="white"/>',
    ]
    for p1, p2, color in segments:
        x1, y1 = to_svg_xy(p1)
        x2, y2 = to_svg_xy(p2)
        parts.append(
            f'<line x1="{x1:.3f}" y1="{y1:.3f}" x2="{x2:.3f}" y2="{y2:.3f}" '
            f'stroke="{color}" stroke-width="{stroke_w:.3f}" stroke-linecap="round"/>'
        )
    parts.append("</svg>")
    return ("\n".join(parts) + "\n").encode("utf-8")


def build_dxf_text(meshes):
    """Minimal ASCII DXF (R12), one 3DFACE entity per triangle, full 3D
    coordinates preserved. This is what the UI's "DWG" export option
    actually writes -- true .dwg is AutoCAD's proprietary binary format
    and needs a paid SDK (Teigha/ODA) to produce; DXF is the open,
    royalty-free interchange format that AutoCAD (and every other major
    CAD/BIM tool) reads natively, so it covers the same "get this into
    AutoCAD" goal without a fake or broken .dwg file."""
    lines = ["0", "SECTION", "2", "ENTITIES"]
    for i, m in enumerate(meshes):
        V, F = m.V, m.F
        layer = f"object{i + 1}"
        for tri in F:
            p0, p1, p2 = V[int(tri[0])], V[int(tri[1])], V[int(tri[2])]
            lines += ["0", "3DFACE", "8", layer]
            # 3DFACE takes 4 corners; repeating the 3rd point as the 4th
            # is the standard way to represent a triangle with it.
            for gx, gy, gz, pt in (
                (10, 20, 30, p0), (11, 21, 31, p1), (12, 22, 32, p2), (13, 23, 33, p2)
            ):
                lines += [str(gx), f"{pt[0]:.6f}", str(gy), f"{pt[1]:.6f}", str(gz), f"{pt[2]:.6f}"]
    lines += ["0", "ENDSEC", "0", "EOF"]
    return ("\n".join(lines) + "\n").encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    server_version = "OpenSCADLikeServer/1.0"

    def log_message(self, fmt, *args):
        pass  # keep console quiet; errors are still printed explicitly

    # -- helpers ----------------------------------------------------------
    def _send_json(self, obj, status=200):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _send_bytes(self, data, content_type, status=200, filename=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        if filename:
            self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)

    def _send_file(self, path):
        if not os.path.isfile(path):
            self._send_json({"error": "not found"}, 404)
            return
        ext = os.path.splitext(path)[1]
        with open(path, "rb") as f:
            data = f.read()
        self._send_bytes(data, MIME.get(ext, "application/octet-stream"))

    def _read_json_body(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw or b"{}")

    # -- routes -------------------------------------------------------
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path == "/":
            self._send_file(os.path.join(FRONTEND_DIR, "index.html"))
        elif path == "/status":
            self._send_json({"build123d": brep._HAVE_BUILD123D})
        elif path == "/examples":
            items = []
            if os.path.isdir(EXAMPLES_DIR):
                for fname in sorted(os.listdir(EXAMPLES_DIR)):
                    if fname.endswith(".py"):
                        items.append(fname)
            self._send_json({"examples": items})
        elif path == "/functions":
            docs = python_function_docs()
            origins = python_function_origins()
            o4_docs = python_function_openscad4_docs()
            self._send_json({"functions": [
                {"name": n, "doc": docs[n], "origin": origins.get(n, "library")}
                for n in sorted(docs)
            ], "openscad4_functions": [
                {"name": n, "doc": o4_docs[n]} for n in sorted(o4_docs)
            ]})
        elif path == "/kernel_status":
            # Was PE.persisted_variable_names() -- read directly out of
            # python_eval.py's module-level dict in THIS process. That
            # dict no longer holds the real data; the actual persisted
            # variables live inside the kernel worker process now (see
            # kernel_manager.py), so this has to ask it instead.
            reply = MANAGER.call("kernel_status", {})
            self._send_json({"persisted_vars": reply.get("persisted_vars", [])})
        elif path.startswith("/examples/"):
            fname = os.path.basename(path[len("/examples/"):])
            fpath = os.path.join(EXAMPLES_DIR, fname)
            if os.path.isfile(fpath):
                with open(fpath, "r", encoding="utf-8") as f:
                    self._send_json({"name": fname, "code": f.read()})
            else:
                self._send_json({"error": "not found"}, 404)
        else:
            candidate = os.path.join(FRONTEND_DIR, path.lstrip("/"))
            if os.path.isfile(candidate):
                self._send_file(candidate)
            else:
                self._send_json({"error": "not found"}, 404)

    def do_POST(self):
        # No lock here anymore -- see the module-level comment above
        # EXAMPLES_DIR for why. In particular, /reset_kernel below is
        # NOT allowed to be blocked by a concurrent, possibly-hung
        # /render (that's the exact bug this file's kernel_manager.py
        # migration fixed), so this method must never wrap the whole
        # dispatch in anything that a stuck request could be holding.
        self._do_post()

    def _do_post(self):
        path = self.path.split("?", 1)[0]
        try:
            body = self._read_json_body()
        except Exception:
            self._send_json({"error": "invalid JSON body"}, 400)
            return

        code = body.get("code", "")
        csg_resolution = int(body.get("csg_resolution", 56))
        csg_resolution = max(16, min(csg_resolution, 160))
        persist = bool(body.get("persist", True))

        if path == "/reset_kernel":
            # Was PE.reset_kernel() -- clearing python_eval.py's
            # module-level dict IN THIS PROCESS. That did nothing to
            # actually stop a script that was still running (there was
            # no way to; the exec() call and this reset both ran on
            # threads inside the same process/GIL, and if the stuck
            # thread was blocked inside a C extension like OCCT, it
            # wasn't even yielding the GIL back for this to run on).
            # MANAGER.restart() instead kills the worker's real OS
            # process outright -- that works unconditionally, hung or
            # not -- and starts a fresh one for the next Render.
            n = MANAGER.restart()
            self._send_json({"cleared": n, "persisted_vars": []})
            return

        if path == "/probe_pick":
            # The actual edge/face lookup now runs inside the kernel
            # worker process (see kernel_process.py's _probe_pick,
            # moved there verbatim) -- the shape being probed only
            # exists as a live build123d object in THAT process now,
            # not this one. The one check that doesn't need the worker
            # at all (an empty variable name) stays here so it's a
            # zero-latency 400, same as before.
            var_name = body.get("variable", "")
            if not var_name:
                self._send_json({"error": "no shape variable given"}, 400)
                return
            reply = MANAGER.call("probe_pick", {
                "variable": var_name,
                "kind": body.get("kind", "edges"),
                "mode": body.get("mode", "inside"),
                "center": body.get("center"),
                "size": body.get("size"),
                "point": body.get("point"),
            })
            status = reply.pop("_status", 200)
            self._send_json(reply, status)
            return

        if path == "/probe_max_fillet":
            var_name = body.get("variable", "")
            indices = body.get("indices", [])
            if not var_name or not indices:
                # Nothing captured yet (or no variable typed) isn't an
                # error condition here -- same "quiet 0" the docstring
                # above promises, not a 400, since the Pick panel calls
                # this on every list change and an empty list is the
                # normal starting state, not a mistake. No need to
                # bother the kernel worker for this one.
                self._send_json({"radii": []})
                return
            reply = MANAGER.call("probe_max_fillet", {
                "variable": var_name, "indices": indices,
            })
            self._send_json(reply)
            return

        if path == "/probe_highlight":
            var_name = body.get("variable", "")
            indices = body.get("indices", [])
            if not var_name or not indices:
                self._send_json({"curves": []})
                return
            reply = MANAGER.call("probe_highlight", {
                "variable": var_name, "indices": indices,
                "kind": body.get("kind", "edges"),
            })
            self._send_json(reply)
            return

        if path == "/render":
            result, _scene = run_any(code, csg_resolution, persist=persist)
            self._send_json(result)
            return

        if path == "/export/stl":
            result, _scene = run_any(code, csg_resolution)
            if result["error"]:
                self._send_json(result, 400)
                return
            meshes = list(ev_meshes_from_result(result))
            if not meshes:
                self._send_json({"error": "nothing to export (empty scene)"}, 400)
                return
            stl = build_stl_binary(meshes)
            self._send_bytes(stl, "model/stl", filename="model.stl")
            return

        if path == "/export/obj":
            result, _scene = run_any(code, csg_resolution)
            if result["error"]:
                self._send_json(result, 400)
                return
            meshes = list(ev_meshes_from_result(result))
            if not meshes:
                self._send_json({"error": "nothing to export (empty scene)"}, 400)
                return
            obj = build_obj_text(meshes)
            self._send_bytes(obj, "text/plain; charset=utf-8", filename="model.obj")
            return

        if path == "/export/svg":
            # A real multi-view, hidden-line-removed engineering drawing
            # (see generate_drawing_svg()/drawing_layout.py) -- NOT the
            # single naive isometric wireframe this route used to build
            # from plain triangle-mesh JSON via build_svg_text(). That
            # function is left defined below, unused by any route now,
            # rather than deleted -- a plain mesh-edge wireframe (no
            # OCCT/HLR needed, works even on a raw openscad4-bridge mesh
            # with no real B-rep shape at all) is still a reasonable
            # thing to want back as a route someday, and this keeps that
            # option cheap to restore instead of rewriting it from
            # scratch.
            svg, error = generate_drawing_svg(code, csg_resolution)
            if error:
                self._send_json({"error": error}, 400)
                return
            self._send_bytes(svg, "image/svg+xml", filename="model.svg")
            return

        if path == "/drawing":
            # Same output as /export/svg above (both are
            # generate_drawing_svg()) -- kept as a separate route/toolbar
            # button rather than folding it into Export so generating a
            # drawing sheet doesn't require opening the Export dropdown
            # and knowing "svg" is where it lives now.
            part_name = body.get("part_name") or None
            svg, error = generate_drawing_svg(code, csg_resolution, part_name=part_name)
            if error:
                self._send_json({"error": error}, 400)
                return
            self._send_bytes(svg, "image/svg+xml", filename="drawing.svg")
            return

        if path == "/drawing_data":
            # Same HLR computation as /drawing above, but returns plain
            # JSON layout data instead of a flat SVG file -- what the
            # toolbar's "Drawing" button now opens INTO (the interactive
            # 2D Drawing tab in index.html) rather than downloading
            # directly. See generate_drawing_layout()/drawing_layout.py's
            # layout_for_frontend() for exactly what's in the response
            # and why the browser needs transform numbers rather than an
            # already-flattened image: it lets you click points/circles/
            # edges on the views to add real-unit dimensions (linear,
            # radius/diameter, angle, center-distance) before downloading
            # a dimensioned SVG -- something a flat image can't support.
            part_name = body.get("part_name") or None
            layout, error = generate_drawing_layout(code, csg_resolution, part_name=part_name)
            if error:
                self._send_json({"error": error}, 400)
                return
            self._send_json(layout)
            return

        if path == "/export/dxf":
            result, _scene = run_any(code, csg_resolution)
            if result["error"]:
                self._send_json(result, 400)
                return
            meshes = list(ev_meshes_from_result(result))
            if not meshes:
                self._send_json({"error": "nothing to export (empty scene)"}, 400)
                return
            dxf = build_dxf_text(meshes)
            self._send_bytes(dxf, "application/dxf", filename="model.dxf")
            return

        self._send_json({"error": "not found"}, 404)


class _SimpleMesh:
    __slots__ = ("V", "F")

    def __init__(self, V, F):
        self.V = np.array(V, dtype=float)
        self.F = np.array(F, dtype=int)


def ev_meshes_from_result(result):
    for m in result["meshes"]:
        yield _SimpleMesh(m["vertices"], m["faces"])


def serve(host="127.0.0.1", port=0):
    httpd = ThreadingHTTPServer((host, port), Handler)
    actual_port = httpd.server_address[1]
    return httpd, actual_port


def print_backend_status():
    if brep._HAVE_BUILD123D:
        print("[SanPyCAD Brep] build123d is installed -- ready to build real B-rep solids.")
    else:
        print("[SanPyCAD Brep] build123d is NOT installed -- every script will fail until "
              "you install it: pip install build123d")

    still_missing = vendor_assets.missing_assets()
    if still_missing:
        # Kick off (or retry) downloading the editor/3D-viewer assets this
        # app needs, in the background -- the app is fully usable right
        # away either way (index.html falls back to the CDN for anything
        # not yet vendored), this just means one more launch with internet
        # access is enough to make every future launch fully offline.
        def _done(remaining):
            if not remaining:
                print("[SanPyCAD Brep] all editor/3D-viewer assets are now stored locally -- "
                      "SanPyCAD Brep can run fully offline from now on.")
            else:
                print(f"[SanPyCAD Brep] {len(remaining)} asset(s) still not available locally "
                      "(no internet access?) -- SanPyCAD Brep will keep loading those from the "
                      "CDN for now and retry on the next launch.")
        print(f"[SanPyCAD Brep] fetching {len(still_missing)} editor/3D-viewer asset(s) in the "
              "background so SanPyCAD Brep can run offline from now on...")
        vendor_assets.ensure_vendor_assets_async(on_done=_done)
    else:
        print("[SanPyCAD Brep] editor/3D-viewer assets are all stored locally -- SanPyCAD Brep can run fully offline.")


if __name__ == "__main__":
    print_backend_status()
    MANAGER.start()  # see kernel_manager.py -- safe here (behind this
                      # module's own __main__ guard), not at import time
    httpd, port = serve(port=8743)
    print(f"OpenSCAD-like server running at http://127.0.0.1:{port}/")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
