#!/bin/bash
# Double-click this if macOS says SanPyCAD-2D.app "can't be opened because
# it is from an unidentified developer" -- clears the quarantine flag Gatekeeper
# puts on anything downloaded/extracted from the internet, since this app
# isn't notarized/signed by an Apple Developer ID.
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
xattr -dr com.apple.quarantine "$DIR/SanPyCAD-2D.app" 2>/dev/null
xattr -dr com.apple.quarantine "$DIR" 2>/dev/null
echo "Done. You can now double-click SanPyCAD-2D.app to open it."
read -p "Press Return to close this window..."
