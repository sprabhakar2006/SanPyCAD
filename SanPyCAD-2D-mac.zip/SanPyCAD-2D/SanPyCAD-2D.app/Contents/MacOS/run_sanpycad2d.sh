#!/bin/bash
# Launches SanPyCAD 2D Sketch from inside the .app bundle.
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
cd "$DIR"
PYTHON_BIN="$(command -v python3 || true)"
if [ -z "$PYTHON_BIN" ]; then
  osascript -e 'display alert "Python 3 not found" message "Install Python 3 (python.org or brew install python3) and try again."'
  exit 1
fi
osascript -e 'tell application "Terminal" to do script "cd '"'"'$DIR'"'"' && '"'"'$PYTHON_BIN'"'"' app.py"'
